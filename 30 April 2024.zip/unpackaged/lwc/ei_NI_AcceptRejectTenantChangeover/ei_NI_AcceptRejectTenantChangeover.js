import { LightningElement, track, wire, api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { loadStyle } from 'lightning/platformResourceLoader';
import { loadScript } from 'lightning/platformResourceLoader';

import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

import getDepositDetailsForChangeoverByAgent from '@salesforce/apex/EI_NI_EWC_ChangeoverApex.getDepositDetailsForChangeoverByAgent';
import rejectChangeoverByTenant from '@salesforce/apex/EI_NI_EWC_ChangeoverApex.rejectChangeoverByTenant';
import approveChangeoverByTenant from '@salesforce/apex/EI_NI_EWC_ChangeoverApex.approveChangeoverByTenant';

export default class Ei_NI_AcceptRejectTenantChangeover extends NavigationMixin (LightningElement) {

    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    addBtnImg = NI_Theme + '/assets/img/add-new-property_blue.png';
    poundImg = NI_Theme + '/assets/img/pound_icon.png';
    thankYouImg = NI_Theme + '/assets/img/thank-you.png';

    

    @track depositIddeptenantlist;
    @track depositlist;
    @track depositamount;
    loggedinTenant = '';
    tenantChange = false;
    isnewDeposit = false;
    @track selectedtenantids;
    @track updatechangeovertenant;
    isNotnewDeposit = true;
    // JS attributes START
    depositRecId;
    @track olddepositid;
    //newdepositstartdate;
    startdatebox = false;
    @track disabledBtn = true;
    @track isValidMaxTenants = false;
    @track amountCantBeLessThan1Error = false;
    @track tenantChangeOver = true;
    @track startOfTenancyDate;

    duplicateEmailPhoneCheck= false;

    // Show and hide section Attributes
    showChangeoverScreen = true;
    isTenantDetailDisplay = false;
    isShowTenantSection = true;
    isTenantYesNo = false;
    isTenantSuccessMsg = false;
    isTenantFillForm = false;
    isShowPageSpinner = false;
    disableSubmit = false;
    // Show and hide section Attributes

    // Thank you section attributes START
    isShowThankyouPage = false;
    isChangeoverAccepted = false;
    isChangeoverRejected = false;
    thankyousuccessMsg = false;
    isInitiateTenantChangeover = false;
    isCancelTenantChangeover = false;
    isAcceptTenantChangeover = false;
    isRejectTenantChangeover = false;
    // Thank you section attributes END

    // Section attributes START
    showTenantChangeover = true; 
    isSummarySection = true;
    isDepositDetailDisplay = false;
    isAddMoreTenantDisplay = false;
    // Section attributes END

    // New attributes START
    depositWrapper;
    userType = '';
    depositTenantsList = [];
    depositAllocList = [];
    changeoverInitiatedBy = '';
    loggedInTenantName = '';
    niDanNumber = '';
    totalChangeoverAmount = 0;
    caseId = '';
    
    totalExistingTenants = 0;
    totalTenantsMovingOut = 0;
    startdatecheck = false;
    newtenantnumber;
    newdepositamount;
    newdepositstartdate;
    screenThirdSaveBtnName = 'Submit';
    // New attributes END

    // Attributes for child component START
    @track tenantItemList = [];
    @track childTenantData = [];
    isTenantSaveError = false;
    numberOfTenants = 0;   // in use to transfer data to child component
    isRelevantPresent = false;

    @api totalTenants;
    @api currentTenant;
    @api currentTenantData = {};
    @api defaultTenantData = [];
    @api relevantPerson = {};
    @api showTenantNumberDetails;
    @api tenantassociatedYesOrNoValue;
    // Attributes for child component END

    // Attributes for Bank Details child component
    bankDetailObject = [];
	showBankDetailSection = false;
    showAddBankDetailBtn = false;
    showEditBankDetailBtn = false;
    isBankDetailsPresent = false;

    @wire(CurrentPageReference) currentPageReference;

    connectedCallback() {
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = atob(depositRecId);
        // this.depositRecId = depositRecId;
        console.log('Line 163 depositRecId -> ' +this.depositRecId);
        
        Promise.all([
            // Server call to get the sign up wrapper list from apex
            getDepositDetailsForChangeoverByAgent({
                depositId:this.depositRecId, 
                scheme:'NI Custodial'
            })
            .then(result => {
                // this.deptenantlist = result;
                // console.log('list of deposit',this.deptenantlist[0].Depallobject);
                // this.olddepositid = this.depositRecId;
                // this.depositlist = result[0];
                // this.depositamount = this.depositlist.Depositobject.Protected_Amount__c

                if(result.length>0) {
                    this.depositWrapper = result[0];
                    console.log('Line 222 - '+JSON.stringify(this.depositWrapper));
                    this.loggedInTenantName = this.depositWrapper.userRec.Name;
                    this.userType = this.depositWrapper.userRec.Profile.Name;
                    console.log('Line 226 - '+JSON.stringify(this.depositWrapper.depAllocList));
                    this.totalChangeoverAmount = parseFloat(this.depositWrapper.depositRec.Change_Overamount_Sum__c.toFixed(2));
                    this.niDanNumber = this.depositWrapper.depositRec.NI_Deposit_Number__c;
                    this.caseId = this.depositWrapper.depCaseList[0].Id;

                    let totalTenantsMovingOut = 0;
                    this.depositWrapper.depAllocList.forEach(depAlloc => {
                        let tenant = {};

                        if(depAlloc.Istenantmoved__c) {
                            tenant.depositAllocId = depAlloc.Id;
                            tenant.tenantId = depAlloc.Deposit_Holder__c;
                            tenant.tenantName = depAlloc.Deposit_Holder__r.Name;
                            tenant.changeoverAmount = depAlloc.Tenencychangeoveramount__c;
                            tenant.isTenantMoved = depAlloc.Istenantmoved__c;

                            totalTenantsMovingOut++;
                        }

                        this.depositTenantsList.push(tenant);
                    });

                    this.totalExistingTenants = this.depositTenantsList.length;
                    this.totalTenantsMovingOut = totalTenantsMovingOut;

                    if(this.depositWrapper.acctBankDetailsRec.length>0) {
                        if(this.depositWrapper.acctBankDetailsRec[0].ValidInternationBankDetails__c == false && 
                            this.depositWrapper.acctBankDetailsRec[0].IBAN__c== undefined) 
                        {
                            console.log('bank details not found');
                            this.showAddBankDetailBtn = true;
                            this.isBankDetailsPresent = false;
                        }
                        else 
                        {
                            console.log('bank details found');
                            this.showEditBankDetailBtn = true;
                            this.isBankDetailsPresent = true;
                        }

                        // Setting bank detail values 
                        this.bankDetailObject = this.depositWrapper.acctBankDetailsRec;
                    }

                    console.log('Line 246 - '+JSON.stringify(this.depositTenantsList));
                }
            })
            .catch(error => {
                console.log('Line 672 Error -> ', error);
            }),

            loadStyle(this, `${NI_Theme}/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js')
        ])
        .then(() => {
            console.log('Files loaded');
        })
        .catch(error => {
            console.log('Error in loading script -> '+error.body.message);
        });

    }

    // For handling event from child component
    handleSaveBankDetails(event) {
        console.log('Line 123 bank detail event -> '+JSON.stringify(event.detail));
        let returnedData = event.detail;

        if(returnedData.isValid) {
            this.isBankDetailsPresent = true;
            this.showAddBankDetailBtn = false;
            this.showAddBankDetailInRedBtn = false;
            this.showEditBankDetailBtn = true;
        }
        
    }
	
	handleBankDetailBtn(event) {
        event.preventDefault();

        this.showBankDetailSection = true;
        // Firing an event from Parent to Child relevant person component START
        console.log(`Line 311 Parent call - ${this.userType} - ${this.bankDetailObject.length} - ${JSON.stringify(this.bankDetailObject)}`);
        this.template.querySelector('c-ei_-n-i_-bank-detail-for-agll-tenant').sendDetailsToChild(this.bankDetailObject, this.userType);
        // Firing an event from Parent to Child relevant person component END
    }
    
    handleAccecptButton(event) {
        event.preventDefault();

        this.isShowPageSpinner = true;
        console.log('Line 233 -> '+this.isBankDetailsPresent+' -> '+this.caseId);

        if(!this.disableSubmit) {
            if(this.isBankDetailsPresent) {
                this.disableSubmit = true;
                approveChangeoverByTenant({
                    caseId : this.caseId,
                    scheme : 'NI Custodial'
                })
                .then(result => {
                    console.log('Line 257 -> '+result);
                    if(result=='Success') {
                        this.showChangeoverScreen = false;
                        this.isShowThankyouPage = true;
                        this.isChangeoverAccepted = true;
                    }
                    this.disableSubmit = false;
                    this.isShowPageSpinner = false;
                })
                .catch(error => {
                    console.log('Error -> '+JSON.stringify(error));
                    this.disableSubmit = false;
                    this.isShowPageSpinner = false;
                })
            }
            else {
                this.showAddBankDetailBtn = false;
                this.showEditBankDetailBtn = false;
                this.showAddBankDetailInRedBtn = true;

                this.isShowPageSpinner = false;
            }
        }
        console.log('Line 256 ');

    }

    handleRejectButton(event){
        event.preventDefault();

        this.isShowPageSpinner = true;
        if(!this.disableSubmit) {
            this.disableSubmit = true;
            rejectChangeoverByTenant({
                depositId : this.depositRecId,
                caseId : this.caseId,
                scheme : 'NI Custodial'
            })
            .then(result => {
                console.log('Line 257 -> '+result);
                if(result=='Success') {
                    this.showChangeoverScreen = false;
                    this.isShowThankyouPage = true;
                    this.isChangeoverRejected = true;
                }
                this.disableSubmit = false;
                this.isShowPageSpinner = false;
            })
            .catch(error => {
                console.log('Error -> ',error);
                this.disableSubmit = false;
                this.isShowPageSpinner = false;
            })
        }

    }

    // Handle go back to the Deposit summary page
    goBackToDepositSummary() {
        var encodedDepositId = btoa(this.depositRecId);

        this[NavigationMixin.Navigate]({
            type: 'standard__namedPage',
            attributes: {
                pageName: 'deposit-summary',
            },
            state: {
                c__depositRecId: encodedDepositId
            },
        })
    }

}