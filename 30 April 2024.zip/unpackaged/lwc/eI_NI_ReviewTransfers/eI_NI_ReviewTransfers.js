import { LightningElement,track,wire,api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import processRejectDeposit from '@salesforce/apex/EI_NI_TransferDeposit.processRejectDeposit';
import checkDepositAllocationMultipleTenantName from '@salesforce/apex/EI_NI_TransferDeposit.checkDepositAllocationMultipleTenantName';
import getDepositInformationTransferred from '@salesforce/apex/EI_NI_TransferDeposit.getDepositInformationTransferred';
import processMultipleAcceptDeposit from '@salesforce/apex/EI_NI_TransferDeposit.processMultipleAcceptDeposit';
import fetchCurrenUserWrapper from '@salesforce/apex/EI_NI_TransferDeposit.fetchCurrenUserWrapper';
import { NavigationMixin } from 'lightning/navigation';

export default class EI_NI_ReviewTransfers extends NavigationMixin(LightningElement) {
    successImage = NI_Theme + '/assets/img/thank-you.png';
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';

    @track TransferedDepositsList = [];
    @track TotalDeposits;
    @track currentPage=1;
    @track totalPagesCount=1;
    @track pageSize=4;
    @track PageSpinner = false;
    @api PaginationPropList = [];
    @track selectAllChecked = false;
    @track selectedRecords = [];
    @track listOfAllDeposits = [];
    @track selectedDepositIds = [];
    @track deposits = [];
    @track depositInfo = {};
    @track selectedCount = 0;
    @track resMessage;
    isCasePresentMsg = false;
    isRequestedDepositSection = true;
    isSuccessScreen = false;
    isAcceptingMsg = false;
    isRejectionMsg = false;
    isTenantvalueBlankErrorMsg = false;
    isunableErrorMsg = false;
   
    @track errors;
    @track tenantNames = '';

    enterTenantName = false;
    isStartPage = true;
    isEndPage = true;
    isEndPageNav = false;
    isStartPageNav = false;
    isStartPage = true;
    isEndPage = true;
    
    enterTenantNameMultiple = false;
    depositslength1 = false;
    @track totalRecordsCountPropList;
    @track isNoDepositsSelected = false;

    @track currentAttempt = 3;
    @track isTenantNameErrorMsg = false;
    @track isTenantNameErrorMsg1 = false;
    @track isTenantMaxAttemptsErrorMsg = false;
    @track disableSumbit = false;

    @track userBranchWrapper;
    @track currentUser;
    @track currentUserBranches = [];
    branchId ;
    showTransferToBranch = false;

    connectedCallback(){
        Promise.all([
            loadStyle(this, NI_Theme  + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme  + '/assets/js/plugin.min.js'),
            // loadScript(this, NI_Theme  + '/assets/js/custom.js'),
            // loadScript(this,NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            // loadScript(this,NI_Theme + '/assets/js/datepicker.js')
        ])
        .then(() => {
            console.log('Files loaded.');
            
        })
        .catch(error => {
            console.log(error.body.message);
        });  

        let urlString = window.location.search;
        let urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            let branchrecId = urlParams.get('branchRecId');
            if (branchrecId != null) {
                this.branchId = atob(branchrecId);
            }
        }

        fetchCurrenUserWrapper({}).then(result => {
            console.log('fetchCurrenUserWrapper result>>>>' + JSON.stringify(result));
            this.userBranchWrapper = result[0];
            this.currentUser = this.userBranchWrapper.userData;
            this.currentUserBranches = this.userBranchWrapper.branches;

        }).catch(error => {
            console.log('Line 85 review transfer fetchCurrenUserWrapper error -> ' + JSON.stringify(error));
        });

        getDepositInformationTransferred({scheme :'Custodial'})
        .then(result=>{
            if(result != null){
                console.log('DepositInformation==>'+JSON.stringify(result));
                this.TransferedDepositsList = result;
                console.log('No.of deposits==>'+this.TransferedDepositsList.length)
                this.TotalDeposits = this.TransferedDepositsList.length;
                console.log('TransferedDepositsList==>'+JSON.stringify(this.TransferedDepositsList));
                var NIDAN = result[0].objDeposit.NI_Deposit_Number__c;
                console.log('No.ofAttempts==>'+result[0].objDeposit.No_of_attempt__c);
                console.log('isBulk_transfer_attempts__c==>'+result[0].objDeposit.Bulk_transfer_attempts__c);
                console.log('NI==>'+NIDAN);
                if(result==''){
                    this.currentPage = 1;
                }
                else {
                    this.currentPage = 1;
                }
                if(result[0].objDeposit.No_of_attempt__c!= undefined){
                    this.currentAttempt = 3-result[0].objDeposit.No_of_attempt__c;
                }
                if(result[0].objDeposit.No_of_attempt__c==0 && result[0].objDeposit.Bulk_transfer_attempts__c == true){
                    this.isTenantMaxAttemptsErrorMsg = true;
                    this.isTenantNameErrorMsg= false;
                    this.isTenantNameErrorMsg1 = false;
                    this.disableSumbit = true;
                    //this.submitButtonDisable();
                }
                if(result[0].objDeposit.No_of_attempt__c==1){
                    this.isTenantNameErrorMsg1 = true;
                }
                if(result[0].objDeposit.No_of_attempt__c==2){
                    this.isTenantNameErrorMsg = true;
                }
                this.propertyList=result;
                console.log('propertyList111===='+ JSON.stringify(this.TransferedDepositsList));
                var pageSize = this.pageSize;
                var totalRecordsList = result;
                var totalLength = totalRecordsList.length;
                this.totalRecordsCountPropList=totalLength;
                this.startPage = 0;
                this.endPage = pageSize-1;
                var PaginationPropList = [];
                for (var i = 0; i < pageSize; i++) {
                 if ((this.propertyList).length > i) {
                    PaginationPropList.push(this.propertyList[i]);
                 }
                }
                this.PaginationPropList = PaginationPropList;
                //console.log('fetchPropertylist===='+ JSON.stringify(this.PaginationPropList));
                this.totalPagesCount=Math.ceil(totalLength / pageSize);
                if(this.totalPagesCount>1){
                    this.isEndPageNav =true;
                    this.isEndPage = false;
                   }
                   else{
                    this.isEndPage = true;
                    this.isEndPageNav = false;
                   }
            }
           console.log('line==>77');
           
            
        })
        .catch(error=>{
            console.log('error accured while loading data==>'+error);
        });
        
       
    }
    renderedCallback() {
        // if(this.TransferedDepositsList[0].objDeposit.No_of_attempt__c==0 && this.TransferedDepositsList[0].objDeposit.Bulk_transfer_attempts__c == true){
        //     this.isTenantMaxAttemptsErrorMsg = true;
        //     this.isTenantNameErrorMsg= false;
        //     this.disableSumbit = true;
        //     let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
        //      finalSubmit.style = 'opacity: 0.5';
        // }
        
        //this.disableSumbit = true;
    }
    handleSelectAllChange(event) {
        this.isNoDepositsSelected = false;
        this.selectAllChecked = event.target.checked;
        console.log('Check box ticked==>'+this.selectAllChecked);
        //var PaginationList = component.get("v.PaginationList");
        var updatedAllRecords = [];
        var listOfAllDeposits = this.PaginationPropList;
        // Get all the data checkboxes
        const dataCheckboxes = this.template.querySelectorAll('.dataCheckbox');
    
        // Iterate over each data checkbox and set their checked state
        dataCheckboxes.forEach((checkbox) => {
          checkbox.checked = this.selectAllChecked;
        });
        
        for (var i = 0; i < listOfAllDeposits.length; i++) {
            if(this.selectAllChecked){
                listOfAllDeposits[i].isChecked = true;
                this.selectedCount = listOfAllDeposits.length;
            }
            else{
                listOfAllDeposits[i].isChecked = false;
                this.selectedCount = 0;
            }
            updatedAllRecords.push(listOfAllDeposits[i]);
        }
        //this.updateSelectedRecords();
        console.log('Line=>114'+JSON.stringify(updatedAllRecords));

        
        var allRecords = listOfAllDeposits;
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].objDeposit.Id);
            }
        }
            this.selectedDepositIds = selectedRecords;
            console.log('selectedDepIds All=>'+selectedRecords);
            console.log('No.of selected records==>'+this.selectedCount);
      }
       handleDataCheckboxChange(event) {
        this.isNoDepositsSelected = false;
       // this.selectedDeposits = this.Paginationlist
        const isChecked = event.target.checked;
        const recordId = event.target.getAttribute('data-key');
        console.log('recordId-107 => ' + recordId);
        console.log('isChecked => ' + isChecked);
        var getSelectedNumber = this.selectedCount;
        if(isChecked) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;

        }
        this.selectedCount = getSelectedNumber;
        console.log('No.of selected records single select ==>'+this.selectedCount);

       // Check if all individual checkboxes are checked
       const dataCheckboxes = document.querySelectorAll('.dataCheckbox');
       const allChecked = Array.from(dataCheckboxes).every((checkbox) => checkbox.checked);
       
       // Update the "Select All" checkbox based on whether all individual checkboxes are checked or not
       this.selectAllChecked = allChecked;
       if (!allChecked) {
        this.selectAllChecked = false;
        }
       // console.log('selectedDeposits =>', this.selectedDeposits);
        this.updateSelectedRecords();

    
      }
      
      updateSelectedRecords() {
        this.selectedDepositIds = [];
      
        // Get all the data checkboxes
        const dataCheckboxes = this.template.querySelectorAll('.dataCheckbox');
      
        dataCheckboxes.forEach((checkbox) => {
          if (checkbox.checked) {
            const recordId = checkbox.getAttribute('data-key');
            this.selectedDepositIds.push(recordId);
          }
        });
      
        console.log('selected Records single 215==>' + this.selectedDepositIds);
        console.log('No.of selected records single select ==>' + this.selectedCount);
        if(this.selectedCount==0){
            this.selectAllChecked = false;
        }
      }
      

    navigationHandle(event){
        event.preventDefault();
        var sObjectList= this.TransferedDepositsList;
        
        var pageSize = Number(this.pageSize);
        var start= this.startPage;
        var end= this.endPage;
        console.log('navigationHandle ==='+event.target.dataset.id);
        var navigate = event.target.dataset.id;

        if(navigate =='propNextId'){
            var sObjectList= this.TransferedDepositsList;
            var listName = 'prop';
            console.log('navigationHandle in  propNextId');
            console.log('navigationHandle in  propNextId sObjectList'+JSON.stringify(sObjectList));
            this.currentPage= this.currentPage + 1;
            this.next(listName,sObjectList,end,start,pageSize);
        }
        else if(navigate =='propPreviousId'){
            var sObjectList= this.TransferedDepositsList;
            var listName = 'prop';
            console.log('navigationHandle in  propPreviousId');
            this.currentPage= this.currentPage - 1;
            this.previous(listName,sObjectList,end,start,pageSize);
        }
        
        
    }
    next (listName,sObjectList,end,start,pageSize){
        console.log('SobjectList==>'+sObjectList);
        console.log('Line116')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for(var i = end + 1; i < end + pageSize + 1; i++){ 
            if(sObjectList.length > i){ 
                    Paginationlist.push(sObjectList[i]);

                }
            counter ++ ;
        }
        console.log('line=>127==>'+Paginationlist);
        this.PageSpinner = false;
        start = start + counter;
        end = end + counter;
        this.startPage = start;
        this.endPage= end;
        if(listName == 'prop'){
            this.PaginationPropList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }
       

        if(this.currentPage == 1){
            this.isStartPage = true;
            this.isStartPageNav = false;
        }else{
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if(this.currentPage==this.totalPagesCount){
            this.isEndPage = true;
            this.isEndPageNav =false;
        }else{
            this.isEndPage = false;
            this.isEndPageNav =true;
        }

    }
    previous(listName,sObjectList,end,start,pageSize){
        console.log('Line155')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
              
                    Paginationlist.push(sObjectList[i]); 
                counter ++;
            }else{
                start++;
            }
        }
        this.PageSpinner = false;
        start = start - counter;
        end = end - counter;
        this.startPage = start;
        this.endPage= end;
        if(listName == 'prop'){
            this.PaginationPropList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }
        if(this.currentPage == 1){
            this.isStartPage = true;
            this.isStartPageNav = false;
        }else{
            this.isStartPage = false;
            this.isStartPageNav = true;
        }
    
        if(this.currentPage==this.totalPagesCount){
            this.isEndPage = true;
            this.isEndPageNav =false;
        }else{
            this.isEndPage = false;
            this.isEndPageNav =true;
        }

    }
    
    handleRejectMultipleDeposits(event){
        console.log('count==>'+this.selectedCount);
        var isValid = true;
        if(this.selectedCount ==0){
            this.isNoDepositsSelected = true;
            isValid = false;
        }
        else{
            this.isNoDepositsSelected = false;
        }
        if(isValid){
            processRejectDeposit({depositIds:this.selectedDepositIds})
            .then(result=>{
                if(result =='Deposit Successfully Rejected'){
                    this.isRequestedDepositSection = false;
                    this.isSuccessScreen = true;
                    this.isRejectionMsg = true;
                }
            }).catch(error=>{
                    console.log('error while rejecting==>'+error);
            });
        }
    }
    
    handleAcceptMultipleDeposits(event) {
        console.log('AcceptClicked');
        console.log('depositsRecordsList==>' + this.selectedDepositIds);
        console.log('Accepted count==>'+this.selectedCount);
        var isValid = true;
        console.log('current User Profile: '+this.currentUser.Profile.Name);
        console.log('current branches length: '+this.currentUserBranches.length);
        if(this.selectedCount ==0){
            this.isNoDepositsSelected = true;
            isValid = false;
        }
        else{
            this.isNoDepositsSelected = false;
        }
        if(isValid){
            processMultipleAcceptDeposit({ depositId: this.selectedDepositIds })
            .then(result => {
                if (result != null) {
                    console.log('resultLine350==>'+JSON.stringify(result));
                    console.log('resultSize==>'+result.length);
                    var conts = result;
                    for ( var key in conts ) {
                        this.deposits.push({value:conts[key], key:key});
                    }
        
                this.enterTenantNameMultiple = true;
                this.depositslength1 = true;
                this.isRequestedDepositSection = false;
        
                console.log('result311==>' + JSON.stringify(this.deposits));
                console.log('length==>' + this.deposits.length);
                }
            })
            .catch(error => {
                console.log('error==>@@' + error);
            });
      
        }
      
    }
    multipleTenantCheckValue(event){
        this.isTenantNameErrorMsg = false;
        this.isTenantNameErrorMsg1 = false;
        this.isunableErrorMsg = false;
        this.isTenantvalueBlankErrorMsg = false;

        var tenantValue = event.target.value;
        var tenantId = event.target.title;
        var jsonArrayData = this.depositInfo;
        let keyfound=false;
        console.log('tenant value 368==>'+tenantValue);
        this.tenantNames = tenantValue;
        if(jsonArrayData == undefined || jsonArrayData == null)
        {	console.log(' 11111');
         jsonArrayData=[];
         jsonArrayData.push({key:tenantId,value:tenantValue}); 
        }
        else{
            if(jsonArrayData.length>0)
            {
                for(let i=0;i<jsonArrayData.length;i++)
                {	console.log(' 222333333333333333333333322');
                 //let tempobj= jsonArrayData[i];console.log(' tempobj[tenantId]'+tempobj[tenantId]);
                 console.log(' jsonArrayData[i]'+jsonArrayData[i].key);
                 if(jsonArrayData[i].key == tenantId){
                     jsonArrayData[i].value = tenantValue;
                     keyfound=true;
                     break;
                 }
                }
                if(!keyfound)
                {console.log(' 25333333333333');
                    jsonArrayData.push({key:tenantId,value:tenantValue}); 
                }
            }
            else
            {console.log(' 4444444444444444'+jsonArrayData);
             jsonArrayData=[];
             jsonArrayData.push({key:tenantId,value:tenantValue});          
            }
        }
        this.depositInfo = jsonArrayData;
        console.log('DepositInfo==>'+JSON.stringify(this.depositInfo));
    }
    acceptMultipleDepositData(event){
        event.preventDefault();
        console.log('this.selectedDepositIds==>'+this.selectedDepositIds);
        console.log('this.deposits==>'+JSON.stringify(this.deposits));
        console.log('this.depositInfo==>'+JSON.stringify(this.depositInfo));
        console.log('tnant Values==>'+this.tenantNames);
        this.isTenantNameErrorMsg = false;
        this.isTenantNameErrorMsg1 = false;
        this.isunableErrorMsg = false;
        this.isTenantvalueBlankErrorMsg = false;
        var isValid = true;


        if(this.tenantNames==null ||this.tenantNames==''|| this.tenantNames==undefined ){
            this.isTenantvalueBlankErrorMsg = true;
            isValid = false;
        }
        else{
            this.isTenantvalueBlankErrorMsg = false;
        }
        if(isValid){
            this.currentAttempt--;
            this.PageSpinner = true;
            console.log('CurrentAttemps==>'+this.currentAttempt);

        checkDepositAllocationMultipleTenantName({
            listDepositId:this.selectedDepositIds,
            values : JSON.stringify(this.depositInfo),
            depositsList:JSON.stringify(this.deposits),
            scheme:'NI Custodial',
            NoOfAttempts:this.currentAttempt
        })
        .then(result=>{
           // if(result!=null){
                console.log('acceptMultipleDep==>Result==>'+result);
                this.resMessage = result;
                if(this.resMessage=='Deposit updated and no case exist'){
                    this.enterTenantNameMultiple = false;
                    this.isRequestedDepositSection = false;
                    //this.isSuccessScreen = true;
                    //this.isAcceptingMsg = true;
                    //this.PageSpinner = false;
                    //alert('User : '+this.currentUser.Profile.Name + ' '+this.currentUserBranches.length);
                    if(this.currentUser.Profile.Name == 'NI_Head_Office_User' && this.currentUserBranches.length >=2 ){
                        //alert('Deposit updated and no case exist To Branch');
                        window.location = window.location.origin + '/ni/s/transferdepositstobranch?depositId=' + window.btoa(this.selectedDepositIds[0]);
                    } else {
                        this.isSuccessScreen = true;
                        this.isAcceptingMsg = true;
                        this.PageSpinner = false;
                    }
                }
                else if(this.resMessage == 'Deposit updated and case exist'){
                    this.enterTenantNameMultiple = false;
                    this.isRequestedDepositSection = false;
                    //this.isSuccessScreen = true;
                    //this.isAcceptingMsg = true;
                    //this.PageSpinner = false;
                    console.log('current User Profile: '+this.currentUser.Profile.Name);
                    //alert('User : '+this.currentUser.Profile.Name + ' '+this.currentUserBranches.length);
                    if(this.currentUser.Profile.Name == 'NI_Head_Office_User' && this.currentUserBranches.length >=2 ){
                        //alert('Deposit updated and case exist');
                       window.location = window.location.origin + '/ni/s/transferdepositstobranch?depositId=' + window.btoa(this.selectedDepositIds[0]);
                    } else {
                        this.isSuccessScreen = true;
                        this.isAcceptingMsg = true;
                        this.PageSpinner = false;
                    }

                    //alert('There are outstanding actions required against some of these deposits. Please see the ‘Outstanding actions’ section of your account to view these deposits and your deadlines to respond.');
                    this.isCasePresentMsg = true;
                    this.error = 'There are outstanding actions required against some of these deposits. Please see the ‘Outstanding actions’ section of your account to view these deposits and your deadlines to respond.';
                }
                // else if(this.resMessage.includes("Please complete the required value for")){
                //     this.isunableErrorMsg= true;
                //     this.errors = this.resMessage;
                // }
                // else if(this.resMessage == 'all blank'){
                //     // component.set("v.tenantValidationError",true);
                //     // component.set("v.errors", "Please enter the required value for all Deposits."); 
                //    // alert('Please enter the required value for all Deposits.'+resMessage);
                //    //this.isTenantNameErrorMsg= true;
                //     this.errors = this.resMessage;
                // }
                
                else{
                   // this.isTenantNameErrorMsg = true;
                   this.PageSpinner = false;
                    if(this.currentAttempt==2){
                        this.isTenantNameErrorMsg= true;
                    }
                    else if(this.currentAttempt==1){
                        this.isTenantNameErrorMsg1 = true;
                    }
                    else if(this.currentAttempt==0){
                        this.isTenantMaxAttemptsErrorMsg = true;
                        this.isTenantNameErrorMsg= false;
                        this.isTenantNameErrorMsg1 = false;
                        let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
                        finalSubmit.style = 'opacity: 0.5';
                        this.disableSumbit = true;
                    }

                }
            //}
        })
        .catch(error=>{
            console.log('error-404==>'+JSON.stringify(error));
        });

        }
    }
        hideBootstrapErrors(event){ 
        var button_Name = event.target.name;
        switch (button_Name) { 
            case "NoDepositsSelected":
                this.isNoDepositsSelected=false;
            break;
        }
    }
    goBackHandle(event){
        event.preventDefault();
        window.location = window.location.origin + '/ni/s';
    }

   
}