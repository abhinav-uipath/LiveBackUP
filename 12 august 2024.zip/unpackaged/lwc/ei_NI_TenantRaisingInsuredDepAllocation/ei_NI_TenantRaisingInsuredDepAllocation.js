import { LightningElement, track, wire } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';

import getDepositInformation from '@salesforce/apex/EI_NI_TenantRaisingInsuredDepAllocation.getDepositeDetails';
import updateDepositInfo from '@salesforce/apex/EI_NI_TenantRaisingInsuredDepAllocation.updateTenantDeposit';
import NI_ViewEvidenceUrl from '@salesforce/label/c.NI_ViewEvidenceUrl';

import NIResource from '@salesforce/resourceUrl/NI_Theme';
import TDSResource from '@salesforce/resourceUrl/TDSTheme';
// import NoTenantsToShow from '@salesforce/label/c.NoTenantsToShow';
// import Redecoration from '@salesforce/label/c.Redecoration';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import error from '@salesforce/apex/FC_ErrorLogger.error';

export default class Ei_NI_TenantRaisingInsuredDepAllocation extends LightningElement {
    backBtnImg = NI_Theme + '/assets/img/md-arrow-dropleft.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    resource1 = `${NIResource}/assets/img/nhos-arrow-dropleft.svg`;
    resource2 = TDSResource + '/assets/img/pound_icon.png';
    resource3 = `${TDSResource}/assets/img/question-circle.png`;
    successImage = NI_Theme + '/assets/img/thank-you.png';
    featherImg = NI_Theme + '/assets/img/feather-edit_nhos.svg';
    calendarwhite = NI_Theme + '/assets/img/calendar-white.svg';


    @track isFutureDateError = false;
    @track isTenEndDateValid = false;
    @track isInValidEndDate = false;
    @track YesHandle = false;
    @track NoHandle = false;
    @track tenancyDay = '';
    @track tenancyMonth = '';
    @track tenancyYear = '';
    @track endDateByTenant = '';
    @track tenancyEndDateYMD = '';
    @track tenancyEndDateDMY = '';
    @track isShowTenantsMovedOut = false;
    @track todayDate = '';
    @track pickedValue;
    @track goBackUrl = NI_ViewEvidenceUrl;
    depositId = '';
    profileName;
    tenantEndDate = '';
    showSpinner = false;
    //showDateError = false;
    branchId = null;
    @track depositRec = {};

    @track tenancyDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

    @track tenancyMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

    @track tenancyYearList = [];

    @wire(CurrentPageReference)
    currentPageReference;

    connectedCallback() {
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositId = atob(depositRecId);
        Promise.all([
            loadStyle(this, `${NIResource}/assets/css/custom-ni.css`),
            loadScript(this, NIResource + '/assets/js/plugin.min.js'),
            loadScript(this, NIResource + '/assets/js/custom.js')
        ]).then(() => {
            console.log('Files loaded.');
        }).catch(error => {
            console.log(error.body.message);
        });
        getDepositInformation({
            "depositRecId": this.depositId
        }).then(result => {
            console.log('Deposit Details:::', JSON.stringify(result));
            this.depositRec = result.depositRec;
            if(result.depositRec.Branch__c != null || result.depositRec.Branch__c != undefined){
                this.branchId = result.depositRec.Branch__c;
                console.log('BranchId==>'+this.branchId);
            }
        }).catch(error => {
            console.log('Error fetching Deposit Details', JSON.stringify(error));
        });
         // set today date for max date as future dates should be grayed out
         //  date picker code start 
         var today = new Date();
         var todayDate = today.getDate();
         todayDate = todayDate>9 ? todayDate : '0'+todayDate;
         var todayMonth = today.getMonth()+1;
         todayMonth = todayMonth>9 ? todayMonth : '0'+todayMonth;
         var todayYear = today.getFullYear();
         this.todayDate = todayYear+'-'+todayMonth+'-'+todayDate;
         console.log(' MAx todayDate => ' + this.todayDate);
     //  date picker code end 
        /* getLoggedUserAccId()
            .then(result => {
                var allValues = result;
                if (result != null) {
                    console.log('user contactId-->' + allValues.ContactId);
                    console.log('user Name-->' + allValues.Name);
                    console.log('user AccountId-->' + allValues.AccountId);
                    this.userContactId = allValues.ContactId;

                    console.log('user Profile name-->' + allValues.Profile.Name);
                    if (allValues.Profile.Name == 'NI_Landlord') {
                        this.initiatedBy = 'Landlord'
                        console.log('initiatedByLL-->' + this.initiatedBy);
                    }
                    else if (allValues.Profile.Name == 'NI_Agent') {
                        this.initiatedBy = 'Agent';
                        console.log('initiatedByAG-->' + this.initiatedBy);
                    }
                }
            }).catch(error => {
                console.log('user details not found-->' + JSON.stringify(error));
            });
        getTenantsInformation({})
            .then(result => {
                var blankAllocationList = [];
                var allValues = result;
                console.log('allValues--194' + JSON.stringify(allValues));
                if (allValues != null) {
                    // this.tenentList=result;

                    // this.depositAllocation.push(allValues);
                    this.depositAllocation = allValues;
                    this.totalNoTenant = allValues.length;
                    console.log('depositAllocation--194' + this.depositAllocation);
                    if (allValues.length == 1) {
                        var rounded = (this.deposit.Protected_Amount__c).toFixed(2);//Actual_Protected_Amount__c
                        this.amountDividedByTenant = rounded;
                        console.log('amountDividedByTenant--198-->' + this.amountDividedByTenant);
                    }
                    if (allValues.length > 1) {
                        rounded = (this.deposit.Protected_Amount__c / allValues.length).toFixed(2);//Actual_Protected_Amount__c
                        console.log('rounded--202-->' + rounded);
                        this.amountDividedByTenant = rounded;
                        var totalLenRound = rounded * allValues.length;
                        var protectAmt = this.deposit.Protected_Amount__c;//Actual_Protected_Amount__c
                        if (parseFloat(totalLenRound) != parseFloat(protectAmt)) {
                            var deductedAmt = parseFloat(parseFloat(totalLenRound.toFixed(2)) - parseFloat(protectAmt.toFixed(2)));
                            var lastTenantAmt = parseFloat(parseFloat(rounded) - parseFloat(deductedAmt.toFixed(2)));
                            this.lastTenantAmount = lastTenantAmt;
                            console.log('lastTenantAmount' + this.lastTenantAmount);
                        }
                    }

                }


            }).
            catch(error => {
                console.log('tenant error', JSON.stringify(error));
            }); */

        //tenancyEndYear List//
        let tenancyYearList = [];
        for (var i = 2012; i <= 2024; i++) {
            tenancyYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
        }
        this.tenancyYearList = tenancyYearList;
    }

    onDatePickerChangeHandler(event){
    this.pickedValue = event.target.value;
        // tenancyDateList, tenancyMonthList,  tenancyYearList
        //  date picker code start
        console.log('onDatePickerChangeHandler date picker => '+ event.target.value);
        let dateVal = new Date(event.target.value);
        var day = dateVal.getUTCDate();
        var month = dateVal.getUTCMonth() + 1;
        var year = dateVal.getUTCFullYear();

        for(let i=0; i< this.tenancyDateList.length; i++){
            if(this.tenancyDateList[i].value == day){
                this.tenancyDateList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyDateList[i].value;

            }else{
                this.tenancyDateList[i].isSelected = false;  
            }

        }
        for(let i=0; i< this.tenancyMonthList.length; i++){
            if(this.tenancyMonthList[i].value == month){
                this.tenancyMonthList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyMonthList[i].value;
            }else{
                this.tenancyMonthList[i].isSelected = false;  
            }
        }

        for(let i=0; i< this.tenancyYearList.length; i++){
            if(this.tenancyYearList[i].value == year){
                this.tenancyYearList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyYearList[i].value;
            }else{
                this.tenancyYearList[i].isSelected = false;  
            }
        }

        this.checkTenancyEndDate(event);
    }

    checkTenancyEndDate(event) {

        // tenancy start date
        let tenancyEndtDate = this.template.querySelector('[name="tenancyEndDate"]').value;
        if (tenancyEndtDate != 'Select day') {
            this.tenancyDay = tenancyEndtDate;
        }
        let tenancyEndtMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
        if (tenancyEndtMonth != 'Select month') {
            this.tenancyMonth = tenancyEndtMonth;
        }
        let tenancyEndYear = this.template.querySelector('[name="tenancyEndYear"]').value;
        if (tenancyEndYear != 'Select year') {
            this.tenancyYear = tenancyEndYear;
        }
        let tenancyDateYMD = tenancyEndYear + '-' + tenancyEndtMonth + '-' + tenancyEndtDate;
        let tenancyDateDMY = tenancyEndtDate + '/' + tenancyEndtMonth + '/' + tenancyEndYear;
        this.tenantEndDate = tenancyEndtDate + '/' + tenancyEndtMonth + '/' + tenancyEndYear;
        if (tenancyEndtDate != 'Select day' && tenancyEndtMonth != 'Select month' && tenancyEndYear != 'Select year') {
            var tenancyDateDDMMYY = tenancyEndtDate + '-' + tenancyEndtMonth + '-' + tenancyEndYear;
        }

        this.tenancyEndDateYMD = tenancyDateYMD;
        this.tenancyEndDateDMY = tenancyDateDMY;
        console.log('Line 518 Tenancy End Date-->' + this.tenancyEndDateYMD);
        console.log('Line 292 Tenancy End Date-->' + this.tenancyDateDDMMYY);
        this.isFutureDateError = false;
        this.isTenEndDateValid = false;
        this.isInValidEndDate = false;
        //  this.displaySummarySection = false;

        let endDate = this.tenancyDay;
        let endMonth = this.tenancyMonth;
        let endYear = this.tenancyYear;


        //let tenancyEndDate = endDate+'-'+endMonth+'-'+endYear;
        let tenancyEndDate = tenancyDateDDMMYY;
        let isValidDate = validatedate(tenancyEndDate);

        var today = new Date();
        var todayDate = today.getDate();
        var todayMonth = today.getMonth() + 1;
        var todayYear = today.getFullYear();

        // Date validation 
        var arraydate = [];
        console.log(' 1357');
        //  let isValidDate = true;
        let isValid = true;
        //let tenancyDateDDMMYY = this.tenancyDay + '-' + this.tenancyMonth + '-' + tenancyEndYear;
        arraydate.push(tenancyEndDate);
        console.log('date-->' + tenancyEndDate);
        let loopCounter = 0;
        this.isInValidEndDate = false;
        for (var i = 0; i < arraydate.length; i++) {
            isValidDate = validatedate(arraydate[i]);
            if (isValidDate == false) {
                if (loopCounter == 0) {
                    isValid = false;
                    //isValidDate == false;

                    this.isShowTenantsMovedOut = false;
                    console.log('invalid date--->412');
                    this.isInValidEndDate = true;
                } else {
                    this.isInValidEndDate = false;
                    // this.isShowTenancyDateError = true;
                }
                break;

            }
            else {
                this.isInValidEndDate = false;
            }
            loopCounter++;
        }
        //GOD class to check date validity
        function validatedate(d) {
            var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
            // Match the date format through regular expression
            if (d.match(dateformat)) {
                var splittedDate = d.split('-');
                var splittedDateLength = splittedDate.length;
                if (splittedDateLength > 1) {
                    var pdate = d.split('-');
                }
                var dd = parseInt(pdate[0]);
                var mm = parseInt(pdate[1]);
                var yy = parseInt(pdate[2]);

                // Create list of days of a month [assume there is no leap year by default]
                var ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                if (mm == 1 || mm > 2) {
                    if (dd > ListofDays[mm - 1]) {
                        return false;
                    }
                }
                if (mm == 2) {
                    var lyear = false;
                    if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
                        lyear = true;
                    }
                    if ((lyear == false) && (dd >= 29)) {
                        return false;
                    }
                    if ((lyear == true) && (dd > 29)) {
                        return false;
                    }
                }
                return true;
            }
            else {
                return false;
            }
        }
        console.log('tenancy end date444--->' + this.endDateByTenant);
        // }
        let setEndDate = endYear + '-' + endMonth + '-' + endDate;
        if (endYear == todayYear) {
            if (endMonth == todayMonth) {
                if (endDate <= todayDate) {
                    this.endDateByTenant = this.tenancyEndDateYMD;
                    // if (this.endDateByTenant < this.depositRec.Start_Date__c) {
                    //     this.showDateError = true;
                    // }
                } else {
                    this.isFutureDateError = true;
                    //this.showDateError = false;
                    this.isInValidEndDate = false;
                    this.isShowTenantsMovedOut = false;
                    isValid = false;
                    // this.displaySummarySection = false;
                }
            } else if (endMonth < todayMonth) {

                this.endDateByTenant = this.tenancyEndDateYMD;
                // if (this.endDateByTenant < this.depositRec.Start_Date__c) {
                //     this.showDateError = true;
                // }
            } else {
                this.isFutureDateError = true;
                //this.showDateError = false;
                this.isInValidEndDate = false;
                this.isShowTenantsMovedOut = false;
                isValid = false;
                // this.displaySummarySection = false;
            }
        } else if (endYear < todayYear) {

            this.endDateByTenant = this.tenancyEndDateYMD;
            // if (this.endDateByTenant < this.depositRec.Start_Date__c) {
            //     this.showDateError = true;
            // }
        } else {
            this.isFutureDateError = true;
            //this.showDateError = false;
            this.isShowTenantsMovedOut = false;
            this.isInValidEndDate = false;
            isValid = false;
        }

        if (isValidDate && isValid) {
            console.log(isValidDate + '<==isValidDate==>' + isValid);
            this.isShowTenantsMovedOut = true;

            console.log('tenancy end date111--->' + this.endDateByTenant);

        } else {
            // this.isTenEndDateValid=true;
            console.log('tenancy end error from here--->' + this.isTenEndDateValid);
            console.log('tenancy end date222--->' + this.endDateByTenant);
        }


        console.log('tenancy end date333--->' + this.endDateByTenant);
        this.myDate = this.tenancyEndDateDMY;
        // console.log('Tenancy end --->'+this.myDate);
        /* if (this.endDateByTenant < this.depositRec.Start_Date__c) {
            this.showDateError = true;
        } */

    }

    onclickYes(event) {
        event.preventDefault();
        this.template.querySelector('.yes').classList.add('active');
        this.template.querySelector('.no').classList.remove('active');
        /* this.YesHandle = true;
        this.NoHandle = false; */
        this.updateDepositHandle('Yes');
    }
    onclickNo(event) {
        event.preventDefault();
        this.template.querySelector('.yes').classList.remove('active');
        this.template.querySelector('.no').classList.add('active');
        /* this.NoHandle = true;
        this.YesHandle = false; */
        this.updateDepositHandle('No');
    }

    updateDepositHandle(movedOut) {
        console.log('DepositId::' + this.depositId + '\t MovedOut::' + movedOut + '\t End Date::' + this.tenantEndDate);
        this.showSpinner = true;
        updateDepositInfo({
            "depositId": this.depositId,
            "movedOut": movedOut,
            "endDate": this.tenancyEndDateYMD,
            "branchId":this.branchId != null ? this.branchId : null
        }).then(result => {
            console.log('Result::', JSON.stringify(result));
            if (result == 'success') {
                if (movedOut == 'Yes') {
                    this.YesHandle = true;
                    this.NoHandle = false;
                } else if (movedOut == 'No') {
                    this.NoHandle = true;
                    this.YesHandle = false;
                }
                this.showSpinner = false;
                this.disableForm(movedOut);
            }
        }).catch(error => {
            console.log('Error updating deposit:::', JSON.stringify(error));
        })
    }

    disableForm(yesOrNo) {
        this.template.querySelector('[name="tenancyEndDate"]').setAttribute('disabled');
        this.template.querySelector('[name="tenancyEndMonth"]').setAttribute('disabled');
        this.template.querySelector('[name="tenancyEndYear"]').setAttribute('disabled');
        this.template.querySelector('[name="yesButton"]').setAttribute('disabled');
        this.template.querySelector('[name="noButton"]').setAttribute('disabled');
    }

    goBackHandle(event) {
        event.preventDefault();
        window.location = window.location.origin + this.goBackUrl + window.btoa(this.depositId);
        //window.location = window.location.origin + '/ni/s/deposit-summary?c__depositRecId=' + window.btoa(this.depositId);
        /* var depositRecId = window.btoa(this.depositId);
        console.log('DepositId::'+this.depositId+'Encrypted Id::'+depositRecId);
        if (depositRecId != null && depositRecId != "" && depositRecId != undefined) {
            console.log('Inside if');
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'deposit-summary'
                },
                state: {
                    c__depositRecId: depositRecId
                }
            });
        } */
    }

    // hideBootstrapErrors(event) {
    //     var buttonName = event.target.name;
    //     switch (buttonName) {
    //         case "showDateErrorMsg":
    //             this.showDateError = false;
    //             break;
    //     }
    // }
}