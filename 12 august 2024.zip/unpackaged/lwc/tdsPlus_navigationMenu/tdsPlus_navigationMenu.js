import { LightningElement, api, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import getNavigationMenuItems from '@salesforce/apex/NavigationMenuItemsController.getNavigationMenuItems';
import IMAGE_SUBLINK from '@salesforce/label/c.TDSPlus_Image_Sublink';

// This is a custom LWC navigation menu component.
// Make sure the Guest user profile has access to the NavigationMenuItemsController apex class.
export default class TdsPlus_navigationMenu extends LightningElement {

    // Add custom label for url
    label = {
        imageSublink: IMAGE_SUBLINK
    };
    // Adding a bottem  border

    
    @api add_bottom_border = false;
    // Adding Logo link
    @api logoimagelink='/tdsplusv1/'

    // Adding Logo image Path
    @api logoimagepath=''


    // Adding Logo image from cms workspace
    @api contentKey;

    // the label or name of the nav menu linkset (NavigationMenuLinkSet.MasterLabel) exposed by the .js-meta.xml, used to look up the NavigationMenuLinkSet.DeveloperName
    @api linkSetMasterLabel;

    // include the Home menu item, if true
    @api addHomeMenuItem = false;
 
    // include image URLs in the response, if true useful for building a tile menu with images
    @api includeImageUrls = false;

    // the menu items when fetched by the NavigationItemsController
    @track menuItems = [];

    // if the items have been loaded
    @track isLoaded = false;

    // The error if it occurs
    @track error;

    @track imageLink;

    // The published state of the site, used to determine from which schema to fetch the NavigationMenuItems
    publishStatus;

    @track hideclasses = true;
    @track isPhone = false;
    // href = 'www.google.com'
    


    get ulclasses() {
        return this.hideclasses ? 'dropdownMenu':'dropdownMenu slds-hide'
    }
    
    

       connectedCallback() {
        console.log('Line 45 connectedCallback isPhone -> '+this.isPhone);
        // Check if the device width is less than or equal to 480 pixels (common width for phones)
        this.isPhone = window.matchMedia('(max-width: 480px)').matches;
        console.log('Line 45 connectedCallback isPhone 1 -> '+this.isPhone);
        this.imageLink = this.label.imageSublink + this.contentKey;
        console.log('Line No:87');
        console.log(this.imageLink);

        // var checktoggle = this.template.querySelector('.navbarSupportedContent').style.display;
        // console.log('Line 45 connectedCallback checktoggle -> '+JSON.stringify(checktoggle));
        // if(checktoggle=="block") {
        //     this.template.querySelector('.navbarSupportedContent').style.display = 'none';
        // }
    }


    // Using a custom Apex controller, query for the NavigationMenuItems using the menu name and published state.
    // The custom Apex controller is wired to provide reactive results. 
    @wire(getNavigationMenuItems, {
        navigationLinkSetMasterLabel: '$linkSetMasterLabel',
        publishStatus: '$publishStatus',
        addHomeMenuItem: '$addHomeMenuItem',
        includeImageUrl: '$includeImageUrls'
    })
    wiredMenuItems({error, data}) {
        if (data && !this.isLoaded) {
            this.menuItems = data.map((item, index) => {
                return {
                    target: item.actionValue,
                    id: index,
                    label: item.label,
                    type: item.actionType,
                    subMenu: item.subMenu.map((subItem, index) => {
                        return {
                            target: subItem.actionValue,
                            id: index,
                            label: subItem.label,
                            type: subItem.actionType,
                            subMenu: subItem.subMenu,
                            imageUrl: subItem.imageUrl,
                            windowName: subItem.target
                        }
                    }),
                    subMenuDisplay: item.subMenu.length == 0 ? false:true,
                    imageUrl: item.imageUrl,
                    windowName: item.target
                }
            });
            console.log('Line 88 -> '+JSON.stringify(this.menuItems));
            this.error = undefined;
            this.isLoaded = true;
        } 
        else if (error) {
            this.error = error;
            this.menuItems = [];
            this.isLoaded = true;
            console.error(`Navigation menu error: ${JSON.stringify(this.error)}`);
        }
    }

    // Show hide the navigation menu through hamburger
    showHideNavMenu() {
        this.isPhone = false;
        console.log('Line 84 showHideNavMenu start ');
        var checktoggle = this.template.querySelector('.navbarSupportedContent').style.display;
        console.log('Line 84 showHideNavMenu checktoggle -> '+JSON.stringify(checktoggle));

        if(checktoggle=="block") {
            this.template.querySelector('.navbarSupportedContent').style.display = 'none';
        }
        else {
            this.template.querySelector('.navbarSupportedContent').style.display = 'block';
        }
        console.log('Line 84 showHideNavMenu end ');
    }

    hideNav() {
        this.hideclasses=false;
    }
    
    handleMouseout() {
        this.hideclasses=true;
    }

    /**
     * Using the CurrentPageReference, check if the app is 'commeditor'.
     * 
     * If the app is 'commeditor', then the page will use 'Draft' NavigationMenuItems. 
     * Otherwise, it will use the 'Live' schema.
    */
    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        const app = currentPageReference && currentPageReference.state && currentPageReference.state.app;
        if (app === 'commeditor') {
            this.publishStatus = 'Draft';
        } else {
            this.publishStatus = 'Live';
        }
    }

    // Add code
    handleClick(evt) {
        // use the NavigationMixin from lightning/navigation to perform the navigation.
        evt.stopPropagation();
        evt.preventDefault();
        if (this.pageReference) {
            this[NavigationMixin.Navigate](this.pageReference);
        } else {
            console.error(`Navigation menu type "${this.item.type}" not implemented for item ${JSON.stringify(this.item)}`);
        }
    }

  
}