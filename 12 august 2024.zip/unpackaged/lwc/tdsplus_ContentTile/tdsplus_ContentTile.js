import { LightningElement, wire, track, api} from 'lwc';
import { getContent, listContent, getRecord, getFieldValue, getContentVersionUrl } from "experience/cmsDeliveryApi";
import siteId from "@salesforce/site/Id";
import communityId from "@salesforce/community/Id";
import IMAGE_SUBLINK from '@salesforce/label/c.TDSPlus_Image_Sublink';
// import getManagedContentByContentKeys from '@salesforce/apex/EI_NI_Website_CmsContent.getManagedContentByContentKeys'

export default class Tdsplus_ContentTile extends LightningElement {

    @api contentKey;
    @track data;
    @track ctaContentKeyList = [];
    label = {
        imageSublink: IMAGE_SUBLINK
    };
    // imageLink = '/tdsplusv1/sfsites/c/cms/delivery/media/';
    imageLink = '';
    title = '';
    description = '';
    buttonLabel = '';
    buttonAction = '';

    @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    onGetContent({ error, data }) {
        if(data) {
            this.data = data;
            console.log('Line 17 -> ');
            console.log('Line 17 data -> '+JSON.stringify(data));
            console.log('Line 17 image content key -> '+data.contentBody.Image.source.ref.contentKey);
            console.log('Line 17 siteId -> '+siteId);
            console.log('Line 17 communityId -> '+communityId);
            console.log('Line 17 end -> ');

            let imageContentKey = data.contentBody.Image.source.ref.contentKey;
            // this.imageLink = this.imageLink + imageContentKey;
            this.imageLink = this.label.imageSublink + imageContentKey;
            this.title = data.contentBody.Title;
            this.description = data.contentBody.Subtitle;
            this.buttonLabel = data.contentBody.Button_1_Label;
            this.buttonAction = data.contentBody.Button_1_Action;
            console.log('Line 17 title -> '+this.title);
            console.log('Line 17 description -> '+this.description);
            console.log('Line 17 buttonLabel -> '+this.buttonLabel);
            console.log('Line 17 buttonAction -> '+this.buttonAction);

        }
        else {
            console.log('Line 17 data not available ');
        }
    }

}