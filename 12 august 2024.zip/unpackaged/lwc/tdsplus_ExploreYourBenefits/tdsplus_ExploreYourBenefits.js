import { LightningElement, wire, api, track} from 'lwc';
import { getContent } from "experience/cmsDeliveryApi";
import siteId from "@salesforce/site/Id";
// import communityId from "@salesforce/community/Id";
// import getManagedContentByContentKeys from '@salesforce/apex/EI_NI_Website_CmsContent.getManagedContentByContentKeys'

export default class Tdsplus_ExploreYourBenefits extends LightningElement {

    // Add salesforce cms content
    @api contentKey;
    @api headingType;
    @api referralUrl;
    @api alternatReferralUrl;
    @api alternateMessage;
    @api isPublicPage;

    @track hasAccess = false;
    @track data;
    @track ctaContentKeyList = [];

    get isHeadingtextNotNull() {
        if(this.headingType!='' && this.headingType!=undefined) {
            return true;
        }
        else {
            return false;
        }
    }

    @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    onGetContent({ error, data }) {
        console.log('Line 16 contentKey -> '+this.contentKey);
        console.log('Line 16 siteId -> '+siteId);
        if(data) {
            this.data = data;
            console.log('Line 25 -> ');
            console.log('Line 25 -> '+JSON.stringify(data));
            let cmsCtaObjectList = data.contentBody['sfdc_cms:collection'];
            let ctaContentKeyList = [];
            for(let cmsImage of cmsCtaObjectList) {
                ctaContentKeyList.push(cmsImage.contentKey);
            }
            this.ctaContentKeyList = ctaContentKeyList;
            
            console.log('Line 25 ctaContentKeyList -> '+JSON.stringify(ctaContentKeyList));
            console.log('Line 25 end -> ');
        }
        else {
            console.log('Line 25 data not available ');
        }
    }

    connectedCallback() {
        console.log('Line 58 -> ');
        console.log('Line 58 document referrer -> '+document.referrer);
        console.log('Line 58 ni referrer link -> '+this.referralUrl);
        let currentReferralUrl = document.referrer;
        // Get the referral URL
        // this.referralUrl = document.referrer;

        // if(currentReferralUrl.startsWith(this.referralUrl) || currentReferralUrl.startsWith('https://thedisputeservice--partcopy.sandbox.builder.salesforce-experience.com/') ) {
        console.log('Line 62 -> '+this.isPublicPage);
        console.log('Line 62 -> '+typeof this.isPublicPage);
        if(!this.isPublicPage) {
            if((this.referralUrl!=undefined && this.referralUrl!='' && currentReferralUrl.startsWith(this.referralUrl) ) || 
            (this.alternatReferralUrl!=undefined && this.alternatReferralUrl!='' && currentReferralUrl.startsWith(this.alternatReferralUrl) ) || 
            currentReferralUrl.startsWith('https://thedisputeservice--fullcopy.sandbox.builder.salesforce-experience.com/') )
            {
                this.hasAccess = true;
            }
        }
        else {
            this.hasAccess = true;
        }
    } 

}