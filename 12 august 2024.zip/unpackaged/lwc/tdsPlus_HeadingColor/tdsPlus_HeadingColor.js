import { LightningElement, api } from 'lwc';

/**
 * @slot Content-Region
*/
export default class TdsPlus_HeadingColor extends LightningElement {
    // Expose properties to parent components
    @api firstheadingsection;
    @api changePrimaryHeadingcolor = false;
    @api secondheadingsection;
    @api changeSecondryHeadingcolor = false;
    @api description;
    @api btn_01_text='';
    @api btn_01_link;
    


    get isButtontextNotNull(){
        if(this.btn_01_text==null || this.btn_01_text==''){
            return false;
        }
        else{
            return true;
        }
    }

}