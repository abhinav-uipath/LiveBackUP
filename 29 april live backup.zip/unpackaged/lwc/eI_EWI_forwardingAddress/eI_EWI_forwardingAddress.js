import { LightningElement, track, api } from 'lwc';
import updateAddress from '@salesforce/apex/eI_EWI_forwardingAddressCls.updateAddress';

export default class EI_EWI_forwardingAddress extends LightningElement {

   @api allocationList;
   @api tenantName;
   @track showEmailInputValue = false;
   @track showEmailInput = false; // is email Contains question?
   @track emailAddress;
   @track selectForwardingAddress = false; // to show address contains question
   @track showAddInputValue = false;
   @track showAddInput = false; // is Address Contains question?
   @track houseName;
   @track streetName;
   @track cityName;
   @track countryName;
   @track postCode;

   get isShowContinueBtn(){
      if((this.showEmailInputValue && !this.showEmailInput && this.showAddInputValue && !this.showAddInput) || 
         (this.showEmailInput && this.emailAddress) ||
         (this.showAddInput && this.houseName && this.streetName && this.cityName && this.countryName && this.postCode) )
      {
         return true;
      }else{
         return false;
      }
   }

   selectEmailAddress(){
      this.showEmailInputValue = true;
      this.showEmailInput = true;
      this.selectForwardingAddress = false;
      this.showAddInput = false;
      this.emailAddress = '';
      this.houseName = '';
      this.streetName = '';
      this.cityName = '';
      this.countryName = '';
      this.postCode = '';
      this.template.querySelector('.is-email-yes-btn').classList.add('bg-color-blue'); 
      this.template.querySelector('.is-email-no-btn').classList.remove('bg-color-blue');
   }

   noEmailAddress(){
      this.showEmailInputValue = true;
      this.showEmailInput = false;
      this.selectForwardingAddress = true;
      this.template.querySelector('.is-email-yes-btn').classList.remove('bg-color-blue'); 
      this.template.querySelector('.is-email-no-btn').classList.add('bg-color-blue');
   }

   handleShowAddInput(){
      this.showAddInputValue = true;
      this.showAddInput = true;
      this.emailAddress = '';
      this.houseName = '';
      this.streetName = '';
      this.cityName = '';
      this.countryName = '';
      this.postCode = '';
      this.template.querySelector('.is-address-yes-btn').classList.add('bg-color-blue'); 
      this.template.querySelector('.is-address-no-btn').classList.remove('bg-color-blue');
   }

   handleHideAddInput(){
      this.showAddInputValue = true;
      this.showAddInput = false;
      this.template.querySelector('.is-address-yes-btn').classList.remove('bg-color-blue'); 
      this.template.querySelector('.is-address-no-btn').classList.add('bg-color-blue');
   }

   handleInputValueChange(event){
      console.log("name => " + event.target.name);
      console.log("value => " + event.target.value);
      this[event.target.name] = event.target.value;
   }

   handleContinue(event){
      console.log('emailaddress => ' + this.emailAddress);
      console.log('houseName => ' + this.houseName);
      console.log('streetName => ' + this.streetName);
      console.log('cityName => ' + this.cityName);
      console.log('postCode => ' + this.postCode);
      console.log('Id Account => ' + this.allocationList[0].Account__c);
      updateAddress({
         AccountId : this.allocationList[0].Account__c,
         showEmailInput : this.showEmailInput?'Yes':'No',
         showAddInput : this.showAddInput?'Yes':'No',
         emailAddress : this.emailAddress,
         houseName : this.houseName,
         streetName : this.streetName,
         cityName : this.cityName,
         countryName : this.countryName,
         postCode : this.postCode
      }).then(result=>{
         console.log('updateAddress result => ' + result);
         //write all logic here 
         var allocationList = this.allocationList;
         console.log('allocationList => ' + JSON.stringify(allocationList));
         console.log('allocationList length => ' + allocationList.length);
         if(allocationList.length == 1 || allocationList.length < 1){
            console.log('if length is 1 => ' + allocationList.length);

            event.preventDefault();
            const myEvent = new CustomEvent('hidecmp', {});
            this.dispatchEvent(myEvent);
         }else{
            console.log("has another tenant");
            var newAllocationList = [];
            for(let i=1; i<allocationList.length; i++){
               newAllocationList.push(allocationList[i]);
            }
            console.log('if length is greater then 1')
            this.allocationList = newAllocationList;
            let tenant = newAllocationList[0].Account__r.Name;
            this.tenantName = tenant;
            this.houseName = '';
            this.streetName = '';
            this.cityName = '';
            this.countryName = '';
            this.postCode = '';
            this.emailAddress = '';
            this.showEmailInput = false;
            this.selectForwardingAddress = false;
            this.showAddInput = false;
        }
      }).catch(error=>{
         console.log('updateAddress error => ' + JSON.stringify(error));
         console.log('updateAddress error => ' + error);
      });
      action.setParams({
          
      });
   }
}