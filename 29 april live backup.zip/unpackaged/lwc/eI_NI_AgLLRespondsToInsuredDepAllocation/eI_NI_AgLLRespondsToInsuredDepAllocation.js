import { LightningElement,track,wire } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin,CurrentPageReference } from 'lightning/navigation';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import getCaseDepositDetails from '@salesforce/apex/EI_NI_AgLLRespondsToInsuredDeposit.getCaseDepositDetails';
import agllDeductionYesButton from '@salesforce/apex/EI_NI_AgLLRespondsToInsuredDeposit.agllDeductionYesButton';
import agllDeductionNoButton from '@salesforce/apex/EI_NI_AgLLRespondsToInsuredDeposit.agllDeductionNoButton';

export default class EI_NI_AgLLRespondsToInsuredDepAllocation extends NavigationMixin(LightningElement) {
    //backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    homeImg= NI_Theme + '/assets/img/home_icon.png';
    pound_icon = NI_Theme +'/assets/img/pound_icon.png';
    successImage = NI_Theme +'/assets/img/circle_checked_icon.png';
    backBtnImg = NI_Theme + '/assets/img/md-arrow-dropleft.png';

    isNoDeductionSection = false;
    isYesDeductionSection = false;
    isProposalSection = false;
    YesSummarySection = false;
    isThankyouSection = false;
    isNoDeductionThankYou = false;
    isYesDeductionThankyou = false;
    isShowMainPropoSection = true;
    isShowOtherText = false;
    isOtherTextToSummary = false;
    @track amtMorethanDepAmtError = false;
    PageSpinner = false;
    @track otherAmtValidationError = false;
    @track otherAmtexplaError = false;
    @track agreeDedButamtToAgllZeroError = false;
    @track amtDetail={cleanAmt:0.00,damageAmt:0.00,redecorationAmt:0.00,gardeningAmt:0.00,arrearsAmt:0.00,otherAmt:0.00,remainderAmt:0,totalAmtToTenant:0,totalDeposit:0};
    @track claimedItems=[];
    @track desputeItemsList=[];
    @track AmtToAgll = 0.00;
    @track AmtToTenant = 0.00;
    @track OtherAmtReason='';
    @track amtToTTAgLL = 0.00;
    @track depositAmount = 0.00;
    @track respondDate;
    @track tenancyEndDate;
    @track agllName;
    @track amtToTTbyTT =0.00;

    // Code stared EID-137
    @track claimexceedamount = 0.00;
    @track newclaimexceedamount = 0.00;
    @track claimexceedYES = false;
    @track claimexceedNO = false;
    @track showclaimexceeddetails = false;
    @track claimexceedbuttonselected = false;
    @track claimexceedbuttonselectedrequired = false;
    @track claimexceedenteramountrequired = false;
    @track showExceedAmountFieldToForm = false;
    // Code ended EID-137

    depositRecId;
    caseId;
    branchId = null;
    @wire(CurrentPageReference)
    currentPageReference;
    connectedCallback(){
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = atob(depositRecId);
       
       console.log('DepositId==>'+this.depositRecId);
       
        Promise.all([
            loadStyle(this, `${NI_Theme }/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme +'/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme +'/assets/js/custom.js')
        ])
        .then(() => {
            console.log('Files loaded.');
        })
        .catch(error => {
            console.log(error.body.message);
        });  

        getCaseDepositDetails({depositId: this.depositRecId})
        .then(result=>{
            if (result != null) {
                console.log('DepositDetails==>'+JSON.stringify(result));
                this.depositAmount = (result[0].Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2);
                this.caseId = result[0].Id;
                this.respondDate = formatDate(result[0].Respond_Date__c, "ddmmyy"); // format respondDate as "30/04/2023"
                this.tenancyEndDate = formatDate(result[0].Deposit_Account_Number__r.End_Date__c, "ddS mmmm yyyy"); // format tenancyEndDate as "30th April 2023"
                this.agllName =result[0].Deposit_Account_Number__r.Customer__r.Name;
                this.amtToTTbyTT = result[0].Amount_to_tenants__c;

              }
              
              function formatDate(dateString, format) {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) {
                  return "Invalid Date";
                }
                const day = date.getDate();
                const month = date.toLocaleString('default', { month: 'long' });
                const year = date.getFullYear();
                const suffix = getDaySuffix(day); // get the day suffix (st, nd, rd, th)
                if (format === "ddmmyy") {
                  const dayStr = String(day).padStart(2, '0');
                  const monthStr = String(date.getMonth() + 1).padStart(2, '0');
                  return `${dayStr}/${monthStr}/${year.toString()}`;
                } else if (format === "ddS mmmm yyyy") {
                  return `${day}${suffix} ${month} ${year}`;
                } else {
                  return "Invalid Format";
                }
              }
              
              function getDaySuffix(day) {
                if (day >= 11 && day <= 13) {
                  return "th";
                }
                switch (day % 10) {
                  case 1:
                    return "st";
                  case 2:
                    return "nd";
                  case 3:
                    return "rd";
                  default:
                    return "th";
                }
              }
              var urlString = window.location.search;
              var urlParams = new URLSearchParams(urlString);
              if (urlParams != undefined) {
                  var branchrecId = urlParams.get('branchRecId');
                  if (branchrecId != null) {
                      this.branchId = atob(branchrecId);
                      console.log('BranchId==>'+this.branchId);
                  }
              }
              
        })
        .catch(error=>{
            console.log(JSON.stringify(error));
        });
    }
    handleContinueProposal(event){
        this.isProposalSection = true;
        this.isShowMainPropoSection = false;
    }
    handleOnYesClick(event){
        this.isProposalSection = true;
        this.isYesDeductionSection = true;
        this.isNoDeductionSection = false;
        let AgreeBtn = this.template.querySelector('[name="tenacyEnd_yes"]'); 
        AgreeBtn.style.backgroundColor = '#13185C';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('[name="tenacyEnd_No"]').style = '';
        // Code stared EID-137
        setTimeout(() => {
        if(this.showExceedAmountFieldToForm == true){               
            let exccedBtnYes = this.template.querySelector('[name="property_yes1"]'); 
            exccedBtnYes.style.backgroundColor = '#13185C';
            exccedBtnYes.style.color = '#fff';
            this.template.querySelector('[name="property_no1"]').style = '';
        
        } else if(this.claimexceedNO == true){
            let exccedBtnNo = this.template.querySelector('[name="property_no1"]'); 
            exccedBtnNo.style.backgroundColor = '#13185C';
            exccedBtnNo.style.color = '#fff';
            this.template.querySelector('[name="property_yes1"]').style = '';
        }
        }, 100); 
        // Code ended EID-137
    }
    handleOnNoClick(event){
        this.isYesDeductionSection = false;
        this.isProposalSection = true;
        this.isNoDeductionSection = true;
        let AgreeBtn = this.template.querySelector('[name="tenacyEnd_No"]'); 
        AgreeBtn.style.backgroundColor = '#13185C';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('[name="tenacyEnd_yes"]').style = '';
    }
       //Code Started EID-137 
       removeError(event) {
        var value = event.target.value;
        if(value != 0 || value != null || value != undefined || value != this.newclaimexceedamount){
        this.claimexceedenteramountrequired = false;
        } else {
            this.claimexceedenteramountrequired = true;
        }
    }
    restrictDecimal1(event) {  
        var t = event.target.value;
        return (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t
        
        // if(t.includes(".")){
        //     var arr = t.split(".");
        //     var lastVal = arr.pop();
        //     var arr2 = lastVal.split('');
        //     if (arr2.length > '1') {
        //         event.preventDefault();
        //     }
        // }
    }
    //Code Ended EID-137 
    restrictDecimal(event) {
        const t = event.target.value;
        const charCode = (event.which) ? event.which : event.keyCode;
        const decimalIndex = t.indexOf('.');
      
        // Allow only one decimal point
        if (charCode === 46 && decimalIndex !== -1) {
          event.preventDefault();
        }
      
        // Allow only digits and a decimal point
        else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
          event.preventDefault();
        }
      
        // Allow only up to two digits after the decimal point
        else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
          event.preventDefault();
        }
      }
    
    removeZero(event) {
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }
  
    calculateRemainder(event){
        this.amtMorethanDepAmtError = false;
        this.agreeDedButamtToAgllZeroError = false;
        let TenantAmt=0.00;
        if(event.target.name==='cleaning'){
            this.amtDetail.cleanAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='DamageToProperty'){
            this.amtDetail.damageAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='redecorationAmt'){
            this.amtDetail.redecorationAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='gardeningAmt'){
            this.amtDetail.gardeningAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='arrearsAmt'){
            this.amtDetail.arrearsAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='otherAmt'){
            this.amtDetail.otherAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='AmtToTenant'){
           // this.AmtToTenant=parseFloat( event.target.value).toFixed(2);
           this.AmtToTenant = event.target.value.trim() !== '' ? parseFloat(event.target.value).toFixed(2) : 0.00;
        }
        if(this.amtDetail.otherAmt > 0){
            this.isShowOtherText = true;
        }
        else{
            this.isShowOtherText = false;
            this.otherAmtValidationError = false;
            this.otherAmtexplaError = false;
        }
        console.log('this.amtDetail.cleanAmt=>'+this.amtDetail.cleanAmt);
        console.log('this.amtDetail.damageAmt=>'+this.amtDetail.damageAmt);
        console.log('this.amtDetail.redecorationAmt=>'+this.amtDetail.redecorationAmt);
        console.log('this.amtDetail.gardeningAmt=>'+this.amtDetail.gardeningAmt);
        console.log('this.amtDetail.arrearsAmt=>'+this.amtDetail.arrearsAmt);
        console.log('this.amtDetail.otherAmt=>'+this.amtDetail.otherAmt);
        console.log('this.amtToTnt=>'+this.AmtToTenant);

        var clnAmt=this.amtDetail.cleanAmt;
        var dmgAmt = this.amtDetail.damageAmt;
        var garAmt = this.amtDetail.gardeningAmt;
        var redAmt= this.amtDetail.redecorationAmt;
        var arrAmt= this.amtDetail.arrearsAmt;
        var othAmt = this.amtDetail.otherAmt;

        //this.AmtToAgll = 0.00;
        let total=0.00;

        if(clnAmt != null && clnAmt != NaN && clnAmt>=0 && clnAmt != '') {
            total+= parseFloat(clnAmt); 
        }
        if(dmgAmt != null && dmgAmt != NaN && dmgAmt>=0 && dmgAmt != '') {
            total+= parseFloat(dmgAmt); 
        }
        if(garAmt != null && garAmt != NaN && garAmt>=0 && garAmt != '') {
            total += parseFloat(garAmt); 
        }
        if(redAmt != null && redAmt != NaN && redAmt>=0 && redAmt != '') {
            total += parseFloat(redAmt); 
        }
        if(arrAmt != null && arrAmt != NaN && arrAmt>=0 && arrAmt != '') {
            total+= parseFloat(arrAmt); 
        }
        if(othAmt != null && othAmt != NaN && othAmt>=0 && othAmt != '') {
            total += parseFloat(othAmt); 
        }
        this.AmtToAgll = total.toFixed(2);
        console.log('amtToAgLL==>'+ this.AmtToAgll);

        this.amtToTTAgLL = parseFloat(this.AmtToAgll)+parseFloat(this.AmtToTenant);
        console.log('amtToTTandAgLL==>'+this.amtToTTAgLL );
    }
    handleGotoReviewPage(event){
        this.amtMorethanDepAmtError = false;
        //this.isOtherTextToSummary = false;
        this.otherAmtValidationError = false;
        this.agreeDedButamtToAgllZeroError = false;
        let isValid = true;
        if(this.amtDetail.otherAmt >0 && this.OtherAmtReason ==""){// (|| this.OtherAmtReason == undefined || this.otherAmtReason == null)){
            this.otherAmtValidationError = true;
            console.log('Line-189==>'+this.OtherAmtReason);
            console.log('Line-190==>'+this.amtDetail.otherAmt);
            isValid = false;
        }
        else{
            this.otherAmtValidationError = false;
        }
     
        if(this.amtDetail.otherAmt > 0 && this.OtherAmtReason.length>300 ){
            this.otherAmtexplaError = true;
            isValid = false;
        }
        else{
            this.otherAmtexplaError = false;
        }
        if(this.amtToTTAgLL !=this.depositAmount){
            this.amtMorethanDepAmtError = true;
            isValid = false;
        }
        else{
            this.amtMorethanDepAmtError = false;
        }
        // code stared EID-137 
        if(this.claimexceedbuttonselected==false){
            isValid = false;  
            this.claimexceedbuttonselectedrequired = true;
            this.template.querySelector(".errorMsgDiv2").scrollIntoView();
        }
        else{
            this.claimexceedbuttonselectedrequired = false; 
        }

        if( this.claimexceedbuttonselected==true && this.claimexceedYES==true &&  (this.claimexceedamount==0 || this.claimexceedamount == null
            || this.claimexceedamount == undefined || this.claimexceedamount == ' '  ))
            {    isValid = false;  
                this.claimexceedenteramountrequired = true;
                this.template.querySelector(".errorMsgDiv1").scrollIntoView();
            }
            else { 
                this.claimexceedenteramountrequired = false; 
            }

            // code ended EID-137 
        if(this.AmtToAgll <=0){
            this.agreeDedButamtToAgllZeroError = true;
            isValid = false;
        }
        else{
            this.agreeDedButamtToAgllZeroError = false;
        }
        this.desputeItemsList = [];
        if (this.amtDetail.cleanAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.cleanAmt).toFixed(2), key: 'Cleaning' });
        }
        
        if (this.amtDetail.damageAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.damageAmt).toFixed(2), key: 'Damage' });
        }
        
        if (this.amtDetail.gardeningAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.gardeningAmt).toFixed(2), key: 'Gardening' });
        }
        
        if (this.amtDetail.redecorationAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.redecorationAmt).toFixed(2), key: 'Redecoration' });
        }
        
        if (this.amtDetail.arrearsAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.arrearsAmt).toFixed(2), key: 'Rent arrears' });
        }
        
        if (this.amtDetail.otherAmt > 0) {
            this.desputeItemsList.push({ value: parseFloat(this.amtDetail.otherAmt).toFixed(2), key: 'Other' });
        }
        
        console.log('disputeItemsList==>'+ JSON.stringify(this.desputeItemsList));

         if(isValid){
            this.YesSummarySection = true;
            this.isProposalSection = false;
            this.amtMorethanDepAmtError = false;
           // this.isOtherTextToSummary = false;
            this.otherAmtValidationError = false;
            // code started EID-137 
            if(this.claimexceedYES==true && this.newclaimexceedamount>0){
            this.showclaimexceeddetails = true;

            }
            else{
                this.showclaimexceeddetails = false; 

            }
            // code ended EID-137 
            if(this.amtDetail.otherAmt > 0 &&(this.OtherAmtReason !="" || this.OtherAmtReason!= undefined || this.otherAmtReason != null)){
                this.isOtherTextToSummary = true;
            }
            else{
                this.isOtherTextToSummary = false;
            }
         
         }
    }
    
    validateOtherAmt(event){
        this.otherAmtValidationError = false;
        this.otherAmtexplaError = false;
        if (this.isShowOtherText) {
            this.OtherAmtReason = event.target.value.trim();
          } 
        console.log('otherReason==>'+this.OtherAmtReason);
    }

    handleNoDeductionSubmit(event){
        this.PageSpinner = true;
        console.log('amtToTTbyTenant==>'+this.amtToTTbyTT);
        agllDeductionNoButton({depositId:this.depositRecId,caseId:this.caseId,
            depositAmount:this.depositAmount,agreedAmount:this.amtToTTbyTT,branchId:this.branchId})
        .then(result=>{
            if(result =='Success'){
                this.PageSpinner = false;
                this.isProposalSection = false;
                this.YesSummarySection = false;
                this.isThankyouSection = true;
                this.isNoDeductionThankYou = true;
            }
        })
        .catch(error=>{
            console.log('errorfromNo=>'+JSON.stringify(error));
            console.log('error=>'+error);
        });
        
    }

    submitProposal(event){
        this.PageSpinner = true;
        console.log('Yes submit clicked');
        var objectofMap = {};
        
        for(let ind in this.desputeItemsList){
            if(this.desputeItemsList[ind]){
                objectofMap[this.desputeItemsList[ind].key] = this.desputeItemsList[ind].value;
            }
            console.log("key => " + this.desputeItemsList[ind].key);
            console.log("value => " + this.desputeItemsList[ind].value);
            console.log("objectofMap => " + JSON.stringify(objectofMap));
        }
        var objectofMapstr = JSON.stringify(objectofMap);
        console.log('claimedItems==>'+JSON.stringify(this.desputeItemsList));
         const claimedItemsString = JSON.stringify(this.desputeItemsList);
         console.log('claimedItemsString==>'+claimedItemsString);
         console.log('claimedAmount'+this.newclaimexceedamount);
         //console.log('otherAmtReason==>'+this.OtherAmtReason);
        agllDeductionYesButton({depositId:this.depositRecId,caseId:this.caseId,claimedItems:objectofMapstr,
                                othReason:this.OtherAmtReason,amtToAgLL:this.AmtToAgll,amtToTenant:this.AmtToTenant,initiatedBy:'',branchId:this.branchId, claimamount :this.newclaimexceedamount}) //EID-137
        .then(result=>{
            if(result=='Success'){
                this.PageSpinner = false;
                this.isProposalSection = false;
                this.YesSummarySection = false;
                this.isThankyouSection = true;
                this.isYesDeductionThankyou = true;
            }

        })
        .catch(error=>{
            console.log('error@@=>'+JSON.stringify(error));
            console.log('error==>'+JSON.stringify(result));
        });
        
    }
    goBackToPropSec(event){
        event.preventDefault();
        
        this.isProposalSection = true;
        this.isYesDeductionSection = true;
        this.isNoDeductionSection = false;
        this.YesSummarySection = false;
        setTimeout(() => {
            let AgreeBtn = this.template.querySelector('[name="tenacyEnd_yes"]'); 
            AgreeBtn.style.backgroundColor = '#13185C';
            AgreeBtn.style.color = '#fff';
            this.template.querySelector('[name="tenacyEnd_No"]').style = '';
            // Code stared EID-137
            if(this.showExceedAmountFieldToForm == true){
            let exccedBtnYes = this.template.querySelector('[name="property_yes1"]'); 
            exccedBtnYes.style.backgroundColor = '#13185C';
            exccedBtnYes.style.color = '#fff';
            this.template.querySelector('[name="property_no1"]').style = '';
            }else{
                let exccedBtnNo = this.template.querySelector('[name="property_no1"]'); 
                exccedBtnNo.style.backgroundColor = '#13185C';
                exccedBtnNo.style.color = '#fff';
                this.template.querySelector('[name="property_yes1"]').style = '';
            }
            // Code ended EID-137
        }, 100);    

    }
    goBackHandle(event){
        console.log('eee');
        console.log(event);
        event.preventDefault();
        // event.stopPropagation(); 
        // window.history.back();
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = atob(depositRecId);
        if(this.branchId != null || this.branchId !=undefined){
           // var branchId = atob(this.branchId);
            window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositRecId)+'&branchRecId='+window.btoa(this.branchId);
            
        }
        else{
            window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositRecId);
            console.log('eee429');
        }
    }

     // Code stared EID-137
     showExceedAmountField(){
        this.claimexceedYES = true;
        this.claimexceedNO = false;
        this.showExceedAmountFieldToForm = true;
        this.claimexceedbuttonselected = true;
        this.claimexceedbuttonselectedrequired = false;
        // this.template.querySelector('.amt-recv-yes1-btn1').classList.add('bg-color-blue'); 
        // this.template.querySelector('.amt-recv-no1-btn1').classList.remove('bg-color-blue');
        let exccedBtnYes = this.template.querySelector('[name="property_yes1"]'); 
        exccedBtnYes.style.backgroundColor = '#13185C';
        exccedBtnYes.style.color = '#fff';
        this.template.querySelector('[name="property_no1"]').style = '';
    }

    hideExceedAmountField(){
        this.claimexceedamount = 0;
        this.newclaimexceedamount = 0;
        this.claimexceedYES = false;
        this.claimexceedNO = true;
        this.showExceedAmountFieldToForm = false;
        this.claimexceedbuttonselected = true;
        this.claimexceedbuttonselectedrequired = false;
        // this.template.querySelector('.amt-recv-no1-btn1').classList.add('bg-color-blue'); 
        // this.template.querySelector('.amt-recv-yes1-btn1').classList.remove('bg-color-blue');
        let exccedBtnNo = this.template.querySelector('[name="property_no1"]'); 
        exccedBtnNo.style.backgroundColor = '#13185C';
        exccedBtnNo.style.color = '#fff';
        this.template.querySelector('[name="property_yes1"]').style = '';
    }

    CalculateExceedClaimAmount(event){
        let val = this.restrictDecimal1(event);
        event.target.value = val;
        this.claimexceedamount = event.target.value;
        this.newclaimexceedamount = this.claimexceedamount;
    }
    // Code ended EID-137
}