import { LightningElement, api, track, wire } from 'lwc';
import trendingarticleNewList from '@salesforce/apex/Ei_Ni_Trending_Article_Controller.trendingarticleNewList';
 
 
export default class TrendingArticlesList extends LightningElement {
 
    //create local variable
    @track conList;
    @track error;

    @api isTrendingArticleForNews = false;
 
    //calling Mathod from Apex class
    // @wire (trendingarticleNewList, {isTrendingArticleForNews: this.isTrendingArticleForNews} ) 
    // @wire (trendingarticleNewList) 
    // newLocalMethod({ error,data })
    // {
    //     console.log('Line 18 trendingArticlesList -> '+data);
    //     if(data) {
    //         console.log('Line 18 trendingArticlesList data'+JSON.stringify(data));
    //         this.conList = data.map(dataVal => {
    //             return {
    //                 ...dataVal,
    //                 LinkUrlName: '/nitds1/article/'+ dataVal.UrlName

    //             }
    //         })
    //         console.log('data Are Coming');
    //     }
    //     if(error) {
    //         this.error=error;
    //     }
    // }

    connectedCallback() {
        // Apex call for trending articles/news
        trendingarticleNewList({ isTrendingArticleForNews: this.isTrendingArticleForNews })
            .then(result => {
                console.log('Line 39 trendingArticlesList -> '+JSON.stringify(result));
                if(result.length>0) {
                    this.conList = result.map(article => { 
                                                return {
                                                    ...article,
                                                    LinkUrlName: '/nitds1/article/'+ article.UrlName
                                                }
                                            });
                }
                console.log('Line 46 trendingArticlesList conList -> '+JSON.stringify(this.conList));
            })
            .catch(error => {
                console.error('Error retrieving dynamic buttons:'+error);
            });
    }
 
}