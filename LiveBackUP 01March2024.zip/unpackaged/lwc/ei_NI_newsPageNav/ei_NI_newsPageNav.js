import { LightningElement, track, wire,api } from 'lwc';
import getNewsCategories from '@salesforce/apex/EI_NI_websitehelpcenterapx.getNewsCategories';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';
import newsChannel from '@salesforce/messageChannel/newsChannel__c';
import { publish, MessageContext } from 'lightning/messageService';
export default class Ei_NI_newsPageNav extends NavigationMixin(LightningElement) {
    @api newsCategoryPage;
    @track records=[];
    @track error;
    @track baseurl = "/nitds1/news/";
    @track url;
    @track selectedNewsCategory;
    @track isKnowledgePage = false;

   

    @wire(MessageContext)
    messageContext;

    @wire(CurrentPageReference)
    getPageReferenceParameters(currentPageReference) {
        this.isKnowledgePage = false;
        if (currentPageReference) {
            console.log('Line 29 currentPageReference -> '+JSON.stringify(currentPageReference));
            //   this.recordId = currentPageReference.attributes.recordId || null;
            //   let attributes = currentPageReference.attributes;
            //   let states = currentPageReference.state;
            //   let type = currentPageReference.type;
            
            let pageName = currentPageReference.attributes.objectApiName;
            console.log('Line 39 pageName -> '+pageName);
            if(pageName!=undefined && pageName=='Knowledge__kav') {
                this.isKnowledgePage = true;
            }
            console.log('Line 39 isKnowledgePage -> '+this.isKnowledgePage);
            if(pageName==undefined){
                console.log('selectedNewsCategory in getPageReferenceParameters-->');
                this.selectedNewsCategory=this.newsCategoryPage;
                console.log('selectedNewsCategory value in getPageReferenceParameters-->'+this.selectedNewsCategory);
            }
        }
    }


   
    connectedCallback() {
       console.log('selectedNewsCategory in cc-->'+this.selectedNewsCategory);
       if(this.selectedNewsCategory==undefined || this.selectedNewsCategory==this.newsCategoryPage){
        this.selectedNewsCategory=this.newsCategoryPage;
        console.log('selectedNewsCategory insie undefined loop-->'+this.selectedNewsCategory);
       }
        const url = new URL(window.location.href);
        let categoryFromUrl;
        let buttonNameToMakeActive = 'news';
    
        // Parse the URL and get the category after the URL is fully initialized
        Promise.resolve(url).then(parsedUrl => {
            categoryFromUrl = parsedUrl.pathname.split('/').pop(); // Extract the last part of the path
            console.log('categoryFromUrl 89-->' + categoryFromUrl);
         
        let selectedCategoryFromStorage = localStorage.getItem('selectedNewsCategory') || 'News';
        console.log('selectedCategoryFromStorage in cc-->'+selectedCategoryFromStorage);
            
        getNewsCategories()
            .then(result => {
                buttonNameToMakeActive = result[0].Name;

                categoryFromUrl && result.some(record => {
                    const transformedCategory = record.Name.toLowerCase().replace(/\s+/g, '-');
                    const match = transformedCategory === categoryFromUrl;
                    console.log(`Transformed Category: ${transformedCategory}, Match: ${match}`);
                    return match;
                });

                function convertToOriginalFormat(urlString) {
                    const words = urlString.split('-');
                    //const originalFormat = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
                    let originalFormat=words.join(' ');
            
                    return originalFormat.toLowerCase();
                }
                console.log('convertToOriginalFormat-->'+convertToOriginalFormat(categoryFromUrl));
    
                 if (convertToOriginalFormat(categoryFromUrl) && result.some(record => record.Name.toLowerCase() === convertToOriginalFormat(categoryFromUrl))) {
                    // Use the URL parameter only if it matches a valid category
                    buttonNameToMakeActive = convertToOriginalFormat(categoryFromUrl);
                    //this.selectedNewsCategory=buttonNameToMakeActive;
                    console.log('buttonNameToMakeActive 100-->'+buttonNameToMakeActive);
                }
                else if (selectedCategoryFromStorage && result.some(record => record.Name === selectedCategoryFromStorage)) {
                    // Use the category from local storage if it matches a valid category
                    // this is commented to get default news button
                   // buttonNameToMakeActive = selectedCategoryFromStorage.toLowerCase();
                   buttonNameToMakeActive=this.newsCategoryPage;
                    
                    console.log('buttonNameToMakeActive 104-->'+buttonNameToMakeActive);
                }
    
                for (let record of result) {
                    let recordToPush = {};
    
                    if (buttonNameToMakeActive == record.Name.toLowerCase()) {
                        recordToPush = { Name: record.Name, Id: record.Id, activeButton: 'button active' };
                        this.selectedNewsCategory= record.Name;
                    } else {
                        recordToPush = { Name: record.Name, Id: record.Id, activeButton: 'button' };
                    }
    
                    this.records.push(recordToPush);
                }
                console.log('records-->'+JSON.stringify(this.records));
            })
            .catch(error => {
                console.error('Error retrieving dynamic buttons:', error);
            });
        });
    }
    
    updateUrl() {
        for(let urlData of this.records){
            if(urlData.Name==this.selectedNewsCategory){
                this.url = this.baseurl + urlData.Name.toLowerCase().replace(/\s+/g, '-');
            }
        }
    }
    

    handleNewsArticleTypeSelection(event) {
        let newsRec = {
            currentPage: 1
            
        };
        publish(this.messageContext, newsChannel, newsRec);
        const selectedButtonName = event.target.name;
        this.selectedNewsCategory = selectedButtonName;
        localStorage.setItem('selectedNewsCategory', this.selectedNewsCategory);
        this.records = this.records.map(record => ({
            ...record,
            activeButton: record.Name === selectedButtonName ? 'button active' : 'button'
        }));
        event.preventDefault();
        console.log(' event.target.name-->'+ event.target.name);
        this.updateUrl();
        console.log(' url-->'+ this.url);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: this.url
            }
        })

    }
    handleNewsButton(event){
        let newsRec = {
            currentPage: 1
            
        };
        publish(this.messageContext, newsChannel, newsRec);
        event.preventDefault();
        console.log(' event.target.name-->'+ event.target.name);
        const selectedButtonName = event.target.name;
        this.selectedNewsCategory = selectedButtonName;
        localStorage.setItem('selectedNewsCategory', this.selectedNewsCategory);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url : this.baseurl 
            }
        })
    }
    get buttonClass() {
        return this.selectedNewsCategory === this.newsCategoryPage ? 'button active' : 'button';
    }
}