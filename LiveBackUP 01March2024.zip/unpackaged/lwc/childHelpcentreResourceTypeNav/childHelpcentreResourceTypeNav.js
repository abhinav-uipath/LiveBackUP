import { LightningElement,api,track } from 'lwc';
import { RefreshEvent } from "lightning/refresh";

export default class childHelpcentreResourceTypeNav extends LightningElement {

   // @track articleType='FAQ';
    @track filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'FAQ'};

    @api firstLink;
    @api secondLink;
    @api firstActiveLink;
    @api secondActiveLink;
    @api recordTypeProp;
    @api thirdLink;
    @api thirdActiveLink;
    @api fourthLink;
    @api fourthActiveLink;
    @api linkobject;
    @api resourceNavigationHeading;
    @api resourceNav1stLabel;
    @api resourceNav2ndLabel;
    @api resourceNav3rdLabel;
    @api resourceNav4thLabel;
    @api resourceNav5thLabel;
    // @track show5thLabel=false;
    @track phonelabel;
    @track isDropdownOpen = false;
    connectedCallback() {
        console.log('line 21 childhelpcenterresource');
        console.log('Child component 2 -> '+JSON.stringify(this.linkobject));
        console.log('recordTypeProp-->'+this.recordTypeProp);
        // if(this.resourceNav5thLabel!=null){
        
        //     this.show5thLabel=true;
        // }
       // this.phonelabel=this.filterSelection.recordType;
       // console.log('phonelabel: '+this.phonelabel);
        console.log('resourceNav1stLabel: '+this.resourceNav1stLabel);
        console.log('recordtype in 38-->'+this.filterSelection.recordType);
        if(this.linkobject!=undefined && this.linkobject!=null) {
            this.firstLink = this.linkobject.firstLink;
            this.secondLink = this.linkobject.secondLink;
            this.thirdLink = this.linkobject.thirdLink;
            this.fourthLink = this.linkobject.fourthLink;
            this.firstActiveLink = this.linkobject.firstActiveLink;
            this.secondActiveLink = this.linkobject.secondActiveLink;
            this.thirdActiveLink = this.linkobject.thirdActiveLink;
            this.fourthActiveLink = this.linkobject.fourthActiveLink;
        }
        if(this.recordTypeProp=='FAQ') {
            console.log('faq printed');
            this.phonelabel=this.resourceNav1stLabel;
        }
        else if(this.recordTypeProp=='Casestudy') {
            console.log('Casestudy printed');
            this.phonelabel=this.resourceNav2ndLabel;
        }
        else if(this.recordTypeProp=='Guide') {
            console.log('Guide printed');
            this.phonelabel=this.resourceNav3rdLabel;
        }
        else if(this.recordTypeProp=='Template') {
            console.log('Template printed');
            this.phonelabel=this.resourceNav4thLabel;
        }
    }
 
    handleArticleTypeSelection(inputevent) {
        console.log('article');
        inputevent.preventDefault();
        // this.dispatchEvent(new RefreshEvent());
        // window.history.replaceState(stateObj, 
        //     "Page 3", '/'+this.articleType); 

       // this.articleType = inputevent.target.name;
       // console.log('article type: '+this.articleType);
        this.filterSelection.recordType = inputevent.target.name;
        localStorage.setItem('recordType', inputevent.target.name); 
        console.log('line 45 in child: '+this.filterSelection.recordType);
        const event = new CustomEvent('change', {
            detail: { filterSelection: this.filterSelection }
        });                
        this.dispatchEvent(event);  
        console.log('line 50 in child');
       // this.filterSelection = {customerType: inputevent.target.name, productType: this.filterSelection.productType,recordType:this.filterSelection.recordType};
         
        this.firstActiveLink = false;
        this.secondActiveLink = false;
        this.thirdActiveLink = false;
        this.fourthActiveLink = false;
        if(this.filterSelection.recordType=='FAQ') {
            this.firstActiveLink = true;
            console.log('resourceNav1stLabel in child75-->'+this.resourceNav1stLabel);
            this.phonelabel=this.resourceNav1stLabel;
        }
        else if(this.filterSelection.recordType=='Casestudy') {
            this.secondActiveLink = true;
            this.phonelabel=this.resourceNav2ndLabel;
        }
        else if(this.filterSelection.recordType=='Guide') {
            this.thirdActiveLink = true;
            this.phonelabel=this.resourceNav3rdLabel;
        }
        else if(this.filterSelection.recordType=='Template') {
            this.fourthActiveLink = true;
            this.phonelabel=this.resourceNav4thLabel;
        }
      //  const event = new CustomEvent('resourcetypechange', {
        
    }

    get activeRecordTypeFirstStyleClass(){
        return this.firstActiveLink ? 'active': '';
    }

    get activeRecordTypeSecondStyleClass(){
        return this.secondActiveLink ? 'active': '';
    }

    get activeRecordTypeThirdStyleClass(){
        return this.thirdActiveLink ? 'active': '';
    }

    get activeRecordTypefourthStyleClass(){
        return this.fourthActiveLink ? 'active': '';
    }

    nextForm(evet){
        
    }
}