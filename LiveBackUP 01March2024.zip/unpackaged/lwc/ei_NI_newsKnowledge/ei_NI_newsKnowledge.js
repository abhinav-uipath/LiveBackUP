import { LightningElement, wire, track, api } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import NI_website_image_base_url from '@salesforce/label/c.NI_website_image_base_url';
import newsChannel from '@salesforce/messageChannel/newsChannel__c';
import { subscribe, MessageContext } from 'lightning/messageService';
const fields = [
    'Knowledge__kav.News_category__r.Name',
    'Knowledge__kav.Title',
    'Knowledge__kav.Short_Description__c',
    'Knowledge__kav.News_category__c',
    'Knowledge__kav.Publish_Date__c',
    'Knowledge__kav.Image_content_key__c',
    'Knowledge__kav.UrlName'
];

import getKnowledgeNewsAricles from '@salesforce/apex/EI_NI_websitehelpcenterapx.getKnowledgeNewsAricles';

export default class Ei_NI_newsKnowledge extends LightningElement {
    @api recordId;
    @api urlName;
    @track articles;
    @track  labelValue = NI_website_image_base_url;
    @track loadChild=false;
   @track pageCount=1;
   ForRecordName; 

    @track totalRecords=0;
    @track pageSize = 9; // Adjust as needed
    @track currentPage = 1;
    isPageLoaded=[{isLoaded:false}];

    subscription = null;
    @wire(MessageContext)
    messageContext;


    // @wire(getRecord, { recordId: '$recordId' })
    // loadNews({ error, data }) {
    //     console.log('testh '+ this.recordId);
    //     console.log('isPageLoaded 11-->'+this.urlName);
    //     if (data) {            
    //         this.ForRecordName=getFieldValue(data, '    .Id');          
    //     } else if (error) {
    //         console.error('Error loading knowledge:', error);
    //     }
    // }
    

    @wire(getKnowledgeNewsAricles, { urlName: '$urlName', pageNumber: '$currentPage', pageSize: '$pageSize'} )
    loadKnowledgeArticleDetail({ error, data }) {
       // this.loadChild=false;
       console.log('recordId-->'+this.recordId);
       console.log('urlName 53-->'+this.urlName);
        if (data) {
            this.totalRecords=0;
            this.totalRecords = data.totalRecords;
            this.pageCount = Math.ceil(this.totalRecords / this.pageSize);
            
            console.log('totalRecords in parent-->'+this.totalRecords);
            console.log('pageCount in parent-->'+this.pageCount);
            this.articles = data.articles.map(article => ({
                Id: article.Id,
                Title: article.Title,
               Short_Description__c: article.Short_Description__c,
                Link: "/nitds1/article/"+article.UrlName,
               // Publish_Date__c: this.formatDate(article.Publish_Date__c),
                Publish_Date__c: article.Publish_Date__c ? this.formatDate(article.Publish_Date__c) : '', 
                imageUrl: this.labelValue+article.Image_content_key__c
                
            }));
            console.log('articles-->'+JSON.stringify(this.articles));
            this.loadChild=true;
             //localStorage.setItem('articles', JSON.stringify(this.articles));
             

        
        } else {
            console.error('Inside wire error:', error);
        }
        this.calculatePages();
        // this.template.querySelector('c-child-pagination').calculatePages();
    }
    connectedCallback() {
        console.log('hello');
       console.log('recordId in connected callback-->'+this.recordId);
        // const storedArticles = localStorage.getItem('articles');
        // if (storedArticles) {
        //     this.articles = JSON.parse(storedArticles);
            
        // }
        console.log('currentPage in parent-->'+this.currentPage);
        
    }
    renderedCallback(){
        console.log('in rendered callback');
        console.log('In handleSubscribe subscription', JSON.stringify(this.subscription));
        this.subscription = subscribe(this.messageContext, newsChannel, (newsRec) => {
            console.log('message', newsRec);
            console.log('newsRec.currentPage', newsRec.currentPage);
            this.currentPage=1;
        });
        console.log('In handleSubscribe subscription 98', JSON.stringify(this.subscription));
        
    }
    formatDate(isoString) {
        const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
        const date = new Date(isoString);
    
        // Extract the day and add 'th', 'st', 'nd', or 'rd' based on the day
        const day = date.getDate();
        const daySuffix = this.getDaySuffix(day);
        
        // Extract the month
        const month = new Intl.DateTimeFormat('en-US', { month: 'long' }).format(date);
    
        return `${new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(date)}, ${day}${daySuffix} of ${month} ${date.getFullYear()}`;
    }
    
    getDaySuffix(day) {
        if (day >= 11 && day <= 13) {
            return 'th';
        }
        const lastDigit = day % 10;
        switch (lastDigit) {
            case 1:
                return 'st';
            case 2:
                return 'nd';
            case 3:
                return 'rd';
            default:
                return 'th';
        }
    }
    
  

    
    handlePageChange(event) {
        this.currentPage = event.detail;
        console.log('currentPage in event-->'+this.currentPage);
    }
    
    calculatePages() {
        console.log('came to calculatePages--');
        console.log('totalRecords in calculatePages-->'+this.totalRecords);
        this.pages = [];
        // let pageCount = Math.ceil(this.totalRecords / this.pageSize);
       // let pageCount=this.pageCount;
        for (let i = 1; i <= this.pageCount; i++) {
            if(i==this.currentPage){
            this.pages.push({pageCount:i, buttonVariant:'brand'});
            }
            else{
                this.pages.push({pageCount:i, buttonVariant:'neutral'});
                }
        }
        this.disablePrevious = this.currentPage === 1;
        this.disableNext = this.currentPage === this.pageCount || this.pageCount === 0;
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.calculatePages();
            
           // this.dispatchEvent(new CustomEvent('changepage', { detail: this.currentPage }));
        }
    }

    nextPage() {
        let pageCount = Math.ceil(this.totalRecords / this.pageSize);
        console.log('pageCount in nxt button-->'+pageCount);
        if (this.currentPage < pageCount) {
            this.currentPage++;
            this.calculatePages();
          //  this.dispatchEvent(new CustomEvent('changepage', { detail: this.currentPage }));
        }
    }

    changePage(event) {
        this.currentPage = parseInt(event.target.label);
        console.log('currentPage in changePage-->'+this.currentPage);
        this.calculatePages();
       // this.dispatchEvent(new CustomEvent('changepage', { detail: this.currentPage }));
    }

}