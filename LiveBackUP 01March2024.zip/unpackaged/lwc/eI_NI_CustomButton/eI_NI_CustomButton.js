import { LightningElement, api } from 'lwc';

export default class EI_NI_CustomButton extends LightningElement {
   @api buttonName = 'xyz button';
   @api getusertargetvalue= 'https://www.google.com/';
   // @api dynamictarget = this.getusertargetvalue == 'External' ? '_blank': '_parent';

   handleButtonClick(){
      console.log('handleButtonClicked !!');
   }
}