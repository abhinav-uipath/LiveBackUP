import { LightningElement,api,track } from 'lwc';

export default class ChildHelpcentreResourceTypeNavV2 extends LightningElement {    
    @api resourceNavigationHeading;
    @api resourceNav1stLabel;
    @api resourceNav2ndLabel;
    @api resourceNav3rdLabel;
    @api resourceNav4thLabel;
    @api resourceNav5thLabel;
    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api fifthLink;
    @api recordTypeProp;

    //@track filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'FAQ'};    
    @track navList=[];
    @track buttonSelected ;

    connectedCallback() {        
        let arrayOfObjects = [
            { recordType: 'FAQ', active: true, link: this.firstLink, label:this.resourceNav1stLabel },
            { recordType: 'Case Study', active: false, link: this.secondLink, label:this.resourceNav2ndLabel },
            { recordType: 'Guide', active: false, link: this.thirdLink , label:this.resourceNav3rdLabel},
            { recordType: 'Template', active: false, link: this.fourthLink, label: this.resourceNav4thLabel },
            { recordType: 'FifthType', active: false, link: this.fifthLink, label:this.resourceNav5thLabel }
        ];

        console.log('Line 32 recordTypeProp -> '+this.recordTypeProp)
        arrayOfObjects.forEach((item, index) => {
            (item.recordType===this.recordTypeProp)?arrayOfObjects[index].active=true:arrayOfObjects[index].active=false;
            if(item.recordType===this.recordTypeProp) {
                console.log('itemlabel-->'+item.label);
                this.buttonSelected = item.label;
            }
        });

        console.log('started nav2 buttonSelected -> '+this.buttonSelected);
        this.navList = arrayOfObjects;
        console.log(this.navList);
        console.log('started nav2 ended' );
        console.log('this is record type '+this.recordTypeProp);
    }

    handleArticleTypeSelection(inputevent) {           
        inputevent.preventDefault();       
        this.recordTypeProp = inputevent.target.name;
        console.log('Line 24 -> '+this.recordTypeProp);
        // localStorage.setItem('recordType', inputevent.target.name);      
        // localStorage.setItem('filterSelection.productType', this.recordTypeProp);

        // const event = new CustomEvent('change', {
        //     detail: { recordTypeProp: this.recordTypeProp }
        // });            
        // this.dispatchEvent(event);
    }

    @api
    dynamicLoad(Articletype){      
        let arrayOfObjects=navList;  
        console.log('this is record type '+this.recordTypeProp);
        arrayOfObjects.forEach((item, index) => {
            (item.recordType===this.recordTypeProp)?arrayOfObjects[index].active=true:arrayOfObjects[index].active=false;            
            });
        this.navList=arrayOfObjects;
    }

}