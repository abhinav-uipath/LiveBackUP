import { LightningElement, api, wire } from 'lwc';
import { getRecord, updateRecord } from 'lightning/uiRecordApi';
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CloseActionScreenEvent } from 'lightning/actions';
import CASE_OBJECT from "@salesforce/schema/Case";

const FIELDS = [
    'Case.On_Hold_Start_Date__c',
    'Case.On_Hold_End_Date__c',
    'Case.On_Hold_Reason__c',
    'Case.RecordTypeId'
];

export default class TRS_CaseOnHold extends LightningElement {
    @api recordId;

    isloading = false;
 
    startDate = new Date().toISOString().slice(0, 10);
    endDate = '';
    selectedReason = '';
    trsComplaintRecordTypeId = '';
    objectNameToGetRecordTypes = 'Case';
    
    reasonOptions = [];
    lstRecordTypes = [];
    
    recordTypePicklist;

    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    getRecordData({ data, error }) {
        if (data) {
            this.startDate = new Date().toISOString().slice(0, 10);
            this.endDate = data.fields.On_Hold_End_Date__c.value;
            this.selectedReason = data.fields.On_Hold_Reason__c.value;
        } else if (error) {
            console.error('Error retrieving record data', JSON.stringify(error));
        }
    }

    @wire(getObjectInfo, { objectApiName: '$objectNameToGetRecordTypes' })
    getObjectInfo({ data, error }) {
        if (data) {
            this.lstRecordTypes = [];
            for (let key in data.recordTypeInfos) {
                if (data.recordTypeInfos[key].name == 'TRS Complaint') {
                    this.lstRecordTypes.push({ value: key, label: data.recordTypeInfos[key].name });
                }
            }
            this.recordTypePicklist = this.lstRecordTypes.map(item => item.value);
            this.trsComplaintRecordTypeId = this.recordTypePicklist[0];

        } else if (error) {
            console.error('Error while getting record types', JSON.stringify(error));
        }
    }

    @wire(getPicklistValuesByRecordType, {objectApiName: CASE_OBJECT, recordTypeId: '$trsComplaintRecordTypeId'})
    getPicklistForField({ data, error }) {
        if (data) {
            let picklistField = data.picklistFieldValues.On_Hold_Reason__c;

            if (picklistField) {
                this.reasonOptions = picklistField.values.map(picklistValue => ({
                    label: picklistValue.label,
                    value: picklistValue.value
                }));
            }
        } else if (error) {
            console.error('Error while getting picklist values', JSON.stringify(error));
        }
    }

    handleEndDateChange(event) {
        this.endDate = event.target.value;
    }

    handleReasonChange(event) {
        this.selectedReason = event.detail.value;
    }

    handleSave() {
        try {
            this.showSpinner(true);
            let isValid = this.checkValidation();

            if (!isValid) {
                this.showSpinner(false);
                return;
            }

            this.updateCaseRecord();
        } catch (error) {
            console.error('Error in Saving Record: ' + error);
            this.showSpinner(false);
        }
    }

    checkValidation() {
        let isValid = true;

        if (!this.endDate) {
            this.showHideErrorMessage('onHoldEndDate', 'Please enter a valid end date.');
            isValid = false;
        } else {
            if (new Date(this.endDate) < new Date(this.startDate)) {
                this.showHideErrorMessage('onHoldEndDate', 'The end date cannot be before the start date.');
                isValid = false;
            } else {
                this.showHideErrorMessage('onHoldEndDate', '');
            }
        }

        if (!this.selectedReason) {
            this.showHideErrorMessage('onHoldReason', 'Please select a reason.');
            isValid = false;
        } else {
            this.showHideErrorMessage('onHoldReason', '');
        }

        return isValid;
    }

    updateCaseRecord() {
        const fields = {};
        
        fields.Id = this.recordId;
        fields.Case_Statuses__c = 'On Hold';
        fields.On_Hold_Start_Date__c = this.startDate;
        fields.On_Hold_End_Date__c = this.endDate;
        fields.On_Hold_Reason__c = this.selectedReason;

        const recordInput = { fields };

        this.showSpinner(true);

        updateRecord(recordInput)
            .then(() => {
                this.showToastMessage('Success', 'Case put on hold successfully.', 'success');
                this.dispatchEvent(new CloseActionScreenEvent());
            })
            .catch(error => {
                let errorMessage = error.body.output.errors[0].message;
                this.showToastMessage('Error', errorMessage, 'error');
            })
            .finally(() => {
                this.showSpinner(false);
            });
    }

    showHideErrorMessage(classNames, errorMessage) {
        let className = '.' + classNames;
        let inputElement = this.template.querySelector(className);
        inputElement.setCustomValidity(errorMessage);
        inputElement.reportValidity();
    }

    showToastMessage(title, message, variant) {
        const successEvent = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });

        this.dispatchEvent(successEvent);
    }

    closeQuickAction() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    showSpinner(showSpinner) {
        this.isloading = showSpinner;
    }

}