import {LightningElement,track,wire,api} from 'lwc';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin } from 'lightning/navigation';
import getCaseandDisputeItemsDetailsForNi from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.getCaseandDisputeItemsDetailsForNi';
import updateCaseAgreetoAGLLbyTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.updateCaseAgreetoAGLLbyTenant';
import NotAgreeAGLLAndSchemeBothbyTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.NotAgreeAGLLAndSchemeBothbyTenant';
import updateCaseNotAgreeAGLLButWishToSchemebyTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.updateCaseNotAgreeAGLLButWishToSchemebyTenant';
import agreedRepaymetSplitAmtEachTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.agreedRepaymetSplitAmtEachTenant';
import getLoggedUserAccId from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.getLoggedUserAccId';
import { CurrentPageReference } from 'lightning/navigation';

export default class EI_NI_TenatRespondtoRepaymentRequest extends NavigationMixin(LightningElement) {
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    
    pound_icon = NI_Theme +'/assets/img/pound_icon.png';
    homeImg= NI_Theme + '/assets/img/home_icon.png';
    groupImg= NI_Theme + '/assets/img/group_icon.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    featherImg = NI_Theme + '/assets/img/feather-edit_nhos.svg';
    calendarwhite = NI_Theme + '/assets/img/calendar-white.svg';

    //tenancy end date attribtes 
    @track tenancyDay='';
    @track tenancyMonth='';
    @track tenancyYear='';
    @track tenancyEndDateYMD='';
    @track tenancyEndDateDMY='';
    @track endDateByTenant='';
    @track isFutureDateError=false;
    @track isTenEndDateValid=false;
    @track isInValidEndDate = false;
   
    @track isrenderAgreeButton = false;
    isCommonSubmit = true;
    isShemeSubmit = false;
    //4 buttons
    @track PageSpinner = false;
    @track isDsputedAmtLessthanZeroBut3 = true;
    @track isDsputedAmtLessthanZeroBut4 = true;
    @track isShowAgreeSplitButton = true;
    resolvedWithoutScheme = false;
    isAgreeBanksection = false;
    isBothNotAgreeBankSection = false;
    @track isShowAddbankdetailSec = true;
    @track isbankdetailsNotAvl = false;
    @track isbankdetailsNotAvl2 = false;
    @track isbankdetailsNotAvl3 = false;
    @track isbankdetailsNotAvl4 = false;
    
   // @track confirmationSection = true;//true
    @track clickedButton = '';
    @track claimedItemsDetailsObjStr;
   
    @track myDate;
    @track otherReason;
    @track isOtherReasonPresent = false;
    @track tenantOtherReason = '';
    @track otherAmtValidationError = false;
    //onload
    @track isUpperSection = true;
    @track depositAmount = 0.00;
    @track respondDate;
    @track amountToTenantByAGLL =0.00;
    @track amountToTenantByTT =0.00;
    @track depositAmountClaimedByAGLL = 0.00;
    @track depositAmountClaimedByTT = 0.00;
    @track remainderToAllocateBttn2 = 0.00;
    @track agllName;
    @track disputeItems = [];
    @track tenantCasepartList = [];
    @track originalCasepartList = [];
    @track isBankDetails = false;
    @track isBackCasepartList = [];
    caseId;
    @track totalDisputeItemAmount = 0;
    @track NoOfTenants;
    @track isUserAmount = false;
    @track showIfClaimedMoreThenDepositAmount = false;
    // agree donot agree
    @track showAmountAmendmentForm = false;
    @track disableSumbit = true;
    @track dontAgreeSection = false;
    @track hideWindow1 = true;
    @track confirmationSection = false;
    //4 buttons continue/submit
    @track isAgreeButtonClicked = false;
    @track isAgreeButSplit = false;
    @track isDonotAgreeButScheme = false;
    @track isBothDoNotAgree = false;
    @track showResolveByTds = false;
    @track moreLessDepAmt = false;
    @track isLessThanTotalTenamt = false;
    @track isLessThanDepAmt = false;
    //Thank you page 
    @track isShowThankyouPage = false;
    @track thankyousuccessMsg = false;
    @track schemeSucessMsg = false;
    @track isAgreeToAGLLRequest = false;
    @track isNotAgreeAndSchemeBoth = false;
    @track isNotAgreeButScheme = false;
    @track depositsId;
    @track depositRecId;
    @track noBankParentValue = false;

    @track tenancyDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

    @track tenancyMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

    @track tenancyYearList = [];
    
    // Bank details attributes START
    showBankDetailSection = false;
    showAddBankDetailBtn = false;
    showEditBankDetailBtn = false;
    isBankDetailsPresent = false;
    loggedInTenantName = '';
    branchId = null;

    // Attributes for Bank Details child component
    caseWrapper;
    bankDetailObject = [];
    userType = '';
    isShownOnMyAccount = false;
    @track todayDate = '';
    @track pickedValue;
    @wire(CurrentPageReference)
    currentPageReference;

    connectedCallback() {
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = atob(depositRecId);
        //alert('Line 99 - '+depositRecId);
        console.log('depId==>'+this.depositRecId);
        Promise.all([
            loadStyle(this, `${NI_Theme }/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme +'/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme +'/assets/js/custom.js')
        ])
        .then(() => {
            console.log('Files loaded.');
        })
        .catch(error => {
            console.log(error.body.message);
        });  

         // set today date for max date as future dates should be grayed out
            //  date picker code start 
            var today = new Date();
            var todayDate = today.getDate();
            todayDate = todayDate>9 ? todayDate : '0'+todayDate;
            var todayMonth = today.getMonth()+1;
            todayMonth = todayMonth>9 ? todayMonth : '0'+todayMonth;
            var todayYear = today.getFullYear();
            this.todayDate = todayYear+'-'+todayMonth+'-'+todayDate;
            console.log(' MAx todayDate => ' + this.todayDate);
        //  date picker code end 


        console.log('104--------@');
        let tenancyYearList = [];
        for (var i = 2012; i <= 2024; i++) {
            tenancyYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
        }
        this.tenancyYearList = tenancyYearList;


        getLoggedUserAccId({})
         .then(result=>{
            if(result != null){
                this.AccountId = result.AccountId;
                console.log('user AccountId==>'+this.AccountId);
            }
         })
         .catch(error=>{

         });
    
         getCaseandDisputeItemsDetailsForNi({depositId : this.depositRecId})
         .then(resultList=>{
                console.log('Line 183 resultList - '+JSON.stringify(resultList));
                this.caseWrapper = resultList[0];
                console.log('Line 183 resultList - '+JSON.stringify(this.caseWrapper));
                if(resultList.length>0) {
                    console.log('Line 183 resultList2 - '+JSON.stringify(resultList));
                    let result = resultList[0].caseList;
                    console.log('Line 183 result1 - '+JSON.stringify(result));
                    console.log('Line 183 result2 - '+result);
                    this.loggedInTenantName = this.caseWrapper.userRec.Name;
                    this.userType = this.caseWrapper.userRec.Profile.Name;
                    console.log('Line 191 - '+this.userType+' -> '+this.loggedInTenantName);

                    // if(result!= null) 
                    if(result.length>0) 
                    {
                        console.log('case cp & DI'+JSON.stringify(result));
                        console.log('getCaseandDispiteItemsDetails => ' + JSON.stringify(result[0]));
                        console.log('depositAmount => ' + result[0].Deposit_Account_Number__r.Final_Protected_Amount__c);
                        console.log('NoOfTenants==>'+result[0].No_of_Tenants__c);
                        if(result[0].No_of_Tenants__c!=undefined){
                            this.NoOfTenants = result[0].No_of_Tenants__c;
            
                        } if(result[0].Deposit_Account_Number__c!=undefined){

                            this.depositsId = result[0].Deposit_Account_Number__c;
                        } if(result[0].Deposit_Account_Number__r.Final_Protected_Amount__c!=undefined){

                            this.depositAmount = (result[0].Deposit_Account_Number__r.Final_Protected_Amount__c).toFixed(2);
            
                        } if(result[0].Total_Claimed_by_Landlord__c!=undefined){

                            this.depositAmountClaimedByAGLL = (result[0].Total_Claimed_by_Landlord__c).toFixed(2);
            
                        }
                        //this.NoOfTenants = result[0].No_of_Tenants__c;
                        //this.depositsId = result[0].Deposit_Account_Number__c;
                        //this.depositAmount = (result[0].Deposit_Account_Number__r.Actual_Protected_Amount__c).toFixed(2);//Protected_Amount__c
                        //this.depositAmountClaimedByAGLL = (result[0].Total_Claimed_by_Landlord__c).toFixed(2);
                        this.amountToTenantByAGLL = this.depositAmount - this.depositAmountClaimedByAGLL;
                        if(result[0].Id!=undefined){
                            this.caseId = result[0].Id;
                            console.log('caseIdfromserver--->'+this.caseId);

                         } if(result[0].Respond_Date__c!=undefined){
                            this.respondDate = formatDate(result[0].Respond_Date__c);
                            console.log('line 186='+  this.respondDate);
                        }
                        if(result[0].Deposit_Account_Number__r.Branch__c!=undefined || result[0].Deposit_Account_Number__r.Branch__c!=null){

                            this.branchId = result[0].Deposit_Account_Number__r.Branch__c;
                            console.log('BranchId==>'+this.branchId);
                        }
                        console.log('line 125--->'+ this.agllName );

                        let aglldisputeItems;

                        if(result[0].Dispute_Items__r !=undefined){
                            aglldisputeItems = JSON.parse(JSON.stringify(result[0].Dispute_Items__r));
                            console.log('line 190='+aglldisputeItems);
                        }
                        let casepartItems ;
                        if(result[0].Case_Participants__r!=undefined){
                            casepartItems = JSON.parse(JSON.stringify(result[0].Case_Participants__r));
                            console.log('line 192='+casepartItems);

                        }
                           // let aglldisputeItems = JSON.parse(JSON.stringify(result[0].Dispute_Items__r));
                           
                      //  let aglldisputeItems = JSON.parse(JSON.stringify(result[0].Dispute_Items__r));
                        //let casepartItems = JSON.parse(JSON.stringify(result[0].Case_Participants__r));

                       // console.log('line 126--->'+JSON.stringify(casepartItems));
                        let totalOriginalAgllReq = 0.00;
                        for(let ind in casepartItems){
                            if(casepartItems[ind].Type__c == 'Tenant'){
                                console.log('type--->'+casepartItems[ind].Type__c );
                                console.log('typename--->'+casepartItems[ind].Account__r.Name );
                                console.log('type--->'+casepartItems[ind].Original_agll_request__c );
                                this.tenantCasepartList.push({
                                    name: casepartItems[ind].Account__r.Name,
                                    agllReqvalue:casepartItems[ind].Original_agll_request__c,
                                    id:casepartItems[ind].Account__c,
                                    tenantReqValue:0.00
                                });
                                const originalAgllReq = casepartItems[ind].Original_agll_request__c;
                                totalOriginalAgllReq += parseFloat(originalAgllReq);
                                
                            }
                            if(casepartItems[ind].Type__c == 'Agent' || casepartItems[ind].Type__c == 'Landlord'){
                                this.agllName =casepartItems[ind].Account__r.Name;
                            }
                            if (casepartItems[ind].Account__c === this.AccountId) {
                                var agllReqvalue = casepartItems[ind].Original_agll_request__c;
                                console.log(`agllReqvalue: ${agllReqvalue}`);
                            }
                            if(totalOriginalAgllReq == 0 || agllReqvalue == 0){
                                this.isUserAmount = false;
                            }
                            else{
                                this.isUserAmount = true;
                            }
                        }
                        console.log('allTenantsTotalValue==>'+totalOriginalAgllReq);
                        console.log('AGLL Name@@@'+this.agllName);
                        console.log('tenant details--->'+JSON.stringify(this.tenantCasepartList));
                        console.log('DisputeItems=>'+JSON.stringify(aglldisputeItems));
                        
                    
                        for (let ind in aglldisputeItems) {
                            if (aglldisputeItems[ind].Claimed_by_Landlord__c > 0) {
                            let itemType;
                            if (aglldisputeItems[ind].Type__c.includes('Rent')) {
                                itemType = 'Rent arrears';
                            } else {
                                itemType = aglldisputeItems[ind].Type__c;
                            }
                            console.log('ItemTypes=>'+itemType);
                            const itemValue = {
                                itemAmountbyAGLL: aglldisputeItems[ind].Claimed_by_Landlord__c.toFixed(2),
                                itemAmountbyTT: 0.00,
                                isTTAmountMoreThenAgllAmount: false,
                                claimItemId: aglldisputeItems[ind].Id
                            };
                            this.totalDisputeItemAmount += parseFloat(itemValue.itemAmountbyAGLL);
                            console.log('total amt by agll==>'+this.totalDisputeItemAmount);
                            console.log('from field total agll amt==>'+this.depositAmountClaimedByAGLL);
                            if (itemType === 'Other') {
                                console.log('otherReason=>'+aglldisputeItems[ind].Other_Reason__c);
                                itemValue.Other_Reason__c = aglldisputeItems[ind].Other_Reason__c;
                                aglldisputeItems[ind].itemValue = itemValue; // Add itemValue to aglldisputeItems array
                            }
                            this.disputeItems.push({
                                key: itemType, 
                                value: itemValue
                            });
                            if (aglldisputeItems[ind].Other_Reason__c != null && aglldisputeItems[ind].Other_Reason__c != undefined) {
                                this.otherReason = aglldisputeItems[ind].Other_Reason__c;
                                this.isOtherReasonPresent = true;
                                console.log('otherReason@@=>'+this.otherReason);
                            }
                            }
                        }
                        
                        console.log("disputeItems => " + JSON.stringify(this.disputeItems));
                    }

                    // Setting the Bank details for the Child Component START
                    if(this.caseWrapper.acctBankDetailsRec.length>0) {
                        console.log('Line 55 - '+this.caseWrapper.acctBankDetailsRec[0].ValidInternationBankDetails__c);
                        console.log('Line 56 - '+this.caseWrapper.acctBankDetailsRec[0].IBAN__c);

                        if(this.caseWrapper.acctBankDetailsRec[0].ValidInternationBankDetails__c == false && 
                            this.caseWrapper.acctBankDetailsRec[0].IBAN__c== undefined) 
                        {
                            console.log('bank details not found');
                            this.showAddBankDetailBtn = true;
                            this.isBankDetailsPresent = false;
                        }
                        else 
                        {
                            console.log('bank details found');
                            this.showEditBankDetailBtn = true;
                            this.isBankDetailsPresent = true;
                        }

                        // Setting bank detail values
                        this.bankDetailObject = this.caseWrapper.acctBankDetailsRec;
                    }
                    // Setting the Bank details for the Child Component END

                }

                /* const childComponent = this.template.querySelector('c-e-i_-n-i_-create-update-bank-details');
                if (childComponent) {
                    this.isBankDetails = childComponent.isBankDetails;
                } */
            
         })
         .catch(error=>{
                console.log('error while getting case cp dI--->'+JSON.stringify(error));
                console.log("getCaseandDispiteItemsDetails JS error=> " + (error));
         });
         function formatDate(dateString) {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) {
              return "Invalid Date";
            }
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
          }
          
          console.log('respondDate==>'+this.respondDate);
    }

    // On click of Bank details Add/Edit button
    handleBankDetailBtn(event) {
        event.preventDefault();

        this.showBankDetailSection = true;
        // Firing an event from Parent to Child relevant person component START
        console.log(`Line 311 Parent call - ${this.userType} - ${this.bankDetailObject.length} - ${JSON.stringify(this.bankDetailObject)}`);
        // this.template.querySelector('c-ei_-n-i_-bank-detail-for-agll-tenant').sendDetailsToChild(this.bankDetailObject, this.userType);
        setTimeout(() => {
        this.template.querySelectorAll('c-ei_-n-i_-bank-detail-for-agll-tenant').forEach(element => {
            element.sendDetailsToChild(this.bankDetailObject, this.userType);
        });
    }, 500);
        // Firing an event from Parent to Child relevant person component END
    }

    // For handling event from child component
    handleSaveBankDetails(event) {
        console.log('Line 123 bank detail event -> '+JSON.stringify(event.detail));
        let returnedData = event.detail;

        if(returnedData.isValid) {
            this.isBankDetailsPresent = true;
            this.showAddBankDetailBtn = false;
            this.showAddBankDetailInRedBtn = false;
            this.showEditBankDetailBtn = true;

            this.isbankdetailsNotAvl = false;
            this.isbankdetailsNotAvl1 = false;
            this.isbankdetailsNotAvl2 = false;
            this.isbankdetailsNotAvl3 = false;
        }
        
    }

    getfromchild(event) {
        // this.childData = event.detail.data;
        this.isBankDetails = event.detail.isBankDetails;
        console.log('bankDetailsPresent@@@000-->'+this.isBankDetails);
        if(this.isBankDetails){
            this.isbankdetailsNotAvl = false;
            this.isbankdetailsNotAvl2 = false;
            this.isbankdetailsNotAvl3 = false;
            this.isbankdetailsNotAvl4 = false;

        }
    }

    checkTenancyEndDate(event){

        // tenancy start date
        let tenancyEndtDate = this.template.querySelector('[name="tenancyEndDate"]').value;
        if (tenancyEndtDate != 'Select day') {
            this.tenancyDay = tenancyEndtDate;
        }
        let tenancyEndtMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
        if (tenancyEndtMonth != 'Select month') {
            this.tenancyMonth = tenancyEndtMonth;
        }
        let tenancyEndYear = this.template.querySelector('[name="tenancyEndYear"]').value;
        if (tenancyEndYear != 'Select year') {
            this.tenancyYear = tenancyEndYear;
        }
        let tenancyDateYMD = tenancyEndYear + '-' + tenancyEndtMonth + '-' + tenancyEndtDate;
        let tenancyDateDMY = tenancyEndtDate + '/' + tenancyEndtMonth + '/' + tenancyEndYear;
        if(tenancyEndtDate != 'Select day' && tenancyEndtMonth != 'Select month' && tenancyEndYear != 'Select year'){
            var tenancyDateDDMMYY = tenancyEndtDate + '-' + tenancyEndtMonth + '-' + tenancyEndYear;
        }
        
        this.tenancyEndDateYMD = tenancyDateYMD;
        this.tenancyEndDateDMY = tenancyDateDMY;
        console.log('Line 518 Tenancy End Date-->' + this.tenancyEndDateYMD);
        console.log('Line 292 Tenancy End Date-->' + this.tenancyDateDDMMYY);
         this.isFutureDateError=false;
        this.isTenEndDateValid=false;
        this.isInValidEndDate = false;
        //  this.displaySummarySection = false;
        
            let endDate =this.tenancyDay ;
            let endMonth =this.tenancyMonth ;
            let endYear = this.tenancyYear;

            
            //let tenancyEndDate = endDate+'-'+endMonth+'-'+endYear;
            let tenancyEndDate = tenancyDateDDMMYY;
            let isValidDate = validatedate(tenancyEndDate);
            
            var today = new Date();
            var todayDate = today.getDate();
            var todayMonth = today.getMonth()+1;
            var todayYear = today.getFullYear();
            
                     // Date validation 
        var arraydate = [];
        console.log(' 1357');
      //  let isValidDate = true;
        let isValid = true;
        //let tenancyDateDDMMYY = this.tenancyDay + '-' + this.tenancyMonth + '-' + tenancyEndYear;
        arraydate.push(tenancyEndDate);
        console.log('date-->'+tenancyEndDate);
        let loopCounter = 0;
        this.isInValidEndDate = false;
        for (var i = 0; i < arraydate.length; i++) {
            isValidDate = validatedate(arraydate[i]);
            if (isValidDate == false) {
                if (loopCounter == 0) {
                    isValid = false;
                    //isValidDate == false;
                    
                    this.isrenderAgreeButton = false;
                    console.log('invalid date--->412');
                    this.isInValidEndDate = true;
                } else {
                    this.isInValidEndDate = false;
                   // this.isShowTenancyDateError = true;
                }
                break;
 
            } 
            else{
                this.isInValidEndDate = false;
            }
            loopCounter++;
        }
            //GOD class to check date validity
            function validatedate(d)
            {
                var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
                // Match the date format through regular expression
                if(d.match(dateformat))
                {     
                    var splittedDate = d.split('-');
                    var splittedDateLength = splittedDate.length;
                    if (splittedDateLength>1)
                    {
                        var pdate = d.split('-');
                    }
                    var dd = parseInt(pdate[0]);
                    var mm  = parseInt(pdate[1]);
                    var yy = parseInt(pdate[2]);
                    
                    // Create list of days of a month [assume there is no leap year by default]
                    var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];
                    if (mm==1 || mm>2)
                    {
                        if (dd>ListofDays[mm-1])
                        {
                            return false;
                        }
                    }
                    if (mm==2)
                    {
                        var lyear = false;
                        if ( (!(yy % 4) && yy % 100) || !(yy % 400)) 
                        {
                            lyear = true;
                        }
                        if ((lyear==false) && (dd>=29))
                        {
                            return false;
                        }
                        if ((lyear==true) && (dd>29))
                        {
                            return false;
                        }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            console.log('tenancy end date444--->'+this.endDateByTenant);
       // }
       let setEndDate = endYear+'-'+endMonth+'-'+endDate;
       if(endYear == todayYear)
       {
           if(endMonth == todayMonth)
           {
               if(endDate<=todayDate)
               {
                     this.endDateByTenant=this.tenancyEndDateYMD ;
               } else {
                   this.isFutureDateError=true;
                   this.isInValidEndDate = false;
                   this.isrenderAgreeButton = false;
                   isValid = false;
                   // this.displaySummarySection = false;
               }
           } else if(endMonth < todayMonth) {
               
               this.endDateByTenant=this.tenancyEndDateYMD ;
           } else {
               this.isFutureDateError=true;
               this.isInValidEndDate = false;
               this.isrenderAgreeButton = false;
               isValid = false;
               // this.displaySummarySection = false;
           }
       } else if(endYear < todayYear) {
           
           this.endDateByTenant=this.tenancyEndDateYMD ;
       } else {
           this.isFutureDateError=true;
           this.isrenderAgreeButton = false;
           this.isInValidEndDate = false;
           isValid = false;
       }
            
            if(isValidDate && isValid)
            {
                console.log(isValidDate+'<==isValidDate==>'+isValid);
                this.isrenderAgreeButton = true;
                if(this.totalDisputeItemAmount ==0 || this.depositAmountClaimedByAGLL==0){
                    this.isDsputedAmtLessthanZeroBut3 = false;
                    this.isDsputedAmtLessthanZeroBut4 = false;
                }
                else{
                    this.isDsputedAmtLessthanZeroBut3 = true;
                    this.isDsputedAmtLessthanZeroBut4 = true;
                }
                if(this.amountToTenantByAGLL == 0 || this.NoOfTenants == 1){
                    this.isShowAgreeSplitButton = false;
                }
                else{
                    this.isShowAgreeSplitButton = true;
                }
             
                console.log('tenancy end date111--->'+this.endDateByTenant);
                
            } else {
               // this.isTenEndDateValid=true;
                console.log('tenancy end error from here--->'+ this.isTenEndDateValid);
                console.log('tenancy end date222--->'+this.endDateByTenant);
            }
            
           
            console.log('tenancy end date333--->'+this.endDateByTenant);
            this.myDate = this.tenancyEndDateDMY ;
           // console.log('Tenancy end --->'+this.myDate);
        
    }
    
    restrictDecimal(event) {  
        let amtVal = event.target.value;
        return (amtVal.indexOf(".") >= 0) ? (amtVal.substr(0, amtVal.indexOf(".")) + amtVal.substr(amtVal.indexOf("."), 3)) : amtVal;

    }
    removeZero(event) {
        console.log('removeZero');
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }
    
    restrictNegativeVal(event){
        if(event.target.value < 0){
            event.target.value = 0;
        }
    }
    restrictDecimals(event) {
        const t = event.target.value;
        const charCode = (event.which) ? event.which : event.keyCode;
        const decimalIndex = t.indexOf('.');
      
        // Allow only one decimal point
        if (charCode === 46 && decimalIndex !== -1) {
          event.preventDefault();
        }
      
        // Allow only digits and a decimal point
        else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
          event.preventDefault();
        }
      
        // Allow only up to two digits after the decimal point
        else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
          event.preventDefault();
        }
      }
    //form submit
    handleAgree(event){
        event.preventDefault();
        this.isUserAmount == true;
        this.disableSumbit = false;
        this.dontAgreeSection = false;
        let AgreeBtn = this.template.querySelector('[name="Agree"]'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('[name="Disagree"]').style = '';

        let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
        finalSubmit.style = 'opacity: 1';

    }
    handleDontAgree(event){
        event.preventDefault();
        console.log('UsetAmt'+this.isUserAmount );
        if(this.isUserAmount == false){
            this.disableSumbit = false;
            this.dontAgreeSection = false;
            let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
            finalSubmit.style = 'opacity: 1';
            console.log('isUserAmtNillDisagree');
        }
        else{
            let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
            finalSubmit.style = 'opacity: 0.5';
    
            console.log('isUserAmtDisagree');
            this.disableSumbit = true;
            this.dontAgreeSection = true;
        }
        let AgreeBtn = this.template.querySelector('[name="Disagree"]'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('[name="Agree"]').style = '';
        
        
    }
    // button 1
    agreeingRepayment(event){
        this.isAgreeButtonClicked = true;
        this.isAgreeBanksection = true;

        this.resolvedWithoutScheme = false;
        this.showAmountAmendmentForm = false;

        this.showAmountAmendmentForm = false;
        this.isBothDoNotAgree = false;
        this.isAgreeButSplit = false;
        this.isDonotAgreeButScheme = false;
        
        if(this.showAddBankDetailInRedBtn) {
            this.showAddBankDetailInRedBtn = false;
            this.showAddBankDetailBtn = true;
            isbankdetailsNotAvl = false;
            isbankdetailsNotAvl2 = false;
            isbankdetailsNotAvl3 = false;
            isbankdetailsNotAvl4 = false;
        }

        let AgreeBtn = this.template.querySelector('.agreebutton'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        if(this.isShowAgreeSplitButton){
            this.template.querySelector('.agreesplitbutton').style = '';
        }
        if (this.isDsputedAmtLessthanZeroBut3){
            this.template.querySelector('.disagreeSchemeButton').style = '';
        }
       if(this.isDsputedAmtLessthanZeroBut4){
            this.template.querySelector('.disagreeBothButton').style = '';
       }
    }
    AgreeButtonHandler(event){
        this.clickedButton = 'AgreeButton1';
        //this.isUserAmount = true;
        console.log('userAmt==>bt1'+this.isUserAmount);
        let isValid = true;
        
        // if(this.isBankDetails == false && this.isUserAmount == true){
        if(this.isBankDetailsPresent == false && this.isUserAmount == true){
            this.isbankdetailsNotAvl = true;
            this.showAddBankDetailBtn = false;
            this.showEditBankDetailBtn = false;
            this.showAddBankDetailInRedBtn = true;
            isValid = false;
            this.noBankParentValue = true;
            this.template.querySelector('c-e-i_-n-i_-create-update-bank-details').showWarning(this.noBankParentValue);
        }
        else{
            this.isbankdetailsNotAvl = false;
        }
        
        if(isValid){
            this.hideWindow1 = false;
            this.confirmationSection = true;
        }
        
        
    }
    //button 2 
    agreeingSplit(event){
        this.showAmountAmendmentForm = true;
        this.isAgreeButSplit = true;

        this.isAgreeBanksection = false;
        this.resolvedWithoutScheme = false;

        this.isAgreeButtonClicked = false;
        this.isBothDoNotAgree = false;
        this.isDonotAgreeButScheme = false;
         
        this.remainderToAllocateBttn2 = parseFloat(this.amountToTenantByAGLL);

        if(this.showAddBankDetailInRedBtn) {
            this.showAddBankDetailInRedBtn = false;
            this.showAddBankDetailBtn = true;
            isbankdetailsNotAvl = false;
            isbankdetailsNotAvl2 = false;
            isbankdetailsNotAvl3 = false;
            isbankdetailsNotAvl4 = false;
        }

        let AgreeBtn = this.template.querySelector('.agreesplitbutton'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('.agreebutton').style = '';
        if (this.isDsputedAmtLessthanZeroBut3){
            this.template.querySelector('.disagreeSchemeButton').style = '';
        }
        if(this.isDsputedAmtLessthanZeroBut4){
            this.template.querySelector('.disagreeBothButton').style = '';
       }
        // this.template.querySelector('.disagreeSchemeButton').style = '';
        // this.template.querySelector('.disagreeBothButton').style = '';
    }
    handleAmountToTenantBySplit(event){
        this.clickedButton = 'AgreeButSplitButton2';
        const inputId = event.target.dataset.id
        const inputValue = event.target.value || 0.00;
    
        const index = this.tenantCasepartList.findIndex(item => item.id === inputId);
        
        console.log('Id from Input'+inputId);
        console.log('Id from Input'+inputValue);
        console.log('Id from list'+index);
        if (index !== -1) {
            this.tenantCasepartList[index].tenantReqValue = inputValue;
        }
        console.log('updated list---> '+JSON.stringify(this.tenantCasepartList));
        this.isBackCasepartList=Array.from(this.tenantCasepartList);
        const sum = this.tenantCasepartList.reduce((total, item) => total + parseFloat(item.tenantReqValue || 0), 0);
        console.log('total sum of split tenantReqValue---> '+sum);
        this.amountToTenantByTT = sum;

        
        // var remainderToAllocate = parseFloat(this.depositAmount)-parseFloat(this.amountToTenantByTT)-
        // parseFloat(this.amountToTenantByAGLL);
        // this.remainderToAllocateBttn2 = parseFloat(this.amountToTenantByAGLL);
        var remainderToAllocate =parseFloat(this.amountToTenantByAGLL)-parseFloat(this.amountToTenantByTT);
        
        this.remainderToAllocateBttn2 = remainderToAllocate;
        if(this.remainderToAllocateBttn2 < 0){
            this.isMoreThanDepAmt = true;
        }else{
            this.isMoreThanDepAmt = false;
        }
        const matchingObject = this.tenantCasepartList.find(item => item.id === this.AccountId);

        if (matchingObject) {
        console.log('Matching object found:', matchingObject);
        console.log('Value of tenantReqValue property:', matchingObject.tenantReqValue);

            if(matchingObject.tenantReqValue>0){
                this.isUserAmount = true;
                console.log('isUserEnteredvalue==>'+this.isUserAmount);
            }else{
                this.isUserAmount = false;
                console.log('isUserEnteredvalue648==>'+this.isUserAmount);
            }
        console.log('Value of tenantReqValue property:', matchingObject['tenantReqValue']);
        }

    }
    AgreeButSplithandler(event){
        event.preventDefault();
        console.log('clicked button =>'+this.clickedButton);
        console.log('remainderToAllocateBttn2 =>'+this.amountToTenantByTT);
        console.log('amountToTenantByAGLL=>'+this.amountToTenantByAGLL);
        let isValid = true;
        if(this.amountToTenantByTT < this.amountToTenantByAGLL){
            this.isLessThanDepAmt = true;
            isValid = false;
        }else{
            this.isLessThanDepAmt = false;
        }
        if(this.isMoreThanDepAmt){
            isValid = false;
        }
        
        // if(this.isBankDetails == false && this.isUserAmount == true){
        if(this.isBankDetailsPresent == false && this.isUserAmount == true){
            this.isbankdetailsNotAvl2 = true;
            this.showAddBankDetailBtn = false;
            this.showEditBankDetailBtn = false;
            this.showAddBankDetailInRedBtn = true;
            isValid = false;
            this.noBankParentValue = true;
            this.template.querySelector('c-e-i_-n-i_-create-update-bank-details').showWarning(this.noBankParentValue);
        }
        else{
            this.isbankdetailsNotAvl2 = false;
        }
        if(isValid){
            this.hideWindow1 = false;
            this.confirmationSection = true;
        }
    }
    //button-3
    disagreeingRepaymentWishToScheme(event){
        this.isDonotAgreeButScheme = true;
       // this.isDonotAgreeButScheme = true;

        this.resolvedWithoutScheme = false;
        this.showAmountAmendmentForm = false;
        this.isAgreeBanksection = false;
        //buttons
        this.isAgreeButtonClicked = false;
        this.isAgreeButSplit = false;
        this.isBothDoNotAgree = false;

        if(this.showAddBankDetailInRedBtn) {
            this.showAddBankDetailInRedBtn = false;
            this.showAddBankDetailBtn = true;
            isbankdetailsNotAvl = false;
            isbankdetailsNotAvl2 = false;
            isbankdetailsNotAvl3 = false;
            isbankdetailsNotAvl4 = false;
        }

        let AgreeBtn = this.template.querySelector('.disagreeSchemeButton'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('.agreebutton').style = '';
        if (this.isShowAgreeSplitButton){
            this.template.querySelector('.agreesplitbutton').style = '';
        }
        if(this.isDsputedAmtLessthanZeroBut4){
            this.template.querySelector('.disagreeBothButton').style = '';
       }
        // this.template.querySelector('.agreesplitbutton').style = '';
        // this.template.querySelector('.disagreeBothButton').style = '';
    }
    @track  remainderToAllocateBttn3=0.00;
    DonotAgreeButSchemeHandler(event){
        this.clickedButton = 'DoNotAgreeButSchemButton3'
        this.confirmationSection = false;
        //this.tenantCasepartList = [];
        this.tenantCasepartList = this.tenantCasepartList.map(item => ({
            ...item,
            tenantReqValue: ""
          }));
        console.log('tenacaseparlist==>'+JSON.stringify(this.tenantCasepartList));
       // this.hideWindow1 = false;
        this.isShowThankyouPage = false;
        this.showResolveByTds = true;
        this.isUpperSection = false;
        this.isrenderAgreeButton = false;
        //test
        this.moreLessDepAmt = true;
        this.remainderToAllocateBttn3 = this.depositAmount;
    }
    handleOtherReason(event){
        this.otherAmtValidationError = false;
        this.otherAmtexplaError = false;
        const OtherReasonTenant = event.target.value; 
        this.tenantOtherReason = OtherReasonTenant;
        console.log('otherreason=>'+this.tenantOtherReason);
        console.log('otherTextLength==>'+this.tenantOtherReason.length);
    }
handleAmountToTenantByTTChange(event) {
    this.showIfClaimedMoreThenDepositAmount = false;
    const inputId = event.target.dataset.id
    const inputValue = event.target.value || 0.00;
    
    const index = this.tenantCasepartList.findIndex(item => item.id === inputId);
    
    console.log('Id from Input'+inputId);
    console.log('Id from list'+index);
    if (index !== -1) {
        this.tenantCasepartList[index].tenantReqValue = inputValue;
    }
    console.log('updated list---> '+JSON.stringify(this.tenantCasepartList));
    this.isBackCasepartList=Array.from(this.tenantCasepartList);
    const sum = this.tenantCasepartList.reduce((total, item) => total + parseFloat(item.tenantReqValue || 0), 0);
    console.log('total sum of tenantReqValue---> '+sum);
    this.amountToTenantByTT = sum;
    this.remainderToAllocateBttn3 = this.depositAmount-this.amountToTenantByTT-this.depositAmountClaimedByTT;
        console.log('tenatvalues=>'+this.tenantCasepartList[index].tenantReqValue);

        const matchingObject = this.tenantCasepartList.find(item => item.id === this.AccountId);

        if (matchingObject) {
        console.log('Matching object found:', matchingObject);
        console.log('Value of tenantReqValue property:', matchingObject.tenantReqValue);

            if(matchingObject.tenantReqValue>0){
                this.isUserAmount = true;
                console.log('isUserEnteredvalue==>'+this.isUserAmount);
            }else{
                this.isUserAmount = false;
                console.log('isUserEnteredvalue648==>'+this.isUserAmount);
            }
        console.log('Value of tenantReqValue property:', matchingObject['tenantReqValue']);
        } else {
        console.log('No matching object found');
        }
        // this.originalCasepartList = JSON.parse(JSON.stringify(this.tenantCasepartList));
}

    handleCalculateClaimAmountByTT(event){
        this.showIfClaimedMoreThenDepositAmount = false;
        this.isLessThanTotalTenamt = false;

        let val = this.restrictDecimal(event);
        console.log("handleCalculateClaimAmountByTT" + val);
        event.target.value = val;

        console.log("handleCalculateClaimAmountByTT" + event.target.value);
        let index = event.target.title;
        let claimItemValue = event.target.value;
        if (claimItemValue === '') {
            claimItemValue = 0.00;
        }
        this.disputeItems[index].value.itemAmountbyTT = claimItemValue;

        if(claimItemValue > 0){
            if(parseFloat(this.disputeItems[index].value.itemAmountbyTT) > parseFloat(this.disputeItems[index].value.itemAmountbyAGLL)){
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = true;
                const topDiv = this.template.querySelector('[data-id="starting_error"]');
                topDiv.scrollIntoView();
            }else{
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = false;
            }
        }

        // console.log(" on change disputeItems=> " + JSON.stringify(this.disputeItems));
        this.depositAmountClaimedByTT = 0;
        
        for(let ind in this.disputeItems ){
            console.log(" on change claimedItem => " + this.disputeItems[ind].value.itemAmountbyTT);
            if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT) + parseFloat(this.disputeItems[ind].value.itemAmountbyTT)).toFixed(2);
            }
        }
        console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
        this.remainderToAllocateBttn3 = this.depositAmount-this.amountToTenantByTT-this.depositAmountClaimedByTT;
    }
    handleClaimSubmit(event){
        
        if(this.amountToTenantByTT > 0){
            this.amountToTenantByTT = (parseFloat(this.amountToTenantByTT)).toFixed(2);
        }else{
            this.amountToTenantByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.amountToTenantByTT => " + this.amountToTenantByTT);

        if(this.depositAmountClaimedByTT > 0){
            this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT)).toFixed(2);
        }else{
            this.depositAmountClaimedByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
        console.log("this.amountToTenantByTT + this.depositAmountClaimedByTT => " + (( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)));
        
        if((( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)) != (parseFloat(this.depositAmount).toFixed(2))){
            this.showIfClaimedMoreThenDepositAmount = true;
            const topDiv = this.template.querySelector('[data-id="starting_error"]');
            topDiv.scrollIntoView();
        }else{
            this.showIfClaimedMoreThenDepositAmount = false;

        if(parseFloat(this.amountToTenantByTT) == this.amountToTenantByAGLL){
           this.isLessThanTotalTenamt = true;
            
        }else{
            this.isLessThanTotalTenamt = false;
        }
            let isValid = true;
            // need to do a server call for update case status to 'Self-resolution' and update claimed amount of tenant on dispute Items
            var claimedItemsDetailsObj = {};
            for(let ind in this.disputeItems){
                if(parseFloat(this.disputeItems[ind].value.itemAmountbyTT) > parseFloat(this.disputeItems[ind].value.itemAmountbyAGLL)){
                    isValid = false;
                    this.disputeItems[ind].value.isTTAmountMoreThenAgllAmount = true;
                    const topDiv = this.template.querySelector('[data-id="starting_error"]');
                    topDiv.scrollIntoView();
                }
                
                console.log("key => " + this.disputeItems[ind].key);
                console.log("value => " + JSON.stringify(this.disputeItems[ind].value));
                let detailsObj = {};
                detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
                if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                    detailsObj['itemAmountbyTT'] = this.disputeItems[ind].value.itemAmountbyTT;
                }else{
                    detailsObj['itemAmountbyTT'] = 0.00;
                }
                detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;

                claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
                console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
            }
                this.claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
                console.log('746');
                if(claimedItemsDetailsObj['Other']!= null){

                let otherValue =claimedItemsDetailsObj['Other']['itemAmountbyTT'];
                if (otherValue && otherValue.trim) {
                    otherValue = otherValue.trim();
                }
                console.log('748');
                console.log(typeof otherValue); 
                console.log('750');
                let othervalueByTenant = parseFloat(otherValue);
                console.log('amtToAgLL by tenant000==>'+otherValue+'floatvalue==>'+othervalueByTenant);
                // console.log('otherAmt==>'+this.claimedItemsDetailsObj.Other);
                //if(isOtherReasonPresent){
                    if(othervalueByTenant > 0 && (this.tenantOtherReason ==""|| this.tenantOtherReason == undefined || this.tenantOtherReason == null)){
                        // alert('other reason ');
                         this.otherAmtValidationError = true;
                         isValid = false;
                         if(this.tenantOtherReason.length >300){
                             this.otherAmtexplaError = true;
                             isValid = false;
     
                         }
                         else{
                             this.otherAmtexplaError = false;
                             
                         }
                     }
                     else{
                         this.otherAmtValidationError = false;
                         this.otherAmtexplaError = false;
                     }

                } 
                   
                    // if(this.isBankDetails == false && this.isUserAmount == true){
                    if(this.isBankDetailsPresent == false && this.isUserAmount == true){
                        this.isbankdetailsNotAvl3 = true;
                        this.showAddBankDetailBtn = false;
                        this.showEditBankDetailBtn = false;
                        this.showAddBankDetailInRedBtn = true;
                        isValid = false;
                        this.noBankParentValue = true;
                        this.template.querySelector('c-e-i_-n-i_-create-update-bank-details').showWarning(this.noBankParentValue);
                    }
                    else{
                        this.isbankdetailsNotAvl3 = false;
                    }
              //  }

            if(isValid){
                console.log('isValid--->True@@@');
                this.showResolveByTds = false;
                this.confirmationSection = true;
                this.isCommonSubmit = false;
                this.isShemeSubmit = true;
                this.hideWindow1 = false;
                
               
            }

        }
    }
    //button-4
    BothDoNotAgree(event){
        event.preventDefault();
        this.resolvedWithoutScheme = true;
        this.isBothNotAgreeBankSection = true;
        this.isBothDoNotAgree = true;

        this.isAgreeBanksection = false;
        this.showAmountAmendmentForm = false;
        
        this.isAgreeButSplit = false;
        this.isAgreeButtonClicked = false;
        this.isDonotAgreeButScheme = false;

        if(this.showAddBankDetailInRedBtn) {
            this.showAddBankDetailInRedBtn = false;
            this.showAddBankDetailBtn = true;
            isbankdetailsNotAvl = false;
            isbankdetailsNotAvl2 = false;
            isbankdetailsNotAvl3 = false;
            isbankdetailsNotAvl4 = false;
        }

        let AgreeBtn = this.template.querySelector('.disagreeBothButton'); 
        AgreeBtn.style.backgroundColor = '#1DAE83';
        AgreeBtn.style.color = '#fff';
        this.template.querySelector('.agreebutton').style = '';
        if(this.isShowAgreeSplitButton){
            this.template.querySelector('.agreesplitbutton').style = '';
        }
        if (this.isDsputedAmtLessthanZeroBut3){
            this.template.querySelector('.disagreeSchemeButton').style = '';
        }
   
        // this.template.querySelector('.agreesplitbutton').style = '';
        // this.template.querySelector('.disagreeSchemeButton').style = '';
    }
    BothDonotAgreeHandler(event){
       let isValid = true;
        // if(this.isBankDetails == false){
        if(this.isBankDetailsPresent == false && this.isUserAmount == true){
            this.isbankdetailsNotAvl4 = true;
            this.showAddBankDetailBtn = false;
            this.showEditBankDetailBtn = false;
            this.showAddBankDetailInRedBtn = true;
            isValid = false;
            this.noBankParentValue = true;
            this.template.querySelector('c-e-i_-n-i_-create-update-bank-details').showWarning(this.noBankParentValue);
        }
        else{
            this.isbankdetailsNotAvl4 = false;
        }
        console.log('button-4 submit clicked');
        if(isValid){
            this.PageSpinner = true;
            NotAgreeAGLLAndSchemeBothbyTenant({caseId :this.caseId,agreedAmount : this.amountToTenantByAGLL,depositAmount : this.depositAmount,
                endDateByTenant:this.tenancyEndDateYMD,depositId:this.depositsId,scheme:'NI Custodial',branchId:this.branchId})
            .then(result=>{
                if(result == 'Success'){
                    console.log('Both donot agree respond sent successfully');
                    this.confirmationSection = false;
                    this.hideWindow1 = false;
                    this.isShowThankyouPage = true;
                    this.thankyousuccessMsg = true;
                    this.isNotAgreeAndSchemeBoth = true;
                    this.PageSpinner = false;
                }
            })
            .catch(error=>{
                console.log('error both not agree @@@@'+error);
                console.log('Failed both not agree  @@@@'+JSON.stringify(error));
            });
        }
       
    }
    submitRespondForm(event){
        event.preventDefault();
        this.PageSpinner = true;
        if(this.clickedButton ==='AgreeButton1'){
            console.log('button-1 submit clicked'+this.clickedButton );
            console.log('button-1 TenAmt==>'+this.amountToTenantByAGLL+'depAmt==>'+ this.depositAmount);
        updateCaseAgreetoAGLLbyTenant({caseId:this.caseId,agreedAmount:this.amountToTenantByAGLL,depositAmount:this.depositAmount,
            endDateByTenant:this.tenancyEndDateYMD,depositId:this.depositsId,scheme:'NI Custodial',branchId:this.branchId})
        .then(result=>{
            if(result == 'Success'){
                console.log('Repayment agreed by tenant ');
                this.isShowThankyouPage = true;
                this.thankyousuccessMsg = true;
                this.isAgreeToAGLLRequest = true;
                this.confirmationSection = false;
                this.PageSpinner = false;
            }
        })
        .catch(error=>{
            console.log('Error occured @@@@'+error);
            console.log('Failed  @@@@'+JSON.stringify(error));

        });
        }
        else if(this.clickedButton ==='DoNotAgreeButSchemButton3'){
            console.log('button-3 submit clicked');
            console.log('amtToAgLL by tenant$$$==>'+this.claimedItemsDetailsObjStr);
            console.log('AgLLAmtbyTT=>'+JSON.stringify(this.tenantCasepartList));
            let tenantCasepartListStr = JSON.stringify(this.tenantCasepartList);
            console.log('tenantOtherReason in 1265 line: '+this.tenantOtherReason);
            updateCaseNotAgreeAGLLButWishToSchemebyTenant({caseId: this.caseId, amountToTTbyTT: this.amountToTenantByTT, 
                tenantClaimedItems: tenantCasepartListStr,claimedItems: this.claimedItemsDetailsObjStr,
                otherReason: this.tenantOtherReason,depositAmount:this.depositAmount,endDateByTenant:this.tenancyEndDateYMD,depositId:this.depositsId,scheme:'NI Custodial',branchId:this.branchId})
                
            .then(result=>{
                console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant result => ' + result);
                if(result == 'Successfully updated'){
                    this.isShowThankyouPage = true;
                    this.schemeSucessMsg = true;
                    this.isNotAgreeButScheme = true;
                    this.confirmationSection = false;
                    this.PageSpinner = false;
                }
            }).catch(error=>{
                console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant error => ' + JSON.stringify(error));
            })
        }
        else if(this.clickedButton ==='AgreeButSplitButton2'){
            let tenantCasepartSplitListStr = JSON.stringify(this.tenantCasepartList);
            console.log('splitTenList=>'+tenantCasepartSplitListStr);
            console.log('End Date==>'+this.myDate);
            console.log('depositId==>'+this.depositsId);
            agreedRepaymetSplitAmtEachTenant({caseId:this.caseId, tenantClaimedItems:tenantCasepartSplitListStr,
                endDateByTenant:this.tenancyEndDateYMD,depositId:this.depositsId,scheme:'NI Custodial',
                agreedAmount:this.amountToTenantByAGLL,depositAmount:this.depositAmount,branchId:this.branchId})
            .then(result=>{
                if(result == 'Successfully updated'){
                    this.confirmationSection = false;
                    this.isShowThankyouPage = true;
                    this.thankyousuccessMsg = true;
                    this.PageSpinner = false;
                    if(this.isUserAmount){
                        this.isAgreeToAGLLRequest = true;
                    }else{
                        this.thankyousuccessMsg = true;
                        this.isNotRecivePayment = true;
                    }
                    
                }
            })
            .catch(error=>{
                    console.log('errror accured button2==>'+JSON.stringify(error));
                    console.log('errror button2==>'+(error));
            });
        }
    }
    goBackHandle(event){
        event.preventDefault();
        window.history.back();
    }
    goBackFromSummarySection(event){
        event.preventDefault();
        this.confirmationSection = false;
        this.hideWindow1 = true;
        var tenancyDate = this.tenancyEndDateDMY;
        console.log('line 1501-->: ' + tenancyDate);
        //  console.log('line 935 date-->'+depositDate.substring(3, 5));
        for (let ind in this.tenancyDateList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyDate.substring(0, 2) == this.tenancyDateList[ind].value) {
                console.log('Line 1506 Deposit date-->' + this.tenancyDateList[ind].value);
                this.tenancyDateList[ind].isSelected = true;
            }
            else {
                this.tenancyDateList[ind].isSelected = false;

            }
        }

        for (let ind in this.tenancyMonthList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyDate.substring(3, 5) == this.tenancyMonthList[ind].value) {
                console.log('Line 1517 Deposit month-->' + this.tenancyMonthList[ind].value);
                this.tenancyMonthList[ind].isSelected = true;
            }
            else {
                this.tenancyMonthList[ind].isSelected = false;

            }
        }

        for (let ind in this.tenancyYearList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyDate.substring(6, 10) == this.tenancyYearList[ind].value) {
                console.log('Line 1528 Deposit month-->' + this.tenancyYearList[ind].value);
                this.tenancyYearList[ind].isSelected = true;
            }
            else {
                this.tenancyYearList[ind].isSelected = false;

            }
        }
        if(this.clickedButton ==='AgreeButton1'){
            setTimeout(() => {
                let AgreeBtn = this.template.querySelector('.agreebutton'); 
                AgreeBtn.style.backgroundColor = '#1DAE83';
                AgreeBtn.style.color = '#fff';
                this.template.querySelector('.agreesplitbutton').style = '';
                this.template.querySelector('.disagreeSchemeButton').style = '';
                this.template.querySelector('.disagreeBothButton').style = '';

        },1000);

        }else if(this.clickedButton ==='AgreeButSplitButton2'){
            setTimeout(() => {
                let AgreeBtn = this.template.querySelector('.agreesplitbutton'); 
                AgreeBtn.style.backgroundColor = '#1DAE83';
                AgreeBtn.style.color = '#fff';
                this.template.querySelector('.agreebutton').style = '';
                this.template.querySelector('.disagreeSchemeButton').style = '';
                this.template.querySelector('.disagreeBothButton').style = '';
        },1000);
        var casePartList = this.tenantCasepartList;
        console.log('backCasePartlist==>'+JSON.stringify(this.tenantCasepartList));
        var arr= this.isBackCasepartList;
        var dep=this.tenantCasepartList;
       
        for(let i in arr){
            for(let j in dep){
                if(arr[i].id== dep[j].id){
                    console.log('******');
                    dep[j].tenantReqValue=arr[i].tenantReqValue;
                }
            }
        }

        }else if(this.clickedButton ==='DoNotAgreeButSchemButton3'){
            console.log('button#3#Back');
            this.showResolveByTds = true;
            console.log('onBackAgLLAmtbyTT=>'+JSON.stringify(this.tenantCasepartList));
            console.log('isbackcaplist==>'+JSON.stringify(this.isBackCasepartList));
            var arr= this.isBackCasepartList;
            var dep=this.tenantCasepartList;
           
            for(let i in arr){
                for(let j in dep){
                    if(arr[i].id== dep[j].id){
                        console.log('******');
                        dep[j].tenantReqValue=arr[i].tenantReqValue;
                    }
                }
            }
           
        }

    }
    HandlegoToDepSummary(event){
        event.preventDefault();
        window.history.back();
    }

    onDatePickerChangeHandler(event){
        this.pickedValue = event.target.value;
        // tenancyDateList, tenancyMonthList,  tenancyYearList
        //  date picker code start
        console.log('onDatePickerChangeHandler date picker => '+ event.target.value);
        let dateVal = new Date(event.target.value);
        var day = dateVal.getUTCDate();
        var month = dateVal.getUTCMonth() + 1;
        var year = dateVal.getUTCFullYear();

        for(let i=0; i< this.tenancyDateList.length; i++){
            if(this.tenancyDateList[i].value == day){
                this.tenancyDateList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyDateList[i].value;

            }else{
                this.tenancyDateList[i].isSelected = false;  
            }

        }
        for(let i=0; i< this.tenancyMonthList.length; i++){
            if(this.tenancyMonthList[i].value == month){
                this.tenancyMonthList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyMonthList[i].value;
            }else{
                this.tenancyMonthList[i].isSelected = false;  
            }
        }

        for(let i=0; i< this.tenancyYearList.length; i++){
            if(this.tenancyYearList[i].value == year){
                this.tenancyYearList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyYearList[i].value;
            }else{
                this.tenancyYearList[i].isSelected = false;  
            }
        }

        this.checkTenancyEndDate(event);
    }
   
}