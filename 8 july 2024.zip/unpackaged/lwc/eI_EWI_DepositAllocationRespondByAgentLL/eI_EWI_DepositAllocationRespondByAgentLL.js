import { LightningElement, track, wire } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import getCaseParticipantDetails from "@salesforce/apex/eI_EWI_DepositAllocationProposalCls.getCaseParticipantDetails";
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import updateCaseRespondbyAGLL from "@salesforce/apex/eI_EWI_DepositAllocationProposalCls.updateCaseRespondbyAGLL";
import getEvidenceAttchObj from "@salesforce/apex/eI_EWI_DepositAllocationProposalCls.getEvidenceAttchObj" //TGK-340
import updateCaseAgreedbyAGLL from "@salesforce/apex/eI_EWI_DepositAllocationProposalCls.updateCaseAgreedbyAGLL";
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

export default class EI_EWI_DepositAllocationRespondByAgentLL extends NavigationMixin(LightningElement) {
    ew_arrow_dropleft = EWITheme + '/assets/img/ew-arrow-dropleft.png';
    pound_icon = EWITheme + '/assets/img/pound_icon.png';
    home_icon = EWITheme + '/assets/img/home_icon.png';
    circle_checked_icon = EWITheme + '/assets/img/circle_checked_icon.png';

    @track caseDetails;
    @track caseParticipantDetails;
    @track accessCode;
    @track formattedEndDate;
    @track depositAmount;
    @track isDepoAllocProposal = false;
    @track isShowThankyouPage = false;
    @track depositAmountReceived = 0.00;
    @track depositAmountClaimed = 0.00;
    @track otherName = '';
    @track claimedItems = [];
    @track summaryDisputeItems = [];
    @track isAmountReceivedYES = false;
    @track isAmountReceivedNO = false;
    @track showIfRecieved0 = false;
    @track showIfRecievedFullAmount = false;
    @track isProposalSummarySubmit = false;
    @track isDepositSummaryReview = false;
    @track showIfClaimedMoreAmount = false;
    //@track isDisbaleNObtn = false;
    @track isDisbaleYESbtn = false;
    @track isOtherNameRequired = false;
    @track isOtherNameLimitExceed = false;
    @track showDetails=true;
    @track disablesubmit=false;

    @track claimexceedamount = 0.00;
    @track newclaimexceedamount = 0.00;
    @track claimexceedYES = false;
    @track claimexceedNO = false;
    @track showclaimexceedmessage = false;
    @track showclaimexceeddetails = false;
    @track claimexceedbuttonselected = false;
    @track claimexceedbuttonselectedrequired = false;
    @track claimexceedenteramountrequired = false;
    @track showExceedAmountFieldToForm = false;

    //TGK-340 : START
    @track claimexceedenteramountReasonrequired = false; 
    @track isOpenClaimBreakDownPage = false;
    @track isFirstPageOpen = false;
    @track reasonLengthforTotalClaim = 0;
    @track reasonForClaimAmount ='';
    @track showNegotiatePart = false;
    @track hideNegotiatePart = false;
    @track reasonLength = 0;
    @track reasonForNegotiation = '';
    @track isShowAccessClaimValue = false;   // need to change this value as false when functionality implemented
    @track accessclaimAmount = 0;  //it is used on third page while previewing the acceess claim amount
    @track evidenceAttachments =[];
    @track isReviewPage3Open = false;
    @track isGobackForPage1 = false;
    //@track claimItemAmountReasonrequired = false;
    @track isNegotiationCheck = false; //TGK-340: P2
    @track negotiationDescRequiredError = false; //TGK-340: P2
    @track showAmountToTT =true; //TGK-340: P2
    @track isShowNegotiationError = false;

    //TGK-340 : END
    
    get isOtherClaimEntered(){
        if(this.claimedItems[5].value > 0 )
            return true;
        return false;
    }

    // get otherNameRequired(){
    //     if(this.otherName == '') 
    //         return true;
    //     return false;
    // }

    connectedCallback(){
    // @wire(CurrentPageReference)
    // getpageRef(pageRef) {
        // console.log('data => ', JSON.stringify(pageRef));
        // console.log("pageReference state => " + JSON.stringify(pageRef.state));
        // console.log("pageReference state Id => " + pageRef.state.id);
        // let recId = pageRef.state.id;
        // let location = window.location.href;
        // console.log('location => ' + location);

      setTimeout(() => { window.history.forward();  }, 0);

        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const caseId = urlParams.get('caseId');
        console.log('caseId => ' + caseId);
        const accessCode = urlParams.get('accessCode');
        this.accessCode = accessCode;
        if(accessCode == '' || accessCode == null){
            this.showDetails = false;
            return;
          }
        console.log('accessCode => ' + accessCode);

        getCaseParticipantDetails({accessCode : this.accessCode}).then(result1 => {
            if(result1==null){
                this.showDetails=false;
                return;
              }
              this.showDetails=true;
            console.log("getCaseParticipantDetails success result 1: ", result1);
            this.caseParticipantDetails = result1;
            this.caseDetails = result1.Case__r;
            this.depositAmount = (result1.Case__r.Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2);
            this.isDepoAllocProposal = true;
            
            var endDate = new Date( this.caseDetails.Deposit_Account_Number__r.End_Date__c);
            if(isNaN(endDate)){
                this.dateValue='';
            } 
            else if(endDate!= null || endDate!= undefined|| endDate!= ''){
                var checkdate = endDate.getDate().toString().padStart(2, "0");;
                var checkmonth = (endDate.getMonth()+1).toString().padStart(2, "0");
                var checkyear = endDate.getFullYear();
                var newDate = checkdate +'/'+ checkmonth+'/'+checkyear;
                this.formattedEndDate = newDate;
                console.log('endDate => '+ endDate );
                console.log('formattedEndDate => '+this.formattedEndDate);     
                console.log('depositAmount => '+this.depositAmount); 
            } 

            //TGK-340 : to get the list of evidense attachment : START
                
            getEvidenceAttchObj({caseId : this.caseDetails.Id}).then(result => {
                console.log("getEvidenceAttchObj result : ", result);
                if(result != null ){
                    this.evidenceAttachments = result;
                }
            }).catch(error => {
                console.log("getEvidenceAttchObj error : ", error);
            });
            
            //TGK-340 : to get the list of evidense attachment : END

        }).catch(error => {
            console.log("getCaseParticipantDetails error 1: ", error);
        });

    this.claimedItems.push({value:0, key:'Cleaning', reason:'', claimItemAmountReasonrequired: false,claimItemAmountReasonlengtherror: false, disablereason : true});
    this.claimedItems.push({value:0, key:'Damage', reason:'', claimItemAmountReasonrequired: false, claimItemAmountReasonlengtherror: false,disablereason : true});
    this.claimedItems.push({value:0, key:'Redecoration', reason:'', claimItemAmountReasonrequired: false, claimItemAmountReasonlengtherror: false,disablereason : true});
    this.claimedItems.push({value:0, key:'Gardening', reason:'', claimItemAmountReasonrequired: false, claimItemAmountReasonlengtherror: false,disablereason : true});
    this.claimedItems.push({value:0, key:'Rent arrears', reason:'', claimItemAmountReasonrequired: false,claimItemAmountReasonlengtherror: false,disablereason : true});
    this.claimedItems.push({value:0, key:'Other', reason:'', claimItemAmountReasonrequired: false,claimItemAmountReasonlengtherror: false,disablereason : true});
    }

    restrictDecimal(event) {  
        var t = event.target.value;
        return (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t
        
        // if(t.includes(".")){
        //     var arr = t.split(".");
        //     var lastVal = arr.pop();
        //     var arr2 = lastVal.split('');
        //     if (arr2.length > '1') {
        //         event.preventDefault();
        //     }
        // }
    }

    removeZero(event) {
        // alert('remove zero');
        var edValue = event.target.value;
        
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        // alert('remove zero 1');
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        // alert('remove zero 3');
        
        if(trimeVal.includes('.')){
            // alert('remove zero 4');
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            // alert('remove zero 5');
            event.target.value = trimeVal;
        }
    }

    restrictNegativeVal(event){
        if(event.target.value < 0){
            event.target.value = 0;
        }
    }

    handleGoBack(event) {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'home'
            },
            state:{
                accessCode: this.accessCode
            }
        });
    }

    //TGK-340: handle go back for page 2 : START 
    handleGoBackForPage2(event){
        this.isOpenClaimBreakDownPage = false;
        this.isDepoAllocProposal = true;
        //this.showAddressFlag = false;
        this.isGobackForPage1 = false;
        this.isFirstPageOpen = false;

         setTimeout(() => {
            this.template.querySelector('.amt-recv-yes-btn').classList.add('bg-color-blue'); 
            this.template.querySelector('.amt-recv-no-btn').classList.remove('bg-color-blue');

            if(this.showExceedAmountFieldToForm == true){
                this.template.querySelector('.amt-recv-yes1-btn1').classList.add('bg-color-blue'); 
                this.template.querySelector('.amt-recv-no1-btn1').classList.remove('bg-color-blue');
                // this.template.querySelector('.amt-recv-yes-btn5').classList.add('bg-color-blue');
                // this.template.querySelector('.amt-recv-no-btn5').classList.remove('bg-color-blue');
            }else{
                this.template.querySelector('.amt-recv-yes1-btn1').classList.remove('bg-color-blue'); 
                this.template.querySelector('.amt-recv-no1-btn1').classList.add('bg-color-blue');
                // this.template.querySelector('.amt-recv-yes-btn5').classList.remove('bg-color-blue');
                // this.template.querySelector('.amt-recv-no-btn5').classList.add('bg-color-blue');
            }           
        }, 100);  
    }
    //TGK-340: handle go back for page 2 : END 

    handleDepositAmountReceivedChange(event){
        let val = this.restrictDecimal(event);
        event.target.value = val;
        this.depositAmountReceived = (event.target.value);
    }

    showExceedAmountField(){
        this.claimexceedYES = true;
        this.claimexceedNO = false;
        this.showExceedAmountFieldToForm = true;
        this.claimexceedbuttonselected = true;
        this.claimexceedbuttonselectedrequired = false;
        this.template.querySelector('.amt-recv-yes1-btn1').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-no1-btn1').classList.remove('bg-color-blue');
    }

    hideExceedAmountField(){
        this.claimexceedamount = 0;
        this.newclaimexceedamount = 0;
        this.claimexceedYES = false;
        this.claimexceedNO = true;
        this.showExceedAmountFieldToForm = false;
        this.claimexceedbuttonselected = true;
        this.claimexceedbuttonselectedrequired = false;
        this.template.querySelector('.amt-recv-no1-btn1').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-yes1-btn1').classList.remove('bg-color-blue');
    }

    //TGK-340 : show Negociate part    
    handleNegotiateYES(){
        console.log('test ')
        this.showNegotiatePart = true;
        this.hideNegotiatePart = false;
        this.template.querySelector('.amt-recv-yes-btn5').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-no-btn5').classList.remove('bg-color-blue');
        this.isNegotiationCheck = true;
    }
    //TGK-340 : hide Negociate part    
    handleNegotiateNO(){
        console.log('NO====>');
        this.showNegotiatePart = false;
        this.hideNegotiatePart = true;
        this.template.querySelector('.amt-recv-no-btn5').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-yes-btn5').classList.remove('bg-color-blue');
        this.isNegotiationCheck = true;
    }

    CalculateExceedClaimAmount(event){
        let val = this.restrictDecimal(event);
        event.target.value = val;
        this.claimexceedamount = event.target.value.trim(); //Added By Himanshi For ISD-28166
        this.newclaimexceedamount = this.claimexceedamount;
    }

    //TGK-340 : For checking the and null amount value for claim amiunt reason : START
    onChangeReasonForClaimAmount(event){
        //check the length of text
        this.reasonLengthforTotalClaim = event.target.value.trim().length; //Added By Himanshi For ISD-28166
        this.reasonForClaimAmount = event.target.value;
        
        //TGK-340 : P2 : START
        console.log('this.reasonLengthforTotalClaim ==> '+this.reasonLengthforTotalClaim);
        let checkTheSize = this.template.querySelector('.checkSizeForError');
        if(this.reasonLengthforTotalClaim < 20 || this.reasonLengthforTotalClaim > 100){
            console.log('Hello Size 200');
            checkTheSize.style = 'border: 2px solid red';
        }
        else{
            console.log('In else --->');
            checkTheSize.style =  'border: 2px solid green';
        }
        ////TGK-340 : P2 : END

    }

    handleAmountReceivedYES(){
        this.isAmountReceivedYES = true;
        this.isAmountReceivedNO = false;
        this.template.querySelector('.amt-recv-yes-btn').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-no-btn').classList.remove('bg-color-blue');
    }

    handleAmountReceivedNO(){
        this.depositAmountReceived = 0.00;
        this.depositAmountClaimed = 0.00;
        this.isAmountReceivedNO = true;
        this.isAmountReceivedYES = false;
        for(let ind in this.claimedItems ){
            this.claimedItems[ind].value = 0.00;
        }
        this.otherName = '';
        this.template.querySelector('.amt-recv-no-btn').classList.add('bg-color-blue'); 
        this.template.querySelector('.amt-recv-yes-btn').classList.remove('bg-color-blue');
    }
    handleSubmit(event){
        this.disablesubmit = true;
        event.preventDefault();
        updateCaseAgreedbyAGLL({caseId: this.caseDetails.Id, 
            agreedAmount: this.depositAmountClaimed,
            depositAmount: this.depositAmount}).then(result => {
            console.log("updateCaseAgreedbyAGLL result => " + result);
            this.isShowThankyouPage = true;
            let makededuction = '';
            if(this.isAmountReceivedYES){
                makededuction = 'Yes';
            }else if(this.isAmountReceivedNO){
                makededuction = 'No';
            }
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'ewithankyou'
                },
                state:{
                    accessCode: this.accessCode,
                    thanksfor: 'respondedbyagll',
                    makededuction: makededuction
                }
            });
            this.isDepoAllocProposal = false;
            this.isDepositSummaryReview = false;
        }).catch(error => {
            console.log("updateCaseAgreedbyAGLL error => ", error);
        });
    }
    handleDepositSummaryReview(){
        window.location.href =  EWIVPlus_Link+this.accessCode;
        
        // let currentURL = window.location.href;
        // console.log('currentURL => ' + currentURL);
        // let homeURL = currentURL.split('/ewinsured/s');
        // console.log('homeURL => ' + homeURL);
        // let redirectToURL = homeURL[0]+'/ewinsured/s/?accessCode='+this.accessCode;
        // console.log('redirectToURL => ' + redirectToURL);
        // window.location.href = redirectToURL; //"https://espdev2-thedisputeservice.cs80.force.com/ewinsured/s/?accessCode="+this.accessCode;

    }
    handleCalculateClaimAmount(event){
        let val = this.restrictDecimal(event);
        event.target.value = val;

        let index = event.target.title;
        let claimItemValue = event.target.value.trim();
        this.claimedItems[index].value = claimItemValue;

         //TGK-340 : field validation for claim amount START 
         let allInputTag = this.template.querySelectorAll('.claimReason'); 
         console.log('allInputTag====> '+allInputTag);
         console.log('claimItemValue length====> '+claimItemValue.length);
 
         //let depositeAmount = 5000;        
         let prices = this.template.querySelectorAll('.sumOfClaimAmount');
         console.log('prices1111====> '+prices[0].value);
         
         let sum = 0;
         for (let i=0;i<prices.length;i++) {
             console.log('sum for loop');
             sum += parseFloat(prices[i].value);
             console.log('prices ====> '+sum);
         }        
         console.log('Out Sum === >'+sum);                                                                                                                   
         //write the error
         console.log('depositAmount for Error ===> '+this.depositAmount);
         if(sum > this.depositAmount){
            
             //let lastValue = allInputTag[index].value;
             let priceVal = this.claimedItems[index].value.substring(0,this.claimedItems[index].value.length-1);
             console.log('Amount check for this ==> '+priceVal);
             console.log('Amount check for this2222 ===> '+ priceVal);
 
             this.claimedItems[index].value = priceVal;
             prices[index].value = priceVal;
             console.log('Inside the sum'+this.claimedItems[index].value);
 
             //Indexing error
             prices[index].style = 'border: 2px solid red'; // need to change the error border
             let errorMessages = this.template.querySelectorAll('.claimedFieldError');
             errorMessages[index].textContent = 'You cannot enter a figure greater than the deposit amount.  If your claim exceeds the deposit amount, you can provide details of this on the next page.'
         }
         else{
             let errorMessages2 = this.template.querySelectorAll('.claimedFieldError');
             errorMessages2[index].textContent = '';
             prices[index].style = '';
         }
         
         //TGK-340 : enable -disable the claim reason input field : START
         if(claimItemValue.length > 0){
             //allInputTag[index].disabled = false;
             this.claimedItems[index].disablereason = false;
         }
         else{
             this.claimedItems[index].disablereason = true;
            // allInputTag[index].disabled = true;
             allInputTag[index].value = '';
         }
         //TGK-340 : enable -disable the claim reason input field : END
        //TGK-340 : field validation for claim amount START 

        this.depositAmountClaimed = 0;
        
        for(let ind in this.claimedItems ){
            console.log(" on change claimedItem => " + this.claimedItems[ind].value);
            if(this.claimedItems[ind].value > 0){
                this.depositAmountClaimed = (parseFloat(this.depositAmountClaimed) + parseFloat(this.claimedItems[ind].value)).toFixed(2);
                this.depositAmountReceived = (parseFloat(this.depositAmount) - parseFloat(this.depositAmountClaimed)).toFixed(2); //Added By Himanshi For ISD-31307
            }
        }
        //ISD-31307 : Autocalculate the deposite Amount received -- Commented by Himanshi For ISD-28166
        //this.depositAmountReceived = (parseFloat(this.depositAmount) - parseFloat(this.depositAmountClaimed)).toFixed(2);

        //TGK-340: P2 : START
        if(this.depositAmountReceived <= 0){
            this.showAmountToTT = false;
        }else{
            this.showAmountToTT = true;
        }
        //TGK-340 : P2 : END

        this.isOtherNameRequired = false;
    }

     //TGK-340 : To capture the reasons for claim amount for 2nd page: START
     onChangeClaimAmountReason(event){
        let allLenPTag = this.template.querySelectorAll('.charSize');
        let allClaimReasonInputTag = this.template.querySelectorAll('.claimReason');
        let index = event.target.title;
        allLenPTag[index].textContent = event.target.value.trim().length;
        this.claimedItems[index].reason = event.target.value.trim(); ////Added by himanshi for ISD-28166
        //console.log();

        //TGK-340 : START
        if(this.claimedItems[index].reason.length > 0 || this.claimedItems[index].reason.length == null || this.claimedItems[index].reason.length == undefined){
            //console.log();
            this.claimedItems[index].claimItemAmountReasonrequired =false;
        }
        if(this.claimedItems[index].reason.length > 0 &&  this.claimedItems[index].reason.length > 20 && this.claimedItems[index].reason.length < 150){  //ISD-31159 Changed to 150 characters
            //console.log();
            this.claimedItems[index].claimItemAmountReasonlengtherror =false;
        }
        //TGK-340 : END

        //TGK-340 : P2 : Highlight Input box : START
        console.log('allClaimReasonTagValue[index].value.length == > '+this.claimedItems[index].reason.length);
        if( this.claimedItems[index].reason.length < 20 ||  this.claimedItems[index].reason.length > 100){
            console.log('print hightlighted');
            allClaimReasonInputTag[index].style = 'border: 2px solid red'; // need to change the error border
        }
        else{
            console.log('Amilia kar');
            allClaimReasonInputTag[index].style  = 'border: 2px solid green'; // need to change the error border            
        }
        //TGK-340 : P2 : Highlight input box : END
        
    }
    //TGK-340 : To capture the reasons for claim amount : END

    //TGK-340 : calculate the size of text reason value : START   
    calReasonTextSize(event){
        console.log('Hi first change');
        this.reasonLength = event.target.value.length;
        this.reasonForNegotiation = event.target.value;

        let isNegotiationFilled = this.template.querySelector('.isNegotiationFilled');
        console.log('test Size of negotiation ==>'+this.reasonLength);
        if(this.reasonLength < 150 || this.reasonLength > 500){
            isNegotiationFilled.style = 'border: 2px solid red';        
        }
        else{
            isNegotiationFilled.style = 'border: 2px solid green';
        }
  
    }

    handleOtherName(event){
        var othertext = event.target.value;
        if(othertext.length > 300){
            event.target.value = othertext.substring(0, 300);
            this.otherName = othertext.substring(0, 300);
            this.isOtherNameLimitExceed = true;
        }else{
            this.otherName = othertext;
            this.isOtherNameLimitExceed = false;
        }
    }

    //TGk-340 : Continue Button for Page 1: Claim Overview
    handleClaimOverviewContinue(event){
        event.preventDefault();

        let isValidAmount = true;
        if(this.claimexceedYES == true){
            this.showclaimexceedmessage = true;
            }
            else{
                this.showclaimexceedmessage = false;   
            }

         //TGK-340 : P2: START
        console.log('try this is the false==> '+this.isNegotiationCheck);
        // if(this.isNegotiationCheck == false){
        //     console.log('this is the console for negotiation ');
        //     isValidAmount = false;
        //     this.isShowNegotiationError = true;
        // }
        // else{
        //     this.isShowNegotiationError = false;
        // }
        //TGK-340 : END

        //check for total claim amount not null   //   //TGK-340 : P2 : Added this.showExceedAmountFieldToForm
        if((this.claimexceedamount==0 || this.claimexceedamount == null || this.claimexceedamount == undefined || this.claimexceedamount == ' ') && this.showExceedAmountFieldToForm ==true){
            console.log('Test Amount is null');
            this.claimexceedenteramountrequired = true;
            isValidAmount = false;
        }else{
            this.claimexceedenteramountrequired = false;
        }

        //TGK-340 : START : Access claim amount visible
        if(this.claimexceedamount!=0 || this.claimexceedamount != null || this.claimexceedamount != undefined || this.claimexceedamount != ' '){
            this.accessclaimAmount  = (parseFloat(this.claimexceedamount) - parseFloat(this.depositAmount)).toFixed(2); 
            if(this.accessclaimAmount > 0){
                this.isShowAccessClaimValue = true;
            }  
        }      
        //TGK-340 : END : Access claim amount

        //check for total claim amount reason not null
        //check for total claim amount not null   //   //TGK-340 : P2 : Added this.showExceedAmountFieldToForm
        if((this.reasonForClaimAmount==0 || this.reasonForClaimAmount == null || this.reasonForClaimAmount == undefined || this.reasonForClaimAmount == ' ') && this.showExceedAmountFieldToForm==true ){
            this.claimexceedenteramountReasonrequired = true;
            isValidAmount = false;
            console.log('Test Amount Reason is null');
        }else{
            this.claimexceedenteramountReasonrequired = false;
        }

        //TGK-340: P2 :START
        if((this.reasonForClaimAmount.length < 20 || this.reasonForClaimAmount.length > 100) && this.showExceedAmountFieldToForm ){
            this.claimexceedenteramountReasonrequired = true; //we can change the attribute
            isValidAmount = false;
            console.log('Test Amount Reason is null');
        }
        else{
            this.claimexceedenteramountReasonrequired = false;
        }
        //TGK-340 : P2 : END
       
        console.log('isValidAmount ==> '+isValidAmount);
        if(isValidAmount){
            console.log('Hello 123');
            this.isOpenClaimBreakDownPage = true;
            this.isFirstPageOpen = true;
            this.isGobackForPage1 = true;
        }
        else{
            console.log('hello 456');
            this.isOpenClaimBreakDownPage = false;
            this.showAddressFlag = false;
            return;
        }
        //TGK-340 : add and remove the active for status bar
       /* this.template.querySelector('.pageBar2').classList.add('active');
        this.template.querySelector('.pageBar1').classList.remove('active');*/
        
    }

    //Continue button for page 2 : Claim Breakdown
    handleClaimContinue(event){
        let isValid = true;
        if(this.depositAmountReceived > 0){
            this.depositAmountReceived = (parseFloat(this.depositAmountReceived)).toFixed(2);
            console.log('depositAmountClaimed ==>'+this.depositAmountReceived);

        }else{
            this.depositAmountReceived = (parseFloat(0.00)).toFixed(2);
        }
        if(this.depositAmountClaimed > 0){
            this.depositAmountClaimed = (parseFloat(this.depositAmountClaimed)).toFixed(2);
            console.log('depositAmountClaimed ==>'+this.depositAmountClaimed);
        }else{
            this.depositAmountClaimed = (parseFloat(0.00)).toFixed(2);
            console.log('depositAmountClaimed ==>'+this.depositAmountClaimed);

        }
        this.summaryDisputeItems=[];
        console.log("handleClaimContinue => " + this.claimedItems);
        for(let ind in this.claimedItems ){
            console.log('claimedItems['+ind+'].value => ' + this.claimedItems[ind].value);
            if( this.claimedItems[ind].value > 0){
                this.summaryDisputeItems.push({value:(parseFloat(this.claimedItems[ind].value)).toFixed(2), key:this.claimedItems[ind].key, previewReason:this.claimedItems[ind].reason});
            
                if(this.claimedItems[ind].value > 0 && this.claimedItems[ind].reason.length < 20){
                //TGK-340
                if(this.claimedItems[ind].reason.length == 0 || this.claimedItems[ind].reason == null || this.claimedItems[ind].reason == undefined){
                    console.log('Test Aditya Yadav == > ');
                    this.claimedItems[ind].claimItemAmountReasonrequired = true;
                    this.claimedItems[ind].claimItemAmountReasonlengtherror = false;
                    isValid = false;
                }

                else if(this.claimedItems[ind].reason.length > 0 &&  (this.claimedItems[ind].reason.length < 20 ||  this.claimedItems[ind].reason.length > 150)){
                    this.claimedItems[ind].claimItemAmountReasonlengtherror = true;
                    this.claimedItems[ind].claimItemAmountReasonrequired = false;
                    isValid = false;
                }
                else{
                    this.claimedItems[ind].claimItemAmountReasonlengtherror = false;
                    this.claimedItems[ind].claimItemAmountReasonrequired = false; 
                    isValid = true;
                }
                }
                

            }
            
        }

       
        
        if((( parseFloat(this.depositAmountClaimed) + parseFloat(this.depositAmountReceived) ).toFixed(2)) != (parseFloat(this.caseDetails.Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2))){
            console.log('parseFloat(this.depositAmountClaimed ==>'+this.depositAmountClaimed);
            console.log('parseFloat(this.depositAmountReceived ==>'+this.depositAmountReceived);

            this.showIfClaimedMoreAmount = true;
            isValid = false;
        }else{
            this.showIfClaimedMoreAmount = false;
        }

        //TGK-340 : Commented due to change of TGK-340 : START
        /*
        if(this.isOtherClaimEntered && this.otherName == ''){
            this.isOtherNameRequired = true;
            isValid = false;
        }else{
            this.isOtherNameRequired = false;
        }*/

        // if(this.isOtherNameLimitExceed){
        //     isValid = false;
        // }
        //TGK-340 : Commented due to change of TGK-340 : END

        if(this.claimexceedbuttonselected==false){
            isValid = false;  
            this.claimexceedbuttonselectedrequired = true;
            this.template.querySelector(".errorMsgDiv2").scrollIntoView();
        }
        else{
            this.claimexceedbuttonselectedrequired = false; 
        }

        if( this.claimexceedbuttonselected==true && this.claimexceedYES==true &&  (this.claimexceedamount==0 || this.claimexceedamount == null
          || this.claimexceedamount == undefined || this.claimexceedamount == ' '  ))
        {    isValid = false;  
            this.claimexceedenteramountrequired = true;
            this.template.querySelector(".errorMsgDiv1").scrollIntoView();
        }
        else { 
            this.claimexceedenteramountrequired = false; 
        }
        console.log('Hello Aditya == > ');
         //TGK-340 : error handling on continue button : START
         let allClaimReasons = this.template.querySelectorAll('.claimReason'); 
         let allClaimAmounts = this.template.querySelectorAll('.sumOfClaimAmount');
         let index = event.target.title;

         console.log('Hello Aditya all claim amount == > '+JSON.stringify(allClaimAmounts));
         console.log('Hello Aditya all claim reason == > '+JSON.stringify(allClaimReasons));
        
         
         //TGK-340 : if ammount is filled and reason is not provided : END
 
          //TGK-340 : error handling on continue button : END
        
        if(isValid){
            if(this.claimexceedYES==true && this.newclaimexceedamount>0){
                this.showclaimexceeddetails = true;
            }
            else{
                this.showclaimexceeddetails = false;  
            }
            this.claimexceedbuttonselectedrequired = false; 
            this.claimexceedenteramountrequired = false;
            this.showIfClaimedMoreAmount = false;
            this.isOtherNameRequired = false;
            this.isOtherNameLimitExceed = false;
            this.isDepoAllocProposal = false;
            this.isDepositSummaryReview = true;
        }
    }
    handleSummaryReviewGoBack(event){
    let allInputTag = this.template.querySelectorAll('.claimReason'); 

        this.isDepoAllocProposal = true;
        this.isDepositSummaryReview = false;
        //TGK-340 : comented for changes : START
        // setTimeout(() => {
        
        // for(let ind in this.claimedItems ){
        // if(this.claimedItems[ind].value >0) {
        //     alert(this.claimedItems[ind].value);
        //     alert(allInputTag[ind].disabled);
        // allInputTag[ind].disabled = false;
        // }

        // }

        // }, 100);   
        //TGK-340 : comented for changes : END   

      
    }
    handleSubmitProposal(){
        console.log("this.claimedItems => " + JSON.stringify(this.claimedItems));
        this.isDisbaleYESbtn = true;
        this.template.querySelector('.submit-btn').classList.remove('bg-color-blue');
        this.template.querySelector('.submit-btn').classList.add('disable_ew_btn');

        var objectofMap = {};
        var objectMapForReason = {}; //TGK-340

        for(let ind in this.claimedItems){
            if(this.claimedItems[ind].value > 0){
                objectofMap[this.claimedItems[ind].key] = this.claimedItems[ind].value;
                objectMapForReason[this.claimedItems[ind].key] = this.claimedItems[ind].reason; //TGK-340
            }
            console.log("key => " + this.claimedItems[ind].key);
            console.log("value => " + this.claimedItems[ind].value);
            console.log("objectofMap => " + JSON.stringify(objectofMap));
        }
        var objectofMapstr = JSON.stringify(objectofMap);
        var objectMapForReasonStr = JSON.stringify(objectMapForReason);

        updateCaseRespondbyAGLL({caseId: this.caseDetails.Id, amountToTenant: this.depositAmountReceived, initiatedBy: this.caseParticipantDetails.Type__c, 
            caseParId: this.caseParticipantDetails.Id,
            claimedItems: objectofMapstr, itemReasons: objectMapForReasonStr , claimamount :this.newclaimexceedamount,
            totalClaimReason :this.reasonForClaimAmount, negotiationReason :this.reasonForNegotiation }).then(result => {
            console.log("updateCaseRespondbyAGLL result => " + result);
            if(result == 'Agll Responded'){
                this.handleDepositSummaryReview();
            }else if(result == 'Successfully updated'){
                this.isShowThankyouPage = true;
                let makededuction = '';
                if(this.isAmountReceivedYES){
                    makededuction = 'Yes';
                }else if(this.isAmountReceivedNO){
                    makededuction = 'No';
                }
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: {
                        pageName: 'ewithankyou'
                    },
                    state:{
                        accessCode: this.accessCode,
                        thanksfor: 'respondedbyagll',
                        makededuction: makededuction
                    }
                });
                this.isDepoAllocProposal = false;
                this.isDepositSummaryReview = false;
            }
        }).catch(error => {
            console.log("updateCaseRespondbyAGLL error => ", error);
        });
    }
 //TGK-340 : This method is used for File upload part :START
 handleChangeEviAttachmentList(event){
    var attachmensts = [];
    if(event.detail.type == 'upload'){
        
       // alert("upload file type" + attachmensts.length);
     //  let aviAttachment = event.detail.evidanceAttachment;
       let aviAttachment = event.detail.evidanceAttachment;
       attachmensts = [...this.evidenceAttachments, aviAttachment];
       //attachmensts.push(aviAttachment);
       
       // alert("push attachment" + attachmensts.length);
       this.evidenceAttachments = attachmensts;
       // alert("Add again attachemnt");
    }else if(event.detail.type == 'delete'){
       console.log('event.detail.deletedAttachment.Id => ' + event.detail.deletedAttachment.Id);
       for(let index in this.evidenceAttachments){
          console.log('this.evidenceAttachments[index].Id => ' + this.evidenceAttachments[index].Id);
          
          if(this.evidenceAttachments[index].Id != event.detail.deletedAttachment.Id){
             attachmensts.push(this.evidenceAttachments[index]);
          }
       }
       this.evidenceAttachments = attachmensts;
    }else if(event.detail.type == 'Case Status Changed'){
       this.handlegotoDepositSummary();
    }
    console.log('this.evidenceAttachments after => '+ JSON.stringify(this.evidenceAttachments));
}
//TGK-340 : This method is used for File upload part :END
    renderedCallback() {
        const style = document.createElement('style');
        style.innerText = '.slds-popover .slds-popover__body{font-size:13px}.deposit_steps .deposit_steps_detail .claim-amont-calculation .form-group .slds-input {color:#333;background: #f0f0f0;border-color: #b8b8b8;outline: 1px solid #cccbcb; border-radius: 0.5rem;}.deposit_steps .deposit_steps_detail .form-group .deposit-upload-file-details textarea{height:205px}.deposit-upload-file p{font-size:1.2rem; line-height: 16px;}.claim-col-details .slds-form-element__icon{position: absolute;top: -22px}.claim-col-details .slds-form-element__icon svg{width: 16px;height: 16px;fill: #12185b;}';
        this.template.querySelector('.deposite-location-sec').appendChild(style);
    }

}