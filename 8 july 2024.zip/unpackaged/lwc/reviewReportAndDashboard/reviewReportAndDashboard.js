import { LightningElement, wire, track } from 'lwc';
import getUnassignedCases from '@salesforce/apex/ReviewReportandDashboardContr.getUnassignedCases';

const columns = [
    { label: 'Case Number', fieldName: 'caseNumberUrl', type: 'url', typeAttributes: { label: { fieldName: 'caseNumber' }, target: '_blank' }},
    { label: 'Case Owner', fieldName: 'OwnerName' },
    { label: 'Account Name', fieldName: 'AccountName' },
    { label: 'Subject', fieldName: 'Subject' },
    { label: 'Date email received', fieldName: 'CreatedDate', type: 'date', typeAttributes: { 
        year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' 
    }},
    { label: 'No. working days since received', fieldName: 'workingDays', type: 'number', cellAttributes: { alignment: 'left' }},
    { label: 'Open', fieldName: 'IsOpen', type: 'boolean' },
    { label: 'Closed', fieldName: 'IsClosed', type: 'boolean' }
];

export default class ReviewReportandDashboard extends LightningElement {
    @track cases = [];
    @track allcases = [];
    @track pageNumber = 1;
    @track pageSize = 20;
    @track totalRecords;
    @track startDate = null;
    @track endDate = null;
    @track isLoading = false; // Track spinner state
    columns = columns;

    @wire(getUnassignedCases, { pageNumber: '$pageNumber', pageSize: '$pageSize', startDate: '$startDate', endDate: '$endDate' })
    wiredCases({ error, data }) {
        if (data) {
            this.isLoading = false; // Turn off spinner when data is received
            this.cases = data.cases.map(caseRecord => ({
                ...caseRecord,
                caseNumberUrl: `/lightning/r/Case/${caseRecord.Id}/view`
            }));
            this.allcases = data.allcases;
            this.totalRecords = data.totalRecords;
        } else if (error) {
            console.error('Error fetching cases:', error);
            this.isLoading = false; // Ensure spinner is turned off in case of error
        } else {
            this.isLoading = true; // Display spinner while data is loading
        }
    }

    get totalPages() {
        return Math.ceil(this.totalRecords / this.pageSize);
    }

    get disablePrevious() {
        return this.pageNumber <= 1;
    }

    get disableNext() {
        return this.pageNumber >= this.totalPages;
    }

    previousPage() {
        if (this.pageNumber > 1) {
            this.isLoading = true; // Display spinner when fetching previous page
            this.pageNumber -= 1;
        }
    }

    nextPage() {
        if (this.pageNumber < this.totalPages) {
            this.isLoading = true; // Display spinner when fetching next page
            this.pageNumber += 1;
        }
    }

    handleStartDateChange(event) {
        this.startDate = event.target.value;
        this.pageNumber = 1;
    }

    handleEndDateChange(event) {
        this.endDate = event.target.value;
        this.pageNumber = 1;
    }

    exportToExcel() {
        // Convert the data to CSV
        let csvContent = 'data:text/csv;charset=utf-8,';
        const columnHeaders = this.columns.map(col => col.label).join(',');
        csvContent += columnHeaders + '\n';

        this.allcases.forEach(record => {
            let row = this.columns.map(col => {
                if (col.fieldName === 'caseNumberUrl') {
                    return record.caseNumber;
                } else {
                    return record[col.fieldName];
                }
            }).join(',');
            csvContent += row + '\n';
        });

        // Create a link to download the CSV file
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', 'unassigned_cases.csv');
        document.body.appendChild(link);

        // Download the CSV file
        link.click();
        document.body.removeChild(link);
    }
}