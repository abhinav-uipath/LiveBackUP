import { LightningElement } from 'lwc';

export default class TrsTenantAccordian extends LightningElement {}