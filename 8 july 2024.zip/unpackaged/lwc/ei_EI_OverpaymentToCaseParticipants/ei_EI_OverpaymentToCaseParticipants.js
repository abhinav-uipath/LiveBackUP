import { LightningElement,wire,api,track } from 'lwc';
import getCaseParticipants from '@salesforce/apex/Case_Participants_TriggerHandler.getCaseParticipants' ;
import saveOverPaymentDetails from '@salesforce/apex/Case_Participants_TriggerHandler.saveOverPaymentDetails' ;
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import UserProfileName from '@salesforce/schema/User.Profile.Name';

export default class Ei_EI_OverpaymentToCaseParticipants extends LightningElement {
 @api recordId;
 @track openModal = false;
 @track showResult ;
 @track caseParticipantslist = [];
 @track showerrormsg = false;
 @track showEditButton = false;
 @track disablebutton = false;
 userId = Id;
 currentUserProfileName;
 @track showButton = false;
 @track isLoading = false;

@wire(getRecord, { recordId: Id, fields: [UserProfileName ]}) 
userDetails({error, data}) {
if (data) {
    this.currentUserProfileName = data.fields.Profile.value.fields.Name.value;
    if(this.currentUserProfileName  == 'System Administrator' || this.currentUserProfileName  =='Credit Control'){
        this.showButton = true;
    } 
    else{
        this.showButton = false;
    }
} else if (error) {
    this.error = error ;
}
}

 showModal() {
    this.openModal = true;
    this.isLoading = true;
    getCaseParticipants({caseId:this.recordId, isEdit : false}).then(result =>{
    this.isLoading = false;
    this.showResult = result;
    let caseParticipantslist = [];
    
    this.showResult.forEach(caseParticipants => {
        caseParticipantslist.push({
        recordId : caseParticipants.Id,
        caseId :  caseParticipants.Case__c,
        participantName: caseParticipants.Account__r.Name,
                        //   caseParticipants.RecordType.Name =='EWI Case Participant'
                        //   ?caseParticipants.First_Name__c+' '+caseParticipants.Last_Name__c:
                          
        isSelected : caseParticipants.Is_overpaid__c == true ? true :false,
        participantType : caseParticipants.Type__c,
        overPaymentAmount :caseParticipants.Overpayment_amount__c ==undefined ? 0 : caseParticipants.Overpayment_amount__c ,
        overPaymentReceivedAmount :caseParticipants.Overpayment_received_amount__c ==undefined ? 0 : caseParticipants.Overpayment_received_amount__c ,
        isFirstChaserSent : caseParticipants.First_chaser_sent__c == true ? true :false,
        isSecondChaserSent : caseParticipants.Second_chaser_sent__c == true ? true :false,
        overPayedAmount: caseParticipants.Payable_Amount__c,
        showerror:false,
        errormessage:''                
        });
    });
    this.caseParticipantslist = caseParticipantslist;
    for(let i=0;  i < this.caseParticipantslist.length; i++){
        if(this.caseParticipantslist[i].isSelected == true ){
            this.showEditButton = true;
        }
        }
        
    })
    .catch (error =>{

    });
}

editParticipant() {
    this.isLoading = true;
    getCaseParticipants({caseId:this.recordId, isEdit : true}).then(result =>{
        this.isLoading = false;
    this.showResult = result;
    let caseParticipantslist = [];
    
    this.showResult.forEach(caseParticipants => {
        caseParticipantslist.push({
        recordId : caseParticipants.Id,
        caseId :  caseParticipants.Case__c,
        participantName: caseParticipants.Account__r.Name,
        // caseParticipants.RecordType.Name =='EWI Case Participant'
        //                   ?caseParticipants.First_Name__c+' '+caseParticipants.Last_Name__c:caseParticipants.Account__r.Name,
        isSelected : caseParticipants.Is_overpaid__c == true ? true :false,
        participantType : caseParticipants.Type__c,
        overPaymentAmount :caseParticipants.Overpayment_amount__c ==undefined ? 0 : caseParticipants.Overpayment_amount__c ,
        overPaymentReceivedAmount :caseParticipants.Overpayment_received_amount__c ==undefined ? 0 : caseParticipants.Overpayment_received_amount__c ,
        isFirstChaserSent : caseParticipants.First_chaser_sent__c == true ? true :false,
        isSecondChaserSent : caseParticipants.Second_chaser_sent__c == true ? true :false,
        overPayedAmount: caseParticipants.Payable_Amount__c,
        showerror:false,
        errormessage:''                
        });
    });
    this.caseParticipantslist = caseParticipantslist;
    for(let i=0;  i < this.caseParticipantslist.length; i++){
        if(this.caseParticipantslist[i].isSelected == true ){
            this.showEditButton = true;
        }
        }
        
    })
    .catch (error =>{

    });
}
closeModal() {
    this.openModal = false;
}

handleSelect (event){
var checkboxvalue = event.target.checked;
var cprecordid = event.target.name;
let cpList = this.caseParticipantslist;
for(let i=0;  i < cpList.length; i++){
if(cpList[i].recordId == cprecordid && cpList[i].isSelected  != checkboxvalue ){
    cpList[i].isSelected  = checkboxvalue;
}
}
}

handleSelectFirstChaser (event){
var checkboxvalue = event.target.checked;
var cprecordid = event.target.name;
let cpList = this.caseParticipantslist;
for(let i=0;  i < cpList.length; i++){
if(cpList[i].recordId == cprecordid && cpList[i].isFirstChaserSent  != checkboxvalue ){
    cpList[i].isFirstChaserSent  = checkboxvalue;
}
}
}

handleSelectSecondChaser (event){
var checkboxvalue = event.target.checked;
var cprecordid = event.target.name;
let cpList = this.caseParticipantslist;
for(let i=0;  i < cpList.length; i++){
if(cpList[i].recordId == cprecordid && cpList[i].isSecondChaserSent  != checkboxvalue ){
    cpList[i].isSecondChaserSent  = checkboxvalue;
}
}
}

handleInput(event){
var inputvalue = event.target.value;
var cprecordid =  event.target.name;
let cpList = this.caseParticipantslist;
for(let i=0;  i < cpList.length; i++){
if(cpList[i].recordId == cprecordid && cpList[i].overPaymentAmount  != inputvalue){
if(inputvalue ==null || inputvalue =='' || inputvalue == undefined){
    cpList[i].overPaymentAmount  = 0 ;
}
else{
    cpList[i].overPaymentAmount  = inputvalue;   
}

}
}
}

handleInputReceivedAmount(event){
var inputvalue = event.target.value;
var cprecordid =  event.target.name;
let cpList = this.caseParticipantslist;
for(let i=0;  i < cpList.length; i++){
if(cpList[i].recordId == cprecordid && cpList[i].overPaymentReceivedAmount  != inputvalue){
if(inputvalue ==null || inputvalue =='' || inputvalue == undefined){
    cpList[i].overPaymentReceivedAmount  = 0 ;
}
else{
    cpList[i].overPaymentReceivedAmount  = inputvalue;   
}

}
}
}

saveDetails(){
let CPdetailsobj = {};
var isvalid = true;
let cpList = this.caseParticipantslist;

for(let i=0;  i < cpList.length; i++){
if(cpList[i].overPaymentAmount > 0 && cpList[i].isSelected == false ){
    cpList[i].showerror = true;
    this.showerrormsg = true;
    cpList[i].errormessage = 'You must select checkbox before entering the overpayment amount.'
    isvalid = false;
}
else if(cpList[i].overPaymentAmount < 0 ){
    cpList[i].showerror = true;
    this.showerrormsg = true;
    cpList[i].errormessage = 'You must enter valid amount.'
    isvalid = false;
}
else if(cpList[i].isSelected == true && (cpList[i].overPaymentAmount == 0 || cpList[i].overPaymentAmount ==null || cpList[i].overPaymentAmount =='' || cpList[i].overPaymentAmount == undefined )){
    cpList[i].showerror = true;
    this.showerrormsg = true;
    cpList[i].errormessage = 'Please enter Overpayment Amount.'
    isvalid = false;
}
else if(cpList[i].isSelected == true && cpList[i].overPaymentAmount > 0 && (cpList[i].overPaymentAmount > cpList[i].overPayedAmount  )){
    cpList[i].showerror = true;
    this.showerrormsg = true;
    cpList[i].errormessage = 'The overpaid amount cannot exceed the paid amount.'
    isvalid = false;
}
else{
    cpList[i].showerror = false;
}


}


if(isvalid){
for(let ind in this.caseParticipantslist){
    let detailobj = {};
    detailobj['isSelected'] = this.caseParticipantslist[ind].isSelected;
    detailobj['overPaymentAmount'] = this.caseParticipantslist[ind].overPaymentAmount;
    detailobj['overPaymentReceivedAmount'] = this.caseParticipantslist[ind].overPaymentReceivedAmount;
    detailobj['isFirstChaserSent'] = this.caseParticipantslist[ind].isFirstChaserSent;
    detailobj['isSecondChaserSent'] = this.caseParticipantslist[ind].isSecondChaserSent;
    CPdetailsobj[this.caseParticipantslist[ind].recordId] = detailobj;
}
this.disablebutton = true;

saveOverPaymentDetails ({cpUpdatedDetails : JSON.stringify(CPdetailsobj),caseId:this.recordId }).then(result =>{
    if(result =='success'){
           this.showerrormsg = false; 
            const event = new ShowToastEvent({
                title: 'Success!',
                variant: 'warning',
                mode: 'dismissable',
                message:
                    'Overpayment details stored successfully.',
            });
            this.dispatchEvent(event);
            this.openModal = false;
           setTimeout(function() {
           window.location.reload();
           }, 1000);
            
           
    }
   
})
.catch(error=>{
    console.log('saveOverPaymentDetails error => ' + JSON.stringify(error));
})
}
}



}