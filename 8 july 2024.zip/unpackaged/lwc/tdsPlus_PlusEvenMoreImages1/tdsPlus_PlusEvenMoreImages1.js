import { LightningElement, wire, api} from 'lwc';
import { getContent, listContent, getRecord, getFieldValue, getContentVersionUrl } from "experience/cmsDeliveryApi";
// import { getContent } from 'lightning/cmsContentApi';
import Maintainance_popup_window from '@salesforce/label/c.Maintainance_popup_window';
import siteId from "@salesforce/site/Id";
import communityId from "@salesforce/community/Id";
// import getManagedContentByContentKeys from '@salesforce/apex/EI_NI_Website_CmsContent.getManagedContentByContentKeys'


export default class TdsPlus_PlusEvenMoreImages1 extends LightningElement {

     //Add salesforce cms containt
     @api contentKey;
     data;
     ctaContentKeyList = [];
     ctaContentList = [];
     popupcontain;
     
   
     @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
     onGetContent({ error, data }) {
         if(data) {
             this.data = data;
             console.log('Line 25 -> ');
             console.log('Line 25 -> '+JSON.stringify(data));
             console.log('Line 25 cms image list -> '+JSON.stringify(data.contentBody));
             console.log('Line 25 cms image list -> '+JSON.stringify(data.contentBody['sfdc_cms:collection']));
             let cmsCtaObjectList = data.contentBody['sfdc_cms:collection'];
             let ctaContentKeyList = [];
             for(let cmsImage of cmsCtaObjectList) {
                 ctaContentKeyList.push(cmsImage.contentKey);
             }
             this.ctaContentKeyList = ctaContentKeyList;
 
             for(let cmsImage of ctaContentKeyList) {
                 console.log('Line 36 -> '+cmsImage);
             }
             console.log('Line 25 ctaContentKeyList -> '+JSON.stringify(ctaContentKeyList));
 
             // Apex call to get the cms images
             getManagedContentByContentKeys({ 
                 communityId: communityId, managedContentIds: ctaContentKeyList, pageParam: 0, pageSize: 1, language: 'en_US', 
                 managedContentType: 'news', showAbsoluteUrl: false
             })
                 .then(result => {
                     if (result) {
                         console.log(`Line 48 result -> ${result}`);
                     }
                     else {
                         console.log(`Line 48 -> result not found`);
                     }
                 })
                 .catch(error => {
                     console.error('Line 48 getManagedContentByContentKeys Error -> '+JSON.stringify(error));
                 })
 
             console.log('Line 25 siteId -> '+siteId);
             console.log('Line 25 communityId -> '+communityId);
             console.log('Line 25 end -> ');
         }
         else {
             console.log('Line 25 data not available ');
         }
     }
}