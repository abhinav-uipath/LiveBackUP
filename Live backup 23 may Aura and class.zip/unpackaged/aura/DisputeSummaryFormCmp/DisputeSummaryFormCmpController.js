({
    doInit : function(component, event, helper) {
        var csId = component.get("v.recordId");
        component.set("v.recordId",csId);
        console.log('csId == >'+csId);
    },
    
	handleChange : function(component, event, helper) {
		var selectedOptionValue = event.getParam("value");
        console.log("Option selected with value: '" + selectedOptionValue);
        component.set("v.selectedOption",event.getParam("value"));   
	},
    
    hanldeGeneratePDF : function(component, event, helper) {
        // Handle button click
        console.log("Clicked Button!"+component.get("v.selectedOption"));
        
        if(component.get("v.selectedOption") == 'Tenant' || component.get("v.selectedOption") == 'Agent/Landlord'){
            
            var caseObjId = component.get("v.recordId");
			            
            //var urlString = window.location.href;
            //var baseURL = urlString.substring(0, urlString.indexOf("/s"));
            
            //var pageUrl = baseURL+'apex/DisputeSummaryFormVF?caseObjId='+caseObjId+'&formType='+component.get("v.selectedOption");
            //component.set("v.disputeFormSummary",'https://docs.google.com/gview?url='+pageUrl);
            
            let hostOrigin = $A.get("$Label.c.Org_vfpage_URL");
            console.log('hostOrigin == > '+hostOrigin);
            var pageUrl = hostOrigin+'/apex/DisputeSummaryFormVF?caseObjId='+caseObjId+'&formType='+component.get("v.selectedOption");
            
            //var pageUrl = 'https://thedisputeservice--fullcopy--c.sandbox.vf.force.com/apex/DisputeSummaryFormVF?caseObjId='+caseObjId+'&formType='+component.get("v.selectedOption");
            window.open(pageUrl, '_blank');
            $A.get("e.force:closeQuickAction").fire();
            //component.set("v.disputeFormSummary",pageUrl);
            
            //component.set("v.isPDFPreviewPage",false);
        }
        else{
            console.log('Please Select the proper value');
            helper.showErrorToast('Error!','Please select either the \'Tenant\' or \'Agent/Landlord\' option to generate the PDF.'); 
        }
    },
    closeModal : function(component, event, helper){
        console.log('close the model');
        $A.get("e.force:closeQuickAction").fire();
    }
})