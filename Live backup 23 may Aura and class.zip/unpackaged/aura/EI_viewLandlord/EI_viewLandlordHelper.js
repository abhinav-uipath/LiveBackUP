({
      logoutHelper: function(component) {
    		var name = component.get("v.currentUser.Name");
	/*	let x = document.cookie;
        console.log('cook ' + x);
       document.cookie = "UName="+name+" ; Expires = 1980-02-02T18:06:21.466Z;path=/;";
		let x2 = document.cookie;
        console.log('cook2 ' + x2);*/
      var cookie ={
          setCookie: function (strName, strValue,cntdays) {
				var days = cntdays != undefined && cntdays !== "" ? cntdays : 60,
					date = new Date(),
					domain = document.location.hostname;
				date.setTime(date.getTime() - ( 24 * 60 * 60 * 1000));
				var expires = date.toUTCString();
				// handle secure vs regular http differently for cookie purposes
				if (location.protocol == 'http:') {
					document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/";
				} else {
					document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
				}
			}
      }
         cookie.setCookie("UName",name,1);
        let currentURL = window.location.origin;
        let redirectURL = $A.get("$Label.c.Lightning_CommunityLogout_URL")+"secur/logout.jsp?retUrl="+$A.get("$Label.c.Lightning_Component_URL");
        window.location.replace(redirectURL);
  
    
	},
         nextLandlord: function(component, event, sObjectList, end, start, pageSize) {
    var Paginationlist = [];
    var counter = 0;
    for (var i = end + 1; i < end + pageSize + 1; i++) {
      if (sObjectList.length > i) {
        {
          Paginationlist.push(sObjectList[i]);
        }
      }
      counter++;
    }
    start = start + counter;
    end = end + counter;
    component.set("v.startPageLandlord", start);
    component.set("v.endPageLandlord", end);
    component.set("v.PaginationLandlordList", Paginationlist);
  },
     previousLandlord: function(component, event, sObjectList, end, start, pageSize) {
    var Paginationlist = [];
    var counter = 0;
    for (var i = start - pageSize; i < start; i++) {
      if (i > -1) {
        {
          Paginationlist.push(sObjectList[i]);
        }
        counter++;
      } else {
        start++;
      }
    }
    start = start - counter;
    end = end - counter;
    component.set("v.startPageLandlord", start);
    component.set("v.endPageLandlord", end);
    component.set("v.PaginationLandlordList", Paginationlist);
  }, 
  getMyLandlords : function(component, event, helper,selPickListValue) {
        var searchTextValue =$("#searchValue").val();
      if(searchTextValue == null){
          searchTextValue = '';
      }
        
       const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
          var branchId = urlParams.get('branchId');
  
      if(branchId != null){
        
          const branchIdList = atob(urlParams.get('branchId'));
           const myArray = branchIdList.split("&");
             let myName = myArray[0];
          branchId = myArray[1];
             var cookie ={
        	getCookie: function (strName) {
				var name = strName + "=";
				var ca = document.cookie.split(';');
				for (var i = 0; i < ca.length; i++) {
					var c = ca[i];
					while (c.charAt(0) == ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(name) == 0) {
						return c.substring(name.length, c.length);
					}
				}
				return false;
            },
          }
         // alert(propertyRecId);
            var uName = cookie.getCookie("UName");
        if(uName != myName){
           
            helper.logoutHelper(component);
        }
      }
       var action = component.get("c.myLandlordListNew");
         action.setParams({
            searchVar: searchTextValue,
             status : selPickListValue,
             branchId:branchId
        }); 
       console.log('@@ action '+action );
        action.setCallback(this, function (a) {
            var state = a.getState();
            var errors = a.getError();
           console.log(JSON.stringify(errors) +' landsearch '+state);
            if (state == "SUCCESS") {
                 component.set("v.PageSpinner",false); 
              console.log('returned value '+a.getReturnValue());
                if(a.getReturnValue()!=null ){
                    if(a.getReturnValue() == ''){
                        component.set("v.currentPageLandlord",0);
                    }else{
                        component.set("v.currentPageLandlord",1);
                    }
                    
                 //    document.getElementById("SelectItem").value = '-- Please select --';
                    component.set("v.LandlordListView",a.getReturnValue());
                 //   console.log('+++++++++LandlordListView++++'+component.get("v.LandlordListView"));
                  //  component.set("v.strRecordId",propertyRecId);                    
                    var pageSize = component.get("v.pageSizeLandlord");
                    var totalRecordsList = a.getReturnValue();
                //    console.log('+++++++++totalRecordsList++++'+totalRecordsList);
                    var totalLength = totalRecordsList.length;
                    component.set("v.totalRecordsCountLandlord", totalLength);
                    component.set("v.startPageLandlord", 0);
                    component.set("v.endPageLandlord", pageSize - 1);
                    var PaginationLandlordList = [];
                    for (var i = 0; i < pageSize; i++) {
                        if (component.get("v.LandlordListView").length > i) {
                            PaginationLandlordList.push(a.getReturnValue()[i]);
                        }
                    }//console.log('+++++++++PaginationLandlordList++++'+JSON.stringify(PaginationLandlordList));
                    component.set("v.PaginationLandlordList", PaginationLandlordList);
                  //  console.log('++++++PaginationLandlordList+++++++'+component.get("v.PaginationLandlordList"));
                    component.set("v.selectedCount", 0);
                    //use Math.ceil() to Round a number upward to its nearest integer
                    component.set("v.totalPagesCountLandlord", Math.ceil(totalLength / pageSize));
                 //   var xyz = getElementsByClassName("dataTables_empty");
                    for(i = 0; i < xyz.length; i++) {
                        xyz.style.visibility = 'hidden';
                    }
                   
                   // document.getElementsByClassName("dataTables_empty").style.visibility = 'hidden';
                }
                    component.set("v.PageSpinner",false); 
                              
                             
            }else{
             //   alert('error '+ JSON.stringify(errors));
            }
            
        });
        
        $A.enqueueAction(action);
  
    },
    
    fetchPhoneCodePicklist : function(component, event, helper){
       //  console.log('&&& ');
        var action2 = component.get("c.getPhoneCodePiclistValues");
        action2.setCallback(this, function(a) {
            var state = a.getState();
         //     console.log('&&&123 '+state);
            if (state === "SUCCESS"){
          //      console.log('a.getReturnValue() '+a.getReturnValue());
                component.set("v.phoneCodePicklist", a.getReturnValue());
            } 
        });
        $A.enqueueAction(action2);
         
    }
})