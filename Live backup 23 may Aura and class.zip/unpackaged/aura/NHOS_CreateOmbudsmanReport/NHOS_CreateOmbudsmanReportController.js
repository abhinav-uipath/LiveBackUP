({
    doInit : function(component, event, helper) {
        var caseId = component.get("v.recordId");
        var action = component.get("c.getCaseRecord");
        let flag=false;
        action.setParams({ caseId : caseId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                let returnValue =  response.getReturnValue();
                component.set("v.rdAddComment",returnValue[0].RD_Additional_Comments_on_Draft_Decision__c);
                var rdAddCommentValue = component.get("v.rdAddComment");
                component.set("v.csAddComment",returnValue[0].CS_Additional_Comments_on_Draft_Decision__c);
                var CSAddCommentValue = component.get("v.rdAddComment");

                for (let i=0;i<returnValue[0].Adjudication_Reports__r.length; i++)
                {
                    if(returnValue[0].Adjudication_Reports__r[i].Decision_Type__c =='Draft Decision')
                    {
                        component.set("v.ShowFinal",true);
                        //Added by Himanshi
                        component.set("v.adjudicationReportRecord",returnValue[0].Adjudication_Reports__r[i]);

                        if(!flag && returnValue[0].Adjudication_Reports__r[i].Status__c=='Published')
                        {
                            component.set("v.adjudicationReportRecord",returnValue[0].Adjudication_Reports__r[i]);
                            console.log('adjudicationReportRecord@@+'+adjudicationReportRecord);
                            flag =true;
                        }
                        
                    }
                }
                
            }else if (state === "ERROR") 
            {
                var errors = response.getError();
                if (errors)
                {
                    if (errors[0] && errors[0].message) 
                    {
                        
                    }
                } else 
                {
                  //  console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
        
    },
    handleClick : function(component, event, helper) {
        var caseId = component.get("v.recordId");
        var adjReport = component.get("v.adjudicationReportRecord");
        var decType = document.getElementById("decType").value;
        var action = component.get("c.createAdjReportRec");
        action.setParams({ caseId : caseId, 
                          decisionType : decType,
                          adjOldRecord : adjReport,
                          csAddComment : component.get("v.csAddComment"),
                          rdAddComment :component.get("v.rdAddComment")
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                let returnValue =  response.getReturnValue();
                component.set("v.nextButton",true);
                var reportid = response.getReturnValue();
                var navService = component.find("navService");
                
                var pageReference = {
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: reportid, 
                        actionName: 'view',
                        objectApiName: 'Adjudication_Report__c' 
                    }
                };
                navService.navigate(pageReference);
            }
            else if (state === "ERROR") 
            {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        
                    }
                } else {
                //    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action); 
        
        
    }
})