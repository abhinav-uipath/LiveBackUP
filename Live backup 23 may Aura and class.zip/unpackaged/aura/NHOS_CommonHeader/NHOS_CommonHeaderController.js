({
    doInit : function(component, event, helper) {
        var action = component.get("c.getUserDetails");
        action.setCallback(this, function (response) {
            
            if(response.getState() === 'SUCCESS')
            {                                  
                var res = response.getReturnValue();
                component.set("v.userName",res);
                component.set("v.userNameEncode",btoa(res));
                
                /******** Set cookies **********/
                var userName = component.get("v.userNameEncode");
                var isExit=false;
                let name = 'UName=';
                let ca = document.cookie.split(';');
                for(let i = 0; i < ca.length; i++) {
                    let c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        isExit = true;
                    }
                }
                
                if(isExit==false){
                    var strValue = userName;
                    //var domain = document.location.hostname;
                    var domain = 'nhos.org.uk';
                    var date = new Date();
                    date.setTime(date.getTime()+(1*24*60*60*1000));
                    var expires = date.toUTCString();
                    document.cookie = "UName=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
                }
                /******** Set cookies **********/
                 
            } 
        });
        $A.enqueueAction(action);
        
    },
    /*logout :  function(component, event, helper) {
        sessionStorage.clear();
        window.location.href = window.location.origin+'/nhos/s/login';
    }*/
    
    logout : function(component, event, helper) {
        var strValue = component.get("v.userNameEncode"); 
       // var domain = document.location.hostname;
        var domain = 'nhos.org.uk';
        var date = new Date(); 
        date.setTime(date.getTime()-(1*24*60*60*1000));
        var expires = date.toUTCString();
        document.cookie = "UName=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
                
        // let currentURL = window.location.origin;
        let redirectURL = $A.get("$Label.c.NHOS_Lightning_CommunityLogout_URL")+"secur/logout.jsp?retUrl="+$A.get("$Label.c.NHOS_Lightning_CommunityLogout_URL");
        window.location.replace(redirectURL); 
        //window.location.replace("https://thedisputeservice--nhos.my.salesforce.com/servlet/networks/switch?startURL/secur/logout.jsp");
    }
    
    /*,
    refreshParentViewEvent :function(component, event, helper){
        var pageName = event.getParam("pageName"); 
        component.set("v.pageName",pageName);
    }*/
})