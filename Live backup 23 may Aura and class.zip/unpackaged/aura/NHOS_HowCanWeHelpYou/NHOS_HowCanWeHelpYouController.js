({
    handleSubmitVisiblity: function(component, event, helper) {

       let myButton = component.find("myButton");
          myButton.set('v.disabled', false);
   },
   doInit : function(component) {       
       var pickvar = component.get("c.getPickListValuesIntoList");
       pickvar.setCallback(this, function(response) {
           var state = response.getState();
           if(state === 'SUCCESS'){
               var list = response.getReturnValue();
               component.set("v.picvalue", list);
           }
           else if(state === 'ERROR'){
               //var list = response.getReturnValue();
               //component.set("v.picvalue", list);
               alert('ERROR OCCURED.');
           }
       })
       $A.enqueueAction(pickvar);
   },
   
   validateEmail : function(component, event, helper) {
       
   },
   
   handleFNChange : function(component, event, helper) {
       let sfFirst = document.getElementById("sfFirst").value;
       document.getElementById("sfFirst").value = sfFirst.charAt(0).toUpperCase() + sfFirst.slice(1);
   },
   
   handleSNChange : function(component, event, helper) {
       let sfSurname = document.getElementById("sfSurname").value;
       document.getElementById("sfSurname").value = sfSurname.charAt(0).toUpperCase() + sfSurname.slice(1);
   },
   
   handlePhoneChange : function(component, event, helper) {
       let sfPhone = document.getElementById("sfPhone").value;
       sfPhone = sfPhone.replace(/[^\d]/g, '');
       document.getElementById("sfPhone").value = sfPhone;
   },
   
   handleLanNumChange : function(component, event, helper) {
       let sfTelephone = document.getElementById("sfTelephone").value;
       sfTelephone = sfTelephone.replace(/[^\d]/g, '');
       document.getElementById("sfTelephone").value = sfTelephone;
   },
   
   handleQueryChange : function(component, event, helper) {
       let sfMessage = document.getElementById("sfMessage").value;
       document.getElementById("sfMessage").value = sfMessage.charAt(0).toUpperCase() + sfMessage.slice(1);
   },
   
   handleClick : function(component, event, helper) { 
  //     console.log('insdide handle click');
       component.set("v.showPhoneError",false);
       component.set("v.showTelephoneError",false);
       component.set("v.showEmailError",false);
       component.set("v.firstNameError", false);
       component.set("v.SurNameError", false);
       component.set("v.QueryError",false);
       
       let isValid = true;
       let sfFirst = document.getElementById("sfFirst").value;
       let sfSurname = document.getElementById("sfSurname").value;
       let sfPhone = document.getElementById('phoneCodeId').selectedOptions[0].value;
       let sfphoneNo = document.getElementById("sfPhone").value;
       let sfTelephone = document.getElementById("sfTelephone").value;
       let sfMessage = document.getElementById("sfMessage").value;
       let sfEmail = document.getElementById("sfEmail").value;
       
       let phoneRegexFormat = /^\d{11}$/;
       if(!sfphoneNo || (sfPhone == '+44' && (!sfphoneNo.match(phoneRegexFormat) || !sfphoneNo.startsWith("07")))) {
           component.set("v.showPhoneError",true);
           isValid = false;    
       }
       
       if(!sfTelephone) {
           component.set("v.showTelephoneError",true);
           isValid = false;    
       }
       
       let regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
       if($A.util.isEmpty(sfEmail) || !sfEmail.match(regExpEmailformat)) {   
           component.set("v.showEmailError",true);
           isValid = false;
       }
       
       if(sfFirst == undefined || sfFirst == "" || sfFirst == null) {
           component.set("v.firstNameError", true);
           isValid = false;
       }    
       
       if(sfSurname == undefined || sfSurname == "" || sfSurname == null) {
           component.set("v.SurNameError", true);
           isValid = false; 
       }   
       if(sfMessage == undefined || sfMessage == "" || sfMessage == null) {
           component.set("v.QueryError", true);
           isValid = false; 
       }
       
      // console.log('isValid = ' + isValid);
       
       if(isValid) {
           component.set("v.personaldata.First_Name__c", sfFirst);
           component.set("v.personaldata.Last_Name__c", sfSurname);
           component.set("v.personaldata.Phone_Code__c", sfPhone);
           component.set("v.personaldata.Phone_Number__c", sfphoneNo);
           component.set("v.personaldata.Email_address__c", sfEmail);
           component.set("v.personaldata.Your_query__c", sfMessage);
           component.set("v.personaldata.Telephone_Number__c", sfTelephone);
           
           
           // call apex
           var action = component.get("c.getPrsnlDetails");
           action.setParams(
               {
                   insertPrsnlDetails: component.get("v.personaldata")
               }
           );
           action.setCallback(this,function(response){
               var state = response.getState();
               if (state=="SUCCESS"){
             //      console.log('response = ' + response.getReturnValue());
                   if(response.getReturnValue() == '')
                       component.set("v.isdatasubmitted",'True');
                   
                     var childCmp = component.find("cComp");
                       console.log('childCmp>> '+childCmp);
                        childCmp.sampleMethod();
               } else {
                   let message = 'Error: ';
                   let errors = response.getError();
                   // Retrieve the error message sent by the server
                   if (errors && errors.length > 0)
                       message = message + errors[0].message;
               //    console.log(message);
               }
               //console.log('Data is Saved!');
               
           });
           $A.enqueueAction(action);
       }
   },
   
   
})