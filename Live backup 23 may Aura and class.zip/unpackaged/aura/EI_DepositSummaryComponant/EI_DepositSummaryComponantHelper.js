({
    logoutHelper: function(component) {
        var name = component.get("v.currentUser.TestName__c");
/*	let x = document.cookie;
    console.log('cook ' + x);
   document.cookie = "UName="+name+" ; Expires = 1980-02-02T18:06:21.466Z;path=/;";
    let x2 = document.cookie;
    console.log('cook2 ' + x2);*/
  var cookie ={
      setCookie: function (strName, strValue,cntdays) {
            var days = cntdays != undefined && cntdays !== "" ? cntdays : 60,
                date = new Date(),
                domain = document.location.hostname;
            date.setTime(date.getTime() - ( 24 * 60 * 60 * 1000));
            var expires = date.toUTCString();
            // handle secure vs regular http differently for cookie purposes
            if (location.protocol == 'http:') {
                document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/";
            } else {
                document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
            }
        }
  }
     cookie.setCookie("UName",name,1);
    let currentURL = window.location.origin;
    let redirectURL = $A.get("$Label.c.Lightning_CommunityLogout_URL")+"secure/logout.jsp?retUrl="+$A.get("$Label.c.Lightning_Component_URL");
    window.location.replace(redirectURL);


},
 deleteAttacRecord : function(component, event, helper) {
    var delAttachId =   component.get("v.data");
      var actionDel = component.get("c.deleteAttachment");
    actionDel.setParams({ 
        attachid :delAttachId                   
    });
    actionDel.setCallback(this, function(response) {
        var state = response.getState();
        var res = response.getReturnValue();
        console.log(res+' state '+state);
        
    });
     $A.enqueueAction(actionDel); 
},
 getDPCHelper : function(component, event, helper) {
// 	console.log('Testhelper');
  var depositId = component.get("v.depsumlist[0].objdeposit.Id");
    var action = component.get("c.getDPC2");
     action.setParams({ 
        depositId :depositId                   
    });
    action.setCallback(this, function(response) {
   //     console.log('action');
        var state = response.getState();
        var res = response.getReturnValue();
     //   console.log(res+' state '+state);
        if (state === "SUCCESS") {
      //      console.log('Testres '+res);
        component.set("v.data",res);
         window.open("https://portal.safedepositsscotland.com/servlet/servlet.FileDownload?file="+res); 
       
        }
     
    });
    
    $A.enqueueAction(action);    
},
  topUpHelper: function(component,event,helper,depositId,topUpVal,topUpAmnt) {
 //  console.log('topUpVal '+topUpVal);
   
  
        const queryString = window.location.search;
      
    const urlParams = new URLSearchParams(queryString);
    const branchId = urlParams.get('branchId');
        const depId = urlParams.get('id');
  //     console.log('branchId '+branchId);
    var state;
        if(branchId != null){
                 state = {
                status: "held",
            id: depId,
            branchId : branchId,
                  topUpVal:topUpVal,
                  topUpAmnt:topUpAmnt
            };
        }else{
              state = {
                status: "held",
                id: depId,
             topUpVal:topUpVal,
                  topUpAmnt:topUpAmnt
            };
        }
    component.find("navService").navigate({
        type: "comm__namedPage",
        attributes: {
            pageName: "paydeposit"
        },
        state: state
    });
},

 serverCallHelper : function(component, apexAction, params ) {
    
    var p = new Promise( $A.getCallback( function( resolve , reject ) {
        var action = component.get("c."+apexAction+"");
        action.setParams( params );
        action.setCallback( this , function(callbackResult) {
            if(callbackResult.getState()=='SUCCESS') {
                resolve( callbackResult.getReturnValue() );
            }
            if(callbackResult.getState()=='ERROR') {
         //       console.log('Error message: ', callbackResult.getError() ); 
                reject( callbackResult.getError() );
            }
        });
        $A.enqueueAction(action);
    }));            
    return p;
    
},

getcurrentUserJobRoleNew: function(component,currentUser) {
//   console.log('resultAll3 --> '+currentUser.Contact.Job_role__c);
    var additionalPerm = currentUser.Contact.Additional_Permission__c;
    //  ISD-26122 : Verify if additionalPerm is Undefined
    if(typeof additionalPerm == "undefined")
        additionalPerm ='';
     if(currentUser.Contact.Job_role__c=='Dispute administrator' || currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Submit evidence'))
    {
   
        component.set("v.submitEvidence",true);
      //     console.log('submit '+component.get("v.submitEvidence"));
        }
    if(currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Edit tenant details'))
    {
        component.set("v.editTenant",true);
    }
     if(currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Edit landlord details'))
    {
        component.set("v.editLandlord",true);
    }
   if(currentUser.Contact.Job_role__c=='Dispute administrator' || currentUser.Contact.Job_role__c=='Finance administrator' || currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Download PI'))
    {
        component.set("v.downloadPI",true);
    }
       
   if(currentUser.Contact.Job_role__c.includes('Deposit') || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Respond to repayment request'))
    { 
    
        component.set("v.resRepayment",true);
    } 
    if(currentUser.Contact.Job_role__c.includes('Deposit') || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || additionalPerm.includes('Request repayment'))
    {
    
        component.set("v.reqRepayment",true);
    }  
     setTimeout(function(){
      component.set("v.PageSpinner",false); 
          }, 1000);
},

getcurrentUserJobRole: function(component,event,helper) {
   //   setTimeout(function(){
    var currentUser = component.get("v.currentUser");
   //   console.log('&& '+currentUser);

   //     console.log(currentUser.Profile.Name+' ** '+currentUser.Contact.Job_role__c);
  
  if(currentUser.Contact.Job_role__c=='Dispute administrator' || currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || currentUser.Contact.Additional_Permission__c=='Submit evidence')
    {
   
        component.set("v.submitEvidence",true);
     //      console.log('submit '+component.get("v.submitEvidence"));
        }
    if(currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || currentUser.Contact.Additional_Permission__c=='Edit tenant details')
    {
        component.set("v.editTenant",true);
    }
     if(currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' ||  currentUser.Contact.Additional_Permission__c=='Edit landlord details')
    {
        component.set("v.editLandlord",true);
    }
   if(currentUser.Contact.Job_role__c=='Dispute administrator' || currentUser.Contact.Job_role__c=='Finance administrator' || currentUser.Contact.Job_role__c=='Deposit, property & dispute administrator' || currentUser.Contact.Job_role__c=='Deposit & property administrator'  || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || currentUser.Contact.Additional_Permission__c=='Download PI')
    {
        component.set("v.downloadPI",true);
    }
       
   if(currentUser.Contact.Job_role__c.includes('Deposit') || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || currentUser.Contact.Additional_Permission__c=='Respond to repayment request')
    { 
    
        component.set("v.resRepayment",true);
    } 
    if(currentUser.Contact.Job_role__c.includes('Deposit') || currentUser.Contact.Job_role__c=='Head office administrator' || currentUser.Contact.Job_role__c=='Account administrator' || currentUser.Contact.Additional_Permission__c=='Request repayment')
    {
    
        component.set("v.reqRepayment",true);
    }   
         
       component.set("v.PageSpinner",false); 
     
},

})