({
    generateHelper: function(component, event, helper) {
              
 

    },
    doneWaiting: function(component, event, helper) {
               
  


    },
    
    doInit : function(component, event, helper) {
        component.set("v.changeovercancelled", false);
        
          const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
    
       const depositIdList = atob(urlParams.get('id'));
       const redirectUrl = urlParams.get('redirect');
        const myArray = depositIdList.split("&");
              let myName;
        var depositId;
        if(myArray.length >2){
            myName = myArray[0]+'&'+myArray[1];
             depositId = myArray[2];
            
        }else{
            myName = myArray[0];
             depositId = myArray[1];
        }
        var cookie ={
        	getCookie: function (strName) {
				var name = strName + "=";
				var ca = document.cookie.split(';');
				for (var i = 0; i < ca.length; i++) {
					var c = ca[i];
					while (c.charAt(0) == ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(name) == 0) {
						return c.substring(name.length, c.length);
					}
				}
				return false;
            },
          }
            var uName = cookie.getCookie("UName");
        console.log(redirectUrl+ ' red ' +uName +' ' +myName);
        console.log(myName+' uName '+uName);
        component.set("v.depositID",depositId);
        if(uName != myName && redirectUrl == null ){
           
            helper.logoutHelper(component);
        } 
        else{
            helper.serverCallHelper(component,'getDepositDetails',{ depositId : depositId })
        .then(function(resultAll) {
            var result = resultAll;
             
            component.set("v.depsumlist", result);
   			console.log('Line 26 -> ',JSON.stringify(component.get("v.depsumlist")));
               component.set("v.depcaselist", result[0].objcase);
            if(result.length>0) {
                component.set("v.depsumlist", result);
                component.set("v.noOfTenants",result[0].objDA.length);
          //       console.log('Line 69Len - ',result[0].objDA.length);
                if(result[0].objAR[0]) {    
                    component.set("v.adjudicatorreportlink",result[0].objAR[0].Webhook_Report_Link__c);
                }
                
                if(result[0].objdeposit.Deposit_Transferred__c && result[0].objdeposit.Status__c=="Deposits held by scheme" ){
                    component.set("v.depositTransferred" ,true);
                }
                
                if(result[0].objdeposit.Status__c=="Awaiting payment" ||result[0].objdeposit.Status__c=="Deposits held by scheme")
                {
                    component.set("v.hidebutton" ,false);
                    component.set("v.showAddNewTenantButton", true);
                
                } else {
                    component.set("v.hidebutton" ,true);
                    component.set("v.showAddNewTenantButton", false);
                }
                
                if(result[0].objinstall[0]) {
                    component.set("v.showAmmendMsg",true);
                    component.set("v.Topupamount",result[0].objinstall[0].Amount__c);
                }
                
                if(result[0].userData.Profile.Name=='Tenant') {
                    component.set("v.isLeadTenant",result[0].Leadtenant);
                    component.set("v.PageSpinner",false); 
                
                } else {
                    if(typeof(result[0].userData.Contact.Job_role__c) !== 'undefined' ){
                        helper.getcurrentUserJobRoleNew(component, result[0].userData);
                    
                    } else {
                        component.set("v.PageSpinner",false); 
                    }
                }
                
                for(var i=0; i<result[0].objDA.length; i++) {
            //        console.log('Line 69 - ',result[0].userData.ContactId);
            //        console.log('Line 69 - ',result[0].objDA[i].Contact__c);
            //        console.log('Line 69 - ',result[0].objDA[i].Istenantmoved__c);
                    if(result[0].userData.Contact.AccountId==result[0].objDA[i].Deposit_Holder__c && 
                       result[0].objDA[i].Istenantmoved__c) 
                    {
                        component.set("v.isTenantMoved",true);
                	}
                }    
             
            }
            
            if(result[0].objdeposit.Case_Status__c!=null || result[0].objdeposit.Case_Status__c!=undefined){
                var dateMonthYear = result[0].objcase[0].Respond_Date__c.split("-");
                 var deadlineDate = dateMonthYear[2]+'/'+dateMonthYear[1]+'/'+dateMonthYear[0];
                        console.log('line no 125' +deadlineDate); 
                 var party = result[0].objcase[0].LastModifiedBy.FirstName + ' ' + result[0].objcase[0].LastModifiedBy.LastName;
                    console.log('line no 128 ' + party);                     
                 var cancelDate = result[0].objcase[0].LastModifiedDate;
                    console.log('line no 130 ' + cancelDate);
                if(result[0].objdeposit.Case_Status__c == 'Evidence gathering TT'){
                   component.set("v.situationMsg","We have requested evidence from the lead tenant and they have until  " + deadlineDate + " to provide this.");
                  }
                 else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid - repayment agreed'){
                    component.set("v.situationMsg",'A mutual agreement has now been reached. We have processed the release of the deposit held in accordance with the agreement. If you have not provided us with your payment instructions, please visit "My account" to add these so we can make payment to you.');
                } 
                else if(result[0].objdeposit.Case_Status__c == 'Deposit transfer requested'){
                    console.log('line no 139');
                    component.set("v.situationMsg",'We are currently processing a request to transfer this deposit to another agent/landlord and waiting for the request to be accepted. An update will be provided in due course.');
                }                
                else if(result[0].objdeposit.Case_Status__c == 'Deposit transfer accepted'){
                    console.log('line no 139');
                    //component.set("v.situationMsg",'The deposit has now been transfered to " + party + " on "+ deadlineDate +".');
                    //Situation Msg Replaced by Abhiav Sharna, Related ISD-29112 date - 14/03/2024
                    component.set("v.situationMsg",'The deposit is now held with the scheme and is protected.');
                }                
                else if(result[0].objdeposit.Case_Status__c == 'Deposit transfer cancelled'){
                    console.log('line no 139');
                    component.set("v.situationMsg",'The deposit transfer has been cancelled by the current agent/landlord.');
                }                
                else if(result[0].objdeposit.Case_Status__c == 'Repayment requested - agent/landlord'){
                    component.set("v.situationMsg","The agent/landlord has raised a repayment request for this deposit. A response from the tenant(s) is required by " + deadlineDate + ". If no response has been received we will send a reminder before this deadline expires.");
                }
                    else if(result[0].objdeposit.Case_Status__c == 'Repayment disputed - self-resolution'){
                        console.log('line no 145');
                    component.set("v.situationMsg",'The case is currently in self-resolution. This is your chance to try and reach an agreement with the other party of the repayment of the deposit.');
                }
                 else if(result[0].objdeposit.Case_Status__c == 'Self-resolution - awaiting review'){
                    component.set("v.situationMsg",'The case is currently being reviewed into by a Resolution Executive to ensure reasonable attempts have been made to resolve the matter before this is accepted as a dispute.');
                }
                    else if(result[0].objdeposit.Case_Status__c == 'Evidence gathering AA/LL'){
                    component.set("v.situationMsg","We have requested evidence from the agent/landlord and they have until  " + deadlineDate + " to provide this.");
                }
                 else if(result[0].objdeposit.Case_Status__c == 'Awaiting evidence review'){
                    component.set("v.situationMsg",'The case is being reviewed before being sent to the adjudicator.');
                }                
                    else if(result[0].objdeposit.Case_Status__c == 'Evidence review complete'){                  
                     component.set("v.situationMsg","The case is currently with an adjudicator and we are no longer accepting any further evidence or comments. We aim to issue a decision around the  " + deadlineDate + ".");    
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Adjudication'){                   
                     component.set("v.situationMsg","The case is currently with an adjudicator and we are no longer accepting any further evidence or comments. We aim to issue a decision around the  " + deadlineDate + ".");
                }
                    else if(result[0].objdeposit.Case_Status__c == 'Decision issued - awaiting request for review'){
                    component.set("v.situationMsg",'The adjudication decision has now been sent to all parties. Please refer to the adjudication report linked to your previous email.');
                } 
                    else if (result[0].objdeposit.Case_Status__c == 'Review of decision requested') {
                        
                    component.set("v.situationMsg", "We have been requested to review the decision by one of the parties. We will advise of an update by no later than " + deadlineDate + ".");
                }
                    else if(result[0].objdeposit.Case_Status__c == 'Review request declined'){
                    component.set("v.situationMsg","We have declined a request to review the decision and all payments will now be made as per the decision issued on  " + deadlineDate + ".");
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Review request accepted'){
                    component.set("v.situationMsg",'We have accepted the review request and it is now in a queue to be sent to another adjudicator.');
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Review request accepted – assign to adjudicator'){
                    component.set("v.situationMsg","A request for review has been accepted and the decision is currently being reviewed by a second adjudicator. We aim to issue our final decision by no later than " + deadlineDate + ".");
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid - no dispute'){
                    component.set("v.situationMsg",'We have been notified that a mutual agreement has now been reached. We have processed the release of the deposit held in accordance with the agreement. Please refer to our email correspondence for further information.');
                }                
                else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid - resolved without adjudication'){
                    component.set("v.situationMsg",'A mutual agreement has now been reached. The release of the deposit held has been processed in accordance with the agreement. If you have not provided us with your payment instructions, please visit" +My account+ " to add these now to any relevant payments can be made.');
                }               
                    else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid - no evidence'){
                   // component.set("v.situationMsg","Evidence has not been received from " + party + " by the deadline provided. The deposit will now be released to the other party. This case is closed and cannot be reopened.");
                   //  Situation Msg Replaced by Abhiav Sharna, Related ISD-29112 date - 14/03/2024
                    component.set("v.situationMsg",'Evidence has not been received by the deadline from the last party invited to do so. The deposit will now be released to the other party. This case is closed and cannot be reopened.');
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Repayment requested - no response from tenant'){
                    component.set("v.situationMsg",'We have currently had no response from the tenant on the repayment request. A further update will be sent soon.');
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Repayment requested - tenant'){
                        console.log('line no 125' +deadlineDate);   
                    component.set("v.situationMsg","A tenant has raised a repayment request for this deposit. A response from the agent/landlord is required by " + deadlineDate + ". If no response has been received we will send a reminder before this deadline expires.");
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Tenant changeover accepted'){
                    component.set("v.situationMsg",'The tenant changeover was accepted by the outgoing tenants.');
                } 
                    else if(result[0].objdeposit.Case_Status__c == 'Tenant changeover cancelled'){
                    //component.set("v.situationMsg","The tenant changeover was cancelled by " + party + " on "+cancelDate+".");
                    //Situation Msg Replaced by Abhiav Sharna, Related ISD-29112 date - 14/03/2024
                    component.set("v.situationMsg",'The deposit is now held with the scheme and is protected.');
                } 
                    else if (result[0].objdeposit.Case_Status__c == 'Tenant changeover initiated - agent/landlord') {
                        
                    component.set("v.situationMsg", "A tenant changeover has been initiated by the agent/landlord. The tenant has until " + deadlineDate + " to respond.");
                }
                    else if (result[0].objdeposit.Case_Status__c == 'Tenant changeover initiated - tenant') {
                        
                  component.set("v.situationMsg", "A tenant changeover has been initiated by the tenant. The agent/landlord has until " + deadlineDate + " to respond.");
                }

                else if(result[0].objdeposit.Case_Status__c == 'No response from agent/landlord – chasing agent/landlord response to request'){
                    component.set("v.situationMsg",'There has been no response to this repayment request by the agent/landlord. A reminder has been sent to the agent/landlord to respond to this request.');
                } 
                   else if(result[0].objdeposit.Case_Status__c == 'Deposit closed - deposit repaid in part'){
                    component.set("v.situationMsg",'We are awaiting payment instructions. Please visit "My account" to ensure you have provided these.');
                } 
                 else if(result[0].objdeposit.Case_Status__c == 'Deposit closed - deposit repaid in full'){
                    component.set("v.situationMsg",'The deposit has been repaid. This deposit is now closed and is no longer protected. All monies have been paid out as per the agreement reached.');
                } 
                 else if(result[0].objdeposit.Case_Status__c == 'Deposit closed - unable to repay'){
                    component.set("v.situationMsg",'We are awaiting payment instructions. Please visit "My account" to ensure you have provided these.');
                }
                else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid - court case'){
                    //Added By Himanshi ISD-26024
                    component.set("v.situationMsg",'We have been notified that there are ongoing court proceedings. The deposit has been released back to the agent/landlord and Safe Deposits Scotland will take no further.');
                }
                else if(result[0].objdeposit.Case_Status__c == 'Deposit to be repaid – decision issued'){
                    component.set("v.situationMsg",'The adjudication decision has been issued to all parties and payments are being processed as per the adjudication report. If you have not provided us with your bank details, please visit "My account" to add these now to any relevant payments can be made.');
                }
                
            }
                 
            else {
               if(result[0].objdeposit.Status__c =='Registered (not paid)'){
                    component.set("v.situationMsg",'The deposit has been registered on our system, however, it is yet to be protected because we are awaiting payment.');
                }
                else if(result[0].objdeposit.Status__c == 'Awaiting payment'){
                    component.set("v.situationMsg",'The deposit has been registered on our system, however, it is yet to be protected because we are awaiting payment.');
                }
                
                else if(result[0].objdeposit.Status__c == 'Deposits held by scheme'){
                    component.set("v.situationMsg",'The deposit is now held with the scheme and is protected.');
                }
                
            }                  
            
        })
      
        }
 
        
      /*  var action = component.get("c.getDepositDetails");
        action.setParams({ depositId :depositId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
             //   console.log('line-->36'+JSON.stringify(result));

           //     console.log(result.length+" From server: " + JSON.stringify(response.getReturnValue()));
                if(result.length>0){
                    component.set("v.depsumlist" , response.getReturnValue());
              //       console.log('## '+JSON.stringify(result[0].objcase[0].AGLL_Respond_Evidance_Gathering__c));
                    if(result[0].objAR[0]){
                        component.set("v.adjudicatorreportlink",result[0].objAR[0].objAR.Webhook_Report_Link__c);
                    }
                    if(result[0].objdeposit.Deposit_Transferred__c && result[0].objdeposit.Status__c=="Deposits held by scheme" ){
                        component.set("v.depositTransferred" ,true);
                    }
                    
                    if(result[0].objdeposit.Status__c=="Awaiting payment" ||result[0].objdeposit.Status__c=="Deposits held by scheme")
                    {
                        component.set("v.hidebutton" ,false);
                        component.set("v.showAddNewTenantButton", true);
                    }
                    else{
                        component.set("v.hidebutton" ,true);
                        component.set("v.showAddNewTenantButton", false);
                    }
                    
                    if(result[0].objinstall[0]){
                        component.set("v.showAmmendMsg",true);
                        component.set("v.Topupamount",result[0].objinstall[0].Amount__c);
                    }
                    var currentUserProfile = component.get("v.currentUser");
                    console.log(currentUserProfile.Profile.Name+' line-->54 ' + result[0].Leadtenant);
                    if(currentUserProfile.Profile.Name=='Tenant'){
                    component.set("v.isLeadTenant",result[0].Leadtenant);
                    } 
                }
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        
        $A.enqueueAction(action);
*/
    },
    
     handlePrescribedOnChange : function(component,event,helper){
        var addPrescribedValue = component.find("AddPrescribedInfo").get("v.value");
        console.log('addPrescribedValue'+addPrescribedValue);
        component.set("v.AddPrescribedInfo",addPrescribedValue);    
    }, 
        handlerChangePIClauseNumber : function(component,event,helper){
        var addPrescribedWording = component.find("AddPrescribedInfoWording").get("v.value");
        console.log('addPrescribedWording'+addPrescribedWording);
        component.set("v.AddPrescribedInfoWording",addPrescribedWording);    
    },
     closeModalCLS: function(component, event, helper) {
      
         var modalPoppup = document.getElementById("openPIPopup");
      						modalPoppup.classList.remove("show");
                            modalPoppup.style. display = "none";
        
    },
    openModalCLS: function(component, event, helper) {
      
         var modalPoppup = document.getElementById("openPIPopup");
         modalPoppup.style.display = "block";
    modalPoppup.classList.add("show");
        modalPoppup.setAttribute("role","dialog");
        modalPoppup.setAttribute("aria-modal","true");
        
    },
        updatePI: function(component, event, helper) {
             component.set("v.btnDisableS",true);
          //  alert(component.get("v.btnDisableS"));
            var addPrescribedValue = component.find("AddPrescribedInfo").get("v.value");
             var addPrescribedWording = component.find("AddPrescribedInfoWording").get("v.value");
        var isValid = true;
        
         if(isValid)
        {
           
            var action = component.get("c.updatePrescribedInfo");
        action.setParams({
            depositId: component.get("v.depositID"),
            piClause: addPrescribedValue,
            piClausewording: addPrescribedWording
        })     
       
     action.setCallback(this, function (a) {
                    var state = a.getState();
                    var errors = a.getError();
        // alert(state+' errors '+errors);
                    if (state == "SUCCESS") {  
                        if(a.getReturnValue() != null){
                       //     alert('Updated');
                      setTimeout(function(){
                        
                              var modalPoppup = document.getElementById("openPIPopup");
      						modalPoppup.classList.remove("show");
                            modalPoppup.style. display = "none";
                           component.set("v.btnDisableS",false); 
                          }, 1000);
                          //  modalPoppup.setAttribute("aria-hidden","true");
                          //   modalPoppup.setAttribute("aria-modal","false");
                        }
                    }else{
                         component.set("v.btnDisableS",false); 
                    }
                });    
            $A.enqueueAction(action);
            
            
        }

    },
    
        
    hideBootstrapErrors: function(component, event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "decreaseAmt":
                component.set("v.depositDecreased", false);
                break;
                
            case "successmsg":
                component.set("v.successDPC", false);
                break;
            case "depositTransfer":
                component.set("v.depositTransferred", false);
                break;
            case "changeovercancel":
                component.set("v.changeovercancelled", false);
                break;
            case "notenant":
                component.set("v.notenanterror", false);
                break;
            case "noamount":
                component.set("v.noamounterror", false);
                break;
            case "unknown":
                component.set("v.unknownerror", false);
                break;
            case "before30days":
                component.set("v.before30dayserror", false);
                break;
            case "depositupdated":
                component.set("v.depositupdatedsuccessmsg", false);
                break;
            case "bankdetailstenent":
                component.set("v.bankdetailssuccessmsg", false);
                break;
                
        }
    },
    
    cancelDeposit: function(component, event) {
        
        
              const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const depositIdList = atob(urlParams.get('id'));
        const myArray = depositIdList.split("&");
            let myName;
            var depositId;
            if(myArray.length >2){
              myName = myArray[0]+'&'+myArray[1];
               depositId = myArray[2];
              }else{
                myName = myArray[0];
                  depositId = myArray[1];
               }   
            
              var branch = urlParams.get('branchId');
            if(branch != null){ 
                      const branchIdList = atob(urlParams.get('branchId'));
         		const myArray = branchIdList.split("&");
             if(myArray.length >2){
              myName = myArray[0]+'&'+myArray[1];
               branch = myArray[2];
              }else{
                myName = myArray[0];
                  branch = myArray[1];
               } 
            }     
        
     //   console.log("depositId"+depositId);
        var action = component.get("c.cancelDepositTransfer");
        action.setParams({depositId : depositId});
        action.setCallback(this, function(response){
            var allValues = response.getReturnValue();
         //   console.log("allValues"+allValues);
            if(allValues!=null && allValues=='canceldeposit'){
                component.set("v.depositTransferred", false);
                if(branchId != null){
                    component.find("navService").navigate({
                        type: "standard__namedPage",
                        attributes: {
                            pageName: "depositsummarypage"
                        },
                        state: {id: depositId,branchId: branchId}
                    });
                }	else{
                    component.find("navService").navigate({
                        type: "comm__namedPage",
                        attributes: {
                            pageName: "depositsummarypage"
                        },
                        state: {
                            id: depositId,
                            
                        }
                    });
                }
            }
        });        
        $A.enqueueAction(action);
    },
    
    doTransferProperty : function(component, event, helper) {
        //  alert('If you need to edit the deposit amount or the amount of tenants, they are unable to do this within this process but can make these changes before or after the transfer has taken place from within their account')
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositId = urlParams.get('id');
        if(branchId != null){
            component.find("navService").navigate({
                type: "standard__namedPage",
                attributes: {
                    pageName: "transferproperty"
                },
                state: {id: depositId,branchId: branchId}
            });
        }else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "transferproperty"
                },
                state: {id: depositId}
            });
        }
    },
    
    downloaDPCTemplate : function(component, event, helper) {
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        var depositDAN = component.get("v.depsumlist[0].objdeposit.Name");
        var customerName = component.get("v.depsumlist[0].objdeposit.Customer_Name__c");
        //  var customlbl ='https://thedisputeservice--uat--c.visualforce.com';
        //   var redirectURL = ''+customlbl+'/apex/DownloadDPC?id='+depositid;
        var redirectURL =   'https://eu11.springcm.com/atlas/doclauncher/OneClickDocGen?aid=20661&config=SDSDepositProtectionCertificateConfig&eos[0].Id='+depositid+'&eos[0].System=Salesforce&eos[0].Type=Deposit__c&eos[0].Name='+depositDAN+'&eos[0].ScmPath=/'+customerName+'/Deposits';

        var myChild= window.open(redirectURL);  
       console.log('Line 256 - '+redirectURL);
        
    //    console.log('out'); 
        setTimeout(function(){ 
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
            component.set("v.successDPC",true);
            //  helper.getDPCHelper(component, event, helper);
     //       console.log('Test1');
            myChild.close();
            window.focus();
            
            
        }, 20000);
        
    },
    
    onDownload : function(component, event, helper) {
              //  helper.getDPCHelper(component, event, helper);
      var depositRecId= component.get("v.depositID");

        console.log('Line-400==>'+depositRecId);
   
        window.open('/apex/DPCCertificatePage?depoId='+ depositRecId +'&isDownload=true');

    },
    
    doTransferDeposit : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositId = urlParams.get('id');
        if(branchId != null){
            component.find("navService").navigate({
                type: "standard__namedPage",
                attributes: {
                    pageName: "transferdeposit"
                },
                state: {branchId: branchId,depositId: depositId}
            });
        }	else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "transferdeposit"
                },
                state: {depositId: depositId}
            });
        }
    },
    
    deleteLandlord : function(component, event, helper) {
        var landlordid = event.getSource().get("v.value"); 
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // alert(landlordid);   
        var action = component.get("c.deletelandlord");
        action.setParams({ 
            landlordid :landlordid,
            depositdelid  :depositid                    
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                // alert('171');
           //     console.log('check value' + JSON.stringify(response.getReturnValue()));
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Landlord has been deleted successfully."
                });
                toastEvent.fire();
                window.location.reload();
            }
            else if (state === "INCOMPLETE") {
                // alert('180');
                
            }
                else if (state === "ERROR") {
                    // alert('184');
                    var errors = response.getError();
                    if (errors) {
                        //   alert('187');
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } 
                }
        });
        
        $A.enqueueAction(action);    
    },
    
    confirmdeletedeposit : function(component, event, helper) {
        component.set('v.showConfirmDialog', true); 
    },
    
    deletedeposit : function(component, event, helper) {
        component.set('v.showConfirmDialog', false);
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // alert(depositid);
        var action = component.get("c.changedepositstatus");
        action.setParams({ 
            depositid:depositid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
              //  console.log('check value' + JSON.stringify(response.getReturnValue()));
                window.location.reload();
            }
            else if (state === "INCOMPLETE") {
                
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } 
                }
        });
        
        $A.enqueueAction(action);    
    },
    
    viewedittenant: function(component, event, helper) {
        var clickedBtn = event.getSource().get("v.value");
        // alert(clickedBtn);
        $A.createComponent("c:EI_TenentDetails",
                           {'strRecordId'  : clickedBtn},
                           function(content, status) {
                               if (status === "SUCCESS") {
                                   var modalBody = content;
                                   component.find('overlayLib').showCustomModal({
                                       header: "Tenant details",
                                       body: modalBody, 
                                       showCloseButton: true,
                                       
                                   })
                               }
                           });
    },
    
    addlandlord: function(component, event, helper) {
        var propertyid = component.get("v.depsumlist[0].objdeposit.Property__c");
        
        $A.createComponent("c:EI_addLandlord",
                           {
                               propertyid:propertyid   
                           },
                           function(content, status) {
                               if (status === "SUCCESS") {
                                   var modalBody = content;
                                   component.find('overlayLib1').showCustomModal({
                                       header: "New landlord",
                                       body: modalBody, 
                                       showCloseButton: true,
                                       
                                   })
                               }
                           });
    },
    
    vieweditlandlord: function(component, event, helper) {
        var landlordid = event.getSource().get("v.value");
        // alert(clickedBtn);
        $A.createComponent("c:EI_LandlordDetails",
                           {'strRecordId'  : landlordid},
                           function(content, status) {
                               if (status === "SUCCESS") {
                                   var modalBody = content;
                                   component.find('overlayLib2').showCustomModal({
                                       header: "Landlord details",
                                       body: modalBody, 
                                       showCloseButton: true,
                                       
                                   })
                               }
                           });
    } ,
    
    downloadpitemplate : function(component, event, helper) {
        const domainHost = window.location.hostname;
        var domainRedirect; 
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // var customlbl ='https://uat-tds.cs87.force.com/';
        //var customlbl ='https://thedisputeservice--uat--c.visualforce.com';
        // alert(customlbl);
        //let currentURL = window.location.origin;
        //let redirectURL = currentURL +'/apex/EI_Prescribeinformation?id=a0L26000003qcDh';
        // var redirectURL = ''+customlbl+'/apex/EI_Prescribeinformation?id='+depositid+'';
      /* setTimeout(function(){ 
           var redirectURL = '/Sds/EI_PrescribedInformationNew?id='+depositid;
        window.open(redirectURL);
       },800);*/
        setTimeout(function(){ 
            if(!domainHost.includes('sandbox')){
                if(domainHost.includes('site.com')){
                    domainRedirect = 'https://thedisputeservice.my.site.com/Sds/apex/EI_PrescribedInformationNew?id='+depositid;
                }else{
                    domainRedirect = 'https://portal.safedepositsscotland.com/apex/EI_PrescribedInformationNew?id='+depositid;
                }
            }if(domainHost.includes('sandbox')){
                domainRedirect = '/Sds/apex/EI_PrescribedInformationNew?id='+depositid;
            }
            
            
            var redirectURL = domainRedirect;
            window.open(redirectURL);
        },800);
        
    },
    
      //Commented By Himanshi On 31/10 -- Unknown Code Source is not known.
  /*  downloadpitemplateWord : function(component, event, helper) {
        
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // var customlbl ='https://uat-tds.cs87.force.com/';
        //var customlbl ='https://thedisputeservice--uat--c.visualforce.com';
        // alert(customlbl);
        let currentURL = window.location.origin;
        //let redirectURL = currentURL +'/apex/EI_Prescribeinformation?id=a0L26000003qcDh';
        // var redirectURL = ''+customlbl+'/apex/EI_Prescribeinformation?id='+depositid+'';
        var redirectURL = currentURL+'/Sds/apex/EI_PrescribedInformationNewWord?id='+depositid;
        window.open(redirectURL);
    }, */
    
    downloadBlankPI :  function(component, event, helper) {
        var blankPI =    $A.get("$Label.c.BlankPITemplate");
       // window.open("/Sds/servlet/servlet.FileDownload?file="+blankPI);
         window.open("https://portal.safedepositsscotland.com/servlet/servlet.FileDownload?file="+blankPI);
        setTimeout(function(){
            helper.deleteAttacRecord(component, event, helper);
        }, 1000);
    },
    
    downloadAdjreport : function(component, event, helper) {
        var redirectURL = component.get("v.adjudicatorreportlink");    
        window.open(redirectURL);     
    },
    
    tenantRespondToChangeover : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositId = urlParams.get('id');
        
        if(typeof depositId != 'undefined'){
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "outstandingactions"
                },
                state: {
                    id : depositId,
                    tchange : true
                }
            });
        }   
    },
    
    doRepaymentRequestOfDeposit : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositId = urlParams.get('id');
        /*var urlRedirect = $A.get("$Label.c.Lightning_Component_URL")+"requestrepaymentofdeposit?depositId="+depositId;
        window.location.replace(urlRedirect);
        return false;*/
        if(branchId != null){
            component.find("navService").navigate({
                type: "standard__namedPage",
                attributes: {
                    pageName: "requestrepaymentofdeposit"
                },
                state: {depositId : depositId,branchId: branchId}
            });
        }else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "requestrepaymentofdeposit"
                },
                state: {
                    depositId : depositId
                }
            });
        }
    },
    
    doRepaymentRequestOfDepositTenant : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositId = urlParams.get('id');
        /*var urlRedirect = $A.get("$Label.c.Lightning_Component_URL")+"requestrepaymentofdeposit?depositId="+depositId;
        window.location.replace(urlRedirect);
        return false;*/
        if(branchId != null){
            component.find("navService").navigate({
                type: "standard__namedPage",
                attributes: {
                    pageName: "viewdeposit"
                },
                state: {branchId: branchId,depositId : depositId}
            });
        }else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "tenantrepaymentrequest"
                },
                state: {
                    depositId : depositId
                }
            });
        }
    },
    
    continuerepayment : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        
        var depositid = urlParams.get('id');
        if(branchId != null){
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "repaymentjourneycontinue"
                },
                state: {
                    depositId : depositid,
                    leadTenant : component.get('v.isLeadTenant'),
                    branchId: branchId
                }
            });
        }else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "repaymentjourneycontinue"
                },
                state: {
                    depositId : depositid
                }
            });
        }
    },
    
    submitevidence : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositid = urlParams.get('id');
        //alert(depositid);
        if(branchId != null){
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "agllevidencegathering"
                },
                state: {
                    depositId : depositid,
                    branchId: branchId
                }
            });
        }else{
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "agllevidencegathering"
                },
                state: {
                    depositId : depositid
                }
            });
        }
    },
    
    submitevidenceTenant : function(component, event, helper) {
         const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
    
        var depositid = urlParams.get('id');
     //   var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // alert(depositid);
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "tenant-evidence-gathering"
            },
            state: {
                depositId : depositid,
                leadTenant : component.get('v.isLeadTenant')
            }
        });
    },
    
    viewEvidencesOnly : function(component, event, helper) {
     //   var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        // alert(depositid);
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
    
        var depositid = urlParams.get('id');
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "view-evidences"
            },
            state: {
                depositId : depositid,
                //leadTenant : component.get('v.isLeadTenant')
            }
        });
    },
    
    cancelclaim: function(component, event, helper) {
        //  debugger;
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositid = urlParams.get('id');
        var state
        if(branchId != null){
            state = {
                depositId : depositid,
                branchId : branchId
            };
        }else{
            state = {
                depositId : depositid
            };
        }
        
        
        if(component.get("v.currentUser.Profile.Name") === "Tenant"){
            state.userType = "TT";
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "cancelclaim"
            },
            state: state
        });
    },
    
    dochangeover:function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        var depositid = urlParams.get('id');
        var profileName = component.get("v.currentUser.Profile.Name");
        //   alert('@@'+profileName);
        if(profileName == 'Tenant'){
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "changeover"
                },
                state: {
                    id : depositid
                }
            });
        }else{
            var state;
            if(branchId != null){
                state = {
                    id : depositid,
                    branchId : branchId
                };
            }else{
                state = {
                    id : depositid
                };
            }
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "tenantchangeoverrequest"
                },
                state: state
            });            
        }
        
        
        
        /*    var address = "/tenantchangeoverrequest";
        var domain = window.location.origin;
        
        var urlEvent = $A.get("e.force:navigateToURL");
        console.log(urlEvent);
        urlEvent.setParams({
            url: address + "?id=" + depositid
        });
        urlEvent.fire();    */
        
    },
    
    CancelTenantChangeover : function(component, event, helper) {
        var depositid = component.get("v.depsumlist[0].objdeposit.Id");
        var action = component.get("c.tenancychangeovercancel");
        action.setParams({
            depositid:depositid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var queryString = window.location.search;
                var urlParams = new URLSearchParams(queryString);
                var branchId = urlParams.get('branchId');
                var newDepId = urlParams.get('id');
                var stateRtrn;
                console.log('--inside');
                if(branchId != null){
                    stateRtrn = {
                        id : newDepId,
                        branchId : branchId,
                        TC:'AGcancel'
                    };
                }else{
                    stateRtrn = {
                        id : newDepId,
                        TC:'AGcancel'
                    };
                }
                //  console.log('check value' + JSON.stringify(response.getReturnValue()));
                component.set("v.PageSpinner",false);
                component.set("v.changeovercancelled", true);
                component.set("v.showProgressbox", false);
                component.find("navService").navigate({
                    type: "comm__namedPage",
                    attributes: {
                        pageName: "thankyoupage"
                    },
                    state: stateRtrn
                });
            }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } 
                }
        });
        $A.enqueueAction(action);     
    },
    
    reviewChangeOver : function(component, event, helper) {
        //  var depositId = event.getSource().get("v.name");  
     //   var depositId = component.get("v.depsumlist[0].objdeposit.Id");
      const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
    
        var depositId = urlParams.get('id');
        if(typeof depositId != 'undefined'){
            component.find("navService").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "tenantchangeoverresponsebyagll"
                },
                state: {
                    id : depositId,
                    tchange : true
                }
            });
        }
    },
      saveStartDate: function(component, event, helper) {
          let depositId = component.get("v.depsumlist[0].objdeposit.Id");
        var startDate = document.getElementById("startDate").value;
       // alert(startDate);
          let action1 = component.get("c.svStartDate");
                    action1.setParams({ 
                        depositId:depositId,
                        startDate: startDate
                    });
          action1.setCallback(this, function(response) {
                        let state = response.getState();
              console.log(state,'state');
                        if (state === "SUCCESS") {
                             $A.get('e.force:refreshView').fire();
                              component.set("v.saveRecord" ,true);
     	 					  component.set("v.showStartDate" ,false);
           					  component.set("v.showSavebtnStartDate" ,false);
                            
                        }
          });
           $A.enqueueAction(action1);
    },
      editDepositStartDate : function(component, event, helper) {
        
    component.set("v.saveRecord" ,false);
        component.set("v.showStartDate" ,true);
             component.set("v.showSavebtnStartDate" ,true);
            

    },
    editDeposit : function(component, event, helper) {
        
        component.set("v.hideDiv" ,false);
        component.set("v.showSavebtn" ,true);
        component.set("v.newDepositAmount" ,parseFloat(component.get("v.depsumlist[0].objdeposit.Deposit_Amount__c")));
        
        document.body.scrollTop = 1;
        document.documentElement.scrollTop = 1;
    },
    
    saveDeposit : function(component, event, helper) {
        
        let depositId = component.get("v.depsumlist[0].objdeposit.Id");
        let oldDepositAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Deposit_Amount__c"));
        let newDepositAmount = parseFloat(component.get("v.newDepositAmount"));
        // let heldAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Amount_of_Deposit_Protected_by_TDS__c"));
        let heldAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Protected_Amount__c"));
        let selectedTenant = component.get("v.selectedTenant");
        let startDateDeposit = component.get("v.depsumlist[0].objdeposit.Date_Deposit_Received__c");
        
        if(newDepositAmount =='')
        {
            component.set("v.noamounterror" , true);
        }
        else
        { 
            if(oldDepositAmount != newDepositAmount )
            {
                if(newDepositAmount == heldAmount)
                {
                    let action1 = component.get("c.saveEqualDepositApx");
                    action1.setParams({ 
                        depositId:depositId,
                        oldDepositAmount: oldDepositAmount,
                        newDepositAmount: newDepositAmount,
                        heldAmount :heldAmount
                    });
                    
                    action1.setCallback(this, function(response) {
                        let state = response.getState();
                        if (state === "SUCCESS") {
                            if(response.getReturnValue() =='successfully Updated')
                            {
                                component.set("v.depositupdatedsuccessmsg", true);
                               /* var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Success',
                                    message: 'Record Updated Successfully',
                                    duration:' 5000',
                                    key: 'info_alt',
                                    type: 'success',
                                    mode: 'pester'
                                });
                                toastEvent.fire();*/
                                component.set("v.hideDiv" ,true);
                                component.set("v.showSavebtn" ,false);
                                component.set("v.ShowTenantRec" ,false);
                                $A.get('e.force:refreshView').fire();
                            }
                        }
                        else
                        {
                             component.set("v.unknownerror", true);
                       /*    let toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message:'There is an error Please contact Adminstrator',
                                duration:' 5000',
                                key: 'info_alt',
                                type: 'error',
                                mode: 'pester'
                            });
                            toastEvent.fire(); */
                        }
                    });
                    
                    $A.enqueueAction(action1);
                    
                }
                else
                {
                    if(newDepositAmount > heldAmount)
                    {
                                            var topUpVal = true;
                                 let topUpAmnt = parseFloat(newDepositAmount-heldAmount);
                        		
                       alert(topUpAmnt.toFixed(2));
                                    helper.topUpHelper(component, event, helper,depositId,topUpVal,topUpAmnt.toFixed(2));
                            
                        let action2 = component.get("c.saveGraterAmountDepositApx");
                        action2.setParams({ 
                            depositId:depositId,
                            oldDepositAmount: oldDepositAmount,
                            newDepositAmount: newDepositAmount,
                            heldAmount :heldAmount
                        });
                        
                        action2.setCallback(this, function(response) {
                            
                            let state = response.getState();
                         //   console.log('-->>'+state);
                         //   console.log('-->>'+response.getReturnValue());
                            if (state === "SUCCESS") {
                                if(response.getReturnValue() =='successfully Updated')
                                {
                                    component.set("v.depositupdatedsuccessmsg", true);
                                  /*  var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        title : 'Success',
                                        message: 'Record Updated Successfully and the remaing part will be picked once Findoc available',
                                        duration:' 5000',
                                        key: 'info_alt',
                                        type: 'success',
                                        mode: 'pester'
                                    });
                                    toastEvent.fire();*/
                                    component.set("v.hideDiv" ,true);
                                    component.set("v.showSavebtn" ,false);
                                    component.set("v.ShowTenantRec" ,false);
                                  //  var topUpVal = true;
                                  //  $A.get('e.force:refreshView').fire();
                                 //   helper.topUpHelper(component, event, helper,depositId,topUpVal);
                                }
                                alert('ads');
                            }
                            else
                            {
                                component.set("v.unknownerror", true);
                               /* let toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message:'There is an error Please contact Adminstrator',
                                    duration:' 5000',
                                    key: 'info_alt',
                                    type: 'error',
                                    mode: 'pester'
                                });
                                toastEvent.fire();*/
                            }
                        });
                        
                        $A.enqueueAction(action2);
                        
                    }
                    else if(newDepositAmount < heldAmount){
                         component.set("v.depositDecreased", true);
                    }
                    else
                    {
					//	let depositReceiveDate  = component.get("v.depsumlist[0].objdeposit.Date_Deposit_Received__c");
                    let depositReceiveDate  = component.get("v.depsumlist[0].objdeposit.WD_Date_Deposit_Received__c");    
                        var browserDate = new Date(depositReceiveDate);
                     //   browserDate.setDate(browserDate.getDate() + 30);
                        var today = new Date(); 
                        if(browserDate.getTime() < today.getTime())
                        {
                            //alert(`495`);
                            if(selectedTenant.length < 1)
                            {
                               component.set("v.notenanterror",true);
                            }
                            else
                            {
                                let action3 = component.get("c.saveLessAmountDepositApx");
                                action3.setParams({ 
                                    depositId:depositId,
                                    DAN : component.get("v.depsumlist[0].objdeposit.Name"),
                                    oldDepositAmount: oldDepositAmount,
                                    newDepositAmount: newDepositAmount,
                                    heldAmount :heldAmount,
                                    tenantDetails :selectedTenant,
                                    startDateDeposit : startDateDeposit
                                });
                                
                                action3.setCallback(this, function(response) {
                                    let state = response.getState();
                                    if (state === "SUCCESS") {
                                        if(response.getReturnValue() =='successfully Updated')
                                        {
                                           // component.set("v.unknownerror", true);
                                            component.set("v.depositupdatedsuccessmsg", true);
                                          /*  var toastEvent = $A.get("e.force:showToast");
                                            toastEvent.setParams({
                                                title : 'Success',
                                                message: 'Record Updated Successfully',
                                                duration:' 5000',
                                                key: 'info_alt',
                                                type: 'success',
                                                mode: 'pester'
                                            });
                                            toastEvent.fire();*/
                                            component.set("v.hideDiv" ,true);
                                            component.set("v.showSavebtn" ,false);
                                            component.set("v.ShowTenantRec" ,false);
                                            $A.get('e.force:refreshView').fire();
                                     
                                            
                                        }
                                        else 
                                        {
                                            if(response.getReturnValue() =='Bank Details Missing')
                                            {
                                                component.set("v.bankdetailssuccessmsg", true);
                                             /*   var toastEvent = $A.get("e.force:showToast");
                                                toastEvent.setParams({
                                                    title : 'Success',
                                                    message: 'Record Updated Successfully and send email to selected tenant to update Bank Details',
                                                    duration:' 5000',
                                                    key: 'info_alt',
                                                    type: 'success',
                                                    mode: 'pester'
                                                });
                                                toastEvent.fire();*/
                                                component.set("v.hideDiv" ,true);
                                                component.set("v.showSavebtn" ,false);
                                                component.set("v.ShowTenantRec" ,false);
                                                $A.get('e.force:refreshView').fire();
                                            }
                                            else
                                            {
                                                component.set("v.unknownerror", true);
                                             /*   let toastEvent = $A.get("e.force:showToast");
                                                toastEvent.setParams({
                                                    title : 'Error',
                                                    message:'There is an error Please contact Adminstrator',
                                                    duration:' 5000',
                                                    key: 'info_alt',
                                                    type: 'error',
                                                    mode: 'pester'
                                                });
                                                toastEvent.fire(); */
                                            }
                                            
                                        }
                                        
                                        
                                    }
                                });
                                $A.enqueueAction(action3);
                                
                            }
                        }
                        else
                        {
                            component.set("v.before30dayserror", true);
                           // alert('Deposit has not been held for more than 30 days And this need to be picked in NPP-220');
                        }
                        
                    }
                }
                
                
            }
            else
            {
                component.set("v.hideDiv" ,true);
                component.set("v.showSavebtn" ,false);
                component.set("v.ShowTenantRec" ,false);
            }
            alert('ads12'); 
        }  
    },
    
    CancelDeposit : function(component, event, helper) {
            component.set("v.depositDecreased", false); 
            component.set("v.hideDiv" ,true);
            component.set("v.showSavebtn" ,false);
            component.set("v.ShowTenantRec" ,false);
            component.set("v.unknownerror", false);
            component.set("v.before30dayserror", false);
            component.set("v.saveRecord" ,true);
     	   component.set("v.showStartDate" ,false);
             component.set("v.showSavebtnStartDate" ,false);
        
    },
    
    viewRepayRequestAgentLandlord : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        const depositId = urlParams.get('id');
        var state;
        if(branchId != null){
            state = {
                repaymentrequest: component.get("v.repayIdAgentLandlord"),
                branchId : branchId
            };
        }else{
            state = {
                repaymentrequest: component.get("v.repayIdAgentLandlord")
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "repaymentrequestrecordsummary"
            },
            state: state
        });
    }, 
    
    RespondtoRequest : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        const depositId = urlParams.get('id');
        var state;
        if(branchId != null){
            state = {
                depositId : depositId,
                branchId : branchId
            };
        }else{
            state = {
                depositId : depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "respondtorequest"
            },
            state: state
        });
    },
    
    handleNewAmount : function(component, event, helper) {
        let oldDepositAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Deposit_Amount__c"));
        let newDepositAmount = parseFloat(component.get("v.newDepositAmount"));
        //  let heldAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Amount_of_Deposit_Protected_by_TDS__c"));
        let heldAmount = parseFloat(component.get("v.depsumlist[0].objdeposit.Protected_Amount__c"));
        
        
        if(oldDepositAmount == newDepositAmount  )
        {
            component.set("v.disabledSaveBtn",true);
        }
        else
        {
            if(newDepositAmount < heldAmount)
            {
                //  alert('check');
                var cmpTarget = component.find("searchField1");
                $A.util.addClass(cmpTarget, "changeMe1");
                component.set("v.ShowTenantRec",true);
            }
            else
            {
                component.set("v.ShowTenantRec",false); 
            }
            component.set("v.disabledSaveBtn",false);
        }
        
    },
    
    searchKeyChange: function (component, event, helper) {
        let searchField = component.find("searchField1").get("v.value");
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const depositId = urlParams.get('id');
        let action = component.get("c.getTenant");
        action.setParams({
            searchField: searchField,
            depositId:depositId        
        });
        action.setCallback(this, function (a) {
            var state = a.getState();
            if (state == "SUCCESS") {
                component.set("v.tenantDetails", a.getReturnValue());
            } else {
            }
        });
        $A.enqueueAction(action);
    },
    
    SelectTenant : function (component, event, helper) {
        let selectRecord = event.target.id;
        let tenantDetails = component.get("v.tenantDetails");
        let selectedrec = [];
        let selectedTenant = component.get("v.selectedTenant");
        for (let i = 0; i < tenantDetails.length; i++) {
            if (tenantDetails[i].Id == selectRecord) {
                selectedrec.push(tenantDetails[i]);
            }
        }
        component.set("v.tenantDetails", "");
        component.set("v.selectedTenant", selectedrec);
    },
    
    handleAddMoreTenants: function (component, event, helper) {
        var modalBody;
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const depositId = urlParams.get('id');
        $A.createComponent(
            "c:EI_addMoreTenants",
            {
                depositId: depositId
            },
            function (content, status) {
                if (status === "SUCCESS") {
                    modalBody = content;
                    component.find("overlayLib").showCustomModal({
                        header: "Additional Tenant Form",
                        body: modalBody,
                        showCloseButton: true,
                        cssClass: "mymodal",
                        closeCallback: function () {
                            //  alert('You closed the alert!');
                        }
                    });
                }
            }
        );
    },
    
    moveToRepaymentPage: function (component, event, helper) {
        
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        const depositId = urlParams.get('id');
        var state;
        if(branchId != null){
            state = {
                depositId : depositId,
                branchId : branchId
            };
        }else{
            state = {
                depositId : depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "tenantresponsedetail"
            },
            state: state
        });
    },
    
    viewrepaymentofagll: function (component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        const depositId = urlParams.get('id');
        var state;
        if(branchId != null){
            state = {
                depositId : depositId,
                branchId : branchId
            };
        }else{
            state = {
                depositId : depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "repaymentviewagll"
            },
            state: state
        });
    },
    
    viewRepReqForJointTenant: function (component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        const depositId = urlParams.get('id');
        var state;
        if(branchId != null){
            state = {
                depositId : depositId,
                branchId : branchId
            };
        }else{
            state = {
                depositId : depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "viewrepaymentrequestfortenants"
            },
            state: state
        });
    },
    
    transferToPay : function(component, event, helper) {
      const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        //  var name = component.get("v.currentUser.Name");
      const depositId = urlParams.get('id');
        // const depositId = btoa(name+'&'+event.target.id);
        
        var state;
        if(branchId != null){
            state = {
                status: "registered",
                id: depositId,
                branchId : branchId
            };
        }else{
            state = {
                status: "registered",
                id: depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "paydeposit"
            },
            state: state
        });
    },
    
    transferToPayTop : function(component, event, helper) {
       // var depositId= event.currentTarget.id;
       var name = component.get("v.currentUser.TestName__c");
     
         const depositId = btoa(name+'&'+event.target.id);
        //const depositId = urlParams.get('id');
        var topUpVal = false;
        helper.topUpHelper(component, event, helper,depositId,topUpVal);
    },
    
    transferToChangePayment : function(component, event, helper) {
          const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
          const depositId = urlParams.get('id');
      var state;
        if(branchId != null){
            state = {
                status: "awaiting",
                id: depositId,
                branchId : branchId
            };
        }else{
            state = {
                status: "awaiting",
                id: depositId
            };
        }
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "paydeposit"
            },
            state: state
        });
    },
    
    handleConfirmDialogNo : function(component, event, helper) {
     //   console.log('No');
        component.set('v.showConfirmDialog', false);
    },
    
    //TGK-333
    gotoDepositHistory: function(component, event, helper) {
        console.log('deposit History');
        var Id = component.get("v.depositID");
        var depositId = btoa(Id);
        console.log('encodeId>>>>>>>>>>'+depositId);
        var state;
        state = {
            scheme: "SDS",
            depositId: depositId
        };
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "deposithistory"
            },
            state: state
        });
    }
    //TGK-333

    
})