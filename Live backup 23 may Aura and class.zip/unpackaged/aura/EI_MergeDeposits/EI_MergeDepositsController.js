({
    doInit : function(component, event, helper) {
        /*var pageReference = {
            type: "standard__recordPage",
            attributes: {
                recordId: "a0L3L00000192hbUAA",
                objectApiName: "Deposit__c"
            },
            state: {}
        };

        var navService = component.find("navService");
        var pageReferenceNav = {
            type: "standard__webPage",
            attributes: {
                url: "/one/one.app#" + JSON.stringify(pageReference)
            }
        };

        navService.navigate(pageReferenceNav);*/
        //alert('end');
        let selectedValues ={};
        selectedValues['Name']='';
        selectedValues['Status__c']='';
        selectedValues['Deposit_Amount__c']='';
        selectedValues['Actual_Protected_Amount__c']='';
        selectedValues['Start_Date__c']='';
        selectedValues['Property__c']='';
        selectedValues['Customer__c']='';
        component.set('v.selectedValues',selectedValues);
    },
    handleSearch : function(component, event, helper) {
        var toastContainer = component.find("toastContainer");
        if((component.get('v.depositNumberToClose')==null || component.get('v.depositNumberToClose')=='')){
            $A.util.removeClass(toastContainer, 'slds-hide');
            component.set("v.errorMessage", 'Please enter the Deposit to close');
            component.set("v.showError", true);
            component.set("v.showNext", false);
            component.set("v.depositCloseRecord", null);
            component.set("v.depositRetainRecord", null);
        }
        else if(component.get('v.depositNumberToRetain')==null || component.get('v.depositNumberToRetain')==''){
            $A.util.removeClass(toastContainer, 'slds-hide');
            component.set("v.errorMessage", 'Please enter the Deposit to retain');
            component.set("v.showError", true);
            component.set("v.showNext", false);
            component.set("v.depositCloseRecord", null);
            component.set("v.depositRetainRecord", null);
        }
            else if(component.get('v.depositNumberToClose')==component.get('v.depositNumberToRetain')){
                $A.util.removeClass(toastContainer, 'slds-hide');
                component.set("v.errorMessage", 'Same Deposits cannot be merged. Please enter different deposit numbers.');
                component.set("v.showError", true);
                component.set("v.showNext", false);
                component.set("v.depositCloseRecord", null);
                component.set("v.depositRetainRecord", null);
            }
                else{
                    var action = component.get("c.fetchDeposits");
                    action.setParams({
                        depositNumberToClose : component.get('v.depositNumberToClose'),
                        depositNumberToRetain : component.get('v.depositNumberToRetain')
                    });
                    action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            var result = response.getReturnValue();
                            //alert(JSON.stringify(result));
                            if(result.record1Error!=''){
                                $A.util.removeClass(toastContainer, 'slds-hide');
                                component.set("v.errorMessage", 'Please enter valid deposit to be closed.');
                                component.set("v.showError", true);
                                component.set("v.showNext", false);
                                component.set("v.depositCloseRecord", null);
                                component.set("v.depositRetainRecord", null);
                            }else if(result.status1Error!=''){
                                //alert(result.status1Error);
                                $A.util.removeClass(toastContainer, 'slds-hide');
                                component.set("v.errorMessage", 'Please enter deposit to close number with Deposits held by scheme status.');
                                component.set("v.showError", true);
                                component.set("v.showNext", false);
                                component.set("v.depositCloseRecord", null);
                                component.set("v.depositRetainRecord", null);
                            }
                                else if(result.record2Error!=''){
                                    $A.util.removeClass(toastContainer, 'slds-hide');
                                    component.set("v.errorMessage", 'Please enter valid deposit to retain.');
                                    component.set("v.showError", true);
                                    component.set("v.showNext", false);
                                    component.set("v.depositCloseRecord", null);
                                    component.set("v.depositRetainRecord", null);
                                }
                                    else if(result.status2Error!=''){
                                        $A.util.removeClass(toastContainer, 'slds-hide');
                                        component.set("v.errorMessage", 'Please enter deposit to retain number with Deposits held by scheme status.');
                                        component.set("v.showError", true);
                                        component.set("v.showNext", false);
                                        component.set("v.depositCloseRecord", null);
                                        component.set("v.depositRetainRecord", null);
                                    }
                                        else if(result.amount1Error!=''){
                                            $A.util.removeClass(toastContainer, 'slds-hide');
                                            component.set("v.errorMessage", 'Please enter deposit to be closed with protected amount greater than zero.');
                                            component.set("v.showError", true);
                                            component.set("v.showNext", false);
                                            component.set("v.depositCloseRecord", null);
                                            component.set("v.depositRetainRecord", null);
                                        }
                                            else if(result.amount2Error!=''){
                                                $A.util.removeClass(toastContainer, 'slds-hide');
                                                component.set("v.errorMessage", 'Please enter deposit to be retain with protected amount greater than zero.');
                                                component.set("v.showError", true);
                                                component.set("v.showNext", false);
                                                component.set("v.depositCloseRecord", null);
                                                component.set("v.depositRetainRecord", null);
                                            }else if(result.ownerError!=''){
                                                $A.util.removeClass(toastContainer, 'slds-hide');
                                                component.set("v.errorMessage", 'Deposits of Different Owners cannot be merged.');
                                                component.set("v.showError", true);
                                                component.set("v.showNext", false);
                                                component.set("v.depositCloseRecord", null);
                                                component.set("v.depositRetainRecord", null);
                                            }
                                                else{
                                                    $A.util.addClass(toastContainer, 'slds-hide');
                                                    component.set("v.depositCloseRecord", result.depositCloseRecord);
                                                    component.set("v.depositRetainRecord", result.depositRetainRecord);
                                                    var depositRetainRecord=result.depositRetainRecord;
                                                    component.set("v.selectedProperty",depositRetainRecord.Property__c);
                                                    component.set("v.selectedAmount",depositRetainRecord.Deposit_Amount__c);
                                                    component.set("v.selectedStartDate",depositRetainRecord.Start_Date__c);
                                                    component.set("v.fields", result.fields);
                                                    component.set("v.depositCloseTenants", result.depositCloseTenants);
                                                    component.set("v.depositRetainTenants", result.depositRetainTenants);
                                                    var tenant1Options = [];
                                                    var tenant2Options = [];
                                                    var selectedTenants2 = [];
                                                    (result.depositCloseTenants).forEach(function(item){
                                                        tenant1Options.push({ label: item.FirstName+' '+item.LastName, value: item.FirstName+' '+item.LastName, checked: true });
                                                        
                                                    });
                                                    (result.depositRetainTenants).forEach(function(item){
                                                        tenant2Options.push({ label: item.FirstName+' '+item.LastName, value: item.FirstName+' '+item.LastName, checked: true });
                                                        selectedTenants2.push(item.FirstName+' '+item.LastName);
                                                    });
                                                    component.set("v.tenant1Options",tenant1Options);
                                                    component.set("v.tenant2Options",tenant2Options);
                                                    component.set("v.selectedTenants2",selectedTenants2);
                                                    component.set("v.previousSelectedTenants2",selectedTenants2);
                                                    let selectedValues ={};
                                                    selectedValues['Name']=depositRetainRecord.Name;
                                                    selectedValues['Status__c']=depositRetainRecord.Status__c;
                                                    selectedValues['Deposit_Amount__c']=depositRetainRecord.Deposit_Amount__c;
                                                    selectedValues['Actual_Protected_Amount__c']=depositRetainRecord.Actual_Protected_Amount__c;
                                                    selectedValues['Start_Date__c']=depositRetainRecord.Start_Date__c;
                                                    selectedValues['Property__c']=depositRetainRecord.Property__c;
                                                    selectedValues['Customer__c']=depositRetainRecord.Customer__c;
                                                    component.set('v.selectedValues',selectedValues);
                                                    //alert(JSON.stringify(component.get('v.selectedTenants2')));
                                                    component.set("v.showNext", true);
                                                }
                        }
                        else if (state === "ERROR") {
                            var errors = response.getError();
                            //alert(JSON.stringify(errors));                
                        }
                    });
                    $A.enqueueAction(action);
                }
    },
    
    handleRadioChange : function(component,event,helper){
        let depositCloseRecord=component.get('v.depositCloseRecord');
        let depositRetainRecord=component.get('v.depositRetainRecord');
        var inputField = event.getSource().get("v.name");
        var inputValue = event.getSource().get("v.value");
        if(inputValue=='record1'){
            inputValue=depositCloseRecord[inputField];
        }else if(inputValue=='record2'){
            inputValue=depositRetainRecord[inputField];
        }
        let selectedValues = component.get('v.selectedValues');
        selectedValues[event.getSource().get("v.name")] = inputValue;
        component.set('v.selectedValues',selectedValues);
    },
    handleChange : function(component,event,helper){
        var values = event.getParam('value');
        var grp = event.getSource().get("v.name");
        let depositCloseTenants = component.get('v.depositCloseTenants');
        let depositRetainTenants = component.get('v.depositRetainTenants');
        let selectedTenants1=component.get('v.selectedTenants1');
        let selectedTenants2=component.get('v.selectedTenants2');
        let previousSelectedTenants1=component.get('v.previousSelectedTenants1 ');
        let previousSelectedTenants2=component.get('v.previousSelectedTenants2');
        var recentlyAddedCheckbox;
        if(JSON.stringify(selectedTenants1)==JSON.stringify(previousSelectedTenants1)){
            var previousCheckboxes = component.get("v.previousSelectedTenants2");
            recentlyAddedCheckbox = values.find(function(checkbox) {
                return !previousCheckboxes.includes(checkbox);
            });
        }else if(JSON.stringify(selectedTenants2)==JSON.stringify(previousSelectedTenants2)){
            var previousCheckboxes = component.get("v.previousSelectedTenants1");
            recentlyAddedCheckbox = values.find(function(checkbox) {
                return !previousCheckboxes.includes(checkbox);
            });
        }
        if(recentlyAddedCheckbox!=undefined){
            if(grp=='Checkbox Group1'){
                //if(selectedTenants2.includes(recentlyAddedCheckbox)){
                depositRetainTenants.forEach(function(item1){
                    if(recentlyAddedCheckbox ==(item1.FirstName+' '+item1.LastName)){
                        depositCloseTenants.forEach(function(item2){
                            if(item1.FirstName==item2.FirstName && item1.LastName==item2.LastName && item1.PersonEmail==item2.PersonEmail){
                                alert('Tenant exist in deposit to retain');
                                let index = selectedTenants1.indexOf(recentlyAddedCheckbox);
                                if(parseInt(index) != -1) {
                                    selectedTenants1.splice(index,1);
                                }
                                component.set('v.selectedTenants1',selectedTenants1);
                            }
                        });
                    }
                });
                //}
            }/*else if(grp=='Checkbox Group2'){
                if(selectedTenants1.includes(recentlyAddedCheckbox)){
                    depositCloseTenants.forEach(function(item1){
                        if(recentlyAddedCheckbox ==(item1.FirstName+' '+item1.LastName)){
                            depositRetainTenants.forEach(function(item2){
                                if(item1.FirstName==item2.FirstName && item1.LastName==item2.LastName && item1.PersonEmail==item2.PersonEmail){
                                    alert('Already selected in record 1');
                                    let index = selectedTenants2.indexOf(recentlyAddedCheckbox);
                                    if(parseInt(index) != -1) {
                                        selectedTenants2.splice(index,1);
                                    }
                                    component.set('v.selectedTenants2',selectedTenants2);
                                }
                            });
                        }
                    });
                }
            }*/
        }
        component.set('v.previousSelectedTenants1',selectedTenants1);
        component.set('v.previousSelectedTenants2',selectedTenants2);
    },
    handlePrevious : function(component, event, helper) {
        let steps=component.get("v.steps");
        let currentStep=component.get("v.currentStep");
        let currentIndex;
        steps.forEach((sec, index) => {
            if(sec==currentStep){
            currentIndex=index-1;
        }
                      });
        currentStep=steps[currentIndex];
        component.set("v.currentStep",currentStep);
        
        
        
    },
    handleNext : function(component, event, helper){
        let steps=component.get("v.steps");
        let currentStep=component.get("v.currentStep");
        let currentIndex;
        steps.forEach((sec, index) => {
            if(sec==currentStep){
            currentIndex=index+1;
        }
                      });
        currentStep=steps[currentIndex];
        component.set("v.currentStep",currentStep);
        component.set("v.editAmount1",false);
        component.set("v.editAmount2",false);
    },
    continueToMerge : function(component, event, helper) {
        var toastContainer = component.find("toastContainer");
        $A.util.addClass(toastContainer, 'slds-hide');
        let depositCloseRecord = component.get('v.depositCloseRecord');
        let depositRetainRecord = component.get('v.depositRetainRecord');
        let selectedValues= component.get('v.selectedValues');
        let selectedTenants1 = component.get('v.selectedTenants1');
        let selectedTenants2 = component.get('v.selectedTenants2');
        let depositCloseTenants = component.get('v.depositCloseTenants');
        let depositRetainTenants = component.get('v.depositRetainTenants');
        let selectedTenant1Ids=[];
        let selectedTenant2Ids=[];
        selectedTenants1.forEach(function(item1){
            depositCloseTenants.forEach(function(item2){
                if(item1==(item2.FirstName+' '+item2.LastName)){
                    selectedTenant1Ids.push(item2.Id);
                }
            });
        });
        selectedTenants2.forEach(function(item1){
            depositRetainTenants.forEach(function(item2){
                if(item1==(item2.FirstName+' '+item2.LastName)){
                    selectedTenant2Ids.push(item2.Id);
                }
            });
        });
        var action = component.get("c.mergeDeposits");
        //alert(JSON.stringify(selectedValues));
        action.setParams({
            depositCloseRecord : depositCloseRecord,
            depositRetainRecord : depositRetainRecord,
            selectedValues : selectedValues,
            selectedTenant1Ids : selectedTenant1Ids,
            selectedTenant2Ids : selectedTenant2Ids
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                if(result.InstallmentAmountError>0){
                    $A.util.removeClass(toastContainer, 'slds-hide');
                    component.set("v.errorMessage", 'Deposit amount should be at least '+result.InstallmentAmountError);
                    component.set("v.showError", true);
                }
                else{
                    sforce.one.back(true);
                }
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                //alert(JSON.stringify(errors));                
            }
        });
        $A.enqueueAction(action);
    },
    closeToast: function (component) {
        var toastContainer = component.find("toastContainer");
        $A.util.addClass(toastContainer, 'slds-hide');
    },
    handleEditAmount1 : function(component){
        component.set('v.editAmount1',true);
    },
    handleEditAmount2 : function(component){
        component.set('v.editAmount2',true);
    },
    handleSave : function(component,event,helper){
        var values = event.getSource().get("v.value");
        var grp = event.getSource().get("v.name");
        let selectedValues = component.get('v.selectedValues');
        if(values=='record1'){
            var depositCloseRecord = component.get('v.depositCloseRecord');
            depositCloseRecord.Deposit_Amount__c = selectedValues.Deposit_Amount__c;
            component.set('v.depositCloseRecord',depositCloseRecord);
        }
        if(values=='record2'){
            var depositRetainRecord = component.get('v.depositRetainRecord');
            depositRetainRecord.Deposit_Amount__c = selectedValues.Deposit_Amount__c;
            component.set('v.depositRetainRecord',depositRetainRecord);
        }
        component.set('v.editAmount1',false);
        component.set('v.editAmount2',false);
    },
    handleDepositChange : function(component,event,helper){
        /*var dep1 = component.get('v.deposit1');
        var dep2 = component.get('v.deposit2');
        //alert(dep1+', '+dep2);
        if(dep1=='' || dep1==null || dep2==null)*/
        component.set('v.showNext',false);
    }
})