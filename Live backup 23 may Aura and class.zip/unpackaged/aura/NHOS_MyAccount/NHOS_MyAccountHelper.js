({
	contactDetails : function(component, event, helper) {
		component.set("v.isHouseBuilderAdditionalUser",false);
        component.set("v.isHouseBuilder",false);
        var contactsid = component.get("v.contacctId");
        /*if(contactsid ==''){
           contactsid = component.get("v.contacctId");
        }*/
        console.log('line 99 '+contactsid);
        var action = component.get("c.getContactInformation");
        action.setParams({
			contId: contactsid
		});
        component.set("v.showSpinner",true);
        action.setCallback(this, function(response) {
          var state = response.getState();
             console.log(" corres state"+action );
          if (state == "SUCCESS") {
            var result = response.getReturnValue();
            //console.log("Result--", JSON.stringify(result));
            component.set("v.contact", result.contact);
            component.set("v.leadContact", result.leadContact);
            component.set("v.isSpoofLogin", result.isSpoofLogin);
             // alert(result.profileName);
            console.log('????????'+result.profileName)
            if(result.profileName == 'NHOS-Registered Developer') 
            {
                component.set("v.isHouseBuilder",true);
                console.log('<<<<<'+component.get("v.isHouseBuilder"))
                var valz;
                
                if(component.get("v.contact.Account.BillingState") != '' && component.get("v.contact.Account.BillingState") != null && component.get("v.contact.Account.BillingState") != undefined)
                {
                    valz =component.get("v.contact.Account.BillingStreet")+"\n"+component.get("v.contact.Account.BillingCity")+"\n"+component.get("v.contact.Account.BillingState")+"\n"+component.get("v.contact.Account.BillingPostalCode")+"\n"+component.get("v.contact.Account.Base_Country__c")+"\n"+component.get("v.contact.Account.BillingCountry");
                }
                else
                {
                     valz =component.get("v.contact.Account.BillingStreet")+"\n"+component.get("v.contact.Account.BillingCity")+"\n"+component.get("v.contact.Account.BillingPostalCode")+"\n"+component.get("v.contact.Account.Base_Country__c")+"\n"+component.get("v.contact.Account.BillingCountry");
                }
               
                var House_No = component.get("v.contact.Account.HouseNo__c");
                if(House_No != null && House_No != '' && House_No != undefined)
                {
                    valz = House_No+", "+valz;
                }
                
                component.set("v.textareaval",valz); 
               
            }
            else
            {
                  component.set("v.isHouseBuilder",false); 
                  var valz; 
                  if(component.get("v.contact.MailingState") != '' && component.get("v.contact.MailingState") != null && component.get("v.contact.MailingState") != undefined)
                  {
                      valz =component.get("v.contact.MailingStreet")+"\n"+component.get("v.contact.MailingCity")+"\n"+component.get("v.contact.MailingState")+"\n"+component.get("v.contact.MailingPostalCode")+"\n"+component.get("v.contact.Base_Country__c")+"\n"+component.get("v.contact.MailingCountry");
                  }
                else
                {
                  valz =component.get("v.contact.MailingStreet")+"\n"+component.get("v.contact.MailingCity")+"\n"+component.get("v.contact.MailingPostalCode")+"\n"+component.get("v.contact.Base_Country__c")+"\n"+component.get("v.contact.MailingCountry");
                }
                  var House_No = component.get("v.contact.House_No__c");
                    if(House_No != null && House_No != '' && House_No != undefined)
                    {
                        valz = House_No+", "+valz;
                    }
                component.set("v.textareaval",valz); 
                
                if(result.property != null && result.property != undefined)
                {
                    var property = result.property;
                    
                    var valzp; 
                      if(property.County__c != '' && property.County__c != null && property.County__c != undefined)
                      {
                          valzp = property.Street__c+"\n"+ property.City__c +"\n"+property.County__c+"\n"+property.Postal_Code__c+"\n"+property.Base_Country__c+"\n"+property.Country__c;
                      }
                    else
                    {
                      valzp = property.Street__c+"\n"+ property.City__c +"\n"+property.Postal_Code__c+"\n"+property.Base_Country__c+"\n"+property.Country__c;
                    }
                      var House_Nop = property.House_No__c;
                        if(House_Nop != null && House_Nop != '' && House_Nop != undefined)
                        {
                            valzp = House_Nop+", "+valzp;
                        }
                    component.set("v.propertytextareaval",valzp); 
                }
            }
            
            
             
              if(result.contact.RecordType_Name__c == $A.get("$Label.c.NHOS_HouseBuilder_Additional_User_s_Record_Type"))
                {
                    component.set("v.isHouseBuilderAdditionalUser",true);
                    console.log('>>>>>>>'+component.get("v.isHouseBuilderAdditionalUser"))
                }
              
              
              if(component.get("v.isHouseBuilderAdditionalUser") != true && component.get("v.isHouseBuilder") == true)
              {
                  helper.helperGetAdditionalUserList(component, event, helper) ;
              }
               // alert(component.get("v.isHouseBuilderAdditionalUser"));
              
            component.set("v.salutationList", result.salutationList);
            component.set("v.phoneCodeList", result.phoneCodeList);
              
          } else {
          
          }
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
        
        
        
	},
    
    helperGetAdditionalUserList: function(component, event, helper) 
    {
        
        var action = component.get("c.getAddtionalUserList");
        action.setParams({
            contId:component.get("v.contacctId")
        });
        
        action.setCallback(this, function(response) {
          var state = response.getState();
             console.log(" corres state"+action );
          if (state == "SUCCESS") {
            var result = response.getReturnValue();
            
              if (result != null && result.length > 0) {
                    
                    component.set("v.additionUserList",result);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = result;
                    var totalLength = totalRecordsList.length;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage", 0);
                   component.set("v.currentPage", 1);
                    component.set("v.endPage", pageSize - 1);
                   
                    var PaginationLst = [];
                 
                    for (var i = 0; i < pageSize; i++) {
                     
                        if (component.get("v.additionUserList").length > i) {
                            PaginationLst.push(result[i]);
                        }
                    }
                  
                
                    component.set("v.PaginationList", PaginationLst);
                    component.set("v.selectedCount", 0);
                    //use Math.ceil() to Round a number upward to its nearest integer
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
                 //alert(JSON.stringify(PaginationLst));
                }
              
              
              
          }
             });
        $A.enqueueAction(action);
    },
    
    helperUpdateContactDetails: function(component, event, helper) 
    {
      //  var isHouseBuilderAdditionalUser = component.get("v.isHouseBuilderAdditionalUser");
       // var isHouseBuilder = component.get("v.isHouseBuilder");
        
        component.set("v.usernameErrorMessage", false);
        component.set("v.successMsg", false);
         component.set("v.errorMsg", false);
        
         var action = component.get("c.contactInformationUpdate");
        component.set("v.showSpinner",true);
         action.setParams({
             contactObj: component.get("v.contact"),
             isHouseBuilderAdditionalUser: component.get("v.isHouseBuilderAdditionalUser"),
             isHouseBuilder: component.get("v.isHouseBuilder")
          });
        
        action.setCallback(this, function(response) {
          var state = response.getState();
             console.log(" corres state"+action );
          if (state == "SUCCESS") {
             var result = response.getReturnValue();
              
              if(result=='Invalid')
              {
                  component.set("v.usernameErrorMessage", true);
                  $("html, body").animate( { scrollTop: $("#MyAccountErrorDiv").offset().top-5}, 500 );
                 // alert('This username has been already taken.');
               
              }
              else
              {
              //console.log("result :" + JSON.stringify(result));
              component.set("v.usernameErrorMessage", false);
              component.set("v.successMsg", true);
              component.set("v.errorMsg", false);
                  $("html, body").animate( { scrollTop: $("#MyAccountErrorDiv").offset().top-5}, 500 );
            
             } 
        }else if (state === "ERROR") {
       
  			  component.set("v.errorMsg", true);
              component.set("v.successMsg", false);
            $("html, body").animate( { scrollTop: $("#MyAccountErrorDiv").offset().top-5}, 500 );
        }
           component.set("v.showSpinner",false); 
            
        } );
        $A.enqueueAction(action);
    },
    
    
    	// navigate to next pagination record set   
    next : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        for(var i = end + 1; i < end + pageSize + 1; i++){
            if(sObjectList.length > i){ 
                    Paginationlist.push(sObjectList[i]);

                }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
   // navigate to previous pagination record set   
    previous : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
              
                    Paginationlist.push(sObjectList[i]); 
                counter ++;
            }else{
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
})