({
    doInit : function(component, event, helper) {
      //  window.history.pushState(null,null,window.location.href);
        //window.history.forward();
        //
        var action = component.get("c.getUserInformation");
       
        action.setCallback(this, function(response) {
          var state = response.getState();
             
          if (state == "SUCCESS") {
            var result = response.getReturnValue();
            console.log("Result--", JSON.stringify(result));
            component.set("v.user", result);
            var profile = result.Profile.Name;
             // alert(profile);
              //let result = text.includes("world");
              component.set("v.isBuilder",profile.includes("Developer"));
             // alert(component.get("v.isBuilder"));
          } else {
          
          }
           
        });
        $A.enqueueAction(action);
	
    },
    
    
    doneWaiting: function(component, event, helper) {
        setTimeout(function(){  component.set("v.PageSpinner",false); 
                              
                             }, 1000);
        
    }
})