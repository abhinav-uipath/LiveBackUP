({
    helperMethod : function(component, recievedDateYMD, allDateValid) {
        //let brwsDate =component.get("v.browserDate"); 
        let brwsDate = recievedDateYMD;
        //--TGK-14-start--//
        let noError = true;
        var commentsError = [];
        //let isDateValid =component.get("v.isDateValid");
        let allDisputeItems = component.get("v.ClaimsDetails[0].Dispute_Items__r");
        allDisputeItems.forEach(function(item){
            if(item.Agreed_by_Tenant__c!=item.Claimed_by_Landlord__c){
                if(item.Tenant_Response_Disagreement__c==undefined || item.Tenant_Response_Disagreement__c==null || ((item.Tenant_Response_Disagreement__c).length==0)){
                    noError = false;
                    commentsError.push({value:'nullError', key:item.Type__c});
                }
                else if((item.Tenant_Response_Disagreement__c).length < 50){
                    noError = false;
                    commentsError.push({value:'minimumLengthError', key:item.Type__c});
                }
            }
        });
        component.set('v.commentsError',commentsError);
        //--TGK-14-End--//
        if(allDateValid  && component.get("v.isDateValid") && noError)
        {
            if(component.get("v.checkResponse"))
            {
                let disputeItemRec = component.get("v.ClaimsDetails[0].Dispute_Items__r");
                var action = component.get("c.UpdateDisputeItem");
                action.setParams({
                    "disputeItemRec": JSON.stringify(disputeItemRec),
                    depositId :component.get("v.ClaimsDetails[0].Deposit_Account_Number__c"),
                    brwsDate : brwsDate,
                    CaseparticipantId : component.get("v.WrapperList[0].Caseparticipant[0].Id")              
                });
                action.setCallback(this, function (response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        var result = response.getReturnValue();
                        let errors = response.getError();
                        console.log('23--->>',JSON.stringify(errors));
                        console.log('24--->>',JSON.stringify(result));
                        if(result=='Record successfully updated')
                        {
                            component.set("v.isOpen",true);
                            component.set("v.showPopupBtn",false);
                            /*let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Success',
                            message: 'Record has been successfully updated',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'success',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                        $A.get('e.force:refreshView').fire();*/
                        }
                        else if(result=='Someone has already respond to this claim')
                        {
                            let toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Info',
                                message: 'Someone has already responded to this claim',
                                duration:' 5000',
                                key: 'info_alt',
                                type: 'info',
                                mode: 'dismissible'
                            });
                            toastEvent.fire();
                            
                        }
                            else{
                                let toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Info',
                                    message: 'Something went wrong please Contact Administrator',
                                    duration:' 5000',
                                    key: 'info_alt',
                                    type: 'info',
                                    mode: 'dismissible'
                                });
                                toastEvent.fire();
                            }
                    }
                    else
                    {
                        let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Info',
                            message: 'Something went wrong please Contact Administrator',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'info',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
                    }
                });
                $A.enqueueAction(action);
                
            }
            else
            {
                window.setTimeout(
                    $A.getCallback(function() {
                        let disputeItemRec = component.get("v.ClaimsDetails[0].Dispute_Items__r");
                        var action = component.get("c.UpdateDisputeItem");
                        action.setParams({
                            "disputeItemRec": JSON.stringify(disputeItemRec),
                            depositId :component.get("v.ClaimsDetails[0].Deposit_Account_Number__c"),
                            brwsDate : brwsDate,
                            CaseparticipantId : component.get("v.WrapperList[0].Caseparticipant[0].Id")              
                        });
                        action.setCallback(this, function (response) {
                            var state = response.getState();
                            let errors = response.getError();
                            console.log('100--->>',JSON.stringify(errors));
                            console.log('101--->>',JSON.stringify(response.getReturnValue()));
                            if (state === "SUCCESS") {
                                var result = response.getReturnValue();
                                if(result=='Record successfully updated')
                                {
                                    component.set("v.isOpen",true);
                                    component.set("v.showPopupBtn",false);
                                    /*let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Success',
                            message: 'Record has been successfully updated',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'success',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                        $A.get('e.force:refreshView').fire();*/
                        }
                        else if(result=='Someone has already respond to this claim')
                        {
                            let toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Info',
                                message: 'Someone has already responded to this claim',
                                duration:' 5000',
                                key: 'info_alt',
                                type: 'info',
                                mode: 'dismissible'
                            });
                            toastEvent.fire();
                            
                        }
                            else{
                                let toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Info',
                                    message: 'Something went wrong please Contact Administrator',
                                    duration:' 5000',
                                    key: 'info_alt',
                                    type: 'info',
                                    mode: 'dismissible'
                                });
                                toastEvent.fire();
                            }
                    }
                    else
                    {
                        let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Info',
                            message: 'Something went wrong please Contact Administrator',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'info',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
                    }
                });
                        $A.enqueueAction(action);
                        
                        
                    }), 5000
                );  
                
                
            }
            
        }
        else
        {
            // alert('Please Enter valid date');
        }
    },
    showToast : function(title,message,type){
        alert('toast');
        
    }
})