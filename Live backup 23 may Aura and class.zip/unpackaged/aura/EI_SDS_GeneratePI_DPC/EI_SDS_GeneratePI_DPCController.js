({
    navigateToeDiscoverySearchCmp : function(component, event, helper) {
        console.log('recordid => ' + component.get("v.recordId") );
        
        var action = component.get("c.generatePIDPC");
        var recordId =  component.get("v.recordId")
        console.log("recordIdNew="+recordId);
        action.setParams({
           depId :  component.get("v.recordId")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log("State="+state);
            if (state === "SUCCESS") {
               console.log("Generated");
                
                 $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
              

            }
        });
        $A.enqueueAction(action);
    } 
})