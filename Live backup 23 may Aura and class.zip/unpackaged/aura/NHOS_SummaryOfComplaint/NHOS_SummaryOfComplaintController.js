({
	doInit: function (component, event, helper) 
    {
		var sURL = decodeURIComponent(window.location.href);
		if (window.location.href.indexOf("id=") > -1) 
        {
			var caseId = sURL.split('id=')[1];
			component.set("v.caseId", atob(caseId));
            console.log('@ ' +atob(caseId))
			helper.helperComplaintBasicDetails(component, event, helper);
		}
	},
    
    
	handleComplaintCheckBox: function (component, event, helper) 
    {
		var checkboxName = event.target.name;
		switch (checkboxName) 
        {
		case "SellingCheckbox":
			component.set("v.SellingComp.isSelected", document.getElementById("SellingCheckbox").checked);
			break;
		case "LegalInspectionCompletionCheckbox":
			component.set("v.LegalInspectionCompletionComp.isSelected", document.getElementById("LegalInspectionCompletionCheckbox").checked);
			break;
		case "AfterSalesCheckbox":
			component.set("v.AfterSalesComp.isSelected", document.getElementById("AfterSalesCheckbox").checked);
			break;
		case "WarrantyProviderCheckbox":
			component.set("v.WarrantyProviderComp.isSelected", document.getElementById("WarrantyProviderCheckbox").checked);
			break;
		case "OtherCheckbox":
			component.set("v.OtherComp.isSelected", document.getElementById("OtherCheckbox").checked);
			break;
		}
	},
    
    otherChkClickOfSummary: function (component, event)
    {
		var chkBox_Name = event.target.name;
        //alert(chkBox_Name);
       // alert(event.target.checked);
        if(chkBox_Name == 'SellingOtherChk' || chkBox_Name == 'reviewSellingOtherChk')
        {
            component.set("v.SellingComp.AreasOfComplaint.Other__c",event.target.checked);
            if(event.target.checked == false)
            {
                component.set("v.SellingComp.AreasOfComplaint.Other_Remedy__c",null);
            }
        }
        else if(chkBox_Name == 'LegalInspectionCompletionOtherChk' || chkBox_Name == 'reviewLegalInspectionCompletionOtherChk')
        {
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c",event.target.checked);
            if(event.target.checked == false)
            {
                component.set("v.LegalInspectionCompletionComp.Other_Remedy__c",null);
            }
        }
        else if(chkBox_Name == 'AfterSalesOtherChk' || chkBox_Name == 'reviewAfterSalesOtherChk')
        {
            component.set("v.AfterSalesComp.AreasOfComplaint.Other__c",event.target.checked);
            if(event.target.checked == false)
            {
                component.set("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c",null);
            }
        }
        else if(chkBox_Name == 'WarrantyProviderOtherChk' || chkBox_Name == 'reviewWarrantyProviderOtherChk')
        {
            component.set("v.WarrantyProviderComp.AreasOfComplaint.Other__c",event.target.checked);
            if(event.target.checked == false)
            {
                component.set("v.WarrantyProviderComp.AreasOfComplaint.Other_Remedy__c",null);
            }
        }
        else if(chkBox_Name == 'OtherOtherChk' || chkBox_Name == 'reviewOtherOtherChk')
        {
			component.set("v.OtherComp.AreasOfComplaint.Other__c",event.target.checked);   
            if(event.target.checked == false)
            {
                component.set("v.OtherComp.AreasOfComplaint.Other_Remedy__c",null);  
            }
        }
       
    },
    
	hideBootstrapErrors: function (component, event)
    {
		var button_Name = event.target.name;
		switch (button_Name) 
        {
		case "summariseErrorMessage":
			component.set("v.summariseError", false);
			break;
		case "AreaOfComplaintErrorMessage":
			component.set("v.AreaOfComplaintError", false);
			break;
		case "summariseSaveErrorMessage":
			component.set("v.summariseSaveError", false);
			component.set("v.summariseSaveErrorMsg", "");
			break;
		case "sellingSummariseTextErrorName":
			component.set("v.sellingSummariseTextError", false);
			break;
		case "sellingRemedyErrorName":
			component.set("v.sellingRemedyError", false);
			break;
		case "sellingOtherTextErrorName":
			component.set("v.sellingOtherTextError", false);
			break;
		case "LegalInspectionCompletionSummariseTextErrorName":
			component.set("v.LegalInspectionCompletionSummariseTextError", false);
			break;
		case "LegalInspectionCompletionRemedyErrorName":
			component.set("v.LegalInspectionCompletionRemedyError", false);
			break;
		case "LegalInspectionCompletionOtherTextErrorName":
			component.set("v.LegalInspectionCompletionOtherTextError", false);
			break;
		case "AfterSalesSummariseTextErrorName":
			component.set("v.AfterSalesSummariseTextError", false);
			break;
		case "AfterSalesRemedyErrorName":
			component.set("v.AfterSalesRemedyError", false);
			break;
		case "AfterSalesOtherTextErrorName":
			component.set("v.AfterSalesOtherTextError", false);
			break;
		case "WarrantyProviderSummariseTextErrorName":
			component.set("v.WarrantyProviderSummariseTextError", false);
			break;
		case "WarrantyProviderRemedyErrorName":
			component.set("v.WarrantyProviderRemedyError", false);
			break;
		case "WarrantyProviderOtherTextErrorName":
			component.set("v.WarrantyProviderOtherTextError", false);
			break;
		case "OtherSummariseTextErrorName":
			component.set("v.OtherSummariseTextError", false);
			break;
		case "OtherRemedyErrorName":
			component.set("v.OtherRemedyError", false);
			break;
		case "OtherOtherTextErrorName":
			component.set("v.OtherOtherTextError", false);
			break;
		case "reviewsummariseErrorMessage":
			component.set("v.reviewsummariseError", false);
			break;
		case "reviewsellingSummariseTextErrorName":
			component.set("v.reviewsellingSummariseTextError", false);
			break;
		case "reviewsellingRemedyErrorName":
			component.set("v.reviewsellingRemedyError", false);
			break;
		case "reviewsellingOtherTextErrorName":
			component.set("v.reviewsellingOtherTextError", false);
			break;
		case "reviewLegalInspectionCompletionSummariseTextErrorName":
			component.set("v.reviewLegalInspectionCompletionSummariseTextError", false);
			break;
		case "reviewLegalInspectionCompletionRemedyErrorName":
			component.set("v.reviewLegalInspectionCompletionRemedyError", false);
			break;
		case "reviewLegalInspectionCompletionOtherTextErrorName":
			component.set("v.reviewLegalInspectionCompletionOtherTextError", false);
			break;
		case "reviewAfterSalesSummariseTextErrorName":
			component.set("v.reviewAfterSalesSummariseTextError", false);
			break;
		case "reviewAfterSalesRemedyErrorName":
			component.set("v.reviewAfterSalesRemedyError", false);
			break;
		case "reviewAfterSalesOtherTextErrorName":
			component.set("v.reviewAfterSalesOtherTextError", false);
			break;
		case "reviewWarrantyProviderSummariseTextErrorName":
			component.set("v.reviewWarrantyProviderSummariseTextError", false);
			break;
		case "reviewWarrantyProviderRemedyErrorName":
			component.set("v.reviewWarrantyProviderRemedyError", false);
			break;
		case "reviewWarrantyProviderOtherTextErrorName":
			component.set("v.reviewWarrantyProviderOtherTextError", false);
			break;
		case "reviewOtherSummariseTextErrorName":
			component.set("v.reviewOtherSummariseTextError", false);
			break;
		case "reviewOtherRemedyErrorName":
			component.set("v.reviewOtherRemedyError", false);
			break;
		case "reviewOtherOtherTextErrorName":
			component.set("v.reviewOtherOtherTextError", false);
			break;
                
                
        case "SellingIdentifyCodeDeveloperBreachedName":
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
			break;
			
		case "SellingBreacheNotAddressedYourConcernsName":
			component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
			break;
			
		case "SellingEvidenceUploadSupportsYourCaseName":
			component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
			break;
			
		case "SellingSummaryName":
			component.set("v.SellingSummaryError", false);
			break;
			
		case "SellingFurtherInformationSeekingLossCostName":
			component.set("v.SellingFurtherInformationSeekingLossCostError", false);
			break;

        case "LegalIdentifyCodeDeveloperBreachedName":
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
			break;
			
		case "LegalBreacheNotAddressedYourConcernsName":
			component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
			break;
			
		case "LegalEvidenceUploadSupportsYourCaseName":
			component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
			break;

        case "LegalSummaryName":
			component.set("v.LegalSummaryError", false);
			break;
			
		case "LegalFurtherInformationSeekingLossCostName":
			component.set("v.LegalFurtherInformationSeekingLossCostError", false);
			break;
			
		case "AfterSalesIdentifyCodeDeveloperBreachedName":
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
			break;
			
		case "AfterSalesBreacheNotAddressedYourConcernsName":
			component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
			break;
			
		case "AfterSalesEvidenceUploadSupportsYourCaseName":
			component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
			break;

        case "AfterSalesSummaryName":
			component.set("v.AfterSalesSummaryError", false);
			break;
			
		case "AfterSalesFurtherInformationSeekingLossCostName":
			component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
			break;
			
        case "OtherBreacheNotAddressedYourConcernsName":
			component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
			break;
			
		case "OtherEvidenceUploadSupportsYourCaseName":
			component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
			break;
			
		case "OtherSummaryName":
			component.set("v.OtherSummaryError", false);
			break;

        case "OtherFurtherInformationSeekingLossCostName":
			component.set("v.OtherFurtherInformationSeekingLossCostError", false);
			break;
			
		case "WarrantyProviderSummaryName":
			component.set("v.WarrantyProviderSummaryError", false);
			break;
                
       case "SellingSectionInCmpId":
			component.set("v.SellingSectionInCmp", false);
			break;
       case "LegalInspectionCompletionSectionInCmpId":
			component.set("v.LegalInspectionCompletionSectionInCmp", false);
			break;
       case "AfterSalesSectionInCmpId":
			component.set("v.AfterSalesSectionInCmp", false);
			break;
       case "WarrantyProviderSectionInCmpId":
			component.set("v.WarrantyProviderSectionInCmp", false);
			break;
       case "OtherSectionInCmpId":
			component.set("v.OtherSectionInCmp", false);
			break;
		}
	},
    
    
	handleSummaryOfComplaint: function (component, event, helper) 
    {
		var isValid = true;
		var summariseValue = document.getElementById("summarise").value;
        component.set("v.summariseError", false);
        component.set("v.AreaOfComplaintError", false);
        
		if (summariseValue == undefined || summariseValue == "" || summariseValue == null) 
        {
			component.set("v.summariseError", true);
			isValid = false;
		}
        
		if (component.get("v.SellingComp.isSelected") == false && component.get("v.LegalInspectionCompletionComp.isSelected") == false && component.get("v.AfterSalesComp.isSelected") == false && component.get("v.WarrantyProviderComp.isSelected") == false && component.get("v.OtherComp.isSelected") == false) 
        {
			component.set("v.AreaOfComplaintError", true);
			isValid = false;
		}
        
		if (isValid == true) 
        {
			component.set("v.case.Homebuyer_Summary_Complaint__c", summariseValue);
			helper.helperSaveSummaryOfComplaint(component, event, helper);
		}
        else
        {
           if(component.get("v.summariseError") == true) 
           {
                $("html, body").animate( { scrollTop: $("#summariseOverviewDiv").offset().top - 10 },500);
           }
        }
	},
    
    
	accordionSellingDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
		//helper.helperAccordionEvent(component, event, helper, !component.get("v.SellingDetailedSection"), false, false, false, false);
		helper.helperAccordionEvent(component, event, helper, !component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
	    $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 25 },500);
    },
    
    
	accordionLegalInspectionCompletionDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), !component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
         $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
		//helper.helperAccordionEvent(component, event, helper, false, !component.get("v.LegalInspectionCompletionDetailedSection"), false, false, false);
	},
    
    
	accordionAfterSalesDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), !component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
		//helper.helperAccordionEvent(component, event, helper, false, false, !component.get("v.AfterSalesDetailedSection"), false, false);
	},
    
    
	accordionWarrantyProviderDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), !component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
		//helper.helperAccordionEvent(component, event, helper, false, false, false, !component.get("v.WarrantyProviderDetailedSection"), false);
	},
    
    
	accordionOtherDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), !component.get("v.OtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
		//helper.helperAccordionEvent(component, event, helper, false, false, false, false, !component.get("v.OtherDetailedSection"));
	},
    
    
	SaveSellingData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("SellingIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("SellingBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("SellingEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("SellingSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("SellingFurtherInformationSeekingLossCost").value;
        
		var ApologyChk = document.getElementById("SellingApologyChk").checked;
		var ProblemPutChk = document.getElementById("SellingProblemPutChk").checked;
		var CompensationChk = document.getElementById("SellingCompensationChk").checked;
		var OtherChk = document.getElementById("SellingOtherChk").checked;
		var OtherText = document.getElementById("SellingOtherText").value;
        
		component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
        component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
        component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
        component.set("v.SellingSummaryError", false);
        component.set("v.SellingFurtherInformationSeekingLossCostError", false);
        
		component.set("v.sellingRemedyError", false);
		component.set("v.sellingOtherTextError", false);
        
        component.set("v.SellingSectionInCmp", false);
        
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.SellingFurtherInformationSeekingLossCostError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
		if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
        {
			component.set("v.sellingRemedyError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
		if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
        {
			component.set("v.sellingOtherTextError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
		if (isValid == true) 
        {
			component.set("v.SellingComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.SellingComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.SellingComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.SellingComp.AreasOfComplaint.HB_Summary__c", Summary);
            component.set("v.SellingComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
            
			component.set("v.SellingComp.AreasOfComplaint.An_apology__c", ApologyChk);
			component.set("v.SellingComp.AreasOfComplaint.The_Problem_Put_Right__c", ProblemPutChk);
			component.set("v.SellingComp.AreasOfComplaint.Comensation__c", CompensationChk);
			component.set("v.SellingComp.AreasOfComplaint.Other__c", OtherChk);
			component.set("v.SellingComp.AreasOfComplaint.Other_Remedy__c", OtherText);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'Selling');
		} 
        else 
        {
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
             $("html, body").animate( { scrollTop: $("#DetailSelling").offset().top-25}, 500 );
		}
	},
    
    
	SaveLegalInspectionCompletionData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("LegalIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("LegalBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("LegalEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("LegalSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("LegalFurtherInformationSeekingLossCost").value;

		var ApologyChk = document.getElementById("LegalInspectionCompletionApologyChk").checked;
		var ProblemPutChk = document.getElementById("LegalInspectionCompletionProblemPutChk").checked;
		var CompensationChk = document.getElementById("LegalInspectionCompletionCompensationChk").checked;
		var OtherChk = document.getElementById("LegalInspectionCompletionOtherChk").checked;
		var OtherText = document.getElementById("LegalInspectionCompletionOtherText").value;
        
		component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
        component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
        component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
        component.set("v.LegalSummaryError", false);
        component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
		component.set("v.LegalInspectionCompletionRemedyError", false);
		component.set("v.LegalInspectionCompletionOtherTextError", false);
        component.set("v.LegalInspectionCompletionSectionInCmp", false);
        
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.LegalFurtherInformationSeekingLossCostError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
		if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
        {
			component.set("v.LegalInspectionCompletionRemedyError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
		if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
        {
			component.set("v.LegalInspectionCompletionOtherTextError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
		if (isValid == true) 
        {
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Summary__c", Summary);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
            
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.An_apology__c", ApologyChk);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.The_Problem_Put_Right__c", ProblemPutChk);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Comensation__c", CompensationChk);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c", OtherChk);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other_Remedy__c", OtherText);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'LegalInspectionCompletion');
		} 
        else 
        {
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
			$("html, body").animate( { scrollTop: $("#DetailLegalInspectionCompletion").offset().top-25}, 500 );
		}
        
	},
    
    
	SaveAfterSalesData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("AfterSalesIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("AfterSalesBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("AfterSalesEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("AfterSalesSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("AfterSalesFurtherInformationSeekingLossCost").value;

		var ApologyChk = document.getElementById("AfterSalesApologyChk").checked;
		var ProblemPutChk = document.getElementById("AfterSalesProblemPutChk").checked;
		var CompensationChk = document.getElementById("AfterSalesCompensationChk").checked;
		var OtherChk = document.getElementById("AfterSalesOtherChk").checked;
		var OtherText = document.getElementById("AfterSalesOtherText").value;
        
		component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
        component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
        component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
        component.set("v.AfterSalesSummaryError", false);
        component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
        
		component.set("v.AfterSalesRemedyError", false);
		component.set("v.AfterSalesOtherTextError", false);
        component.set("v.AfterSalesSectionInCmp", false);
        
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
		if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
        {
			component.set("v.AfterSalesRemedyError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
		if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
        {
			component.set("v.AfterSalesOtherTextError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
		if (isValid == true) 
        {
			component.set("v.AfterSalesComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Summary__c", Summary);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
            
			component.set("v.AfterSalesComp.AreasOfComplaint.An_apology__c", ApologyChk);
			component.set("v.AfterSalesComp.AreasOfComplaint.The_Problem_Put_Right__c", ProblemPutChk);
			component.set("v.AfterSalesComp.AreasOfComplaint.Comensation__c", CompensationChk);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other__c", OtherChk);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c", OtherText);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'AfterSales');
		} 
        else 
        {
            $("html, body").animate( { scrollTop: $("#DetailAfterSales").offset().top-25}, 500 );

			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
		}
	},
    
   
	SaveOtherData: function (component, event, helper) 
    {
		var isValid = true;
        
		var BreacheNotAddressedYourConcerns = document.getElementById("OtherBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("OtherEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("OtherSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("OtherFurtherInformationSeekingLossCost").value;

		var ApologyChk = document.getElementById("OtherApologyChk").checked;
		var ProblemPutChk = document.getElementById("OtherProblemPutChk").checked;
		var CompensationChk = document.getElementById("OtherCompensationChk").checked;
		var OtherChk = document.getElementById("OtherOtherChk").checked;
		var OtherText = document.getElementById("OtherOtherText").value;
        
		
        component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
        component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
        component.set("v.OtherSummaryError", false);
        component.set("v.OtherFurtherInformationSeekingLossCostError", false);
        
		component.set("v.OtherRemedyError", false);
		component.set("v.OtherOtherTextError", false);
        
        component.set("v.OtherSectionInCmp", false);
        
		
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.OtherFurtherInformationSeekingLossCostError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
		if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
        {
			component.set("v.OtherRemedyError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
		if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
        {
			component.set("v.OtherOtherTextError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
		if (isValid == true) 
        {
			component.set("v.OtherComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.OtherComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.OtherComp.AreasOfComplaint.HB_Summary__c", Summary);
            component.set("v.OtherComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
            
			component.set("v.OtherComp.AreasOfComplaint.An_apology__c", ApologyChk);
			component.set("v.OtherComp.AreasOfComplaint.The_Problem_Put_Right__c", ProblemPutChk);
			component.set("v.OtherComp.AreasOfComplaint.Comensation__c", CompensationChk);
			component.set("v.OtherComp.AreasOfComplaint.Other__c", OtherChk);
			component.set("v.OtherComp.AreasOfComplaint.Other_Remedy__c", OtherText);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'Other');
		} 
        else 
        {
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
			 $("html, body").animate( { scrollTop: $("#DetailOther").offset().top-25}, 500 );
		}
	},
    
    
    SaveWarrantyProviderData: function (component, event, helper) 
    {
		var isValid = true;
        
		var Summary = document.getElementById("WarrantyProviderSummary").value;
        
		
        
		component.set("v.WarrantyProviderSummaryError", false);
        component.set("v.WarrantyProviderSectionInCmp", false);
        
		
        
        if (Summary == undefined || Summary == "" || Summary == null) 
        {
			component.set("v.WarrantyProviderSummaryError", true);
            component.set("v.WarrantyProviderSectionInCmp", true);
			isValid = false;
		}
        
		
        
		if (isValid == true) 
        {
			component.set("v.WarrantyProviderComp.AreasOfComplaint.HB_Summary__c", Summary);
            
			
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'WarrantyProvider');
		} 
        else 
        {
             $("html, body").animate( { scrollTop: $("#DetailWarrantyProvider").offset().top-25}, 500 );
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
		}
	},

    
	goBackFromDetailedSubmission: function (component, event, helper) 
    {
        helper.helperSaveDataToAttribute(component, event, helper);
		window.scroll({top: 0,behavior: 'smooth'});
		component.set("v.summarySection", true);
		component.set("v.detailedSection", false);
		component.set("v.reviewSection", false);
        component.set("v.thankYouSection", false);
        component.set("v.isCancel", false);         
        
        component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			component.set("v.sellingRemedyError", false);
			component.set("v.sellingOtherTextError", false);
			
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
            component.set("v.LegalInspectionCompletionRemedyError", false);
            component.set("v.LegalInspectionCompletionOtherTextError", false);
			
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            
            component.set("v.AfterSalesRemedyError", false);
            component.set("v.AfterSalesOtherTextError", false);
            
			component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
            component.set("v.OtherRemedyError", false);
            component.set("v.OtherOtherTextError", false);
			
			component.set("v.WarrantyProviderSummaryError", false);
        
            component.set("v.SellingSectionInCmp", false);
            component.set("v.LegalInspectionCompletionSectionInCmp", false);
            component.set("v.AfterSalesSectionInCmp", false);
            component.set("v.OtherSectionInCmp", false);
            component.set("v.WarrantyProviderSectionInCmp", false);
	},
    
    
	saveAndContinueFromDetailedSubmission: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        
		/*component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);*/
        
         component.set("v.SellingSectionInCmp", false);
         component.set("v.LegalInspectionCompletionSectionInCmp", false);
         component.set("v.AfterSalesSectionInCmp", false);
         component.set("v.OtherSectionInCmp", false);
         component.set("v.WarrantyProviderSectionInCmp", false);
        
		var isFinalValid = true;
		var ArrOfAreaOfComp = [];
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			var isValid = true;
            
            var IdentifyCodeDeveloperBreached = component.get("v.SellingComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.SellingComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.SellingComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.SellingComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.SellingComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
            
			var ApologyChk = component.get("v.SellingComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk = component.get("v.SellingComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk = component.get("v.SellingComp.AreasOfComplaint.Comensation__c");
			var OtherChk = component.get("v.SellingComp.AreasOfComplaint.Other__c");
			var OtherText = component.get("v.SellingComp.AreasOfComplaint.Other_Remedy__c");
            
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			component.set("v.sellingRemedyError", false);
			component.set("v.sellingOtherTextError", false);
            component.set("v.SellingSectionInCmp", false);
            
			if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.SellingFurtherInformationSeekingLossCostError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
			if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
            {
				component.set("v.sellingRemedyError", true);
                component.set("v.SellingSectionInCmp", true);
				isValid = false;
			}
			if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
            {
				component.set("v.sellingOtherTextError", true);
                component.set("v.SellingSectionInCmp", true);
				isValid = false;
			}
            
			if (isValid == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.SellingDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			var isValid1 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
			var ApologyChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Comensation__c");
			var OtherChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c");
			var OtherText1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Other_Remedy__c");
           
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
            component.set("v.LegalInspectionCompletionRemedyError", false);
            component.set("v.LegalInspectionCompletionOtherTextError", false);
            
            component.set("v.LegalInspectionCompletionSectionInCmp", false);
        
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.LegalFurtherInformationSeekingLossCostError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
			if (ApologyChk1 != true && ProblemPutChk1 != true && CompensationChk1 != true && OtherChk1 != true)
            {
				component.set("v.LegalInspectionCompletionRemedyError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
				isValid1 = false;
			}
			if (OtherChk1 == true && (OtherText1 == undefined || OtherText1 == "" || OtherText1 == null)) 
            {
				component.set("v.LegalInspectionCompletionOtherTextError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
				isValid1 = false;
			}
            
			if (isValid1 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.LegalInspectionCompletionDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			var isValid2 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
			var ApologyChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.Comensation__c");
			var OtherChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.Other__c");
			var OtherText2 = component.get("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c");
            
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            
            component.set("v.AfterSalesRemedyError", false);
            component.set("v.AfterSalesOtherTextError", false);
            component.set("v.AfterSalesSectionInCmp", false);
            
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
			if (ApologyChk2 != true && ProblemPutChk2 != true && CompensationChk2 != true && OtherChk2 != true) 
            {
				component.set("v.AfterSalesRemedyError", true);
                component.set("v.AfterSalesSectionInCmp", true);
				isValid2 = false;
			}
			if (OtherChk2 == true && (OtherText2 == undefined || OtherText2 == "" || OtherText2 == null)) 
            {
				component.set("v.AfterSalesOtherTextError", true);
                component.set("v.AfterSalesSectionInCmp", true);
				isValid2 = false;
			}
            
			if (isValid2 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.AfterSalesDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			var isValid4 = true;
            
			var BreacheNotAddressedYourConcerns = component.get("v.OtherComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.OtherComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.OtherComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.OtherComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
            
			var ApologyChk4 = component.get("v.OtherComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk4 = component.get("v.OtherComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk4 = component.get("v.OtherComp.AreasOfComplaint.Comensation__c");
			var OtherChk4 = component.get("v.OtherComp.AreasOfComplaint.Other__c");
			var OtherText4 = component.get("v.OtherComp.AreasOfComplaint.Other_Remedy__c");
            
			 component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
            component.set("v.OtherRemedyError", false);
            component.set("v.OtherOtherTextError", false);
            
            component.set("v.OtherSectionInCmp", false);
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.OtherFurtherInformationSeekingLossCostError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
			if (ApologyChk4 != true && ProblemPutChk4 != true && CompensationChk4 != true && OtherChk4 != true) 
            {
				component.set("v.OtherRemedyError", true);
                component.set("v.OtherSectionInCmp", true);
				isValid4 = false;
			}
			if (OtherChk4 == true && (OtherText4 == undefined || OtherText4 == "" || OtherText4 == null)) 
            {
				component.set("v.OtherOtherTextError", true);
                component.set("v.OtherSectionInCmp", true);
				isValid4 = false;
			}
            
			if (isValid4 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.OtherDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			var isValid3 = true;
            
			var Summary = component.get("v.WarrantyProviderComp.AreasOfComplaint.HB_Summary__c");
           	
          
            
			component.set("v.WarrantyProviderSummaryError", false);
            component.set("v.WarrantyProviderSectionInCmp", false);
           
            
            
            if (Summary == undefined || Summary == "" || Summary == null) 
            {
                component.set("v.WarrantyProviderSummaryError", true);
                component.set("v.WarrantyProviderSectionInCmp", true);
                isValid3 = false;
            }
			
			if (isValid3 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			} else 
            {
				component.set("v.WarrantyProviderDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		
		if (isFinalValid == true) 
        {
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, true,null);
		} 
        else 
        {
            if(component.get("v.SellingSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 50 },500);
            }
            else if(component.get("v.LegalInspectionCompletionSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 50 },500);
            }
            else if(component.get("v.AfterSalesSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 50},500);
            }
            else if(component.get("v.OtherSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 50 },500);
            }
            else if(component.get("v.WarrantyProviderSectionInCmp") == true)
            {
                 $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 100 },500);
            }
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
		}
	},
    
    
	goBackFromReviewSubmission: function (component, event, helper) 
    {
        helper.helperSaveDataToAttributeReview(component, event, helper); 
		helper.helperExpandDetailSection(component, event, helper);
        
		window.scroll({top: 0,behavior: 'smooth'});
		component.set("v.summarySection", false);
		component.set("v.detailedSection", true);
		component.set("v.reviewSection", false);
        component.set("v.thankYouSection", false);
        component.set("v.isCancel", false);         
        
        component.set("v.reviewSaveWarningMsg", false);
        component.set("v.reviewSubmitWarningMsg", false);
        component.set("v.isActiveReviewContinueBtn", false);
        
        component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			component.set("v.sellingRemedyError", false);
			component.set("v.sellingOtherTextError", false);
			
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
            component.set("v.LegalInspectionCompletionRemedyError", false);
            component.set("v.LegalInspectionCompletionOtherTextError", false);
			
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            
            component.set("v.AfterSalesRemedyError", false);
            component.set("v.AfterSalesOtherTextError", false);
            
			component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
            component.set("v.OtherRemedyError", false);
            component.set("v.OtherOtherTextError", false);
			
			component.set("v.WarrantyProviderSummaryError", false);
            
            component.set("v.SellingSectionInCmp", false);
            component.set("v.LegalInspectionCompletionSectionInCmp", false);
            component.set("v.AfterSalesSectionInCmp", false);
            component.set("v.OtherSectionInCmp", false);
            component.set("v.WarrantyProviderSectionInCmp", false);
	},
    
    
	accordionSellingReviewSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
		helper.helperAccordionEventReview(component, event, helper, !component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
	    $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 25 },500);
    },
    
    
	accordionLegalInspectionCompletionReviewSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
       helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), !component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
        //helper.helperAccordionEventReview(component, event, helper, false, !component.get("v.reviewLegalInspectionCompletionDetailedSection"), false, false, false);
	},
    
    
	accordionAfterSalesReviewSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
        helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), !component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
        //helper.helperAccordionEventReview(component, event, helper, false, false, !component.get("v.reviewAfterSalesDetailedSection"), false, false);
	},
    
    
	accordionWarrantyProviderReviewSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
        helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), !component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
        //helper.helperAccordionEventReview(component, event, helper, false, false, false, !component.get("v.reviewWarrantyProviderDetailedSection"), false);
	},
    
    
	accordionOtherReviewSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
		helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), !component.get("v.reviewOtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
        //helper.helperAccordionEventReview(component, event, helper, false, false, false, false, !component.get("v.reviewOtherDetailedSection"));
	},
    
    
	ReviewSaveBtnClick: function (component, event, helper) 
    {
		helper.helperSaveDataToAttributeReview(component, event, helper);
        
        
        
		/*component.set("v.reviewSellingDetailedSection", false);
		component.set("v.reviewLegalInspectionCompletionDetailedSection", false);
		component.set("v.reviewAfterSalesDetailedSection", false);
		component.set("v.reviewWarrantyProviderDetailedSection", false);
		component.set("v.reviewOtherDetailedSection", false);*/
        
         component.set("v.SellingSectionInCmp", false);
         component.set("v.LegalInspectionCompletionSectionInCmp", false);
         component.set("v.AfterSalesSectionInCmp", false);
         component.set("v.OtherSectionInCmp", false);
         component.set("v.WarrantyProviderSectionInCmp", false);
        
		var isFinalValid = true;
		var ArrOfAreaOfComp = [];
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			var isValid = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.SellingComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.SellingComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.SellingComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.SellingComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.SellingComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
			var ApologyChk = component.get("v.SellingComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk = component.get("v.SellingComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk = component.get("v.SellingComp.AreasOfComplaint.Comensation__c");
			var OtherChk = component.get("v.SellingComp.AreasOfComplaint.Other__c");
			var OtherText = component.get("v.SellingComp.AreasOfComplaint.Other_Remedy__c");
            
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			component.set("v.reviewsellingRemedyError", false);
			component.set("v.reviewsellingOtherTextError", false);
            
            component.set("v.SellingSectionInCmp", false);
            
			if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.SellingFurtherInformationSeekingLossCostError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
			if (ApologyChk != true && ProblemPutChk != true && CompensationChk != true && OtherChk != true) 
            {
				component.set("v.reviewsellingRemedyError", true);
                component.set("v.SellingSectionInCmp", true);
				isValid = false;
			}
			if (OtherChk == true && (OtherText == undefined || OtherText == "" || OtherText == null)) 
            {
				component.set("v.reviewsellingOtherTextError", true);
                component.set("v.SellingSectionInCmp", true);
				isValid = false;
			}
            
			if (isValid == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.reviewSellingDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			var isValid1 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
            var ApologyChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Comensation__c");
			var OtherChk1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c");
			var OtherText1 = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.Other_Remedy__c");
            
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
            
			component.set("v.reviewLegalInspectionCompletionRemedyError", false);
			component.set("v.reviewLegalInspectionCompletionOtherTextError", false);
            
            component.set("v.LegalInspectionCompletionSectionInCmp", false);
            
			if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.LegalFurtherInformationSeekingLossCostError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
			if (ApologyChk1 != true && ProblemPutChk1 != true && CompensationChk1 != true && OtherChk1 != true) 
            {
				component.set("v.reviewLegalInspectionCompletionRemedyError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
				isValid1 = false;
			}
			if (OtherChk1 == true && (OtherText1 == undefined || OtherText1 == "" || OtherText1 == null)) 
            {
				component.set("v.reviewLegalInspectionCompletionOtherTextError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
				isValid1 = false;
			}
            
            if (isValid1 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.reviewLegalInspectionCompletionDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			var isValid2 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.AfterSalesComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
            var ApologyChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.Comensation__c");
			var OtherChk2 = component.get("v.AfterSalesComp.AreasOfComplaint.Other__c");
			var OtherText2 = component.get("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c");
            
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            
			component.set("v.reviewAfterSalesRemedyError", false);
			component.set("v.reviewAfterSalesOtherTextError", false);
            component.set("v.AfterSalesSectionInCmp", false);
            
			 if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
			if (ApologyChk2 != true && ProblemPutChk2 != true && CompensationChk2 != true && OtherChk2 != true) 
            {
				component.set("v.reviewAfterSalesRemedyError", true);
                component.set("v.AfterSalesSectionInCmp", true);
				isValid2 = false;
			}
			if (OtherChk2 == true && (OtherText2 == undefined || OtherText2 == "" || OtherText2 == null)) 
            {
				component.set("v.reviewAfterSalesOtherTextError", true);
                component.set("v.AfterSalesSectionInCmp", true);
				isValid2 = false;
			}
            
			if (isValid2 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.reviewAfterSalesDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		
		if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			var isValid4 = true;
            
			var BreacheNotAddressedYourConcerns = component.get("v.OtherComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.OtherComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.OtherComp.AreasOfComplaint.HB_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.OtherComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c");
            
            var ApologyChk4 = component.get("v.OtherComp.AreasOfComplaint.An_apology__c");
			var ProblemPutChk4 = component.get("v.OtherComp.AreasOfComplaint.The_Problem_Put_Right__c");
			var CompensationChk4 = component.get("v.OtherComp.AreasOfComplaint.Comensation__c");
			var OtherChk4 = component.get("v.OtherComp.AreasOfComplaint.Other__c");
			var OtherText4 = component.get("v.OtherComp.AreasOfComplaint.Other_Remedy__c");
            
			 component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
			component.set("v.reviewOtherRemedyError", false);
			component.set("v.reviewOtherOtherTextError", false);
            component.set("v.OtherSectionInCmp", false);
            
			 if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.OtherFurtherInformationSeekingLossCostError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
			if (ApologyChk4 != true && ProblemPutChk4 != true && CompensationChk4 != true && OtherChk4 != true) 
            {
				component.set("v.reviewOtherRemedyError", true);
                component.set("v.OtherSectionInCmp", true);
				isValid4 = false;
			}
			if (OtherChk4 == true && (OtherText4 == undefined || OtherText4 == "" || OtherText4 == null)) 
            {
				component.set("v.reviewOtherOtherTextError", true);
                component.set("v.OtherSectionInCmp", true);
				isValid4 = false;
			}
            
			if (isValid4 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.reviewOtherDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			var isValid3 = true;
            
			var Summary = component.get("v.WarrantyProviderComp.AreasOfComplaint.HB_Summary__c");
           	
          
            
			component.set("v.WarrantyProviderSummaryError", false);
            component.set("v.WarrantyProviderSectionInCmp", false);
           
            
            
            if (Summary == undefined || Summary == "" || Summary == null) 
            {
                component.set("v.WarrantyProviderSummaryError", true);
                component.set("v.WarrantyProviderSectionInCmp", true);
                isValid3 = false;
            }
            
			if (isValid3 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.reviewWarrantyProviderDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        
		var summariseValue = document.getElementById("reviewSummarise").value;
		component.set("v.reviewsummariseError", false);
        
		if (summariseValue == undefined || summariseValue == "" || summariseValue == null) 
        {
			component.set("v.reviewsummariseError", true);
			isFinalValid = false;
		} 
        else 
        {
			component.set("v.case.Homebuyer_Summary_Complaint__c", summariseValue);
		}
        
		if (isFinalValid == true) 
        {
			var isSubmitBtn = 0;
			var button_Name = event.target.name;
            
			switch (button_Name) 
            {
			case "reviewSaveBtn":
				isSubmitBtn = 0;
                component.set("v.reviewSubmitCount",0);
				component.set("v.reviewSubmitWarningMsg",false);
				break;
			case "reviewSubmitBtn":
				isSubmitBtn = 1;
                component.set("v.isActiveReviewContinueBtn",true);
                component.set("v.reviewSubmitWarningMsg",true);
                component.set("v.reviewSaveWarningMsg",false);
				break;
             case "reviewContinueBtn":
				isSubmitBtn = 2;
				break;       
                    
			}
            
           if(isSubmitBtn == 0)
           {
               component.set("v.reviewSaveWarningMsg",false); 
               var cnt = component.get("v.reviewSubmitCount");
              /* if(cnt == 0)
               {
                   component.set("v.reviewSubmitCount",1);
                   component.set("v.reviewSubmitWarningMsg",true);
               }
               if(cnt == 1)
               {*/
                   helper.helperSaveReviewComplaint(component, event, helper, ArrOfAreaOfComp, false);
               //}
           }
           else if(isSubmitBtn == 2)
           {
               helper.helperSaveReviewComplaint(component, event, helper, ArrOfAreaOfComp, true);
           }
			
		} 
        else 
        {
			var offsets = document.getElementById("ReviewSection");
            
			if (summariseValue == undefined || summariseValue == "" || summariseValue == null) 
            {
				window.scroll({top: offsets.offsetTop + 100,behavior: 'smooth'});
			} 
            else 
            {
				//window.scroll({top: offsets.offsetTop + 500,behavior: 'smooth'});
				if(component.get("v.SellingSectionInCmp") == true)
                {
                    $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 50 },500);
                }
                else if(component.get("v.LegalInspectionCompletionSectionInCmp") == true)
                {
                    $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 50 },500);
                }
                else if(component.get("v.AfterSalesSectionInCmp") == true)
                {
                    $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 50 },500);
                }
                else if(component.get("v.OtherSectionInCmp") == true)
                {
                    $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 50 },500);
                }
                else if(component.get("v.WarrantyProviderSectionInCmp") == true)
                {
                     $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 50 },500);
                }
			}
		}
	},
    
    
    reviewSaveWarningMsgClose: function (component, event, helper) 
    {
        component.set("v.reviewSaveWarningMsg",false);
    },
    
    reviewSubmitWarningMsgClose: function (component, event, helper) 
    {
        component.set("v.reviewSubmitWarningMsg",false);
    },
    
    goToDashboard: function (component, event, helper) 
    {
        let redirectURL = $A.get("$Label.c.NHOS_CommunityName");
        window.location.replace(redirectURL); 
    }
           
})