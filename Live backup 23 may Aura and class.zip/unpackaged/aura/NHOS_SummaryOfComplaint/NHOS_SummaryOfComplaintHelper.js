({
	helperComplaintBasicDetails: function (component, event, helper) 
    {
		var action = component.get("c.getComplaintBasicDetails");
        
		component.set("v.showSpinner", true);
		action.setParams({
			caseId: component.get("v.caseId")
		});
        
        
        
		action.setCallback(this, function (response) {
			var state = response.getState();
            
			//console.log(" corres state :::::::" + state);
			if (state == "SUCCESS") 
            {
				var result = response.getReturnValue();
                //console.log("Result--", JSON.stringify(result));
                //console.log("Result 33--", result);
                if(Object.keys(result).length === 0 && result.constructor === Object){
                    let redirectURL = $A.get("$Label.c.NHOS_Lightning_CommunityLogout_URL")+"secur/logout.jsp?retUrl="+$A.get("$Label.c.NHOS_Lightning_CommunityLogout_URL");
                    window.location.replace(redirectURL); 
                }else{
                    
				component.set("v.case", result.caseObj);
                component.set("v.EvidenceList", result.EvidenceList);
				component.set("v.ComplaintWrapper", result);
                var valz;
                var valzNew;
				
                if(component.get("v.case.Contact.MailingState") != '' && component.get("v.case.Contact.MailingState") != null && component.get("v.case.Contact.MailingState") != undefined)
                {
                    valz = component.get("v.case.Contact.MailingStreet") + ", " + component.get("v.case.Contact.MailingCity") + ", " + component.get("v.case.Contact.MailingState") + ", " + component.get("v.case.Contact.MailingPostalCode") + ", " + component.get("v.case.Contact.Base_Country__c") + ", " + component.get("v.case.Contact.MailingCountry");
                    valzNew = component.get("v.case.Contact.MailingStreet") + "\n" + component.get("v.case.Contact.MailingCity") + "\n" + component.get("v.case.Contact.MailingState") + "\n" + component.get("v.case.Contact.MailingPostalCode") + "\n" + component.get("v.case.Contact.Base_Country__c") + "\n" + component.get("v.case.Contact.MailingCountry");

                }
                else
                {
                    valz = component.get("v.case.Contact.MailingStreet") + ", " + component.get("v.case.Contact.MailingCity") + ", "  + component.get("v.case.Contact.MailingPostalCode") + ", " + component.get("v.case.Contact.Base_Country__c") + ", " + component.get("v.case.Contact.MailingCountry");
                    valzNew = component.get("v.case.Contact.MailingStreet") + "\n" + component.get("v.case.Contact.MailingCity") + "\n"  + component.get("v.case.Contact.MailingPostalCode") + "\n" + component.get("v.case.Contact.Base_Country__c") + "\n" + component.get("v.case.Contact.MailingCountry");
                }
                
                var House_No = component.get("v.case.Contact.House_No__c");
                if(House_No != null && House_No != '' && House_No != undefined)
                {
                    valz = House_No+", "+valz;
                    valzNew = House_No+", "+valzNew;
                }
               
                component.set("v.currentAddress", valz);
                component.set("v.currentAddressNew", valzNew);
                
                var valz1;
                var valz1New;
				
                if(component.get("v.case.Property_Address__r.County__c") != '' && component.get("v.case.Property_Address__r.County__c") != null && component.get("v.case.Property_Address__r.County__c") != undefined)
                {
                    valz1 = component.get("v.case.Property_Address__r.Street__c") + ", " + component.get("v.case.Property_Address__r.City__c") + ", " + component.get("v.case.Property_Address__r.County__c") + ", " + component.get("v.case.Property_Address__r.Postal_Code__c") + ", " + component.get("v.case.Property_Address__r.Base_Country__c")+ ", " + component.get("v.case.Property_Address__r.Country__c");
                    valz1New = component.get("v.case.Property_Address__r.Street__c") + "\n" + component.get("v.case.Property_Address__r.City__c") + "\n" + component.get("v.case.Property_Address__r.County__c") + "\n" + component.get("v.case.Property_Address__r.Postal_Code__c") + "\n" + component.get("v.case.Property_Address__r.Base_Country__c")+ "\n" + component.get("v.case.Property_Address__r.Country__c");
                }
                else
                {
                    valz1 = component.get("v.case.Property_Address__r.Street__c") + ", " + component.get("v.case.Property_Address__r.City__c") +  ", " + component.get("v.case.Property_Address__r.Postal_Code__c") + ", " + component.get("v.case.Property_Address__r.Base_Country__c")+ ", " + component.get("v.case.Property_Address__r.Country__c");
                    valz1New = component.get("v.case.Property_Address__r.Street__c") + "\n" + component.get("v.case.Property_Address__r.City__c") +  "\n" + component.get("v.case.Property_Address__r.Postal_Code__c") + "\n" + component.get("v.case.Property_Address__r.Base_Country__c")+ "\n" + component.get("v.case.Property_Address__r.Country__c");
                }
                 
                var House_No1 = component.get("v.case.Property_Address__r.House_No__c");
                if(House_No1 != null && House_No1 != '' && House_No1 != undefined)
                {
                    valz1 = House_No1+", "+valz1;
                    
                    valz1New = House_No1+", "+valz1New;
                }
                 
                component.set("v.propertyAddress", valz1);
                component.set("v.propertyAddressNew", valz1New);
             
				
                component.set("v.BuilderName", result.BuilderName);
				component.set("v.SellingComp", result.Selling);
				component.set("v.LegalInspectionCompletionComp", result.LegalInspectionCompletion);
				component.set("v.AfterSalesComp", result.AfterSales);
				component.set("v.WarrantyProviderComp", result.WarrantyProvider);
				component.set("v.OtherComp", result.Other);
               // component.set("v.AdditionalCommentsComp", result.AdditionalComments );
                
                component.set("v.currentContact", result.currentContact);
                
                component.set("v.isSpoofLogin", result.isSpoofLogin);
                
                if(result.currentContact != null && result.currentContact.RecordType_Name__c != 'NHOS Customer')
                {
                    component.set("v.isHouseBuilder",true);
                }
                else
                {
                    component.set("v.isHouseBuilder",false);
                }
               
                var isSpoofLogin = component.get("v.isSpoofLogin");
                var caseStatus = component.get("v.case.Status");
                var isHouseBuilder = component.get("v.isHouseBuilder");
              
                component.set("v.isSummaryOfComplaint",false);
                component.set("v.isSummaryOfComplaintReadOnly",false);
                component.set("v.isSummaryOfComplaintRD",false);
                component.set("v.isCancel", false);
                
               // console.log('---caseStatus-',caseStatus);
                if(isSpoofLogin != true && caseStatus == 'Complaint in progress')
                {
                    component.set("v.isSummaryOfComplaint",true);
                    component.set("v.isSummaryOfComplaintReadOnly",false);
                    component.set("v.isSummaryOfComplaintRD",false);
                    component.set("v.isCancel", false);
                    
                }
                else if((isSpoofLogin == true && caseStatus == 'Complaint in progress') ||  caseStatus == 'Complaint Rejected')
                {
                    component.set("v.isSummaryOfComplaint",false);
                    component.set("v.isSummaryOfComplaintReadOnly",true);
                    component.set("v.isSummaryOfComplaintRD",false);
                    component.set("v.isCancel", true);
                   
                }
                else if(caseStatus == 'Complaint received by NHOS'  || (isHouseBuilder != true && caseStatus == 'Complaint accepted – awaiting developer/housebuilder response' ) || (/*isHouseBuilder != true &&*/ caseStatus == 'On Hold'))
                {
                    component.set("v.isSummaryOfComplaint",false);
                    component.set("v.isSummaryOfComplaintReadOnly",true);
                    component.set("v.isSummaryOfComplaintRD",false);
                    if(isSpoofLogin == true)
                    {
                       component.set("v.isCancel", true); 
                    }
                    else
                    {
                        component.set("v.isCancel", false);
                    }
                     
                   
                }
                else if(isHouseBuilder == true && (caseStatus == 'Complaint accepted – awaiting developer/housebuilder response' || caseStatus == 'On Hold'))
                {
                    component.set("v.isSummaryOfComplaint",false);
                    component.set("v.isSummaryOfComplaintReadOnly",false);
                    component.set("v.isSummaryOfComplaintRD",true);
                    component.set("v.isCancel", true); 
                }
                else if (caseStatus == 'Developer/housebuilder evidence submitted - Review in progress' || caseStatus == 'Developer/housebuilder evidence submitted - supplementary comments'
                          || caseStatus == 'Portal closed – Pre-ombudsman review' || caseStatus == 'Awaiting Ombudsman draft decision' 
                         || caseStatus == 'Draft decision issued' || caseStatus == 'Deadline for comments passed – pending final decision' || caseStatus == 'Final decision issued'
                         || caseStatus == 'Complaint Resolved' ||  caseStatus == 'Ombudsman Decision Issued' ||  caseStatus == 'Complaint cancelled' 
                        || caseStatus == 'Final decision accept' ||  caseStatus == 'Final decision reject')
                {
                    component.set("v.isSummaryOfComplaint",false);
                    component.set("v.isSummaryOfComplaintReadOnly",false);
                    component.set("v.isSummaryOfComplaintRD",true);
                    
                    if(isSpoofLogin != true && isHouseBuilder != true)
                     {
                         component.set("v.isCancel", false); 
                         if(caseStatus == 'Complaint Resolved' || caseStatus == 'Ombudsman Decision Issued' || caseStatus == 'Complaint cancelled'
                           || caseStatus == 'Final decision accept' ||  caseStatus == 'Final decision reject')
                         {
                             component.set("v.isCancel", true); 
                         }
                     }
                   
                }   
                
                 if(isSpoofLogin == true || isHouseBuilder == true)
                 {
                     component.set("v.isCancel", true); 
                 }
                
                } 
			} 
            else if (state === "ERROR") 
            {
                
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    
	helperSaveSummaryOfComplaint: function (component, event, helper) 
    {
		var action = component.get("c.saveSummaryOfComplaint");
        
		component.set("v.showSpinner", true);
		action.setParams({
			caseObj: component.get("v.case"),
			Selling: component.get("v.SellingComp"),
			LegalInspectionCompletion: component.get("v.LegalInspectionCompletionComp"),
			AfterSales: component.get("v.AfterSalesComp"),
			WarrantyProvider: component.get("v.WarrantyProviderComp"),
			Other: component.get("v.OtherComp")
		});
        
		action.setCallback(this, function (response) {
			var state = response.getState();
			if (state == "SUCCESS") 
            {
				var result = response.getReturnValue();
				if (result == 'Success') 
                {
					helper.helperComplaintBasicDetails(component, event, helper);
					helper.helperExpandDetailSection(component, event, helper);
					
					document.body.scrollTop = 0;
					document.documentElement.scrollTop = 0;
					component.set("v.summarySection", false);
					component.set("v.detailedSection", true);
					component.set("v.reviewSection", false);
                    component.set("v.thankYouSection", false);
                    component.set("v.isCancel", false);
                    
				} 
                else 
                {
					//component.set("v.summariseSaveErrorMsg", JSON.stringify(result));
					//component.set("v.summariseSaveError", true);
                     var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
				}
			} 
            else if (state === "ERROR") 
            {
				var result = response.getReturnValue();
				//component.set("v.summariseSaveErrorMsg", JSON.stringify(result));
				//component.set("v.summariseSaveError", true);
				var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
			}
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    
	helperExpandDetailSection: function (component, event, helper) 
    {
		component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.SellingDetailedSection", true);
		} 
        //else 
        if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.LegalInspectionCompletionDetailedSection", true);
		} 
        //else 
        if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.AfterSalesDetailedSection", true);
		} 
        //else 
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.OtherDetailedSection", true);
		}
        //else 
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.WarrantyProviderDetailedSection", true);
		} 
        
	},
    
    
	helperUpdateAreaOfComplaint: function (component, event, helper, complaintList, isContinue,areaName) 
    {
		var action = component.get("c.UpdateAreaOfComplaint");
        
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
            caseObj: null
		});
        
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
			if (state == "SUCCESS") 
            {
				if (result == 'Success') 
                {
                    if (isContinue == true) 
                    {
                        helper.helperExpandReviewSection(component, event, helper);
                        component.set("v.summarySection", false);
                        component.set("v.detailedSection", false);
                        component.set("v.reviewSection", true);
                        component.set("v.thankYouSection", false);
                        component.set("v.isCancel", false);
                        
                        component.set("v.reviewSubmitCount",0);
                        component.set("v.reviewSaveWarningMsg",false);
                        component.set("v.reviewSubmitWarningMsg",false);
                        component.set("v.isActiveReviewContinueBtn",false);
                        window.scroll({top: 0,behavior: 'smooth'});
                    } 
                    else
                    {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Success',
                            message: 'Data has been saved successfully',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'success',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                        
                        
                        if (areaName == 'Selling')//(component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true &&  component.get("v.SellingDetailedSection") == true) 
                        {
                            if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
                            {
                                component.set("v.LegalInspectionCompletionDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailLegalInspectionCompletion1");
								//window.scroll({top: offsets.offsetTop - 25 ,behavior: 'smooth'});
                                 $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
                            } 
                            else if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
                            {
                                component.set("v.AfterSalesDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                                //var offsets = document.getElementById("DetailAfterSales1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
								$("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
                            } 
                            else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                              //  component.set("v.SellingDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailOther1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailWarrantyProvider1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                                
                            } 
                           
                           
                        } 
                        else if (areaName == 'LegalInspectionCompletion')//(component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true && component.get("v.LegalInspectionCompletionDetailedSection") == true) 
                        {
                            if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
                            {
                                component.set("v.AfterSalesDetailedSection", true);
                               // component.set("v.LegalInspectionCompletionDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
								//var offsets = document.getElementById("DetailAfterSales1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
                            } 
                             else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                                //component.set("v.LegalInspectionCompletionDetailedSection",false);
                              //  var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailOther1");
							//	window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.LegalInspectionCompletionDetailedSection",false);
                              //  var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailWarrantyProvider1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            } 
                           
                        } 
                        else if (areaName == 'AfterSales')//(component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true && component.get("v.AfterSalesDetailedSection") == true) 
                        {
                            if(component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                               // component.set("v.AfterSalesDetailedSection",false);
                              //  var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                                // var offsets = document.getElementById("DetailOther1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                 $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                              //  component.set("v.AfterSalesDetailedSection",false);
                              //  var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailWarrantyProvider1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            } 
                            
                        } 
                        else if (areaName == 'Other')//(component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true && component.get("v.OtherDetailedSection") == true) 
                        {
                            if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.OtherDetailedSection",false);
                               // var offsets = document.getElementById("DetailedSection");
								//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
                               // var offsets = document.getElementById("DetailWarrantyProvider1");
								//window.scroll({top: offsets.offsetTop - 25,behavior: 'smooth'});
                                $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            }
                        } 
                        
                    }
                }
                else
                {
                     var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
				
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    
	helperExpandReviewSection: function (component, event, helper) 
    {
		component.set("v.reviewSellingDetailedSection", false);
		component.set("v.reviewLegalInspectionCompletionDetailedSection", false);
		component.set("v.reviewAfterSalesDetailedSection", false);
		component.set("v.reviewWarrantyProviderDetailedSection", false);
		component.set("v.reviewOtherDetailedSection", false);
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.reviewSellingDetailedSection", true);
		} 
        //else 
        if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.reviewLegalInspectionCompletionDetailedSection", true);
		} 
        //else 
        if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.reviewAfterSalesDetailedSection", true);
		}
        //else 
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.reviewOtherDetailedSection", true);
		}
        //else 
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.reviewWarrantyProviderDetailedSection", true);
		}
	},
    
    
	helperSaveDataToAttribute: function (component, event, helper) 
    {
		if (component.get("v.SellingDetailedSection") == true) 
        {
			component.set("v.SellingComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("SellingIdentifyCodeDeveloperBreached").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("SellingBreacheNotAddressedYourConcerns").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("SellingEvidenceUploadSupportsYourCase").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Summary__c", document.getElementById("SellingSummary").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("SellingFurtherInformationSeekingLossCost").value);
            
			component.set("v.SellingComp.AreasOfComplaint.An_apology__c", document.getElementById("SellingApologyChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("SellingProblemPutChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Comensation__c", document.getElementById("SellingCompensationChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Other__c", document.getElementById("SellingOtherChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("SellingOtherText").value);
		}
        
		if (component.get("v.LegalInspectionCompletionDetailedSection") == true) 
        {
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("LegalIdentifyCodeDeveloperBreached").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("LegalBreacheNotAddressedYourConcerns").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("LegalEvidenceUploadSupportsYourCase").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Summary__c", document.getElementById("LegalSummary").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("LegalFurtherInformationSeekingLossCost").value);
            
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.An_apology__c", document.getElementById("LegalInspectionCompletionApologyChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("LegalInspectionCompletionProblemPutChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Comensation__c", document.getElementById("LegalInspectionCompletionCompensationChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c", document.getElementById("LegalInspectionCompletionOtherChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("LegalInspectionCompletionOtherText").value);
		}
        
		if (component.get("v.AfterSalesDetailedSection") == true) 
        {
			component.set("v.AfterSalesComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("AfterSalesIdentifyCodeDeveloperBreached").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("AfterSalesBreacheNotAddressedYourConcerns").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("AfterSalesEvidenceUploadSupportsYourCase").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Summary__c", document.getElementById("AfterSalesSummary").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("AfterSalesFurtherInformationSeekingLossCost").value);
            
			component.set("v.AfterSalesComp.AreasOfComplaint.An_apology__c", document.getElementById("AfterSalesApologyChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("AfterSalesProblemPutChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Comensation__c", document.getElementById("AfterSalesCompensationChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other__c", document.getElementById("AfterSalesOtherChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("AfterSalesOtherText").value);
		}
        
        if (component.get("v.OtherDetailedSection") == true) 
        {
			component.set("v.OtherComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("OtherBreacheNotAddressedYourConcerns").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("OtherEvidenceUploadSupportsYourCase").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Summary__c", document.getElementById("OtherSummary").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("OtherFurtherInformationSeekingLossCost").value);
            
			component.set("v.OtherComp.AreasOfComplaint.An_apology__c", document.getElementById("OtherApologyChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("OtherProblemPutChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Comensation__c", document.getElementById("OtherCompensationChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Other__c", document.getElementById("OtherOtherChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("OtherOtherText").value);
		}
        
		if (component.get("v.WarrantyProviderDetailedSection") == true) 
        {
			component.set("v.WarrantyProviderComp.AreasOfComplaint.HB_Summary__c", document.getElementById("WarrantyProviderSummary").value);
			
        }
        
	},
    
    
	helperAccordionEvent: function (component, event, helper, Selling, LegalInspectionCompletion, AfterSales, WarrantyProvider, Other) 
    {
		component.set("v.SellingDetailedSection", Selling);
		component.set("v.LegalInspectionCompletionDetailedSection", LegalInspectionCompletion);
		component.set("v.AfterSalesDetailedSection", AfterSales);
		component.set("v.WarrantyProviderDetailedSection", WarrantyProvider);
		component.set("v.OtherDetailedSection", Other);
        
		//var offsets = document.getElementById("DetailedSection");
		//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
	},
    
    
	helperSaveDataToAttributeReview: function (component, event, helper) 
    {
		if (component.get("v.reviewSellingDetailedSection") == true) 
        {
            component.set("v.SellingComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("SellingIdentifyCodeDeveloperBreached").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("SellingBreacheNotAddressedYourConcerns").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("SellingEvidenceUploadSupportsYourCase").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Summary__c", document.getElementById("SellingSummary").value);
            component.set("v.SellingComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("SellingFurtherInformationSeekingLossCost").value);
            			
            
            component.set("v.SellingComp.AreasOfComplaint.An_apology__c", document.getElementById("reviewSellingApologyChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("reviewSellingProblemPutChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Comensation__c", document.getElementById("reviewSellingCompensationChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Other__c", document.getElementById("reviewSellingOtherChk").checked);
			component.set("v.SellingComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("reviewSellingOtherText").value);
		}
        
		if (component.get("v.reviewLegalInspectionCompletionDetailedSection") == true) 
        {
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("LegalIdentifyCodeDeveloperBreached").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("LegalBreacheNotAddressedYourConcerns").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("LegalEvidenceUploadSupportsYourCase").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Summary__c", document.getElementById("LegalSummary").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("LegalFurtherInformationSeekingLossCost").value);
            
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.An_apology__c", document.getElementById("reviewLegalInspectionCompletionApologyChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("reviewLegalInspectionCompletionProblemPutChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Comensation__c", document.getElementById("reviewLegalInspectionCompletionCompensationChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other__c", document.getElementById("reviewLegalInspectionCompletionOtherChk").checked);
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("reviewLegalInspectionCompletionOtherText").value);
		}
        
		if (component.get("v.reviewAfterSalesDetailedSection") == true) 
        {
			component.set("v.AfterSalesComp.AreasOfComplaint.HB_Identify_Code_Developer_Breached__c", document.getElementById("AfterSalesIdentifyCodeDeveloperBreached").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("AfterSalesBreacheNotAddressedYourConcerns").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("AfterSalesEvidenceUploadSupportsYourCase").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Summary__c", document.getElementById("AfterSalesSummary").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("AfterSalesFurtherInformationSeekingLossCost").value);
            
            component.set("v.AfterSalesComp.AreasOfComplaint.An_apology__c", document.getElementById("reviewAfterSalesApologyChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("reviewAfterSalesProblemPutChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Comensation__c", document.getElementById("reviewAfterSalesCompensationChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other__c", document.getElementById("reviewAfterSalesOtherChk").checked);
			component.set("v.AfterSalesComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("reviewAfterSalesOtherText").value);
		}
        
        if (component.get("v.reviewOtherDetailedSection") == true) 
        {
			component.set("v.OtherComp.AreasOfComplaint.HB_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("OtherBreacheNotAddressedYourConcerns").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Evidence_Upload_Supports_Your_Case__c", document.getElementById("OtherEvidenceUploadSupportsYourCase").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Summary__c", document.getElementById("OtherSummary").value);
            component.set("v.OtherComp.AreasOfComplaint.HB_Further_Information_Seeking_Loss_Cost__c", document.getElementById("OtherFurtherInformationSeekingLossCost").value);
            
            component.set("v.OtherComp.AreasOfComplaint.An_apology__c", document.getElementById("reviewOtherApologyChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.The_Problem_Put_Right__c", document.getElementById("reviewOtherProblemPutChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Comensation__c", document.getElementById("reviewOtherCompensationChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Other__c", document.getElementById("reviewOtherOtherChk").checked);
			component.set("v.OtherComp.AreasOfComplaint.Other_Remedy__c", document.getElementById("reviewOtherOtherText").value);
		}
        
		if (component.get("v.reviewWarrantyProviderDetailedSection") == true) 
        {
						component.set("v.WarrantyProviderComp.AreasOfComplaint.HB_Summary__c", document.getElementById("WarrantyProviderSummary").value);

		}
        
		
        
        var summariseValue = document.getElementById("reviewSummarise").value;
        component.set("v.case.Homebuyer_Summary_Complaint__c", summariseValue);
	},
    
    
	helperAccordionEventReview: function (component, event, helper, Selling, LegalInspectionCompletion, AfterSales, WarrantyProvider, Other) 
    {
		component.set("v.reviewSellingDetailedSection", Selling);
		component.set("v.reviewLegalInspectionCompletionDetailedSection", LegalInspectionCompletion);
		component.set("v.reviewAfterSalesDetailedSection", AfterSales);
		component.set("v.reviewWarrantyProviderDetailedSection", WarrantyProvider);
		component.set("v.reviewOtherDetailedSection", Other);
        
		//var offsets = document.getElementById("ReviewSection");
		//window.scroll({top: offsets.offsetTop + 500,behavior: 'smooth'});
	},
    
    
	helperSaveReviewComplaint: function (component, event, helper, complaintList, isSubmit) 
    {
		var action = component.get("c.SaveReviewComplaint");
        
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
			caseObj: component.get("v.case"),
			isSubmitCase: isSubmit
		});
        
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
			if (state == "SUCCESS") 
            {
                if(result == 'Success') 
                {
                    if(isSubmit == false)
                    {
                       component.set("v.reviewSaveWarningMsg",true);
                        component.set("v.reviewSubmitWarningMsg",false);
                        component.set("v.isActiveReviewContinueBtn",false);
                    }
                    else
                    {
                        component.set("v.summarySection", false);
                        component.set("v.detailedSection", false);
                        component.set("v.reviewSection", false);
                        component.set("v.thankYouSection",true);
                        component.set("v.isCancel", true);
                        window.scroll({top: 0,behavior: 'smooth'});
                    }
                }
                else
                {
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    
})