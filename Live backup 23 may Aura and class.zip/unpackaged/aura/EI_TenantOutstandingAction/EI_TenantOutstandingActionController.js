({
    doInit: function(component, event, helper) {
        helper.helperInit(component, event, helper);
        helper.getdeposittenantdetails(component, event, helper);
        helper.bankDetails(component, event, helper);
        helper.getError(component, event, helper);
      //  helper.helperGetOutstandingCases(component, event, helper);
    },
    
    aprvChangeOver : function(component, event, helper) {
        var noBankDetails = component.get("v.noBankDetails");
        var paybleamount = component.get("v.morethenzeroamount");
        var isvalid = true;
        if(paybleamount){
        if(noBankDetails)
        {
            isvalid = false;
            component.set("v.noBankDetailsFoundError",true);
        } else {
            component.set("v.noBankDetailsFoundError",false);
        }
        }
        
        var updateCaseId = event.getSource().get("v.value");
        if(isvalid){
        component.set("v.IsDisabled",true);
         component.set("v.showProgressbox", true);
          /*  if(component.get("v.clickbuttononce")){
              component.set("v.clickbuttononce",false);*/
       var action = component.get("c.approveChangeOver");
        action.setParams({
            CaseId : updateCaseId
        });
        action.setCallback(this, function(result){
            var resResult = result.getReturnValue();
            // alert(resResult);
            if(resResult == 'Success') {
             component.set("v.showProgressbox", false);
                // alert('Successfully Approved Change Over')
                helper.helperInit(component, event, helper);
                component.find("navService").navigate({
                    type: "comm__namedPage",
                    attributes: {
                        pageName: "home"
                    },
                    state: {}
                });
            
            } else {
                 component.set("v.IsDisabled",false);
            }
        });
        $A.enqueueAction(action);
        }
      //  }
    },
    
    rjctChangeOver : function(component, event, helper) {
        var updateCaseId = event.getSource().get("v.value");
        component.set("v.IsDisabled",true);
         component.set("v.showProgressbox", true);
        var action = component.get("c.rejectChangeOver");
        action.setParams({
            CaseId : updateCaseId
        });
        action.setCallback(this, function(result) {
            var resResult = result.getReturnValue();
            if(resResult == 'Successfully Updated') {
                 component.set("v.showProgressbox", false);
                //  alert('Successfully Rejected Change Over')
                
                helper.helperInit(component, event, helper);
                //$A.get('e.force:refreshView').fire(); 
                
                var queryString = window.location.search;
                var urlParams = new URLSearchParams(queryString);
                var depositId = urlParams.get('id');
                
                component.find("navService").navigate({
                    type: "comm__namedPage",
                    attributes: {
                        pageName: "depositsummarypage"
                    },
                    state: {
                        id : depositId
                    }
                });
                
            }
        });
        $A.enqueueAction(action); 
    },
    
    addBankDetails:function(component, event, helper){
        component.set("v.showBankDetails",true);
        component.set("v.bankSuccessMessage", false);
        component.set("v.intbankSuccessMessage", false);
        
    },
    cancelBankDetails: function (component, event, helper) {
        component.set("v.showBankDetails", false);
    },
    
    updateBankDetails: function (component, event, helper) {
        helper.updateBankDetails(component, event);
    },
    
    updateInternationalBankDetails: function (component, event, helper) {
        helper.updateInternationalBankDetails(component, event);
    },
    hideBootstrapErrors: function(component, event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "bankSuccessMessage":
                component.set("v.bankSuccessMessage", false);
                break;
            case "bankErrorMessage":
                component.set("v.bankErrorMessage", false);
                break;
             case "nameOnAccountBlankError":
                component.set("v.nameOnAccountBlankError", false);
                break;
             case "accountNumberBlankError":
                component.set("v.accountNumberBlankError", false);
                break;
            case "invalidAccountNumberError":
                component.set("v.invalidAccountNumberError", false);
                break;
            case "sortCodeBlankError":
                component.set("v.sortCodeBlankError", false);
                break;
            case "bankOfAmericaSortCode":
                component.set("v.bankOfAmericaSortCode", false);
                break;
            case "invalidSortCodeError":
                component.set("v.invalidSortCodeError", false);
                break;
            case "intbankSuccess":
                component.set("v.intbankSuccessMessage", false);
                break;
            case "intbankname":
                component.set("v.intbanknameerror", false);
                break;
            case "intbankaccount":
                component.set("v.intbankaccounterror", false);
                break; 
        }
    },
    
})