({
	readFile: function(component, helper, file,fileLable) {
        
        let recordId = component.get("v.recordId");
        const currentDate = new Date();
        const timestamp = currentDate.getTime();
        let FileName = (file.name.replace("#","")).replace("*","");
        
        if (!file) return;
        
        let icon = file.name.toLowerCase();
        const ext = ['.mov','.pdf', '.doc', '.docx', '.txt', '.rtf','.odt', '.xls', '.xlsx', '.ods', '.msg', '.csv', '.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp', '.mp3', '.mp4', '.wmv', '.wav', '.ppt', '.pptx'];
        var fileTypeCheck = ext.some(el => icon.endsWith(el));
        if (!fileTypeCheck) {
           return alert("File type not supported!");
        }
        
        var sizeInMB = (file.size / (1024*1024)).toFixed(2);
        if(sizeInMB > 20){
             return alert("File size is greater than 20mb");
        }
         
        var baseUrl = component.get("v.secureURI");
        
        var baseUrlLength = baseUrl.length;
        
        var indexOfQueryStart = baseUrl.indexOf("?");
        
        var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
        
        var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ FileName+ baseUrl.substring(indexOfQueryStart);
        
        component.set("v.azureLink", baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ FileName+sasKeys);
        component.set("v.fileNameInAzure", recordId+'-'+timestamp +'-'+ FileName);
        
        var reader = new FileReader();
        reader.onload = function() {
            var dataURL = reader.result;
            helper.upload(component, file, dataURL.match(/,(.*)$/)[1],submitUri,fileLable);
        };
        reader.readAsDataURL(file);
    },
    
    upload: function(component, file, base64Data,submitUri,fileLable) {
        var xhr = new XMLHttpRequest();
        
 //line added for ading created_date_external
       let date = JSON.stringify(new Date(file.lastModified));
        let datesplit = date.replace("T",' ');
        let finaldate = datesplit.slice(1, 20);
        
        var endPoint = submitUri;
        
        
        component.set("v.message", "Uploading...");
        
        xhr.open("PUT", endPoint, true);
        xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.onreadystatechange = function () {
            

            if (xhr.readyState === 4 && xhr.status === 201) {   
                
                window.setTimeout(
                    $A.getCallback(function() {
                    })
                    ,1000);
                
                var action = component.get("c.saveFile"); 
              console.log('fileLable@ '+fileLable);
                action.setParams({
                    parentId: component.get("v.recordId"),
                    disputeId :component.get("v.disputeItemId"),
                    fileName: file.name,
                    azureLink: component.get('v.azureLink'),
                    userType: component.get('v.userTypeSelVal'),
                    fileType :(file.name).split('.').pop(),	
                    fileSize :file.size,
                    fileLable :fileLable,
                    evidenceCategories : component.get('v.categorySelVal'),
                    fileNameInAzure : component.get('v.fileNameInAzure'),
                    source : 'Adjudicator',
                    createdate : finaldate
                });
                action.setCallback(this, function(a) {
                    let state = a.getState();
                    let errors = a.getError();
                    
                    if (state == "SUCCESS") {
                        let ReturnValue = a.getReturnValue();
                        //component.set("v.message", "Image uploaded");
                        component.set("v.message", "");
                        component.set("v.fileLableVisible", false); 
                        component.set("v.fileName", "");
                        //component.set("v.fileLable", '');
                        //document.getElementById("filelabel").value='';
                        
                        let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Info',
                            message: 'File Uploaded Successfully',
                            duration:' 5000',
                            key: 'success_alt',
                            type: 'success',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
                        component.set("v.submitBtn", true);
                    }
                });
                $A.enqueueAction(action);
                
            }else{
                //image error code
            }
        };
        xhr.send(file);
    }
    
     
     
})