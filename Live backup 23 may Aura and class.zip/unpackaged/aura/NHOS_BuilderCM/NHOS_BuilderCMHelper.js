({
    fetchCases : function(component, event, helper,archiveComplaint,selectedValue) {
        console.log('lone 3 '+archiveComplaint);
        component.set("v.sortColumnName","");
        component.set("v.descendingOrder",false);
        component.set("v.isComplaintInProgress",false);
        component.set("v.isComplaintInProgressClass","col-md-12");
        component.set("v.archiveComplaint",false);
        component.set("v.archiveComplaintClass","go-back");
        component.set("v.activeComplaintClass","see-all");
        component.set("v.currentPage", 1);
        component.set("v.PaginationList",null);
        component.set("v.cList",null);
        component.set("v.startPage", 0);
        component.set("v.endPage", 0);
        component.set("v.selectedCount", 0);
        component.set("v.totalPagesCount",0);
        
         if(archiveComplaint == true)
            {
                component.set("v.archiveComplaint",true);
                component.set("v.archiveComplaintClass","see-all");
                component.set("v.activeComplaintClass","go-back");
            }
            else
            {
                component.set("v.archiveComplaint",false);
                component.set("v.archiveComplaintClass","go-back");
                component.set("v.activeComplaintClass","see-all");
            }
        
        component.set("v.showSpinner",true);
        console.log('line 33 '+archiveComplaint);
        var action = component.get("c.showCases");
        action.setParams({
            isArchiveComplaint: archiveComplaint,
            selectedVal:selectedValue  
        });
        
        action.setCallback(this, function(a){
            var state = a.getState();
            console.log('state'+state);
            if (state === "SUCCESS") {
                console.log('--->>'+JSON.stringify(a.getReturnValue()));
                if(a.getReturnValue()!=null){
                    component.set('v.csWrapper',a.getReturnValue());
                    console.log('--->>'+JSON.stringify(a.getReturnValue()));
                    //console.log('>>>>>>'+JSON.stringify(a.getReturnValue()));
                    console.log('555'+JSON.stringify(a.getReturnValue().lstInner));
                    var pageSize = component.get("v.pageSize");
                    console.log('pageSize=='+pageSize);
                    var totalRecordsList = a.getReturnValue().lstInner;
                    
                    component.set("v.isSpoofLogin",a.getReturnValue().isSpoofLogin);
                    
                    if(archiveComplaint == true)
                    {
                        component.set("v.isSpoofLogin",true);
                    }
                    
                    console.log('totalRecordsList=='+totalRecordsList);
                    var totalLength = totalRecordsList.length;
                    console.log('totalLength=='+totalLength);
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage", 0);
                    component.set("v.endPage", pageSize - 1);
                    var PaginationLst = [];
                    for (var i = 0; i < pageSize; i++) {
                        if (totalRecordsList.length > i) {
                            PaginationLst.push(a.getReturnValue().lstInner[i]);
                        }
                    }console.log('+++++++++PaginationLst++++11'+PaginationLst);
                    component.set("v.csWrapperpagination", PaginationLst);
                    console.log('++++++PaginationList+++++++22'+component.get("v.csWrapperpagination"));
                    //console.log('++++++PaginationList+++++++22'+component.get("v.PaginationList"));
                    component.set("v.selectedCount", 0);
                    //use Math.ceil() to Round a number upward to its nearest integer
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
                    console.log('++++++PaginationList+++++++33'+component.get("v.PaginationList"));
                }
            }
            component.set("v.showSpinner",false);
        }
                          );
        $A.enqueueAction(action);
    },
    fetchUserMapping : function(component, event, helper,archiveComplaint) {
        component.set("v.showSpinner",true);
        var action = component.get("c.fetchUsrMapping");
        
        action.setCallback(this, function(a){
            var state = a.getState();
            if (state === "SUCCESS") {
                if(a.getReturnValue()!=null){
                    component.set("v.fetchUsrMapping",a.getReturnValue());	
                }
            }
            component.set("v.showSpinner",false);
        })
                
        $A.enqueueAction(action);
    },
    next: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.csWrapperpagination", Paginationlist);
    },
    // navigate to previous pagination record set
    previous: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.csWrapperpagination", Paginationlist);
    },
    
    
    sortBy : function(component, event,helper,dataArg, colName) {

        var descendingOrder = component.get("v.descendingOrder");
        var multiplier = 1;
        if(component.get("v.descendingOrder") == true)
        {
            multiplier = -1;
        }
        
   dataArg.sort(function(res01, res02) {
      var arg01 = res01[colName];//.touppercase();
       var arg02 = res02[colName];
      
    if(arg01 != undefined && arg02 != undefined)
    {
      if(arg01 < arg02) { return -1*multiplier; }
      if(arg01 > arg02) { return 1*multiplier; }
      return 0; 
    }
       else if(arg01 == undefined && arg02 != undefined)
       {
           return -1*multiplier;
       }
       else if(arg01 != undefined && arg02 == undefined)
       {
           return 1*multiplier;
       }
       else
       {
           return 0; 
       }
      
   });
       
       
        component.set("v.csWrapper.lstInner",dataArg);
      
        var sObjectList = component.get("v.csWrapper.lstInner");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
  
        var Paginationlist = [];
        var counter = 0;
        for (var i = start; i <= end; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        component.set("v.csWrapperpagination", Paginationlist);
       
       
        
       /* 
        From page start
var pageSize = component.get("v.pageSize");
                    var totalRecordsList = dataArg;
                
                    var totalLength = totalRecordsList.length;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage", 0);
         			component.set("v.currentPage",1);
                    component.set("v.endPage", pageSize - 1);
                    var PaginationLst = [];
                    for (var i = 0; i < pageSize; i++) {
                        if (component.get("v.csWrapper.lstInner").length > i) {
                            PaginationLst.push(dataArg[i]);
                        }
                    }
                    component.set("v.csWrapperpagination", PaginationLst);
                    component.set("v.selectedCount", 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
        */
        

}
})