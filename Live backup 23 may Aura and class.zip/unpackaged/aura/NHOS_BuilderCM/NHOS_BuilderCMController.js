({
    
    doInit : function(component, event, helper) {
        helper.fetchUserMapping(component, event, helper,false);
        //helper.getPropertyAllocations(component, event, helper);
        //helper.fetchCases(component, event, helper,false);
    },
    summaryComplaint : function(component, event, helper) {
        var encodeId = btoa(event.target.id);
        var encodeURL = $A.get("$Label.c.NHOS_CommunityName")+"/summary-of-complaint?id="+encodeId;
        window.open(encodeURL, '_blank');
    },
    myAccountURLEncode : function(component, event, helper) {
        console.log('line 14 '+component.get("v.accountctId"));
        var encodeId = btoa(component.get("v.accountctId"));
        var encodeURL = $A.get("$Label.c.NHOS_CommunityName")+"/my-account?id="+encodeId;
        window.open(encodeURL,'_self');
    },
     getArchiveComplaint : function(component, event, helper) {
        helper.fetchCases(component, event, helper,true,component.get("v.contacctId"));
    },
    
     getActiveComplaint : function(component, event, helper) {
        helper.fetchCases(component, event, helper,false,component.get("v.contacctId"));
    },
    
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.csWrapper.lstInner");
        console.log('sObjectList=='+sObjectList);
        var end = component.get("v.endPage");
        console.log('end=='+end);
        var start = component.get("v.startPage");
        console.log('start=='+start);
        var pageSize = component.get("v.pageSize");
        console.log('pageSize=='+pageSize);
        //var whichBtn = event.getSource().get("v.name");
        
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    sortCol: function(component, event, helper) {
      var columnName = event.target.name;
        
       // 
       if(component.get("v.sortColumnName") == columnName)
       {
          component.set("v.descendingOrder",!component.get("v.descendingOrder"));
       }
        else
        {
            component.set("v.descendingOrder",false);
        }
         component.set("v.sortColumnName",columnName);
       
    var clst = component.get("v.csWrapper.lstInner");
         
    helper.sortBy(component, event,helper,clst,columnName);
   
},
    
    onSelect: function(component, event, helper) {
        console.log('srk11');
        var selectedValue= component.get("v.selectedValue");
        alert("selectedValue:"+selectedValue);
        //component.set('v.selectedvalue',selectedValue);
        //var assignTo=component.find("selected").get("v.value");
        //alert(assignTo);
        
        //helper.getContactList(component, page, pageSize);
    },
    renderComplaintsList : function(component, event, helper) {
        var selectedValue = component.find("selectedCotactId").get("v.value");
        
        var action = component.get("c.fetchContactID");
        action.setParams({
            selectedVal:selectedValue  
        });
        
        action.setCallback(this, function(a){
            var state = a.getState();
            if (state === "SUCCESS") {
               // console.log('a.getReturnValue() '+a.getReturnValue());
                component.set("v.accountctId",a.getReturnValue());
            }
        })
                
        $A.enqueueAction(action);
       // console.log('line 99 '+component.get("v.contacctId"));
        component.set("v.contacctId",selectedValue);
        helper.fetchCases(component, event, helper,false,selectedValue);
        component.set("v.showComplaints",true);
    }
    
})