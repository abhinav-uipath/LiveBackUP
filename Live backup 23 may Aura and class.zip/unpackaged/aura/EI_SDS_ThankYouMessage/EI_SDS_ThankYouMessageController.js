({
	doInit : function(component, event, helper) {
        
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        
        var tcMsg = urlParams.get('TC');
        
        if(tcMsg == 'AGraise'){
            component.set("v.message1","You have successfully initiated the tenant changeover.");
            component.set("v.message2","We will now contact the outgoing tenant(s) who have 14 working days to respond to the tenant changeover. We will be in contact with you once they have responded.");
        }
        if(tcMsg == 'AGcancel'){
            component.set("v.message1","You have successfully cancelled the tenant changeover request.");
            component.set("v.message2","The request has been cancelled and no changes have been made to the deposit. If another request needs to be made this can be done through tenants or agents accounts.");
        }
        if(tcMsg == 'TTraise'){
            component.set("v.message1","You have successfully initiated the tenant changeover.");
            component.set("v.message2","We will now contact the outgoing tenant(s) who have 14 working days to respond to the tenant changeover. We will be in contact with you once they have responded.");
        }
        if(tcMsg == 'TTAccept'){
            component.set("v.message1","You have successfully completed your response to the changeover request accepting it.");
            component.set("v.message2","The agent/landlord will complete the changeover process. Once completed any payment due will be paid to outgoing tenant(s) within 5 working days and be removed from the deposit record.");
            component.set("v.message3","We will now repay any amounts due to the outgoing tenant(s) within 5 working days and remove them from the deposit record. The remaining tenants details and their funds will move to a new deposit with the details of this issued to them.");
        }
        if(tcMsg == 'TTReject'){
            component.set("v.message1","You have successfully completed your response to the changeover request rejecting it.");
            component.set("v.message2","The request has been cancelled and no changes have been made to the deposit. If another request needs to be made this can be done through tenants or agents accounts.");
           // component.set("v.message3","We will now repay any amounts due to the outgoing tenant(s) within 5 working days and remove them from the deposit record. The remaining tenants details and their funds will move to a new deposit with the details of this issued to them.");
        }
         if(tcMsg == 'TTraised'){
            component.set("v.message1","You have successfully initiated the tenant changeover.");
            component.set("v.message2","We will now contact the agent/landlord who have 14 working days to respond to the tenant changeover. We will be in contact with you once they have responded.");
        }
        if(tcMsg == 'AgentCancleCbyTT'){
            component.set("v.message1","You have successfully cancelled the tenant changeover request.");
            component.set("v.message2","The request has been cancelled and no changes have been made to the deposit. If another request needs to be made this can be done through tenants or agents accounts.");
        }
        if(tcMsg == 'AgentacceptTCbyTT'){
            component.set("v.message1","You have successfully completed your response to the changeover request accepting it.");
            component.set("v.message2","We will now repay any amounts due to the outgoing tenant(s) within 5 working days and remove them from the deposit record. The remaining tenants details and their funds will move to a new deposit with the details of this issued to them. If you have registered new tenant details as part of this process these will be added to the new deposit details.");
        }
        
        
	},
    backToDepositDetail: function(component, event, helper) {
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        var depid = urlParams.get('id');
        var branchId = urlParams.get('branchId');
    
        var stateRtrn;
        if(branchId != null){
            stateRtrn = {
                id : depid,
                branchId : branchId
            };
        }else{
            stateRtrn = {
                id : depid
            };
        }
    
        component.find("navService").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "depositsummarypage"
            },
            state: stateRtrn
        }); 
    }
})