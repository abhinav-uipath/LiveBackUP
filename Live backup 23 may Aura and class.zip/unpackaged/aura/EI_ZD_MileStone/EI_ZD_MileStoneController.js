({
    doInit : function(component, event, helper) {
        // Fetch case details
        var action = component.get("c.getCaseDetails");
        action.setParams({
            recordId: component.get("v.recordId")
        });
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                var caseRec = response.getReturnValue();
                component.set("v.CaseRec", caseRec);
                // Check if conditions are met to change background color
                helper.checkBackgroundColor(component, caseRec);
            }
        });
        $A.enqueueAction(action);
    }
})