({
    checkBackgroundColor : function(component, caseRec) {
        if (caseRec.Days_Remaining__c <= 5 && 
            (caseRec.Status === 'Evidence review complete' || 
             caseRec.Status === 'Adjudication')) {
            document.getElementById("maindiv").style.backgroundColor = "#f54646e8";
        }
    }
})