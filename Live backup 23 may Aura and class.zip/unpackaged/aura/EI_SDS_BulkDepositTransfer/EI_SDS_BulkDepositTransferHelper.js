({
    
    onLoadHelper :function(component, event, helper,branchId){
            var action = component.get('c.getDepositInformation');
        action.setParams({
            branchId: branchId });
        action.setCallback(this, function(response){
            var state = response.getState();
          
            if (state === "SUCCESS"){
               
                var oRes = response.getReturnValue();
                 //  alert(oRes.length);
                if(oRes.length > 0){
                    component.set("v.showDeposits",false);
                    component.set("v.viewtransferred",false);
                    component.set("v.transferdepositonebranch",false);
                    component.set("v.transferthedeposits",false);
                    component.set("v.clickedyes",false);
                    component.set("v.bNoRecordsFound" , false);
                    component.set("v.transfertoaglld",false);
                    component.set("v.selectedrowsdeposit",false);
                    component.set("v.transfermultipledeposit",true);
                    component.set("v.listOfAllDeposits", oRes);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }
                else{
                    component.set("v.bNoRecordsFound" , true);
                }
            }
            else{
                
            }
        });        
        $A.enqueueAction(action);
        
        // open sub tabs
        var regMultDepTab =  component.find("leftSideSubTabs");
        console.log('weird regMultDepTab -> '+regMultDepTab);
        $A.util.addClass(regMultDepTab, "openSubTab");
    },
         /* Search Code*/
    handleSearch : function(component, event, helper,branchId) {    
    
        var action = component.get('c.getDepositInformation');
        action.setParams({
            branchId: branchId });
        action.setCallback(this, function(response){
            var state = response.getState();
         
            if (state === "SUCCESS"){
               
                var oRes = response.getReturnValue();
                 //  alert(oRes.length);
                if(oRes.length > 0){
                   /* component.set("v.showDeposits",false);
                    component.set("v.viewtransferred",false);
                    component.set("v.transferdepositonebranch",false);
                    component.set("v.transferthedeposits",false);
                    component.set("v.clickedyes",false);
                    component.set("v.bNoRecordsFound" , false);
                    component.set("v.transfertoaglld",false);
                    component.set("v.selectedrowsdeposit",false);
                    component.set("v.transfermultipledeposit",true);*/
                    component.set("v.listOfAllDeposits", oRes);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }
            }
            else{
                
            }
        });        
        $A.enqueueAction(action);
        
    }, 
    // navigate to next pagination record set
    next: function(component, event, sObjectList, end, start, pageSize) {
         console.log('@@@ '+sObjectList);
        var Paginationlist = [];
        var counter = 0;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
        console.log('@@ '+ component.get("v.selectedDepositIds"));
    },
    // navigate to previous pagination record set
    previous: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
    },
        
    transferdeposits1 : function(component, event, helper) {
        var emailFieldValue = component.get("v.emailValue");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
        
        if(!$A.util.isEmpty(emailFieldValue)){
            console.log("Helper47");
            component.set("v.emailValidationError", false);
            if(emailFieldValue.match(regExpEmailformat)){
                component.set("v.emailNotValid", false);
            }else{
                component.set("v.emailNotValid", true);
            }
        }
        else{
            console.log("Helper55");
            component.set("v.emailValidationError", true);
        }
        
        
        if ((component.get("v.emailNotValid") ||  component.get("v.emailValidationError") ))
        {
            console.log("Helper63");
            component.set("v.openconfirmbox",false);
        }
        else
        {
            
            var allRecords = component.get("v.listOfAllDeposits");
            var selectedRecords = [];
            for (var i = 0; i < allRecords.length; i++) {
                if (allRecords[i].isChecked) {
                    selectedRecords.push(allRecords[i].objDeposit);
                }
            }
       // component.set('v.selectedContacts', selectedRecords);
            
            console.log("Helper68 && "+JSON.stringify(selectedRecords));
            console.log("Helper42");
             component.set("v.selectedDepositIds",selectedRecords);
            let selectedData = component.get("v.selectedDepositIds");
            let amountToShow =0;
            console.log("selectedData=>"+JSON.stringify(selectedData));
            component.set("v.viewtransferred",false);
            component.set("v.transferdepositonebranch",false);
            component.set("v.transfertoaglld",false);
            component.set("v.transferthedeposits",false);
            component.set("v.bNoRecordsFound" , false);
            component.set("v.clickedyes",false);
            component.set("v.showDeposits",false);
            component.set("v.useremailsection",false);
            
            var pageSize = component.get("v.pageSizeselecteddepst");
            var totalRecordsList = selectedData;
            var totalLength = totalRecordsList.length;
            
             //component.set("v.currentPage", 1);
            component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPageselecteddeposit",0);
            component.set("v.endPageselecteddeposit",pageSize-1);
            var selectedrecords = selectedData.length;
            component.set("v.selecteddeposit",selectedrecords);
            console.log('selectedData.length => ' + selectedData.length);
            var PaginationLst = [];
            for(var i=0; i < pageSize; i++){
                if(selectedData.length > i){
                    PaginationLst.push(selectedData[i]);    
                } 
            }
                      //  amountToShow 
            for(var i=0; i<selectedData.length; i++) {
               var listofamount = [];
               amountToShow =  selectedData[i].Protected_Amount__c + amountToShow ;
               console.log('depositamount-->'+amountToShow);
            }
            

             console.log('amountToShow==>'+amountToShow);

            console.log('PaginationLst=>'+JSON.stringify(PaginationLst.length));
            component.set('v.PaginationListselect', PaginationLst);
            component.set("v.selectedCount" , 0);
            component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));   
            component.set("v.selectedrowsdeposit",true);
            component.set("v.ProceedFurther",true);
            component.set("v.amountToShowOnPopup",parseFloat(amountToShow).toFixed(2));
           // console.log('amountToShow'+amountToShow);
           // console.log("Line139");
            
        }
        
    },
        nextselect: function(component, event, sObjectList, endselect, startselect, pageSizeselect) {
        console.log('nextselect '+sObjectList);
        var Paginationlistselect = [];
        var counter = 0;
        for (var i = endselect + 1; i < endselect + pageSizeselect + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlistselect.push(sObjectList[i]);
                }
            }
            counter++;
        }
        startselect = startselect + counter;
        endselect = endselect + counter;
        console.log('endselectnextselect=>'+endselect);
        console.log('Paginationlistnext=>'+JSON.stringify(Paginationlistselect));
        component.set("v.startPageselecteddeposit", startselect);
        component.set("v.endPageselecteddeposit", endselect);
        component.set("v.PaginationListselect", Paginationlistselect);
    },
    // navigate to previous pagination record set
    previousselect: function(component, event, sObjectList, endselect, startselect, pageSizeselect) {
        var Paginationlistselect = [];
        var counter = 0;
        for (var i = startselect - pageSizeselect; i < startselect; i++) {
            if (i > -1) {
                {
                    Paginationlistselect.push(sObjectList[i]);
                    console.log('Paginationlistselect'+JSON.stringify(Paginationlistselect));
                }
                counter++;
            } else {
                startselect++;
            }
        }        
        startselect = startselect - counter;
        endselect = endselect - counter;
        component.set("v.startPageselecteddeposit", startselect);
        component.set("v.endPageselecteddeposit", endselect);
        component.set("v.PaginationListselect", Paginationlistselect);
    },
      handleDepositSearch : function(component, event, helper,searchKey) { /* Code Modified for TGK-60 */
        
        var getSelectedNumber = component.get("v.selectedCount");  
        var PaginationLst = [];
        var pageSize = component.get("v.pageSize");
        const branchId = component.get("v.branchId");
        var action = component.get('c.searchdeposit');
        action.setParams({
            searchKey: searchKey });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('State==>'+response.getState());
            if (state === "SUCCESS"){
                
                var oRes = response.getReturnValue();
                console.log('searchResults==>'+JSON.stringify(oRes));
                component.set("v.listOfAllDeposits", oRes);
                //  alert(oRes.length);
                if(oRes.length > 0){
                    
                    var totalLength = oRes.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }
                else{
                    component.set('v.PaginationList', []);
                    
                }
            }
            else{
                console.error('Error in handleSearchNew callback: ' + response.getError());
            }
        });        
        $A.enqueueAction(action);
    }, 
        
})