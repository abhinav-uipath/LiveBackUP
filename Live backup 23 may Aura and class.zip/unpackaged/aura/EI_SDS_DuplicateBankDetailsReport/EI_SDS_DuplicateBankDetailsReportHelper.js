({
    showToast : function(title,msg,type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message:msg,
            duration:' 5000',
            key: 'info_alt',
            type: type,
            mode: 'dismissible'
            
        });
        toastEvent.fire();
    },
    convertArrayOfObjectsToCSV : function(component,objectRecords){


        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
       
        // check if "objectRecords" parameter is null, then return from function
        if (objectRecords == null || !objectRecords.length) {
            return null;
         }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n';
 
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        //keys = ['FirstName','LastName','Department','MobilePhone','Id' ];
        
        csvStringResult = 'Instalment,DAN,Type of Contact, Sort Code,Account Number';
        csvStringResult += lineDivider;
        //csvStringResult += keys.join(columnDivider);
        //csvStringResult += lineDivider;
        
        for(var i=0; i < objectRecords.length; i++){   

            csvStringResult += objectRecords[i].Name+','+objectRecords[i].Deposit__r.Name+','+objectRecords[i].User_type__c+','+objectRecords[i].Bank_Sort_Code__c+','+objectRecords[i].Bank_Account_Number__c; 
            csvStringResult += lineDivider;
          } 
       // return the CSV formate String 
        return csvStringResult;        
    },
    
    next: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
    },
    
    previous: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
    }
})