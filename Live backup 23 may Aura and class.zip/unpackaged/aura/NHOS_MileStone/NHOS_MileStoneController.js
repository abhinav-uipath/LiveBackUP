({
	doInit : function(component, event, helper) {
        var action = component.get("c.getCaseDetails");
        action.setParams({
            recordId: component.get("v.recordId")
        });
        action.setCallback(this, function(a) { 
            var state = a.getState();
            var errors = a.getError();
            if (state == "SUCCESS") {
                component.set("v.CaseRec",a.getReturnValue());
                if(a.getReturnValue().Status =='Awaiting Ombudsman draft decision' || a.getReturnValue().Status =='Deadline for comments passed – pending final decision' ||
                  a.getReturnValue().PreviousStatus__c =='Awaiting Ombudsman draft decision' || a.getReturnValue().PreviousStatus__c =='Deadline for comments passed – pending final decision')
                {
                    component.set("v.showMilestone",true);
                    
                }
                else
                {
                    component.set("v.showMilestone",false);
                }
                
                if(a.getReturnValue().Status =='Awaiting Ombudsman draft decision' || a.getReturnValue().PreviousStatus__c =='Awaiting Ombudsman draft decision')
                {
                    if(a.getReturnValue().Total_On_Hold_Days__c <= 5)
                    {  
                        component.set("v.ShowRed",true);
                        //document.getElementById("maindiv").style.backgroundColor = "#f54646e8";
                    } 
                    else if(a.getReturnValue().Total_On_Hold_Days__c > 5)
                    {
                        component.set("v.ShowRed",false);
                        //document.getElementById("maindiv").style.backgroundColor = "#fff";
                    }
                }
                else if(a.getReturnValue().Status =='Deadline for comments passed – pending final decision' || a.getReturnValue().PreviousStatus__c =='Deadline for comments passed – pending final decision')
                {
                    if(a.getReturnValue().Total_On_Hold_Days__c <= 2)
                    {  
                        component.set("v.ShowRed",true);
                        //document.getElementById("maindiv").style.backgroundColor = "#f54646e8";
                    }
                    else if(a.getReturnValue().Total_On_Hold_Days__c > 2)
                    {
                        component.set("v.ShowRed",false);
                        //document.getElementById("maindiv").style.backgroundColor = "#fff";
                    }
                }
                
                
            }
            else {
                
            }
        });
        $A.enqueueAction(action);
        
        
        //window.setInterval(function(){ $A.enqueueAction(component.get("c.doInit")); }, 30000000);
	},
    doneWaiting: function(component, event, helper) {
       setTimeout(function(){  component.set("v.PageSpinner",false); 
                         
                         }, 2000);
    },
})