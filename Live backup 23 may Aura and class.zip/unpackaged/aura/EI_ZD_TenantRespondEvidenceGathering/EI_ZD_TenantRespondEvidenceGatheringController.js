({
    doAgreeToClaim : function(component, event, helper) {
        var action = component.get("c.UpdateClaimDetails");
        action.setParams({
            "claimId": component.get("v.ClaimsDetails[0].Id"),
            "customerType": "TT",
            "amount":component.get("v.ClaimsDetails[0].Total_Agreed_by_AG_LL__c"),
            "scheme":'Zero Deposite',
            "claimExternalId":component.get("v.ClaimsDetails[0].External_ID__c")
        });
        action.setCallback(this, function(a) {
            let state = a.getState();
            let errors = a.getError();
            console.log('error at line 13',errors);
            if (state == "SUCCESS") {
                component.set("v.viewClaim",false);
                component.set("v.ViewContinue",false);
                component.set("v.showClaimBreakdown",false);
                component.set("v.showAdditionalComments",false);
                component.set("v.showReviewsubmission",false);
                component.set("v.showConfirmDialog",false);
                component.set("v.showEvidenceConfirmDialog",false);
                component.set("v.showConfirmDiv",true);
                component.set("v.LeadTenantUrl",a.getReturnValue());
            }
            else
            {
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Info',
                    message: 'Something went wrong please Contact Administrator',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'info',
                    mode: 'dismissible'
                });
                toastEvent.fire();
                
            }
        });
        $A.enqueueAction(action);
        
    },
    agreeClaim : function(component, event, helper) {
        component.set("v.showConfirmDialog",true);
    },
    CloseCancelPopup : function(component, event, helper) { 
        component.set("v.showConfirmDialog",false);
    },
    /**tgk -15 */
    agreeSubmitEvidence : function(component, event, helper) {
        component.set("v.showEvidenceConfirmDialog",true);
    },
    CloseSubmitEvidencePopup : function(component, event, helper) { 
        component.set("v.showEvidenceConfirmDialog",false);
    },
    /**tgk -15 end */
    makePayment: function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": component.get("v.LeadTenantUrl") 
        });
        urlEvent.fire();
        
    },
    showContinue : function(component, event, helper) {        
        component.set("v.ViewContinue",true);
        component.set("v.viewClaim",false);
        //  document.getElementById('scrollView').scrollIntoView(true);
        
    },
    goToClaimBreakdown : function(component, event, helper) {
        
        
        if(!component.get("v.isLead")) 
        {
            component.set("v.ViewContinue",false);
            component.set("v.viewClaim",false);
            component.set("v.showConsentError",false);
            component.set("v.showClaimBreakdown",true);
            let index= component.get("v.currentItem");
            let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
            component.set("v.currentClaimCatagories",Dispute_Item[index].Type__c);
            document.getElementById('scrollView').scrollIntoView(true);
            component.set("v.currentItem",0);
        }
        else{
            var sel = document.getElementById("exampleCheck2").checked; 
            if(sel)
            {
                var action = component.get("c.updateClaimTT");
                action.setParams({
                    "claimId":component.get("v.ClaimsDetails[0].Id"),
                    "consentBox":true
                    
                });
                action.setCallback(this, function(a) {
                    var state = a.getState();
                    var errors = a.getError();
                    if (state == "SUCCESS") {
                        component.set("v.ViewContinue",false);
                        component.set("v.viewClaim",false);
                        component.set("v.showConsentError",false);
                        component.set("v.showClaimBreakdown",true);
                        let index= component.get("v.currentItem");
                        let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
                        component.set("v.currentClaimCatagories",Dispute_Item[index].Type__c);
                        document.getElementById('scrollView').scrollIntoView(true);
                        component.set("v.currentItem",0);
                        
                    }
                    else {
                        alert('An error has occured');
                    }
                });
                $A.enqueueAction(action); 
                
                
            }
            else
            {
                component.set("v.showConsentError",true);
            }
        }
        
    },
    charCountDisplay : function(component, event, helper) {
        /*//let index= component.get("v.currentItem");
        //let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
        let disagreeComment= event.getSource().get("v.value");
    	//let disagreeComment = component.get("v.desptItems.Tenant_Disagree_comment__c");
        console.log('disagreeComment',disagreeComment);
        var disagreeCommentChars = disagreeComment.length;
        component.set("v.disagreeCommentCharsCount", disagreeCommentChars);*/
        /*//addn not working 2
        let currentItem = component.get("v.currentItem");
    let disputeItems = component.get("v.ClaimsDetails[0].Dispute_Items__r");
    let currentDisputeItem = disputeItems[currentItem];
    
    // Set the character count for the current Dispute_Item
    currentDisputeItem.disagreeCommentCharsCount = disagreeCommentChars;
      //addn end  */
/*     let disagreeComment = component.get("v.desptItems.Tenant_Disagree_comment__c");
        //let disagreeComment = event.getSource().get("v.value");
    //let desptItems = event.getSource().get("v.value");
    //console.log('desptItems',desptItems);    
    console.log('disagreeComment', disagreeComment);
    //let disagreeCommentChars = disagreeComment.length;
    //desptItems.disagreeCommentCharsCount = disagreeCommentChars;
    //console.log(desptItems.disagreeCommentCharsCount);
    let index= component.get("v.currentItem");
        console.log('index:',index);
    let disputeItems = component.get("v.ClaimsDetails[0].Dispute_Items__r");
        console.log('disputeItems:',disputeItems);
    let currentDisputeItem = disputeItems[index];
        console.log('currentDisputeItem',currentDisputeItem);
    let disagreeCommentCharsCount = currentDisputeItem.Tenant_Disagree_comment__c ? currentDisputeItem.Tenant_Disagree_comment__c.length : 0;
    component.set("v.disagreeCommentCharsCount", disagreeCommentCharsCount);
    console.log(component.get("v.disagreeCommentCharsCount")); console.log('disagreeComment', disagreeComment);    
    //component.set("v.disagreeCommentCharsCount", desptItems.disagreeCommentCharsCount);             */
    //test
/*var textareaName = event.target.name;
console.log(textareaName);
var textarea = component.find(textareaName);
console.log(textarea);
var value = textareaDC.get("v.value");
        console.log(value);   */    
        //test end 
let textarea = component.find("Cleaning1");
        console.log(textarea);
let value = textarea.get("v.value");
        console.log(value);
let length = value.length;
        console.log(length);

if (length >= 50 && length <= 1000) {
	$A.util.addClass(textarea, "slds-has-success");
	$A.util.removeClass(textarea, "slds-has-error");
} else if (length < 50) {
	$A.util.addClass(textarea, "slds-has-error");
	$A.util.removeClass(textarea, "slds-has-success");
} else {
	$A.util.removeClass(textarea, "slds-has-error slds-has-success");
}

    },
    goToNextItem : function(component, event, helper) {
        console.log('Line 179');
       
        /*var elements = document.getElementsByClassName("file_section");
        var elements1 = document.getElementsByClassName("custom_file");
        if (elements.length > 1 || elements1.length == 0)
        { */ 
        
            let validInput = true;
            let index= component.get("v.currentItem");
        console.log('Line 188');
            let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
            if((Dispute_Item[index].Is_Tenant_Agree__c=='No' && (!Dispute_Item[index].Tenant_Disagree_comment__c)) ||(!Dispute_Item[index].Is_Tenant_Agree__c) )
            {
                validInput= false;
            }
        console.log('Line 193');
            if(Dispute_Item[index].Tenant_Disagree_comment__c && Dispute_Item[index].Is_Tenant_Agree__c=='No' )
            {	
                if(Dispute_Item[index].Tenant_Disagree_comment__c.length < 50)
                {
                   //component.set("v.showDisputeItemError",true);
                    validInput= false;
                    //index++;
                    //component.set("v.currentItem", index);
                }
                
                if(Dispute_Item[index].Tenant_Disagree_comment__c.length > 2000)
                {
                    validInput= false;
                    alert('You have exceeded the character limit of 2000.');
                }
            }
        
        console.log('Line 212');
            if(!Dispute_Item[index].Is_Tenant_Upload_Evidence__c)
            {
                console.log('Line 215');
                validInput= false;
            }
        console.log('Line 217');
            if(!component.get("v.isLead"))
            {
                validInput=true;            
            }
        console.log('Line 222'+component.get("v.handleBtn") );
        if(component.get("v.handleBtn") ==true)
        {
            component.set("v.handleBtn",false);
            console.log('Line 226'+validInput );
            if(Dispute_Item[index].Agreed_by_AGLL__c == Dispute_Item[index].Agreed_by_Tenant__c)
            {
                validInput = true;
            }
            window.setTimeout(
                $A.getCallback(function() {
                    if(validInput)
                    {
                        component.set("v.showDisputeItemError",false);
                        if(!component.get("v.isLead")) {
                            let totalItem = component.get("v.ClaimsDetails[0].Dispute_Items__r").length;
                            console.log('line 227-->'+totalItem);
                             
                            let CurrentItem = component.get("v.currentItem") +1;
                            console.log('line 229-->'+CurrentItem);
                            document.getElementById('scrollView').scrollIntoView(true);
                            component.set("v.agentResponse",true);
                            if(totalItem == CurrentItem)
                            {
                                component.set("v.showAdditionalComments",true);
                                component.set("v.showClaimBreakdown",false);
                                component.set("v.viewClaim",false);
                            }
                            else
                            {
                                component.set("v.currentItem",(component.get("v.currentItem")+1));
                                let index= component.get("v.currentItem");
                                let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
                                component.set("v.currentClaimCatagories",Dispute_Item[index].Type__c);
                            } 
                            
                            
                        }else{
                            
                            var action = component.get("c.updateClaimItemTT");
                            action.setParams({
                                "disputeItemRec":JSON.stringify(component.get("v.ClaimsDetails[0].Dispute_Items__r")),
                                "claimId": component.get("v.ClaimsDetails[0].Id"),
                                "isTenantRespond":component.get("v.ClaimsDetails[0].TT_respond_evidence_gathering__c")
                                
                            });
                            action.setCallback(this, function(a) {
                                var state = a.getState();
                                var errors = a.getError();
                                if (state == "SUCCESS") {
                                    let totalItem = component.get("v.ClaimsDetails[0].Dispute_Items__r").length;
                                    let CurrentItem = component.get("v.currentItem") +1;
                                    document.getElementById('scrollView').scrollIntoView(true);
                                    component.set("v.agentResponse",true);
                                    if(totalItem == CurrentItem)
                                    {
                                        component.set("v.showAdditionalComments",true);
                                        component.set("v.showClaimBreakdown",false);
                                        component.set("v.showDisputeItemError",false);
                                        component.set("v.viewClaim",false);
                                    }
                                    else
                                    {
                                        component.set("v.currentItem",(component.get("v.currentItem")+1));
                                        let index= component.get("v.currentItem");
                                        let Dispute_Item =  component.get("v.ClaimsDetails[0].Dispute_Items__r");
                                        component.set("v.currentClaimCatagories",Dispute_Item[index].Type__c);
                                    } 
                                    
                                }
                                else
                                {
                                    alert('An error has occured');
                                }
                                
                            });
                            $A.enqueueAction(action); 
                        }
                    }
                    else
                    {
                        component.set("v.showDisputeItemError",true);
                    }
                    component.set("v.handleBtn",true);
                }), 2000
            );
        }
       /* }else{
            alert("Please upload file before continue.");
        }*/
    },
    goToTenantResponse: function(component, event, helper) {
        document.getElementById('scrollView').scrollIntoView(true);
        component.set("v.agentResponse",false);        
    },
    goToReviewsubmission : function(component, event, helper) {
        if(!component.get("v.isLead")) {
            component.set("v.showAdditionalComments",false);
            component.set("v.showReviewsubmission",true);
            document.getElementById('scrollView').scrollIntoView(true);
        }else{
            let addComment = component.get("v.ClaimsDetails[0].Additional_comments_TT__c");
            let charlength  = 0;
            if(addComment)
            {
                charlength= addComment.length
            }
            if(charlength < 2000)
            {
                
                var action = component.get("c.updateAdditionalCommentsTT");
                action.setParams({
                    "caseId":component.get("v.ClaimsDetails[0].Id"),
                    "additionalComment":component.get("v.ClaimsDetails[0].Additional_comments_TT__c")
                });
                action.setCallback(this, function(a) {
                    var state = a.getState();
                    var errors = a.getError();
                    console.log('Error-->'+JSON.stringify(errors));
                    if (state == "SUCCESS") {
                        component.set("v.showAdditionalComments",false);
                        component.set("v.showReviewsubmission",true);
                        document.getElementById('scrollView').scrollIntoView(true);
                    }
                    else {
                        alert('An error has occured');
                    }
                });
                $A.enqueueAction(action);
                
            }
            else
            {
                alert('You have exceeded the character limit of 2000.');
            }
            
        }
    },
    goToCliamSummary : function(component, event, helper) {
        //location.reload();
        var divId = event.getSource().getLocalId();
        if(divId=='div0'){
            component.set("v.viewClaim",true);
            component.set("v.ViewContinue",false);
            component.set("v.showClaimBreakdown",false);
            component.set("v.showAdditionalComments",false);
            component.set("v.showReviewsubmission",false);
            component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
        }
        
        if(divId=='div1'){
            component.set("v.ViewContinue",true);
            component.set("v.viewClaim",false);
            component.set("v.showClaimBreakdown",false);
            component.set("v.showAdditionalComments",false);
            component.set("v.showReviewsubmission",false);
            component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
        }
        
        if(divId=='div2'){
            let agentresponce = component.get("v.agentResponse");
            if(component.get("v.currentItem")==0 && agentresponce){
                component.set("v.viewClaim",false);
                component.set("v.ViewContinue",true);
                component.set("v.showClaimBreakdown",false);
                component.set("v.showAdditionalComments",false);
                component.set("v.showReviewsubmission",false);
                component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
            }else{
                if(agentresponce)
                {
                    component.set("v.agentResponse",false);
                    component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
                    component.set("v.currentItem",component.get("v.currentItem") - 1);
                }
                else
                {
                    component.set("v.agentResponse",true);
                    component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
                }
                
                
            }
        }
        
        if(divId=='div3'){
            component.set("v.showClaimBreakdown",true);
            component.set("v.viewClaim",false);
            component.set("v.ViewContinue",false);
            component.set("v.showAdditionalComments",false);
            component.set("v.showReviewsubmission",false);
            component.set("v.agentResponse",false);
            component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
        }
        
        if(divId=='div4'){
            component.set("v.showAdditionalComments",true);
            component.set("v.viewClaim",false);
            component.set("v.ViewContinue",false);
            component.set("v.showClaimBreakdown",false);
            component.set("v.showReviewsubmission",false);
            component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
        }
        if(divId=='div5'){
            component.set("v.viewClaim",true);
            component.set("v.ViewContinue",false);
            component.set("v.showClaimBreakdown",false);
            component.set("v.showAdditionalComments",false);
            component.set("v.showReviewsubmission",false);
            component.set("v.showDisputeItemError",false);
            component.set("v.showConsentError",false);
        }
    },
    clickYes : function(component, event, helper) {
        let selectRecordId = event.target.id;
        let selectBtnName = event.target.name;
        let disputeItemRec  = component.get("v.ClaimsDetails[0].Dispute_Items__r");
        
        for(let i=0; i< disputeItemRec.length;i++)
        {
            if(selectRecordId ==disputeItemRec[i].Id)
            {
                if(selectBtnName =='IsTenantAgree')
                {
                    disputeItemRec[i].Is_Tenant_Agree__c= 'Yes';
                }
                else if (selectBtnName =='IsTenantUploadEvidence')
                {
                    disputeItemRec[i].Is_Tenant_Upload_Evidence__c= 'Yes';
                }
                
            }
        }
        component.set("v.ClaimsDetails[0].Dispute_Items__r",disputeItemRec);
        
        
    },
    clickNo : function(component, event, helper) { 
        let disputeItemRec  = component.get("v.ClaimsDetails[0].Dispute_Items__r");
        let selectRecordId = event.target.id;
        let selectBtnName = event.target.name;
        for(let i=0; i< disputeItemRec.length;i++)
        {
            if(selectRecordId ==disputeItemRec[i].Id)
            {
                if(selectBtnName =='IsTenantAgree')
                {
                    disputeItemRec[i].Is_Tenant_Agree__c= 'No';
                }
                else if (selectBtnName =='IsTenantUploadEvidence')
                {
                    disputeItemRec[i].Is_Tenant_Upload_Evidence__c= 'No';
                }
                
            }
        }
        component.set("v.ClaimsDetails[0].Dispute_Items__r",disputeItemRec);
        
    },
    goToHomePage :function(component, event, helper)
    {
        location.reload();
    },
    /**tgk -15 */
    finalSubmitEvidence: function(component, event, helper) {
        var action = component.get("c.UpdateCaseStatus");
        action.setParams({
            "claimId": component.get("v.ClaimsDetails[0].Id"),
            "customerType": "TT"
        });
        action.setCallback(this, function(a) {
            let state = a.getState();
            let errors = a.getError();
            if (state === "SUCCESS") {
                component.set("v.showEvidenceConfirmDialog", false);
                component.set("v.isEditable",false);
                component.set("v.showAdditionalComments",false);
                component.set("v.showReviewsubmission",true);
                document.getElementById('scrollView').scrollIntoView(true);               
            } else {
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Info',
                    message: 'Something went wrong. Please contact the Administrator.',
                    duration: '5000',
                    key: 'info_alt',
                    type: 'info',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    /**tgk -15 end*/
})