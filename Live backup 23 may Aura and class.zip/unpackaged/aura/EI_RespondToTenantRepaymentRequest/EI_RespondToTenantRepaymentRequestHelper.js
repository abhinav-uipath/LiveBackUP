({
    logoutHelper: function(component) {
        var name = component.get("v.currentUser.TestName__c");
        /*	let x = document.cookie;
        console.log('cook ' + x);
        document.cookie = "UName="+name+" ; Expires = 1980-02-02T18:06:21.466Z;path=/;";
		let x2 = document.cookie;
        console.log('cook2 ' + x2);*/
        var cookie ={
            setCookie: function (strName, strValue,cntdays) {
                var days = cntdays != undefined && cntdays !== "" ? cntdays : 60,
                    date = new Date(),
                    domain = document.location.hostname;
                date.setTime(date.getTime() - ( 24 * 60 * 60 * 1000));
                var expires = date.toUTCString();
                // handle secure vs regular http differently for cookie purposes
                if (location.protocol == 'http:') {
                    document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/";
                } else {
                    document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
                }
            }
        }
        cookie.setCookie("UName",name,1);
        let currentURL = window.location.origin;
        let redirectURL = $A.get("$Label.c.Lightning_CommunityLogout_URL")+"secur/logout.jsp?retUrl="+$A.get("$Label.c.Lightning_Component_URL");
        window.location.replace(redirectURL);
        
    },
    
    doSubmitHelper : function(component, repaymentRec) {
        
         if(repaymentRec.Tenant_Cleaning__c=="" || repaymentRec.Tenant_Cleaning__c==undefined){           
            repaymentRec.Tenant_Cleaning__c = 0;         
        }
        if(repaymentRec.Tenant_Dmg_to_Property__c=="" || repaymentRec.Tenant_Dmg_to_Property__c==undefined){           
            repaymentRec.Tenant_Dmg_to_Property__c = 0;         
        }
        if(repaymentRec.Tenant_Gardening__c=="" || repaymentRec.Tenant_Gardening__c==undefined){           
            repaymentRec.Tenant_Gardening__c = 0;         
        }
        if(repaymentRec.Tenant_Rent_Arrears__c=="" || repaymentRec.Tenant_Rent_Arrears__c==undefined){           
            repaymentRec.Tenant_Rent_Arrears__c = 0;         
        }
        if(repaymentRec.Tenant_Redecoration__c=="" || repaymentRec.Tenant_Redecoration__c==undefined){           
            repaymentRec.Tenant_Redecoration__c = 0;         
        }
        if(repaymentRec.Tenant_Other__c=="" || repaymentRec.Tenant_Other__c==undefined){           
            repaymentRec.Tenant_Other__c = 0;         
        }
        var tenantrequestedAmount = parseFloat(repaymentRec.Tenant_Cleaning__c) + parseFloat(repaymentRec.Tenant_Dmg_to_Property__c) +
            parseFloat(repaymentRec.Tenant_Gardening__c) + parseFloat(repaymentRec.Tenant_Rent_Arrears__c) +
            parseFloat(repaymentRec.Tenant_Redecoration__c) + parseFloat(repaymentRec.Tenant_Other__c);
      	// console.log("requestedAmount",tenantrequestedAmount);
        component.set("v.tenantrequestedAmount", tenantrequestedAmount);
    },
    
    checkBankDetails : function(component, event, helper) {
        var depositRecId = component.get("v.depositId");
        let action = component.get("c.fetchBankDetails");
        action.setParams({depositId : depositRecId});
        action.setCallback(this, function (response) {
            var state = response.getState();
            console.log("state-->>" + state);
            if (state === "SUCCESS") {

                var result = response.getReturnValue();
                //console.log("result 9 bank details - :", JSON.stringify(result));
                
                if (result[0].Branch__c != null && result[0].Branch__c != '') {
                    if (result[0].Branch__r.ValidInternationBankDetails__c == true) {
                        component.set("v.isBankDetailsPresent", true);
                        component.set("v.bankAccountName",result[0].Branch__r.Bank_Account_Holder_Name__c);
                        component.set("v.accountNumber",result[0].Branch__r.Account_Number__c);
                        component.set("v.sortCode",result[0].Branch__r.Sort_Code__c);
                        component.set("v.bankName",result[0].Branch__r.Bank_Name__c);
                    }
                }
                else if(result[0].Customer__r.ValidInternationBankDetails__c == true){
                    component.set("v.isBankDetailsPresent", true);
                    component.set("v.bankDetails",result);
                    component.set("v.bankAccountName",result[0].Customer__r.Bank_Account_Holder_Name__c);
                    component.set("v.accountNumber",result[0].Customer__r.Account_Number__c);
                    component.set("v.sortCode",result[0].Customer__r.Sort_Code__c);
                    component.set("v.bankName",result[0].Customer__r.Bank_Name__c);
                }
                    else{
                        component.set("v.noBankDetails",true);
                        component.set("v.isBankDetailsPresent", false);
                    }
                
            } else if (state === "ERROR") {
                var error = response.getError();
                console.log(error);
            }
        });
        $A.enqueueAction(action);
    },
    getDepositBankDetails :function(component) {	
        const queryString = window.location.search;	
        const urlParams = new URLSearchParams(queryString);	
        const depositIdList = atob(urlParams.get('depositId'));	
        const myArray = depositIdList.split("&");	
        let myName;	
        var depositId;	
        if(myArray.length >2){	
            myName = myArray[0]+'&'+myArray[1];	
            depositId = myArray[2];	
        }else{	
            myName = myArray[0];	
            depositId = myArray[1];	
        }	
        var action = component.get('c.getDepositInformation');	
        action.setParams({depositRecordId : depositId});	
        action.setCallback(this, function(response){	
            var allValues = response.getReturnValue();	
            if(allValues!=null){	
                if(allValues.Bank_Account_Holder_Name__c){	
                    component.set("v.isBankDetailsPresent", true);	
                    component.set("v.bankAccountName",allValues.Bank_Account_Holder_Name__c);	
                }	
                if(allValues.Bank_Name__c != null){	
                    component.set("v.bankName",allValues.Bank_Name__c);	
                }	
                if(allValues.Account_Number__c != null){	
                    component.set("v.accountNumber",allValues.Account_Number__c);	
                }	
                if(allValues.Sort_Code__c != null){	
                    component.set("v.sortCode",allValues.Sort_Code__c);	
                }	
            }	
        });        	
        $A.enqueueAction(action);	
    },
    
    updateBankDetails : function(component, event) {
        component.set("v.disabledBtn",true); //added by abhinav on 11/09/23
        component.set('v.bankSuccessMessage',false);
        component.set('v.bankErrorMessage',false);
        component.set('v.nameOnAccountBlankError',false);
        component.set('v.accountNumberBlankError',false);
        component.set('v.invalidAccountNumberError',false);
        component.set('v.sortCodeBlankError',false);
        component.set('v.invalidSortCodeError',false);
        component.set('v.nameOnAccountSpecialCharError',false);
        component.set('v.bankOfAmericaSortCode',false);
        
        var isValid = true;
        var toastEvent = $A.get("e.force:showToast");
        
        var bankAccountName = component.find("bankAccountName").get("v.value");
        var accountNumber = component.find("accountNumber").get("v.value");
        var sortCode = component.find("sortCode").get("v.value");
        var bankName = component.find("bankName").get("v.value");
        var specials = new RegExp('[-!$%^&*()_+|~=`{}\[\]:";\'<>?,.\/]');
        
        if(bankAccountName == undefined || bankAccountName == "" || bankAccountName==null){
            component.set('v.nameOnAccountBlankError',true);
            isValid = false;
        }
        if(sortCode == undefined || sortCode == "" || sortCode==null){
            component.set('v.sortCodeBlankError',true);
            isValid = false;
        }
      	if(accountNumber == undefined || accountNumber == "" || accountNumber==null){
          component.set('v.accountNumberBlankError',true);
          isValid = false;
       	}
        if(specials.test(bankAccountName)){
            component.set("v.nameOnAccountSpecialCharError", true);
            isValid = false;
        }
        if(sortCode == '234079') {
            component.set("v.bankOfAmericaSortCode", true);
            isValid = false;
        }
        
        if(isValid) {
            console.log('isValid'+isValid);
            
            const queryString = window.location.search;	
                const urlParams = new URLSearchParams(queryString);	
                const depositIdList = atob(urlParams.get('depositId'));	
                const myArray = depositIdList.split("&");	
                let myName;	
                var depositId;	
                if(myArray.length >2){	
                    myName = myArray[0]+'&'+myArray[1];	
                    depositId = myArray[2];	
                }else{	
                    myName = myArray[0];	
                    depositId = myArray[1];	
                }	
            
            var saveFuturePaymentsCheckbox =  component.get("v.repaymentCheckbox");	
            //alert(saveFuturePaymentsCheckbox);	
            var action;	
            if(saveFuturePaymentsCheckbox){	
                //alert('In if');	
                action = component.get("c.updateBankDetailsOfTenant");	
                action.setParams({accountNumber : accountNumber ,	
                              sortCode:sortCode,	
                              bankAccountName : bankAccountName,	
                              bankName : bankName,
                              depositId :depositId,
                              userType : 'Agent/landlord'});	
            }	
            else{	
                //alert('In else');	
                
                action = component.get("c.updateBankDetailsOfTenantIntoDeposit");	
                action.setParams({accountNumber : accountNumber ,	
                                  sortCode:sortCode,	
                                  bankAccountName : bankAccountName,	
                                  bankName : bankName,	
                                  depositId : depositId});	
            }
            /*var action = component.get("c.updateBankDetailsOfTenant");
            action.setParams({accountNumber : accountNumber ,
                              sortCode:sortCode,
                              bankAccountName : bankAccountName,
                              bankName : bankName});*/
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log('state ' + state);
                if(state == 'SUCCESS') {
                    component.set("v.isBankDetailsPresent",true);
                    component.set("v.noBankDetailsFoundError",false);
                    component.set("v.disableBankEdit", true);
                    component.set("v.disableInterBankEdit", true);
                    var messageValue = response.getReturnValue();
                    console.log('messageValue111111111 ' + messageValue);
                    if(messageValue=='UnknownSortCode') {
                        component.set('v.invalidSortCodeError',true);	
                        component.set("v.disabledBtn",false);
                    } else if(messageValue=='InvalidAccountNumber') {
                         component.set('v.invalidAccountNumberError',true);	
                        component.set("v.disabledBtn",false);
                    } else {
                        component.set('v.bankName',messageValue);
                        
                        component.set("v.bankSuccessMessage",true);
                        component.set("v.fieldBankDetailsEdit", true);
        				component.set("v.toggleBankDetails", true);
                        component.set("v.disabledBtn",false);
                        
                        setTimeout(function() {
                            component.set("v.showEditBankDetailsSect",false);
                        }, 1000);
                    }
                }
                else if(state =='ERROR') {
                    
                    console.log('In Error');
                    var errors = action.getError();
                    console.log('errors---'+JSON.stringify(errors));
                    component.set("v.disabledBtn",false);
                    
                }
                else{
                    toastEvent.setParams({
                        "message": messageValue                    
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
    },
    
    updateInternationalBankDetails : function(component, event) {
        component.set("v.disabledBtn",true); //added by abhinav on 11/09/23
        component.set('v.intbankSuccessMessage',false);
        
        var isValid = true;
        var toastEvent = $A.get("e.force:showToast");
        
        var bankIntName = component.find("bankIntName").get("v.value");
        var bankIdentificationCode = component.find("bankIdentificationCode").get("v.value");
        var bankSwiftCode = component.find("bankSwiftCode").get("v.value");
        var IBAN = component.find("IBAN").get("v.value");
        var bankIntAccountName = component.find("bankIntAccountName").get("v.value");
        var specials = new RegExp('[-!$%^&*()_+|~=`{}\[\]:";\'<>?,.\/]');
       	//var bankIntaddress = component.find("bankIntaddress").get("v.value");

        if(bankIntName == undefined || bankIntName == "" || bankIntName==null) {
            isValid = false;
            component.set("v.intbanknameerror", true);
        }
        else {
           component.set("v.intbanknameerror", false); 
        }

        if(bankIntAccountName == undefined || bankIntAccountName == "" || bankIntAccountName==null){
            isValid = false;
            component.set("v.intbankaccounterror", true);
        }
        else{
          component.set("v.intbankaccounterror", false);  
        }
        
        if(specials.test(bankIntAccountName)){
            component.set("v.intNameOnAccountSpecialCharError", true);
            isValid = false;
        }
        else{
          component.set("v.intNameOnAccountSpecialCharError", false);  
        }
        
        if(isValid){
            var action = component.get("c.updateIntBankDetailsOfTenant");
            action.setParams({
                bankIntName : bankIntName ,
                // bankIntaddress:bankIntaddress,
                bankIntAccountName : bankIntAccountName,
                bankIdentificationCode : component.find("bankIdentificationCode").get("v.value"),
                bankSwiftCode : component.find("bankSwiftCode").get("v.value"),
                IBAN : component.find("IBAN").get("v.value"),
                accountId : component.get("v.tenant.AccountId__c"),
                contactId : component.get("v.tenant.Id")
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                var messageValue = response.getReturnValue();
                if(state == 'SUCCESS'){
                    if(messageValue=='successMessage'){
                        /*  toastEvent.setParams({
                            "type" : "success",
                            "message": "Bank account updated successfully."                  
                        });                        
                        toastEvent.fire(); */
                        //  component.set("v.ShowSubmit", false);
                        // component.set("v.fieldInternationalBankDetailsEdit", true);
                        //component.set("v.toggleInternationalBankDetails", true);
                        //  $A.get('e.force:refreshView').fire();
                        component.set("v.intbankSuccessMessage", true);
                        component.set("v.isBankDetailsPresent",true);
                        component.set("v.noBankDetailsFoundError",false);
                        component.set("v.disableBankEdit", true);
                        component.set("v.disableInterBankEdit", true);
                        component.set("v.intbankSuccessMessage", true);
                        component.set("v.disabledBtn",false);
                        
                        setTimeout(function() {
                            component.set("v.showEditBankDetailsSect",false);
                        }, 1000);
                    }
                    else {
                        toastEvent.setParams({
                            "type" : "error",
                            "message": messageValue                  
                        });
                        isValid = false;
                        toastEvent.fire();    
                    }
                }
                else{
                    toastEvent.setParams({
                        "message": messageValue                    
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
    },
    
})