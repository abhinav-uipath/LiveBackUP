({
    enableButton: function (component, event, helper){ 
        //alert('123');
      
    },
    onInit: function (component, event, helper){ 
        
        document.addEventListener("grecaptchaVerified", function(e) {
            component.set('v.recaptchaResponse', e.detail.response);
             var compEvent = component.getEvent("compEvent"); // 
  			  compEvent.fire();
          
            let myButton = component.find("myButton");
            myButton.set('v.disabled', false);
        });
        
        document.addEventListener("i", function() {
               
            let myButton = component.find("myButton");
            myButton.set('v.disabled', true);
        }); 
    },
    onRender: function (component, event, helper){ 
        document.dispatchEvent(new CustomEvent("grecaptchaRender", { "detail" : { element: 'nhosrecaptchaCheckbox'} }));
    },
    doSubmit: function (component, event, helper){
        var action = component.get("c.insertRecord");
        action.setParams({
            record: null, //TODO: map UI fields to sobject
            recaptchaResponse: component.get('v.recaptchaResponse')
        });
        
        action.setCallback(this, function(response) {
            document.dispatchEvent(new Event("grecaptchaReset"));
            let myButton = component.find("myButton");
            myButton.set('v.disabled', true);
             
            var state = response.getState();
          
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                console.log('capcha res '+result);
            } else {
                var errors = response.getError();
                if (errors) {
                    console.log(errors[0]);
                }
            }
        });
        
        $A.enqueueAction(action);
    }
})