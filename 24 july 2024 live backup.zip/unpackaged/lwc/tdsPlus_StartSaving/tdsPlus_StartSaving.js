import { LightningElement ,api} from 'lwc';

/**
 * @slot Content-Region
 *  @slot Content-Region2
*/
export default class TdsPlus_StartSaving extends LightningElement {
    //  Tile 1 property
    @api tile1heading;
    @api descriptiontile1; 
    @api loginbuttontile1;
    @api buttonlinktile1;
    @api loginbutton2tile1
    @api buttonlink2tile1
    
     //  Tile 2 property
    @api tile2heading;
    @api descriptiontile2;
    @api description2tile2; 
    @api loginbuttontile2;
    @api buttonlinktile2;
    @api loginbutton2tile2
    @api button2linktile2
    
    @api bgColor;
    @api main_heading;
   
    get isButtontextNotNull1(){
        if(this.loginbuttontile1==null || this.loginbuttontile1==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isButton2textNotNull2(){
        if(this.loginbutton2tile1==null || this.loginbutton2tile1==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isButtontextNotNull2(){
        if(this.loginbuttontile2==null || this.loginbuttontile2==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isButtontile2textNotNull2(){
        if(this.loginbutton2tile2==null || this.loginbutton2tile2==''){
            return false;
        }
        else{
            return true;
        }
    }


    get tileStyle() {
        // Dynamically compute the background color style
        return `background-color: ${this.bgColor} !important;`;
    }
}