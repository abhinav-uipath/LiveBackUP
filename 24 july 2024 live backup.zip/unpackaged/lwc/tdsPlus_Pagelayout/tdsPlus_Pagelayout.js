import { LightningElement } from 'lwc';
/**
 * @slot header1 This is the header slot
 * @slot footer This is the footer slot
 * @slot default This is the default slot
 */
export default class TdsPlus_Pagelayout extends LightningElement {}