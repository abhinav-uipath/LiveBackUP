import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CloseActionScreenEvent } from 'lightning/actions';

import addCaseParticipantRecord from '@salesforce/apex/TRS_AddCaseParticipantsBackUp.addCaseParticipantRecord';

const FIELDS = [
    'Case.Other_party_first_name__c',
    'Case.Other_party_last_name__c',
    'Case.Other_party_email_address__c',
    'Case.TRS_Complaint_raised_by__c'
];


export default class TRS_AddCaseParticipants extends LightningElement {
    @api recordId;
  
    firstName = '';
    lastName = '';
    email = '';
    complaintRaisedBy = '';
    showActivateUserCheckbox = false;
    activateUser = false;
    isloading = false;

   

  /*  connectedCallback() {
        
        if(this.complaintRaisedBy == 'Tenant'){
            this.showActivateUserCheckbox = true;
        }
        console.log('In connectedCallback showActivateUserCheckbox:'+this.showActivateUserCheckbox);
       
    }*/

    
    handleCheckboxChange(event) {
        console.log('Checkbox function called');
        this.activateUser = event.target.checked;
        console.log('activateUser:'+this.activateUser);
    }



    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    wiredRecord({ data, error }) {
        if (data) {
            console.log('data : '+JSON.stringify(data));
            this.firstName = data.fields.Other_party_first_name__c.value;
            this.lastName = data.fields.Other_party_last_name__c.value;
            this.email = data.fields.Other_party_email_address__c.value;
            this.complaintRaisedBy = data.fields.TRS_Complaint_raised_by__c.value;
            
            //this.isComplaintRaisedBy = this.complaintRaisedBy == 'Landlord';
            if(this.complaintRaisedBy == 'Tenant'){
                this.showActivateUserCheckbox = true;
            }

        } else if (error) {
            console.error('Error retrieving record data', JSON.stringify(error));
        }
    }

    handleInputChange(event) {
        const { name, value } = event.target;

        if (name == 'FirstName') {
            this.firstName = value;
        } else if (name == 'LastName') {
            this.lastName = value;
        } else if (name == 'Email') {
            this.email = value;
        }
    }

    async handleAddCaseParticipant() {
        
        try {
            this.showSpinner(true);

            let isValid = false;

            isValid = this.checkValidity();

            if (isValid) {
                const result = await addCaseParticipantRecord({ caseId: this.recordId, firstName: this.firstName, lastName: this.lastName, email: this.email, complaintRaisedBy: this.complaintRaisedBy, activateUser: this.activateUser});
                console.log('result : '+result);
                if (result == 'Case Participant already exists with same name or email address') {
                    this.showToastMessage('Warning', result, 'warning');
                    this.showSpinner(false);
                } else if (result == 'Failed to add Case Participant') {
                    this.showToastMessage('Error', result, 'error');
                    this.showSpinner(false);
                } else if (result == 'Case Participant Added Successfully') {
                    this.showToastMessage('Success', result, 'success');
                    this.showSpinner(false);
                    this.closeQuickAction();
                } else {
                    this.showToastMessage('Error', result, 'error');
                    this.showSpinner(false)
                }
                
            }

            this.showSpinner(false);
        } catch (error) {
            console.log('error in handleAddCaseParticipant : ' + error);
            this.showSpinner(false);
        }
        
    }

    checkValidity() {
        let isValid = true;

        if (this.firstName == null || this.firstName == "") {
            this.showHideErrorMessage('FirstName', 'Please Enter the First Name');
            isValid = false;
        } else {
            this.showHideErrorMessage('FirstName', '');
        }
        if (this.lastName == null || this.lastName == "") {
            this.showHideErrorMessage('LastName', 'Please Enter the Last Name');
            isValid = false;
        } else {
            this.showHideErrorMessage('LastName', '');
        }
        if (this.email == null || this.email == '') {
            
        } else {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(this.email)) {
                this.showHideErrorMessage('Email', 'Please Enter the Valid Email Address');
                isValid = false;
            } else {
                this.showHideErrorMessage('Email', '');
            }
        }

        return isValid;
    }

    showHideErrorMessage(classNames, errorMessage) {
        let className = '.' + classNames;
        let inputElement = this.template.querySelector(className);
        inputElement.setCustomValidity(errorMessage);
        inputElement.reportValidity();
    }

    showToastMessage(title, message, variant) {
        const successEvent = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });

        this.dispatchEvent(successEvent);
    }

    closeQuickAction() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    showSpinner(showSpinner) {
        if(showSpinner) {
            this.isloading = true;
        } else {
            this.isloading = false;
        }
    }

}