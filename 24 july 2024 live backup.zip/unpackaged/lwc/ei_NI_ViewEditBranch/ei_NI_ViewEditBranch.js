import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import jQuery from '@salesforce/resourceUrl/JQuery';

import fetchBranchRecs from '@salesforce/apex/ei_NI_BranchManagement.fetchSelectedBranch';
import getPhoneCodes from '@salesforce/apex/ei_NI_BranchManagement.getPhoneCodes';
import updateBranch from '@salesforce/apex/ei_NI_BranchManagement.updateBranch';
import fetchBranchusers from '@salesforce/apex/ei_NI_BranchManagement.getBranchUsers';

export default class Ei_NI_ViewEditBranch extends NavigationMixin(LightningElement) {
    back_icon = NI_THEME + '/assets/img/ew-arrow-dropleft.png';
    view_edit = NI_THEME + '/assets/img/view_icon.png';

    @track hideField = true;
    @track isEdit = false;
    recordId;
    @track branchRec = {};
    @track brachUsers = [];
    brachUsersLength = '';
    usersLength = false;
    isAddressNotNI = false;
    showSuccessScreen = false;
    showErrorScreen = false;
    mobileLengthOrPatternError = false;
    addressError = false;
    PageSpinner = false;

    @track currentPageReference;
    @track phoneCodeList = [];
    @track postalCodesList = [];
    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        this.currentPageReference = currentPageReference;
        this.recordId = window.atob(this.currentPageReference?.state?.c__recId);
        console.log('RecordId:::', this.recordId);
    }

    connectedCallback() {
        this.PageSpinner = true;
        // loadScript(this, jQuery).then(() => {
        //     console.log('View/Edit Script loaded');
        // }).catch(error => {
        //     console.log('Failed to load the JQuery : ' + error);
        // });
        Promise.all([
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')
        ]).then(() => {

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });

        fetchBranchRecs({ branchId: this.recordId }).then(result => {
            console.log('View/Edit Result::', JSON.stringify(result));
            this.branchRec = result;

            fetchBranchusers({ branchId: this.recordId }).then(result => {
                console.log('Branch Users:::', JSON.stringify(result));
                this.brachUsers = result;
                this.brachUsersLength = result.length;
                if(this.brachUsersLength > 0){
                    this.usersLength = true;
                }
                console.log('line 70'+this.brachUsersLength);

                getPhoneCodes().then(result => {
                    var selected = false;
                    let countryCodes = [];
                    result.phoneCodes.forEach(item => {
                        // console.log('Selected Phone Code:::' + item + 'Phone Code:::' + this.branchRec.Phone_Code__c);
                        if (item == this.branchRec.Phone_Code__c) {
                            selected = true;
                        } else {
                            selected = false;
                        }
                        countryCodes.push({
                            label: item,
                            value: selected
                        })
                    });
                    this.phoneCodeList = countryCodes;
                    this.postalCodesList = result.postalCodes;
                    this.PageSpinner = false;
                }).catch(error => {
                    this.PageSpinner = false;
                })
            }).catch(error => {
                console.log('BranchUsers Error::', JSON.stringify(error));
                this.PageSpinner = false;
            })
        }).catch(error => {
            console.log('View/Edit getRecords Error:::', JSON.stringify(error));
            this.PageSpinner = false;
        })
        this.PageSpinner = false;
    }

    editBranch(event) {
        event.preventDefault();
        this.hideField = false;
        this.isEdit = true;
    }

    handleCancel() {
        this.hideField = true;
        this.isEdit = false;
    }

    backToBranch() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'home'
            }
        });
    }

    addressFieldChangeHandler(event) {
        console.log('Searched Address::', JSON.stringify(event.detail));
        let retunredAddress = event.detail;

        if (retunredAddress.addressType == 'Branch address') {
            if (retunredAddress.fieldName.includes("TownCity")) {
                this.branchRec.Town_City__c = retunredAddress.value;

            } else if (retunredAddress.fieldName.includes("County")) {
                this.branchRec.County__c = retunredAddress.value;

            } else if (retunredAddress.fieldName.includes("Postcode")) {
                this.branchRec.Postcode__c = retunredAddress.value;
                var isPostalCodeNI = false;
                this.postalCodesList.forEach(item => {
                    if (retunredAddress.value.includes(item.Label)) {
                        isPostalCodeNI = true;
                    }
                });
                this.isAddressNotNI = !isPostalCodeNI;
            } else if (retunredAddress.fieldName.includes("Country")) {
                this.branchRec.Country__c = retunredAddress.value;

            } else if (retunredAddress.fieldName.includes("Street")) {
                this.branchRec.Address__c = retunredAddress.value;
            }
        }
        console.log('Address Map::', JSON.stringify(this.branchRec));
    }
    selectingAddressHandler(event) {
        let retunredAddress = event.detail;
        console.log('Retunred Address::', JSON.stringify(retunredAddress));

        if (retunredAddress.addressType == 'Branch address') {
            var address = retunredAddress.addressObj;
            this.branchRec.Address__c = address.Street;
            this.branchRec.Town_City__c = address.Town;
            this.branchRec.County__c = address.County;
            this.branchRec.Country__c = address.Country;
            this.branchRec.Postcode__c = address.Postcode;
            var isPostalCodeNI = false;
            this.postalCodesList.forEach(item => {
                if (address.Postcode.includes(item.Label)) {
                    isPostalCodeNI = true;
                }
            });
            this.isAddressNotNI = !isPostalCodeNI;
        }
        console.log('Selected Address Map::', JSON.stringify(this.address));
    }

    updateSelectedField(event) {
        var changedField = event.target.name;
        console.log('::Changed Field::' + changedField + 'Updated Value::' + event.target.value);
        if (changedField == 'branch-name') {
            this.branchRec.Branch_Name__c = event.target.value;
        } else if (changedField == 'company-phone') {
            this.branchRec.Alt_telephone_no__c = event.target.value;
        } else if (changedField == 'phone-code') {
            this.branchRec.Phone_Code__c = event.target.value;
        } else if (changedField == 'telephone') {
            this.branchRec.Telephone_no__c = event.target.value;
        } else if (changedField == 'fax') {
            this.branchRec.Fax__c = event.target.value;
        } else if (changedField == 'website') {
            this.branchRec.Website__c = event.target.value;
        } else if (changedField == 'general-email') {
            this.branchRec.General_correspondence_e_mail__c = event.target.value;
        } else if (changedField == 'dispute-email') {
            this.branchRec.Dispute_resolution_e_mail__c = event.target.value;
        } else if (changedField == 'finance-email') {
            this.branchRec.Finance_e_mail__c = event.target.value;
        } else if(changedField=='address'){
            this.branchRec.Address__c = event.target.value;
        } else if(changedField=='town'){
            this.branchRec.Town_City__c = event.target.value;
        } else if(changedField=='postcode'){
            this.branchRec.Postcode__c = event.target.value;
        } else if(changedField=='county'){
            this.branchRec.County__c = event.target.value;
        } else if(changedField=='country'){
            this.branchRec.Country__c = event.target.value;
        }
        console.log('::Updated Branch:::', JSON.stringify(this.branchRec));
    }

    updateBranchUser(event) {
        this.PageSpinner = true;
        event.preventDefault();
        var conId = window.btoa(event.target.dataset.value);
        var branchId = window.btoa(event.target.dataset.record);

        if ((conId != null && conId != '' && conId != undefined) && (branchId != null && branchId != '' && branchId != undefined)) {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'editbranchuser'
                },
                state: {
                    c__branchId: branchId,
                    c__recId: conId
                }
            });
        }
        this.PageSpinner = false;
    }

    saveBranch(event) {
        this.PageSpinner = true;
        // console.log('Inside Save');
        console.log('Before Save::', JSON.stringify(this.branchRec));
        event.preventDefault();
        var isValid = true;
        this.mobileLengthOrPatternError = false;
        this.addressError = false;

        if (this.branchRec.Telephone_no__c != null && this.branchRec.Telephone_no__c != "" && this.branchRec.Telephone_no__c != undefined) {
            if (this.branchRec.Phone_Code__c == '+44' && this.branchRec.Telephone_no__c.length != 11) {
                this.mobileLengthOrPatternError = true;
                isValid = false;
            }
        }
        if(this.isAddressNotNI) {
            this.addressError = true;
            isValid = false;
        }
        if (!isValid) {
            this.PageSpinner = false;
            this.template.querySelector(".errorMessages").scrollIntoView();
        } else {
            window.scrollTo(0, 0);
            updateBranch({
                branchData: JSON.stringify(this.branchRec)
            }).then(result => {
                this.PageSpinner = false;
                console.log('Update Branch Result:', JSON.stringify(result));
                this.showSuccessScreen = true;
                this.isEdit = false;
            }).catch(error => {
                this.PageSpinner = false;
                this.isEdit = false;
                this.showErrorScreen = true;
                console.log('Update Branch Error::', JSON.stringify(error));
            })
            this.PageSpinner = false;
        }
        this.PageSpinner = false;
    }

    hideBootstrapErrors(event) {
        var buttonName = event.target.name;
        switch (buttonName) {
            case "successMg":
                this.showSuccessScreen = false;
                break;
            case "errorMsg":
                this.showErrorScreen = false;
                break;
            case "mobileLengthOrPatternErrorMsg":
                this.mobileLengthOrPatternError = false;
                break;
            case "addressErrorMsg":
                this.addressError = false;
                break;
        }
    }
    onlyNumberKey(event) {
        if(!(event.key == 0 || event.key == 1 || event.key == 2 || event.key == 3 || event.key == 4 || event.key == 5 || event.key == 6 || event.key == 7 || event.key == 8 || event.key == 9)){
            event.preventDefault();
        }
    }
}