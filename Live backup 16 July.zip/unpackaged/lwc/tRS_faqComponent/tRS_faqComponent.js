import { LightningElement, wire } from 'lwc';
import getFAQs from '@salesforce/apex/FAQController.getFAQs';

export default class FaqComponent extends LightningElement {
    faqs;

    @wire(getFAQs)
    wiredFAQs({ error, data }) {
        if (data) {
            this.faqs = data;
        } else if (error) {
            console.error('Error retrieving FAQs: ', error);
        }
    }
}