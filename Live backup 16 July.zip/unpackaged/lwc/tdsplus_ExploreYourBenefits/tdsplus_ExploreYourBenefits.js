import { LightningElement, wire, api, track} from 'lwc';
import { getContent } from "experience/cmsDeliveryApi";
import siteId from "@salesforce/site/Id";
// import communityId from "@salesforce/community/Id";
// import getManagedContentByContentKeys from '@salesforce/apex/EI_NI_Website_CmsContent.getManagedContentByContentKeys'

export default class Tdsplus_ExploreYourBenefits extends LightningElement {

    // Add salesforce cms content
    @api contentKey;
    @api headingType ='';
    @api referralUrl;
    @track data;
    @track ctaContentKeyList = [];
    

    get isHeadingtextNotNull(){
        if(this.headingType==null || this.headingType==''){
            return false;
        }
        else{
            return true;
        }
    }

    @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    onGetContent({ error, data }) {
        console.log('Line 16 contentKey -> '+this.contentKey);
        console.log('Line 16 siteId -> '+siteId);
        if(data) {
            this.data = data;
            console.log('Line 25 -> ');
            console.log('Line 25 -> '+JSON.stringify(data));
            let cmsCtaObjectList = data.contentBody['sfdc_cms:collection'];
            let ctaContentKeyList = [];
            for(let cmsImage of cmsCtaObjectList) {
                ctaContentKeyList.push(cmsImage.contentKey);
            }
            this.ctaContentKeyList = ctaContentKeyList;
            
            console.log('Line 25 ctaContentKeyList -> '+JSON.stringify(ctaContentKeyList));
            console.log('Line 25 end -> ');

            // Apex call to get the cms images
            // getManagedContentByContentKeys({ 
            //     communityId: communityId, managedContentIds: ctaContentKeyList, pageParam: 0, pageSize: 1, language: 'en_US', 
            //     managedContentType: 'news', showAbsoluteUrl: false
            // })
            //     .then(result => {
            //         if (result) {
            //             console.log(`Line 48 result -> ${result}`);
            //         }
            //         else {
            //             console.log(`Line 48 -> result not found`);
            //         }
            //     })
            //     .catch(error => {
            //         console.error('Line 48 getManagedContentByContentKeys Error -> '+JSON.stringify(error));
            //     })
            
        }
        else {
            console.log('Line 25 data not available ');
        }
    }

    // @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    // onGetContent({ error, data }) {
    //     if(data) {
    //         this.data = data;
    //         console.log('Line 25 -> ');
    //         console.log('Line 25 -> '+JSON.stringify(data));
    //         console.log('Line 25 cms image list -> '+JSON.stringify(data.contentBody));
    //         console.log('Line 25 cms image list -> '+JSON.stringify(data.contentBody['sfdc_cms:collection']));
    //         let cmsImagesObjectList = data.contentBody['sfdc_cms:collection'];
    //         let cmsImagesList = [];
    //         for(let cmsImage of cmsImagesObjectList) {
    //             cmsImagesList.push(cmsImage.contentKey)
    //         }
    //         console.log('Line 25 cmsImagesList -> '+JSON.stringify(cmsImagesList));
    //         console.log('Line 25 siteId -> '+siteId);

    //         // Apex call to get the cms images
    //         getManagedContentByContentKeys({ 
    //             communityId: siteId, managedContentIds: cmsImagesList, pageParam: 0, pageSize: 1, language: 'en_US', 
    //             managedContentType: 'news', showAbsoluteUrl: false
    //         })
    //             .then(result => {
    //                 if (result) {
    //                     console.log(`Line 48 result -> ${result}`);
    //                 }
    //                 else {
    //                     console.log(`Line 48 -> result not found`);
    //                 }
    //             })
    //             .catch(error => {
    //                 console.error('Line 48 getManagedContentByContentKeys Error -> '+JSON.stringify(error));
    //             })
    //         // console.log('line 25 subtitle -> '+result.data.contentBody.Subtitle);
    //         // this.popupcontain=result.data.contentBody.Subtitle;  
    //         console.log('Line 25 end -> ');
    //     }
    // }   

}