import { LightningElement } from 'lwc';
export default class TRS_TenantComplaintProcessHomePage extends LightningElement {

}