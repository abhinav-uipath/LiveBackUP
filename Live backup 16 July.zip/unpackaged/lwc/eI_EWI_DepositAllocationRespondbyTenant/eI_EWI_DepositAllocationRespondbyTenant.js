import { api,LightningElement, wire, track } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import getCaseandDispiteItemsDetails from '@salesforce/apex/eI_EWI_DepositAllocationProposalCls.getCaseandDispiteItemsDetails';
import updateCaseNotAgreeAGLLButWishToSchemebyTenant from '@salesforce/apex/eI_EWI_DepositAllocationProposalCls.updateCaseNotAgreeAGLLButWishToSchemebyTenant';
//import updateCaseAgreetoAGLLbyTenant from '@salesforce/apex/eI_EWI_DepositAllocationProposalCls.updateCaseAgreetoAGLLbyTenant';
import updateCaseInRepaymentAgreementbyTenantForEqualAmt from '@salesforce/apex/eI_EWI_DepositAllocationProposalCls.updateCaseInRepaymentAgreementbyTenantForEqualAmt';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

export default class EI_EWI_DepositAllocationRespondbyTenant extends NavigationMixin(LightningElement) {
    ew_arrow_dropleft = EWITheme + '/assets/img/ew-arrow-dropleft.png';
    pound_icon = EWITheme + '/assets/img/pound_icon.png';
    home_icon = EWITheme + '/assets/img/home_icon.png';

    @track isShowThankyouPage = false;
    @track accessCode;
    @track depositAmount = 0.00;
    @track formattedEndDate;
    @track amountToTenantByAGLL =0.00;
    @track amountToTenantByTT =0.00;
    @track depositAmountClaimedByAGLL = 0.00;
    @track depositAmountClaimedByTT = 0.00;
    @track agllName;
    @track disputeItems = [];
    @track showIfClaimedMoreThenDepositAmount=false;
    @track otherReason;
    @track isDisableSubmitBtn = false;
    @track isDisableFinalSubmitBtn = false;
    @track showDetails=true;
    @track bothAmountAreEquals = false; // added by Abhinav Sharma, Enhancement-: EID-1419, Date-: 21/Nov/2023
    @track showAmountEqualSection = false;

    //TGK-340 : START
    @track totalClaimedAmount;
    @track isshowtotalclaimsection = false;
    @track totalClaimedReason;
    @track isAccessClaimAmountVisible = false;
    @track excessClaimValueForTTPreiv = false;
    @track isShowClaimAmountVisible = false;
   //TGK: 340 : END

    @api initialAmountToAGLL;
    @api caseParticipant;
    caseId;


    connectedCallback(){
    // @wire(CurrentPageReference)
    // getpageRef(pageRef) {
      setTimeout(() => { window.history.forward();  }, 0);

        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const accessCode = urlParams.get('accessCode');
        this.accessCode = accessCode;
        if(accessCode == '' || accessCode == null){
            this.showDetails = false;
            return;
          }

        getCaseandDispiteItemsDetails({accessCode: this.accessCode})
        .then(result => {
            if(result==null){
                this.showDetails=false;
                return;
              }
              this.showDetails=true;
            console.log('getCaseandDispiteItemsDetails => ' + JSON.stringify(result[0]));
            console.log('depositAmount => ' + result[0].Deposit_Account_Number__r.Deposit_Amount__c);
            this.depositAmount = (result[0].Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2);
            this.depositAmountClaimedByAGLL = (result[0].Total_Claimed_by_Landlord__c).toFixed(2);
            this.amountToTenantByAGLL = this.depositAmount - this.depositAmountClaimedByAGLL;
            this.caseId = result[0].Id;
            var endDate = new Date( result[0].Deposit_Account_Number__r.End_Date__c);
            this.totalClaimedAmount = result[0].Claim_exceed_amount__c; //TGK-340 : added the total claim amount
            this.totalClaimedReason = result[0].Total_Claim_Exceed_Reason__c; //TGK-340 : added the total claim amount reason
            if(this.totalClaimedAmount>0 ){
            this.isshowtotalclaimsection = true;
            }
            
            if(isNaN(endDate)){
                this.dateValue='';
            } 
            else if(endDate!= null || endDate!= undefined|| endDate!= ''){
                var checkdate = endDate.getDate().toString().padStart(2, "0");;
                var checkmonth = (endDate.getMonth()+1).toString().padStart(2, "0");
                var checkyear = endDate.getFullYear();
                var newDate = checkdate +'/'+ checkmonth+'/'+checkyear;
                this.formattedEndDate = newDate;
                console.log('endDate => '+ endDate );
                console.log('formattedEndDate => '+this.formattedEndDate);     
                console.log('depositAmount => '+this.depositAmount); 
            } 
            
            this.agllName = result[0].Case_Participants__r[0].Account__r.Name ? result[0].Case_Participants__r[0].Account__r.Name : '';
            let aglldisputeItems = JSON.parse(JSON.stringify(result[0].Dispute_Items__r));
            for(let ind in aglldisputeItems ){
                // console.log('aglldisputeItems['+ind+'].Claimed_by_Landlord__c => ' + aglldisputeItems[ind].Claimed_by_Landlord__c.toFixed(2));
                aglldisputeItems[ind].Claimed_by_Landlord__c = (parseFloat(aglldisputeItems[ind].Claimed_by_Landlord__c)).toFixed(2);
                let itemType;
                if(aglldisputeItems[ind].Type__c.includes('Rent')){
                    itemType = 'Rent arrears'
                }
                else{
                    itemType = aglldisputeItems[ind].Type__c;
                }
                console.log('TGK-340 : aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c ==> '+aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c);
                
                this.disputeItems.push({
                    key: itemType, 
                    value:{itemAmountbyAGLL: aglldisputeItems[ind].Claimed_by_Landlord__c, itemAmountbyTT: 0.00, isTTAmountMoreThenAgllAmount: false, claimItemId: aglldisputeItems[ind].Id,reason:aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c,ttReason:'',claimItemAmountReasonlengtherror:false, claimItemAmountReasonrequired:false}
                });
                if(aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c != null && aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c != undefined){
                    this.otherReason = aglldisputeItems[ind].Agent_landlord_s_reason_for_claim__c;
                }
            }
            console.log("disputeItems => " + JSON.stringify(this.disputeItems));
            
        }).catch(error => {
                console.log("getCaseandDispiteItemsDetails Apex error=> " + JSON.stringify(error));
                console.log("getCaseandDispiteItemsDetails JS error=> " + (error));
        });
    }

    restrictDecimal(event) {  
        let amtVal = event.target.value;
        return (amtVal.indexOf(".") >= 0) ? (amtVal.substr(0, amtVal.indexOf(".")) + amtVal.substr(amtVal.indexOf("."), 3)) : amtVal;

        // if(t.includes(".")){
        //     let arr = t.split(".");
        //     let lastVal = arr.pop();
        //     let arr2 = lastVal.split('');
        //     if (arr2.length > '1') {
        //         event.preventDefault();
        //     }
        // }
    }
    
    removeZero(event) {
        console.log('removeZero');
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }
    
    restrictNegativeVal(event){
        if(event.target.value < 0){
            event.target.value = 0;
        }
    }
    
    handleGoBack(event) {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'home'
            },
            state:{
                accessCode: this.accessCode,
                reviewProposal: 'true'
            }
        });
    }

    handleAmountToTenantByTTChange(event){
        let val = this.restrictDecimal(event);
        event.target.value = val;
        this.amountToTenantByTT = event.target.value.trim(); //Added by Himanshi For ISD-28166
    }

    handleCalculateClaimAmountByTT(event){
        let val = this.restrictDecimal(event);
        console.log("handleCalculateClaimAmountByTT" + val);
        event.target.value = val;

        console.log("handleCalculateClaimAmountByTT" + event.target.value);
        let index = event.target.title;
        let claimItemValue = event.target.value.trim(); //Added by Himanshi for ISD-28166
        
        this.disputeItems[index].value.itemAmountbyTT = claimItemValue;

        if(claimItemValue > 0){
            if(parseFloat(this.disputeItems[index].value.itemAmountbyTT) > parseFloat(this.disputeItems[index].value.itemAmountbyAGLL)){
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = true;
            }else{
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = false;
            }
        }

        // console.log(" on change disputeItems=> " + JSON.stringify(this.disputeItems));
        this.depositAmountClaimedByTT = 0;
        
        for(let ind in this.disputeItems ){
            console.log(" on change claimedItem => " + this.disputeItems[ind].value.itemAmountbyTT);
            if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT) + parseFloat(this.disputeItems[ind].value.itemAmountbyTT)).toFixed(2);
            }
        }
        console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
    }

    //TGK-340 : handle the reason of Claim Item provided by TT : START
    handleClaimReasonByTT(event){
        
        console.log('Test Reason Change');
        let allLengthSpanTag = this.template.querySelectorAll('.charSize');
        let allHighlightedClaimreasonInput = this.template.querySelectorAll('.isHighlightedClaimReason');
        let index = event.target.title
        allLengthSpanTag[index].textContent = event.target.value.length;
        //disputeItems[index].value.reason = event.target.value;

        let claimItemReasonValue = event.target.value;  
        console.log('claimItemReasonValue == >'+claimItemReasonValue);      
        this.disputeItems[index].value.ttReason = claimItemReasonValue;

        console.log('test claimItemReasonValue == > '+this.disputeItems[index].value.ttReason);

        //TGK-340 : checked the claimed item reason is null(remove the error message) : START
        if(this.disputeItems[index].value.ttReason.length > 0 ){
            console.log('check the null value for reason on Change');
            this.disputeItems[index].value.claimItemAmountReasonrequired =false;
        }
        if(this.disputeItems[index].value.ttReason.length > 0 && this.disputeItems[index].value.ttReason.length >20  && this.disputeItems[index].value.ttReason.length <= 100){
            console.log('check the null value for reason on Change');
            this.disputeItems[index].value.claimItemAmountReasonlengtherror =false;
        }
        //TGK-340 : checked the claimed item reason is null : END

         //TGK-340 : highlighted the claim amount reason field : START
         if(this.disputeItems[index].value.ttReason.length < 20 || this.disputeItems[index].value.ttReason.length > 100){
            console.log('check the null value for reason on Change for highlight');
            allHighlightedClaimreasonInput[index].style = 'border: 2px solid red'; // need to change the error border        
        }
        else{
            allHighlightedClaimreasonInput[index].style = 'border: 2px solid green'; // need to change the error border
        }
        //TGK-340 : highlighted the claim amount reason field : END
    }
    //TGK-340 : handle the reason of Claim Item provided by TT : END
    
    //Submit the claim details : button 
    handleClaimSubmit(event){
        let isValid = true;
        console.log("this.depositAmountClaimedByTT-->>"+this.depositAmountClaimedByTT);
        console.log("this.depositAmountClaimedByAGLL"+this.depositAmountClaimedByAGLL);

        //TGK-340 : Auto Access claim value calculation continue : START
        if(this.totalClaimedAmount!=0 || this.totalClaimedAmount != null || this.totalClaimedAmount != undefined || this.totalClaimedAmount != ' '){
            this.excessClaimValueForTTPreiv  = (parseFloat(this.totalClaimedAmount) - parseFloat(this.depositAmount)).toFixed(2); 
            if(this.excessClaimValueForTTPreiv > 0){
                this.isAccessClaimAmountVisible = true;
            }  
        }
        if(this.totalClaimedAmount > 0){
            this.isShowClaimAmountVisible = true;
        } 
         //TGK-340 : Auto Access claim value calculation continue : END

        //if( this.amountToTenantByAGLL == this.amountToTenantByTT || (this.amountToTenantByTT ==0 && this.amountToTenantByAGLL ==0)){
       // if( this.amountToTenantByAGLL == this.amountToTenantByTT && (this.depositAmountClaimedByTT == this.depositAmountClaimedByAGLL)){
            console.log("LineNo207If-->>");
            //this.bothAmountAreEquals = true; //TGK-340 : commented
            //this.showDetails = false; //TGK-340 : commented 

            //TGK-340 : check the claimed item reason is not nulll : START
            for(let ind in this.disputeItems){                
                console.log('this.disputeItems[ind].value.ttReason.length == >'+this.disputeItems[ind].value.ttReason.length );
                console.log('this.disputeItems[ind].value.ttReason == >'+this.disputeItems[ind].value.ttReason );
                if(this.disputeItems[ind].value.itemAmountbyTT >0 && this.disputeItems[ind].value.ttReason.length < 20){
                    if(this.disputeItems[ind].value.itemAmountbyTT >0 && ( this.disputeItems[ind].value.ttReason.length == 0 || this.disputeItems[ind].value.ttReason.length == null || this.disputeItems[ind].value.ttReason.length == undefined)){
                        console.log('undefined Data if condition ==>');
                        this.disputeItems[ind].value.claimItemAmountReasonrequired =true;
                        this.disputeItems[ind].value.claimItemAmountReasonlengtherror =false;
                        this.bothAmountAreEquals = false;
                        this.showDetails = true;
                        isValid = false;
                    }
                   else if(this.disputeItems[ind].value.itemAmountbyTT >0 && this.disputeItems[ind].value.ttReason.length > 0 && (this.disputeItems[ind].value.ttReason.length < 20 || this.disputeItems[ind].value.ttReason.length >100)){
                        console.log('undefined Data if condition ==>');
                        this.disputeItems[ind].value.claimItemAmountReasonlengtherror =true;
                        this.disputeItems[ind].value.claimItemAmountReasonrequired =false;
                        this.bothAmountAreEquals = false;
                        this.showDetails = true;
                        isValid = false;
                    }
                   else{  
                        this.disputeItems[ind].value.claimItemAmountReasonlengtherror =false;
                        this.disputeItems[ind].value.claimItemAmountReasonrequired =false; 
                        this.bothAmountAreEquals = true;              
                        this.showDetails = false;
                        isValid = true;
                   }
                }
              
                
               console.log('this.bothAmountAreEquals ==>' + this.bothAmountAreEquals);
               console.log('this.showDetails ==>' + this.showDetails);
                console.log('this.disputeItems[ind].value.claimItemAmountReasonrequired  TGK-340: ==> '+this.disputeItems[ind].value.claimItemAmountReasonrequired )
            //TGK-340 : check the claimed item reason is not nulll : START
            }

            if( isValid == true){
                this.bothAmountAreEquals = true;              
                this.showDetails = false;   
                }
     //   }
        
       // if( this.amountToTenantByAGLL != this.amountToTenantByTT || (this.amountToTenantByTT !=0 && this.amountToTenantByAGLL !=0)){
       // if(this.depositAmountClaimedByTT != this.depositAmountClaimedByAGLL){

       // else{
                console.log("LineNo219else-->>");
                //this.bothAmountAreEquals = false; //TGK-340
                //isValidReason = false; //TGK-340
            if(this.amountToTenantByTT > 0){
                this.amountToTenantByTT = (parseFloat(this.amountToTenantByTT)).toFixed(2);
            }else{
                this.amountToTenantByTT = (parseFloat(0.00)).toFixed(2);
            }
            console.log("this.amountToTenantByTT => " + this.amountToTenantByTT);

            if(this.depositAmountClaimedByTT > 0){
                this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT)).toFixed(2);
            }else{
                this.depositAmountClaimedByTT = (parseFloat(0.00)).toFixed(2);
            }
            console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
            console.log("this.amountToTenantByTT + this.depositAmountClaimedByTT => " + (( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)));
            
            if((( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)) != (parseFloat(this.depositAmount).toFixed(2))){
                this.showIfClaimedMoreThenDepositAmount = true;
                this.bothAmountAreEquals = false;
                this.showDetails = true;
            }else{
                this.showIfClaimedMoreThenDepositAmount = false;
               // this.bothAmountAreEquals = true;
               // this.showDetails = false;
               
                // need to do a server call for update case status to 'Self-resolution' and update claimed amount of tenant on dispute Items
                var claimedItemsDetailsObj = {};
                var claimItemReasonDetailObj = {}; //TGK-340 : to store the item claim reason

                for(let ind in this.disputeItems){
                    if(parseFloat(this.disputeItems[ind].value.itemAmountbyTT) > parseFloat(this.disputeItems[ind].value.itemAmountbyAGLL)){
                        console.log('TGK-340 inside ');
                       // isValid = false;
                        this.disputeItems[ind].value.isTTAmountMoreThenAgllAmount = true;
                        this.template.querySelector(".moreamounterror").scrollIntoView();
                    }
                    console.log("key => " + this.disputeItems[ind].key);
                    console.log("value => " + JSON.stringify(this.disputeItems[ind].value));
                    let detailsObj = {};
                    detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
                    if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                        detailsObj['itemAmountbyTT'] = this.disputeItems[ind].value.itemAmountbyTT;
                    }else{
                        detailsObj['itemAmountbyTT'] = 0.00;
                    }
                    detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;

                    //TGk-340 : send the TTReason : START
                    if(this.disputeItems[ind].value.ttReason.length > 0 || this.disputeItems[ind].value.ttReason.length != null || this.disputeItems[ind].value.ttReason.length != undefined){
                        console.log('ttReason Object Passing');
                        detailsObj['ttReason'] = this.disputeItems[ind].value.ttReason;
                    }
                    //TGK-340 : send the TTReason : END                    
                    console.log('detailObject ===> '+JSON.stringify(detailsObj));

                    claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
                    console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));

                }   
                var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);

            //    if(isValid){
            //         this.isDisableSubmitBtn = true;
            //         this.template.querySelector('.submit-btn').classList.remove('blue_theme');
            //         this.template.querySelector('.submit-btn').classList.add('disable_ew_btn');

            //         updateCaseNotAgreeAGLLButWishToSchemebyTenant({caseId: this.caseId, amountToTTbyTT: this.amountToTenantByTT, 
            //             accessCode: this.accessCode, claimedItems: claimedItemsDetailsObjStr, otherReason: this.otherReason})
            //         .then(result=>{
            //             console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant result => ' + result);
            //             if(result == 'Tenant Responded'){
            //                 this.handleDepositSummaryReview();
            //             }
            //             if(result == 'Successfully updated'){
            //                 this.isShowThankyouPage = true;
            //                 this[NavigationMixin.Navigate]({
            //                     type: 'comm__namedPage',
            //                     attributes: {
            //                         pageName: 'ewithankyou'
            //                     },
            //                     state:{
            //                         accessCode: this.accessCode,
            //                         thanksfor: 'respondedbytt'
            //                     }
            //                 });
            //             }
            //         }).catch(error=>{
            //             console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant error => ' + JSON.stringify(error));
            //         })
            //     }
            }
  //  }
    }

    //Final page summary preview page submit
    handleSubmitAgreetoAGLLRequest(event){
        console.log("LineNo378-->>");
       // this.isSelfresButtonDisabled = true;
       // this.isCourtCaseButtonDisabled = true;
       this.template.querySelector('.submit-btn').classList.remove('blue_theme');
       this.template.querySelector('.submit-btn').classList.add('disable_ew_btn');
        this.isSubmitBtnDisable = true;

        //TGK-340 : Send the ttReason to backend : START
        // var claimedItemsDetailsObj = {};        

        // for(let ind in this.disputeItems){
        //     let detailsObj = {};

        //     if(this.disputeItems[ind].value.ttReason.length > 0 || this.disputeItems[ind].value.ttReason.length != null || this.disputeItems[ind].value.ttReason.length != undefined){
        //         console.log('ttReason Object Passing');
        //         detailsObj['ttReason'] = this.disputeItems[ind].value.ttReason;
        //     }
        //     console.log('detailObject ===> '+JSON.stringify(detailsObj));

        //     claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
        //     console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
        // }

        // var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
        // console.log('claimedItemsDetailsObjStr ===> '+claimedItemsDetailsObjStr);

        if(this.amountToTenantByTT > 0){
            this.amountToTenantByTT = (parseFloat(this.amountToTenantByTT)).toFixed(2);
        }else{
            this.amountToTenantByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.amountToTenantByTT => " + this.amountToTenantByTT);

        if(this.depositAmountClaimedByTT > 0){
            this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT)).toFixed(2);
        }else{
            this.depositAmountClaimedByTT = (parseFloat(0.00)).toFixed(2);
        }

        if((( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)) != (parseFloat(this.depositAmount).toFixed(2))){
            this.showIfClaimedMoreThenDepositAmount = true;
            
        }else{
            this.showIfClaimedMoreThenDepositAmount = false;

            let isValid = true;
            // need to do a server call for update case status to 'Self-resolution' and update claimed amount of tenant on dispute Items
            var claimedItemsDetailsObj = {};
            var claimItemReasonDetailObj = {}; //TGK-340 : to store the item claim reason

            for(let ind in this.disputeItems){
                if(parseFloat(this.disputeItems[ind].value.itemAmountbyTT) > parseFloat(this.disputeItems[ind].value.itemAmountbyAGLL)){
                    console.log('TGK-340 inside ');
                    isValid = false;
                    this.disputeItems[ind].value.isTTAmountMoreThenAgllAmount = true;
                    this.template.querySelector(".moreamounterror").scrollIntoView();
                }
                console.log("key => " + this.disputeItems[ind].key);
                console.log("value => " + JSON.stringify(this.disputeItems[ind].value));
                let detailsObj = {};
                detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
                if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                    detailsObj['itemAmountbyTT'] = this.disputeItems[ind].value.itemAmountbyTT;
                }else{
                    detailsObj['itemAmountbyTT'] = 0.00;
                }
                detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;

                //TGk-340 : send the TTReason : START
                if(this.disputeItems[ind].value.ttReason.length > 0 || this.disputeItems[ind].value.ttReason.length != null || this.disputeItems[ind].value.ttReason.length != undefined){
                    console.log('ttReason Object Passing');
                    detailsObj['ttReason'] = this.disputeItems[ind].value.ttReason;
                }
                //TGK-340 : send the TTReason : END                    
                console.log('detailObject ===> '+JSON.stringify(detailsObj));

                claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
                console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));

            }   
            var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
        }
         //TGK-340 : Send the ttReason to backend : END

        if( (this.amountToTenantByAGLL != this.amountToTenantByTT) /*&& (this.amountToTenantByTT !=0 && this.amountToTenantByAGLL !=0)*/){

        updateCaseNotAgreeAGLLButWishToSchemebyTenant({caseId: this.caseId, amountToTTbyTT: this.amountToTenantByTT, 
                    accessCode: this.accessCode, claimedItems: claimedItemsDetailsObjStr, otherReason: this.otherReason})
                .then(result=>{
                    console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant result => ' + result);
                     //  AccessCodeNotMatched if condition added by Abhinav - ISD-27945 Start
                    if(result=='AccessCodeNotMatched'){
                        this.handleDepositSummaryReview();
                    }
                     //  AccessCodeNotMatched if condition added by Abhinav - ISD-27945 End

                    if(result == 'Tenant Responded'){
                        this.handleDepositSummaryReview();
                    }
                    if(result == 'Successfully updated'){
                        this.isShowThankyouPage = true;
                        this[NavigationMixin.Navigate]({
                            type: 'comm__namedPage',
                            attributes: {
                                pageName: 'ewithankyou'
                            },
                            state:{
                                accessCode: this.accessCode,
                                thanksfor: 'respondedbytt'
                            }
                        });
                    }
                }).catch(error=>{
                    console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant error => ' + JSON.stringify(error));
                })
            }


            else{
         this.showAmountEqualSection = true;
         this.bothAmountAreEquals = false;
    // need to add an apex call for update case status > ‘Case closed - resolved without adjudication’
    // updateCaseInRepaymentAgreementbyTenantForEqualAmt({caseId: this.caseId, 
            
    // agreedAmount: this.amountToTenantByAGLL,
    // depositAmount: this.depositAmount,
    // accessCode: this.accessCode,
    // claimedItems: claimedItemsDetailsObjStr
    // }).then(result => {
    // console.log("updateCaseInRepaymentAgreementbyTenantForEqualAmt result => " + result);
    // this.isShowThankyouPage = true;
    // this[NavigationMixin.Navigate]({
    //     type: 'comm__namedPage',
    //     attributes: {
    //         pageName: 'ewithankyou'
    //     },
    //     state:{
    //         accessCode: this.accessCode,
    //         thanksfor: 'agreeForEqualAmount'
    //     }
    // });
    // }).catch(error => {
    // console.log("updateCaseInRepaymentAgreementbyTenantForEqualAmt error => ", error);
    // });
            }
            
        }
    

    
    handleDepositSummaryReview(){
        window.location.href =  EWIVPlus_Link+this.accessCode;

        // window.location.href = "https://espdev2-thedisputeservice.cs80.force.com/ewinsured/s/?accessCode="+this.accessCode;
        // let currentURL = window.location.href;
        // console.log('currentURL => ' + currentURL);
        // let homeURL = currentURL.split('/ewinsured/s');
        // console.log('homeURL => ' + homeURL);
        // let redirectToURL = homeURL[0]+'/ewinsured/s/?accessCode='+this.accessCode;
        // console.log('redirectToURL => ' + redirectToURL);
        // window.location.href = redirectToURL;
    }

    handleBackFromEqualAmount(){

        /*this.bothAmountAreEquals = true;
        this.showDetails = false;
        this.showAmountEqualSection = false;*/
				this.bothAmountAreEquals = false;
        this.showDetails = true;

    }

    submitEqualAmountRequest(event){
        this.isDisableFinalSubmitBtn = true;
    
        if(this.amountToTenantByTT > 0){
            this.amountToTenantByTT = (parseFloat(this.amountToTenantByTT)).toFixed(2);
        }else{
            this.amountToTenantByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.amountToTenantByTT => " + this.amountToTenantByTT);
    
        if(this.depositAmountClaimedByTT > 0){
            this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT)).toFixed(2);
        }else{
            this.depositAmountClaimedByTT = (parseFloat(0.00)).toFixed(2);
        }
    
        if((( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)) != (parseFloat(this.depositAmount).toFixed(2))){
            this.showIfClaimedMoreThenDepositAmount = true;
            
        }else{
            this.showIfClaimedMoreThenDepositAmount = false;
    
            let isValid = true;
            // need to do a server call for update case status to 'Self-resolution' and update claimed amount of tenant on dispute Items
            var claimedItemsDetailsObj = {};
            var claimItemReasonDetailObj = {}; //TGK-340 : to store the item claim reason
    
            for(let ind in this.disputeItems){
                if(parseFloat(this.disputeItems[ind].value.itemAmountbyTT) > parseFloat(this.disputeItems[ind].value.itemAmountbyAGLL)){
                    console.log('TGK-340 inside ');
                    isValid = false;
                    this.disputeItems[ind].value.isTTAmountMoreThenAgllAmount = true;
                    this.template.querySelector(".moreamounterror").scrollIntoView();
                }
                console.log("key => " + this.disputeItems[ind].key);
                console.log("value => " + JSON.stringify(this.disputeItems[ind].value));
                let detailsObj = {};
                detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
                if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                    detailsObj['itemAmountbyTT'] = this.disputeItems[ind].value.itemAmountbyTT;
                }else{
                    detailsObj['itemAmountbyTT'] = 0.00;
                }
                detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;
    
                //TGk-340 : send the TTReason : START
                if(this.disputeItems[ind].value.ttReason.length > 0 || this.disputeItems[ind].value.ttReason.length != null || this.disputeItems[ind].value.ttReason.length != undefined){
                    console.log('ttReason Object Passing');
                    detailsObj['ttReason'] = this.disputeItems[ind].value.ttReason;
                }
                //TGK-340 : send the TTReason : END                    
                console.log('detailObject ===> '+JSON.stringify(detailsObj));
    
                claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
                console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
    
            }   
            var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
        }
            //TGK-340 : Send the ttReason to backend : END
    
        
    // need to add an apex call for update case status > ‘Case closed - resolved without adjudication’
    updateCaseInRepaymentAgreementbyTenantForEqualAmt({caseId: this.caseId, 
        
    agreedAmount: this.amountToTenantByAGLL,
    depositAmount: this.depositAmount,
    accessCode: this.accessCode,
    claimedItems: claimedItemsDetailsObjStr
    }).then(result => {
    console.log("updateCaseInRepaymentAgreementbyTenantForEqualAmt result => " + result);
     //  AccessCodeNotMatched if condition added by Abhinav - ISD-27945 Start
     if(result=='AccessCodeNotMatched'){
        this.handleDepositSummaryReview();
    }
     //  AccessCodeNotMatched if condition added by Abhinav - ISD-27945 End
     else{
        this.isShowThankyouPage = true;
        this[NavigationMixin.Navigate]({
        type: 'comm__namedPage',
        attributes: {
            pageName: 'ewithankyou'
        },
        state:{
            accessCode: this.accessCode,
            thanksfor: 'agreeForEqualAmount'
        }
        });
     }
    
    }).catch(error => {
    console.log("updateCaseInRepaymentAgreementbyTenantForEqualAmt error => ", error);
    });
    }

        renderedCallback() {
        const style = document.createElement('style');
        style.innerText = '.deposite-respond-sec .agree-container .agree-detail .request-section .form-group input, .agree-container .agree-detail .request-section .form-group textarea{text-align: left;resize: none;}.deposite-respond-sec .deposit_steps .deposit_steps_detail .form-group .slds-textarea[disabled],.deposite-respond-sec .deposit_steps .deposit_steps_detail .form-group .slds-input[disabled]{ background: #efefef;}';
        this.template.querySelector('.deposite-respond-sec').appendChild(style);
    }

}