import { LightningElement ,api} from 'lwc';

export default class TdsPlus_StartSaving extends LightningElement {
    //  Tile 1 property
    @api tile1heading;
    @api descriptiontile1; 
    @api loginbuttontile1;
    @api buttonlinktile1;
     //  Tile 2 property
    @api tile2heading;
    @api descriptiontile2;
    @api description2tile2; 
    @api loginbuttontile2;
    @api buttonlinktile2;

    @api bgColor;
   
    get isButtontextNotNull1(){
        if(this.loginbuttontile1==null || this.loginbuttontile1==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isButtontextNotNull2(){
        if(this.loginbuttontile2==null || this.loginbuttontile2==''){
            return false;
        }
        else{
            return true;
        }
    }


    get tileStyle() {
        // Dynamically compute the background color style
        return `background-color: ${this.bgColor} !important;`;
    }
}