import { LightningElement, track, wire, api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { loadStyle } from 'lightning/platformResourceLoader';
import { loadScript } from 'lightning/platformResourceLoader';

import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

import getDepositDetails from '@salesforce/apex/EI_NI_tenancyOutcome.getDepositDetails';
import submitDepositNotRequired from '@salesforce/apex/EI_NI_tenancyOutcome.submitDepositNotRequired';
import submitPreoidic from '@salesforce/apex/EI_NI_tenancyOutcome.submitPreoidic';
import submitOtherScheme from '@salesforce/apex/EI_NI_tenancyOutcome.submitOtherScheme';
import submitRenewDeposit from '@salesforce/apex/EI_NI_tenancyOutcome.submitRenewDeposit';
import protectedInError from '@salesforce/apex/EI_NI_tenancyOutcome.protectedInError';


export default class EI_NI_TenancyOutcome extends NavigationMixin(LightningElement) {
    depositID;
    depositNoLongerReq= false;
    perdiocDeposit= false;
    renewDeposit= false;
    otherSchemDeposit= false;
    showDeductionsBtns = false;
    showotherSchemOptions = false;
    showProtectedInErrorOptions = false;
    showDepositInErrorYes = false;
    
    showSubmitBtn = false;
    isDeductions = false;
    OtherErrorMassage ='';
    showListOfBtn = true;
    showPerdiocDepositYes = false;
    showDepositNotReqSec = false;
    showRenewTenancyOptions = false;

    @track tenancyDay='';
    @track tenancyMonth='';
    @track tenancyYear='';
    @track tenancyEndDateYMD='';
    @track tenancyEndDateDMY='';
    @track endDateByTenant='';
    @track isFutureDateError=false;
    @track isTenEndDateValid=false;
    @track isInValidEndDate = false;
    @track depositAllocation=[];
    @track deposit=[];
    customerName='';
    showRenewMeassageForMIC = false;
    @track tenantAmt;
    @track tenInfo=[];
    @track editYesAllocation=[];
    depositNotReqError =false;
    depositNotReqErrorMsg ='';
    showperdiocDepositBtn = false;
    showpRenewDepositBtn = false;
    showProtectedInErrorBtn = false;
    otherSchemeName ='';

    disabledBtnSection = true;
    disabledErrorBtnSection = true;
    ShowotherSchemeError =false;
    otherSchemeErrorMsg ='';
    customerType ='';
    disabledsubmitRenewBtn = false;

    disabledsubmitProNoReq = false;

    calendarwhite = NI_Theme + '/assets/img/calendar-white.svg';
    @track todayDate = '';
    @track pickedValue;
    @track branchId = null;



    @track amtDetail={cleanAmt:0.00,damageAmt:0.00,redecorationAmt:0.00,gardeningAmt:0.00,arrearsAmt:0.00,otherAmt:0.00};
    @track OtherAmtReason='';
    @track otherAmtValidationError=false;
    @wire(CurrentPageReference)
    currentPageReference;

    @track tenancyDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];
    @track tenancyMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];
    @track tenancyYearList = [];


    connectedCallback() {
        let dipositeIdEncode = `${this.currentPageReference.state.depositId}`;
        this.depositID=atob(dipositeIdEncode);
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null && branchRecId != '' && branchRecId != undefined) {
                console.log('Encoded BranchId>>>' + branchRecId);
                this.branchId = window.atob(branchRecId);
            }
            console.log('Decoded-- BranchId>>>' + this.branchId);
        }

        var today = new Date();
            var todayDate = today.getDate();
            todayDate = todayDate>9 ? todayDate : '0'+todayDate;
            var todayMonth = today.getMonth()+1;
            todayMonth = todayMonth>9 ? todayMonth : '0'+todayMonth;
            var todayYear = today.getFullYear();
            this.todayDate = todayYear+'-'+todayMonth+'-'+todayDate;
            console.log(' Line 97 --->> ' + this.todayDate);


        Promise.all([
            // Server call to get the sign up wrapper list from apex
            getDepositDetails({depositId:this.depositID})
                .then(result => {
                    this.deposit = result[0].depositRec;
                    this.depositAllocation = result[0].depositRec.Deposit_Allocations__r;
                    this.customerType = this.deposit.Customer__r.Pay_for_Tenancies__c;
                    this.customerName = this.deposit.Customer__r.Name;
                    console.log('this.deposit.Periodic__c-93---->>:', this.deposit.Periodic__c);
                    console.log('this.deposit.Customer__r.Insured_status__c --->'+this.deposit.Customer__r.Insured_status__c );
                    if(!this.deposit.Periodic__c)
                    {
                        if(this.deposit.Customer__r.Insured_status__c =='Approved')
                        {
                            this.showperdiocDepositBtn = true;

                        }
                        else{
                            this.showperdiocDepositBtn = false;
                        }
                        
                    }
                    if(this.deposit.Customer__r.Insured_status__c =='Approved')
                    {
                        this.showpRenewDepositBtn = true;

                    }
                    else{
                        this.showpRenewDepositBtn = false;
                    }

                    if(result[0].depositRec.Installments1__r.length > 0)
                        {
                            this.showProtectedInErrorBtn = true;
                        } 
                })
                .catch(error => {
                    console.log('Line 672 Error -> ', error);
                }),

            loadStyle(this, `${NI_Theme}/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js')
        ])
        .then(() => {
            console.log('Files loaded');
        })
        .catch(error => {
            console.log('Error in loading script -> ', error.body.message);
        });
        let tenancyYearList =[];
        for (var i = 2012; i <= 2024; i++) {
            tenancyYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
        }
        this.tenancyYearList = tenancyYearList;

    }

    depositNoLongerReqBtn()
    {
        this.depositNoLongerReq= true;
        this.perdiocDeposit= false;
        this.renewDeposit= false;
        this.otherSchemDeposit= false;
        this.showListOfBtn = false;
        this.showDepositNotReqSec = true;
        this.showProtectedInErrorOptions= false;

    }
    perdiocDepositBtn()
    {
        this.depositNoLongerReq= false;
        this.perdiocDeposit= true;
        this.renewDeposit= false;
        this.otherSchemDeposit= false;
        this.showListOfBtn = false;
        this.showDepositNotReqSec = false;
        this.disabledBtnSection = true;
        this.showProtectedInErrorOptions= false;
    }
    renewDepositBtn()
    {
        this.depositNoLongerReq= true;
        this.perdiocDeposit= false;
        this.renewDeposit= true;
        this.otherSchemDeposit= false;
        this.showListOfBtn = false; 
        this.showDepositNotReqSec = false;
        this.showProtectedInErrorOptions= false;

    }
    otherSchemDepositBtn()
    {
        this.depositNoLongerReq= false;
        this.perdiocDeposit= false;
        this.renewDeposit= false;
        this.otherSchemDeposit= true;
        this.showListOfBtn = false;
        this.showDepositNotReqSec = false; 
        this.showProtectedInErrorOptions= false;
    }
    protectedInErrorBtn()
    {
        this.depositNoLongerReq= false;
        this.perdiocDeposit= false;
        this.renewDeposit= false;
        this.otherSchemDeposit= false;
        this.showListOfBtn = false;
        this.showDepositNotReqSec = false;
        this.disabledBtnSection = false;
        this.showProtectedInErrorOptions= true;
        this.disabledErrorBtnSection = true;
    }
    periodicNoBtn()
    {
        this.perdiocDeposit = false;
        this.showListOfBtn = true;
        this.disabledBtnSection = false;
        this.showProtectedInErrorOptions= false;
    }
    

    periodicYesBtn()
    {
        this.disabled = true;
        this.disabledBtnSection = false;
        submitPreoidic({depositRec:this.deposit})
                .then(result => {
                    if(result=='Successfully executed')
                    {
                        console.log('Successfully executed');
                        this.showPerdiocDepositYes = true;
                        this.deposit.Periodic__c = true;
                        this.showperdiocDepositBtn = false;
                    }
                    else{
                        this.showPerdiocDepositYes = false;
                        console.log('result Error -> '+result);
                    }
                    
                })
                .catch(error => {
                    console.log('Line 672 Error -> ', error);
                })

    }
    depositInErrorYesBtn()
    {
        this.disabled = true;
        this.disabledErrorBtnSection = false;
        protectedInError({depositRec:this.deposit})
                .then(result => {
                    if(result=='Successfully executed')
                    {
                        console.log(' Line 243 Successfully executed');
                        this.showDepositInErrorYes = true;
                    }
                    else{
                        this.showDepositInErrorYes = false;
                        console.log('result Error -> '+result);
                    }
                    
                })
                .catch(error => {
                    console.log('Line 672 Error -> ', error);
                })

    }

    onDatePickerChangeHandler(event){
        this.pickedValue = event.target.value;
        // tenancyDateList, tenancyMonthList,  tenancyYearList
        //  date picker code start
        console.log('onDatePickerChangeHandler date picker => '+ event.target.value);
        let dateVal = new Date(event.target.value);
        var day = dateVal.getUTCDate();
        var month = dateVal.getUTCMonth() + 1;
        var year = dateVal.getUTCFullYear();

        for(let i=0; i< this.tenancyDateList.length; i++){
            if(this.tenancyDateList[i].value == day){
                this.tenancyDateList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyDateList[i].value;

            }else{
                this.tenancyDateList[i].isSelected = false;  
            }

        }
        for(let i=0; i< this.tenancyMonthList.length; i++){
            if(this.tenancyMonthList[i].value == month){
                this.tenancyMonthList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyMonthList[i].value;
            }else{
                this.tenancyMonthList[i].isSelected = false;  
            }
        }

        for(let i=0; i< this.tenancyYearList.length; i++){
            if(this.tenancyYearList[i].value == year){
                this.tenancyYearList[i].isSelected = true;
                this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyYearList[i].value;
            }else{
                this.tenancyYearList[i].isSelected = false;  
            }
        }

        this.checkTenancyEndDate(event);
    }

    checkTenancyEndDate(event){

        // tenancy start date
        let isValidEndDate = false;
        let tenancyEndtDate = this.template.querySelector('[name="tenancyEndDate"]').value;
        if (tenancyEndtDate != 'Select day') {
            this.tenancyDay = tenancyEndtDate;
        }
        let tenancyEndtMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
        if (tenancyEndtMonth != 'Select month') {
            this.tenancyMonth = tenancyEndtMonth;
        }
        let tenancyEndYear = this.template.querySelector('[name="tenancyEndYear"]').value;
        if (tenancyEndYear != 'Select year') {
            this.tenancyYear = tenancyEndYear;
        }
        let tenancyDateYMD = tenancyEndYear + '-' + tenancyEndtMonth + '-' + tenancyEndtDate;
        let tenancyDateDMY = tenancyEndtDate + '/' + tenancyEndtMonth + '/' + tenancyEndYear;
        let tenancyDateDDMMYY = tenancyEndtDate + '-' + tenancyEndtMonth + '-' + tenancyEndYear;
        this.tenancyEndDateYMD = tenancyDateYMD;
        this.tenancyEndDateDMY = tenancyDateDMY;
         this.isFutureDateError=false;
        this.isTenEndDateValid=false;
        //  this.displaySummarySection = false;
        
        let endDate =this.tenancyDay ;
        let endMonth =this.tenancyMonth ;
        let endYear = this.tenancyYear;

        
        //let tenancyEndDate = endDate+'-'+endMonth+'-'+endYear;
        let tenancyEndDate = tenancyDateDDMMYY;
        let isValidDate = validatedate(tenancyEndDate);
        
        var today = new Date();
        var todayDate = today.getDate();
        var todayMonth = today.getMonth()+1;
        var todayYear = today.getFullYear();
            
        // Date validation 
        var arraydate = [];
        // let isValidDate = true;
        let isValid = true;

        // To check if date, month and year is entered by the user
        if(tenancyEndtDate == 'Select day' || tenancyEndtMonth == 'Select month' || tenancyEndYear == 'Select year') {
            // isValidEndDate = true;
            isValid = false;
            isValidDate = false;
        }

        //let tenancyDateDDMMYY = this.tenancyDay + '-' + this.tenancyMonth + '-' + tenancyEndYear;
        arraydate.push(tenancyEndDate);
        let loopCounter = 0;
        this.isInValidEndDate = false;
        if(isValid) {
            for (var i = 0; i < arraydate.length; i++) {
                isValidDate = validatedate(arraydate[i]);
                if (isValidDate == false) {
                    if (loopCounter == 0) {
                        isValid = false;
                        //isValidDate == false;
                        this.isInValidEndDate = true;
                        this.isrenderAgreeButton = false;
                    } else {
                        this.isInValidEndDate = false;
                    // this.isShowTenancyDateError = true;
                    }
                    break;
    
                } 
                else{
                    this.isInValidEndDate = false;
                }
                loopCounter++;
            }
        }

        //GOD class to check date validity
        function validatedate(d)
        {
            var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
            // Match the date format through regular expression
            if(d.match(dateformat))
            {     
                var splittedDate = d.split('-');
                var splittedDateLength = splittedDate.length;
                if (splittedDateLength>1)
                {
                    var pdate = d.split('-');
                }
                var dd = parseInt(pdate[0]);
                var mm  = parseInt(pdate[1]);
                var yy = parseInt(pdate[2]);
                
                // Create list of days of a month [assume there is no leap year by default]
                var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];
                if (mm==1 || mm>2)
                {
                    if (dd>ListofDays[mm-1])
                    {
                        return false;
                    }
                }
                if (mm==2)
                {
                    var lyear = false;
                    if ( (!(yy % 4) && yy % 100) || !(yy % 400)) 
                    {
                        lyear = true;
                    }
                    if ((lyear==false) && (dd>=29))
                    {
                        return false;
                    }
                    if ((lyear==true) && (dd>29))
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }       // }

        let setEndDate = endYear+'-'+endMonth+'-'+endDate;
        if(endYear == todayYear)
        {
            if(endMonth == todayMonth)
            {
                if(endDate<=todayDate)
                {
                        this.endDateByTenant=this.tenancyEndDateYMD ;
                } else {
                    this.isFutureDateError=true;
                    this.isInValidEndDate = false;
                    this.isrenderAgreeButton = false;
                    isValid = false;
                    // this.displaySummarySection = false;
                }
            } else if(endMonth < todayMonth) {
                
                this.endDateByTenant=this.tenancyEndDateYMD ;
            } else {
                this.isFutureDateError=true;
                this.isInValidEndDate = false;
                this.isrenderAgreeButton = false;
                isValid = false;
                // this.displaySummarySection = false;
            }
        } else if(endYear < todayYear) {
            
            this.endDateByTenant=this.tenancyEndDateYMD ;
        } else {
            this.isFutureDateError=true;
            this.isrenderAgreeButton = false;
            this.isInValidEndDate = false;
            isValid = false;
        }

            
        if(isValidDate && isValid)
        {
            this.isrenderAgreeButton = true;
            if(this.totalDisputeItemAmount ==0 || this.depositAmountClaimedByAGLL==0){
                this.isDsputedAmtLessthanZeroBut3 = false;
                this.isDsputedAmtLessthanZeroBut4 = false;
            }
            else{
                this.isDsputedAmtLessthanZeroBut3 = true;
                this.isDsputedAmtLessthanZeroBut4 = true;
            }
            if(this.amountToTenantByAGLL == 0 || this.NoOfTenants == 1){
                this.isShowAgreeSplitButton = false;
            }
            else{
                this.isShowAgreeSplitButton = true;
            }
            
            
        } else {
        }
            
           
        this.myDate = this.tenancyEndDateDMY ;
        if(this.isFutureDateError ==false && this.isTenEndDateValid ==false && this.isInValidEndDate==false && isValid)
        {
            if(this.renewDeposit)
            {
                this.showRenewTenancyOptions = true;
            }
            else{
                this.showDeductionsBtns = true;
            }
            this.showotherSchemOptions = true;
        }
        else{
            this.showDeductionsBtns = false;
            this.showotherSchemOptions = false;
            this.showRenewTenancyOptions = false;
        }
        
    }

    propertyYesHandle()
    {
        let deductionsYesBtn = this.template.querySelector("[name='property_yes']");
        let deductionsNoBtn = this.template.querySelector("[name='property_no']");
        deductionsYesBtn.classList.add("active");
        deductionsNoBtn.classList.remove("active");
        this.showSubmitBtn = true;
        this.isDeductions = true;
    }
    propertyNoHandle()
    {
        let deductionsYesBtn = this.template.querySelector("[name='property_yes']");
        let deductionsNoBtn = this.template.querySelector("[name='property_no']");
        deductionsYesBtn.classList.remove("active");
        deductionsNoBtn.classList.add("active");
        this.showSubmitBtn = true;
        this.isDeductions = false;
    }
    submitBtn()
    {
        if(this.amtDetail.otherAmt >0 && this.OtherAmtReason.trim()=='')
        {
            this.otherAmtValidationError = true;
            this.OtherErrorMassage ='You must provide an explanation for the ‘Other’ amount.';
        }
        else if(this.OtherAmtReason.trim().length > 300)
        {
            this.otherAmtValidationError = true;
            this.OtherErrorMassage ='You are unable to enter more than 300 characters in this field.';

        }else{

            this.otherAmtValidationError = false;
            this.OtherErrorMassage ='';
        }
        let disputeItemTotalAmmount = parseFloat(this.amtDetail.cleanAmt)+parseFloat(this.amtDetail.damageAmt)+parseFloat(this.amtDetail.redecorationAmt)+parseFloat(this.amtDetail.gardeningAmt)+parseFloat(this.amtDetail.arrearsAmt)+parseFloat(this.amtDetail.otherAmt);
        
        let tennatTotalAmount =0;
        for(let i=0;i< this.editYesAllocation.length;i++)
        {
            tennatTotalAmount = parseFloat(tennatTotalAmount)+ parseFloat(this.editYesAllocation[i].value);
        }
        let totalAmountvalue = parseFloat(tennatTotalAmount)+parseFloat(disputeItemTotalAmmount);
        let validRequest = true;
        if(totalAmountvalue >0)
        {
            if(totalAmountvalue !=this.deposit.Deposit_Amount__c)
            {
                validRequest = false;
                this.depositNotReqError = true;
                this.depositNotReqErrorMsg ='Entered amount should be equal to deposit amount';
            }
            else{
                this.depositNotReqError = false;
            }

        }
        if(validRequest && !this.otherAmtValidationError)
        {
            console.log('line 567-----');
            this.disabledsubmitProNoReq = true;
            submitDepositNotRequired({isDeduction:this.isDeductions,depositRec:this.deposit,tenantListwithAmount:JSON.stringify(this.editYesAllocation),endDateByUser:this.endDateByTenant,diputeItemDetails: JSON.stringify(this.amtDetail),otherText: this.OtherAmtReason})
                .then(result => {
                    if(result=='Successfully executed')
                    {
                      var encodeId = btoa(this.depositID);
                        this[NavigationMixin.Navigate]({
                            type: 'standard__namedPage',
                                attributes: {
                                pageName: 'depositinsuredsummary',
                             },
                        state: {
                            depositId: encodeId,
                        // status: encodeName
                        },
                        }).then(url => {
                        window.open(url,"_blank");
                        }).catch(error => {
                            console.log('error in deposit Protection status' +error);
                        });
                    }
                    else{
                        console.log('result Error -> '+result);
                    }
                    
                })
                .catch(error => {
                    console.log('Line 672 Error -> ', error);
                })

        }
        
    }
    goToDepositSummaryPage()
    {
        var encodeId = btoa(this.depositID);
        this[NavigationMixin.Navigate]({
            type: 'standard__namedPage',
                attributes: {
                pageName: 'depositinsuredsummary',
                },
        state: {
            depositId: encodeId,
        // status: encodeName
        },
        }).then(url => {
        window.open(url,"_blank");
        }).catch(error => {
            console.log('error in deposit Protection status' +error);
        });

    }
    removeZero(event) {
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }
    restrictDecimal(event) {
        const t = event.target.value;
        const charCode = (event.which) ? event.which : event.keyCode;
        const decimalIndex = t.indexOf('.');
      
        // Allow only one decimal point
        if (charCode === 46 && decimalIndex !== -1) {
          event.preventDefault();
        }
      
        // Allow only digits and a decimal point
        else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
          event.preventDefault();
        }
      
        // Allow only up to two digits after the decimal point
        else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
          event.preventDefault();
        }
      }
      calculateRemainder(event){
        if(event.target.name==='cleaning'){
            // var clnAmt=parseFloat( event.target.value);
            this.amtDetail.cleanAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='DamageToProperty'){
            this.amtDetail.damageAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='redecorationAmt'){
            this.amtDetail.redecorationAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='gardeningAmt'){
            this.amtDetail.gardeningAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='arrearsAmt'){
            this.amtDetail.arrearsAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='otherAmt'){
            this.amtDetail.otherAmt=parseFloat( event.target.value).toFixed(2);
        }
        if(event.target.name==='otherText'){
            this.OtherAmtReason=event.target.value;
        }
    }
    calculateTenRemainder(event){
        var value = event.target.value;
        var value1 = event.target.label;
        var keyName = event.target.name;
        var tenAmt= Number(value);
        let jsonArrayData=[];
        jsonArrayData.push({key:keyName,value:tenAmt,name:value1});
            let indexfound= false;
            for(let i=0;i<this.editYesAllocation.length;i++)
            {
                if(this.editYesAllocation[i].key==keyName)
                {
                    indexfound= true;
                    this.editYesAllocation.splice(i, 1);
                    this.editYesAllocation.push(jsonArrayData[0]);
                }
            }
            if(!indexfound)
            {
                this.editYesAllocation.push(jsonArrayData[0]);
            }
        
    }
    submitOtherSchemeBtn()
    {
        if(this.otherSchemeName =='')
        {
            this.ShowotherSchemeError =true;
            this.otherSchemeErrorMsg ='Please let TDS Northern Ireland know the scheme the deposit is now protected with.';

        }
        else{
            this.ShowotherSchemeError =false;
            this.otherSchemeErrorMsg ='';
            submitOtherScheme({depositRec:this.deposit,endDateByUser:this.endDateByTenant,otherScheme: this.otherSchemeName})
                .then(result => {
                    if(result=='Successfully executed')
                    {
                        console.log('Successfully executed');

                        var encodeId = btoa(this.depositID);
                        this[NavigationMixin.Navigate]({
                            type: 'standard__namedPage',
                                attributes: {
                                pageName: 'depositinsuredsummary',
                             },
                        state: {
                            depositId: encodeId,
                        // status: encodeName
                        },
                        }).then(url => {
                            console.log('url-->>', url);
                        window.open(url,"_blank");
                        }).catch(error => {
                            console.log('error in deposit Protection status' +error);
                        });
                    }
                    else{
                        this.ShowotherSchemeError =true;
                        this.otherSchemeErrorMsg =result;
                        console.log('result Error 690 -> '+JSON.stringify(result));
                    }
                    
                })
                .catch(error => {
                    this.ShowotherSchemeError =true;
                    this.otherSchemeErrorMsg =error;
                    console.log('Line 672 Error -> ', JSON.stringify(error));
                })

        }

    }
    otherSchemeMyDeposits(){ 
        console.log('line 642');
        this.otherSchemeName ='mydeposits';
        let mydepositsli = this.template.querySelector('[data-id="mydepositsli"]');
        let lspni = this.template.querySelector('[data-id="lspni"]');
        let other = this.template.querySelector('[data-id="other"]');
        let unsure = this.template.querySelector('[data-id="unsure"]');
        console.log('line 645-->>'+mydepositsli);
        mydepositsli.classList.add("classli");
        lspni.classList.remove("classli");
        unsure.classList.remove("classli");
        unsure.classList.remove("classli");
        console.log('line 647-->>'+mydepositsli);



    }
    otherSchemeLPSNI(){ 
        this.otherSchemeName ='LPS NI';
        let mydepositsli = this.template.querySelector('[data-id="mydepositsli"]');
        let lspni = this.template.querySelector('[data-id="lspni"]');
        let other = this.template.querySelector('[data-id="other"]');
        let unsure = this.template.querySelector('[data-id="unsure"]');
        mydepositsli.classList.remove("classli");
        lspni.classList.add("classli");
        other.classList.remove("classli");
        unsure.classList.remove("classli");
    }
    otherSchemeOther(){ 
        this.otherSchemeName ='Other';
        let mydepositsli = this.template.querySelector('[data-id="mydepositsli"]');
        let lspni = this.template.querySelector('[data-id="lspni"]');
        let other = this.template.querySelector('[data-id="other"]');
        let unsure = this.template.querySelector('[data-id="unsure"]');
        mydepositsli.classList.remove("classli");
        lspni.classList.remove("classli");
        other.classList.add("classli");
        unsure.classList.remove("classli");

    }
    otherSchemeUnsure(){ 
        this.otherSchemeName ='Unsure';
        let mydepositsli = this.template.querySelector('[data-id="mydepositsli"]');
        let lspni = this.template.querySelector('[data-id="lspni"]');
        let other = this.template.querySelector('[data-id="other"]');
        let unsure = this.template.querySelector('[data-id="unsure"]');
        mydepositsli.classList.remove("classli");
        lspni.classList.remove("classli");
        other.classList.remove("classli");
        unsure.classList.add("classli");

    }
    submitRenewBtn(){
        this.disabledsubmitRenewBtn = true;
        submitRenewDeposit({depositRec:this.deposit,endDateByUser:this.endDateByTenant,customerType: this.customerType})
                .then(result => {
                    if(result.includes('Successfully executed'))
                    {
                        console.log('Successfully executed');
                        let newDepositID = result.substring(22);
                        console.log('newDepositID---->>'+newDepositID);
                        var encodeId = btoa(newDepositID);
                        if(this.customerType=='Pay as you go')
                        {
                            var en = btoa('Registered (not paid)');
                            this[NavigationMixin.Navigate]({
                                type: 'comm__namedPage',
                                attributes: {
                                    pageName: 'payInsuredDeposit'
                                },
                                state: {
                                    depositId: encodeId,
                                    status: en
                                },
                            }).then(url => {
                                console.log('url-->>', url);
                            window.open(url,"_blank");
                            }).catch(error => {
                                console.log('error in deposit Protection status' +error);
                            });

                        }
                        else{
                            this.showRenewMeassageForMIC= true;
                            setTimeout(() => {
                                this[NavigationMixin.Navigate]({
                                    type: 'standard__namedPage',
                                        attributes: {
                                        pageName: 'depositinsuredsummary',
                                     },
                                state: {
                                    depositId: encodeId,
                                // status: encodeName
                                },
                                }).then(url => {
                                    console.log('url-->>', url);
                                window.open(url,"_blank");
                                }).catch(error => {
                                    console.log('error in deposit Protection status' +error);
                                });

                            }, 5000);
                            

                        } 
                        
                    }
                    else{
                        this.ShowotherSchemeError =true;
                        this.otherSchemeErrorMsg =result;
                        console.log('result Error -> '+result);
                    }
                    
                })
                .catch(error => {
                    this.ShowotherSchemeError =true;
                    this.otherSchemeErrorMsg =error;
                    console.log('Line 672 Error -> ', error);
                })


    }
    showCustodialTab(event)
    {
        if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
 
            event.preventDefault();
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'viewbranchuser'
                },
                state: {
                    branchRecId: btoa(this.branchId),
                    showBranch: window.btoa('false'),
                    pagetype: btoa('Custodial')
                }
 
            });
        }
        else{
            console.log('redirected to normal page'+location);
                this[NavigationMixin.Navigate]({
                    type: 'standard__namedPage',
                    attributes: {
                        pageName: 'home'
                    },
                    state: {
                        pagetype: btoa('Custodial')
                    }
                });
        }
    }

    showInsuredTab(event)
    {
        if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
 
            event.preventDefault();
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'viewbranchuser'
                },
                state: {
                    branchRecId: btoa(this.branchId),
                    showBranch: window.btoa('false'),
                    pagetype: btoa('Insured')
                }
 
            });
        }
        else{
            console.log('redirected to normal page'+location);
                this[NavigationMixin.Navigate]({
                    type: 'standard__namedPage',
                    attributes: {
                        pageName: 'home'
                    },
                    state: {
                        pagetype: btoa('Insured')
                    }
                });
        }
    }

}