import { LightningElement, track, wire, api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getclaimdetailsInTenantEvidence from '@salesforce/apex/EI_EWC_NI_TenantEvidenceGatheringClass.getclaimdetailsInTenantEvidence';
import getLoggedUserAccId from '@salesforce/apex/EI_EWC_NI_TenantEvidenceGatheringClass.getLoggedUserAccId';

export default class Ei_NI_ViewEvidence_Custodial extends NavigationMixin(LightningElement) {

	ew_arrow_dropleft = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
	md_arrow_dropleft = NI_Theme + '/assets/img/md-arrow-dropleft.png';
	warning_icon = NI_Theme + '/assets/img/warning_icon.png';
	feather_download = NI_Theme + '/assets/img/feather-download.svg';
	question_circle = NI_Theme + '/assets/img/question-circle.png';

	pound_icon = NI_Theme + '/assets/img/pound_icon.png';

	@track branchId;
	@track accessCode;
	@track ClaimsDetails = [];
	@track caseParticipants = {};
	@track evidenceAttachments = [];
	@track disputeItems = [];
	@track AGLLandTTCalaimDetails = [];
	@track currentItem = 0;
	@track ViewContinue = true;
	@track keyDocuments = false;
	@track isShowPaymentOfRentKey;
	@track showClaimBreakdown = false;
	@track showAllClaimAgreed = false;
	@track showAdditionalComments = false;
	@track showReviewsubmission = false;
	@track showCancelDispute = false;
	@track cancelFromPage = '';
	@track isHoldingDisputedFunds = false;
	@track isBreakdownContbtnDisable = false;
	@track allFieldsRequiredErrorMsg;
	@track showDetails = true;
	@track loggedinUserProfileName;
	@track isAgentViewing = false;
	@track isTTRespondedEviGathering = false;

	// get isTTRespondedEviGathering(){
	//    if(this.ClaimsDetails.TT_respond_evidence_gathering__c && this.ClaimsDetails.AGLL_Respond_Evidance_Gathering__c)
	//    {
	//       return true;
	//    }else{
	//       return false;
	//    }
	// }

	preventBack() {
		console.log('preventBack');
		window.history.forward();
	}

	connectedCallback() {
		setTimeout(() => { window.history.forward(); }, 0);

		console.log('evidence gather EWC AGLL => ');
		const queryString = window.location.search;
		console.log('queryString => ' + queryString);
		const urlParams = new URLSearchParams(queryString);
		console.log('urlParams => ' + urlParams);
		const depositRecId = urlParams.get('depositId');
		console.log('depositRecId => ' + depositRecId);
		this.depositRecId = window.atob(depositRecId);
		console.log('depositRecId convert into atob => ' + this.depositRecId);

		const branch = urlParams.get('branchRecId');
		if (branch != null && branch != '' && branch != undefined) {
			this.branchId = window.atob(branch);
		}

		getclaimdetailsInTenantEvidence({ depositid: this.depositRecId }).then(result => {

			this.showDetails = true;
			console.log('getclaimdetailsInTenantEvidence result => ' + JSON.stringify(result.claim));
			let caseDetails = result.claim; //result[0].claim;
			this.caseParticipants = result.caseParticipants;

			this.evidenceAttachments = result.evidAttach; //result[0].evidAttach; //caseDetails.Evidence_Attachments__r;

			this.ClaimsDetails['Total_Protected_Amount__c'] = caseDetails.Total_Protected_Amount__c;
			this.isHoldingDisputedFunds = caseDetails.Amount_of_Disputed_Funds_Received__c == 0 ? false : true;
			this.ClaimsDetails['Status'] = caseDetails.Case_Statuses__c;
			this.ClaimsDetails['agllName'] = caseDetails.Account.Name;

			this.ClaimsDetails['Agreedamountpaidtotenant'] = parseFloat(caseDetails.Agreed_amount_paid_to_tenant__c).toFixed(2);
			this.ClaimsDetails['AGLL_Respond_Evidance_Gathering__c'] = caseDetails.AGLL_Respond_Evidance_Gathering__c;
			this.ClaimsDetails['TT_respond_evidence_gathering__c'] = caseDetails.TT_respond_evidence_gathering__c;
			this.ClaimsDetails['totalAgreedByAGLL'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c).toFixed(2);
			this.ClaimsDetails['totalAgreedByTT'] = parseFloat(caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
			this.ClaimsDetails['Agreed_amount_from_AGLL_to_TT__c'] = parseFloat(caseDetails.Agreed_amount_from_AGLL_to_TT__c).toFixed(2);
			this.ClaimsDetails['totalAmountRepaid'] = parseFloat(caseDetails.Agreed_amount_paid_to_tenant__c + caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
			this.ClaimsDetails['remainDisputeAmount'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c - caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
			this.ClaimsDetails['Id'] = caseDetails.Id;
			this.ClaimsDetails['Evidence_Attachments__r'] = caseDetails.Evidence_Attachments__r;
			this.ClaimsDetails['Dispute_Responded_By__c'] = caseDetails.Dispute_Responded_By__c;
			this.ClaimsDetails['Additional_comments_AGLL__c'] = caseDetails.Additional_comments_AGLL__c;
			this.ClaimsDetails['Additional_comments_TT__c'] = caseDetails.Additional_comments_TT__c;

			console.log('63' + caseDetails.Consent_box_TT__c);
			if (caseDetails.Consent_box_TT__c == 'Yes') {
				this.ClaimsDetails['Consent_box_TT__c'] = true;
			}
			else {
				this.ClaimsDetails['Consent_box_TT__c'] = false;
			}
			console.log('70' + this.ClaimsDetails['Consent_box_TT__c']);
			if (caseDetails.Claim_exceed__c == 'Yes' || caseDetails.Claim_exceed__c == 'No') {
				if (caseDetails.Claim_exceed__c == 'Yes') {
					this.ClaimsDetails['claimExceed'] = true;
				}
				else if (caseDetails.Claim_exceed__c == 'No') {
					this.ClaimsDetails['claimExceed'] = false;
				}
			}
			this.ClaimsDetails['claimExceedsComment'] = caseDetails.Claim_exceeds_comment_AGLL__c;

			if (caseDetails.Tenant_obligations__c == 'Yes' || caseDetails.Tenant_obligations__c == 'No') {
				this.ClaimsDetails['isTenantObligationsValue'] = true;
				if (caseDetails.Tenant_obligations__c == 'Yes') {
					this.ClaimsDetails['TenantObligations'] = true;
				}
				else if (caseDetails.Tenant_obligations__c == 'No') {
					this.ClaimsDetails['TenantObligations'] = false;
				}
			}
			if (caseDetails.inventorycheck_in_report_AGLL__c == 'Yes' || caseDetails.inventorycheck_in_report_AGLL__c == 'No') {
				this.ClaimsDetails['isInventorycheckValue'] = true;
				if (caseDetails.inventorycheck_in_report_AGLL__c == 'Yes') {
					this.ClaimsDetails['inventorycheck'] = true;
				}
				else if (caseDetails.inventorycheck_in_report_AGLL__c == 'No') {
					this.ClaimsDetails['inventorycheck'] = false;
				}
			}
			if (caseDetails.check_out_report_AGLL__c == 'Yes' || caseDetails.check_out_report_AGLL__c == 'No') {
				this.ClaimsDetails['isCheckoutReportValue'] = true;
				if (caseDetails.check_out_report_AGLL__c == 'Yes') {
					this.ClaimsDetails['checkoutReport'] = true;
				}
				else if (caseDetails.check_out_report_AGLL__c == 'No') {
					this.ClaimsDetails['checkoutReport'] = false;
				}
			}
			if (caseDetails.Rent_statement_AGLL__c == 'Yes' || caseDetails.Rent_statement_AGLL__c == 'No') {
				this.ClaimsDetails['isRentStatementValue'] = true;
				if (caseDetails.Rent_statement_AGLL__c == 'Yes') {
					this.ClaimsDetails['rentStatement'] = true;
				}
				else if (caseDetails.Rent_statement_AGLL__c == 'No') {
					this.ClaimsDetails['rentStatement'] = false;
				}
			}

			var respondDate = new Date(caseDetails.Respond_Date__c);
			if (respondDate != null || respondDate != undefined || respondDate != '') {
				var checkdate = respondDate.getDate().toString().padStart(2, "0");;
				var checkmonth = (respondDate.getMonth() + 1).toString().padStart(2, "0");
				var checkyear = respondDate.getFullYear();
				var newDate = checkdate + '/' + checkmonth + '/' + checkyear;
				this.ClaimsDetails['respondDate'] = newDate;
			}
			let today = new Date();
			console.log('respond date => ' + respondDate);
			console.log('today date => ' + today);
			const yyyy = today.getFullYear();
			const mm = today.getMonth() + 1; // Months start at 0!
			const dd = today.getDate();
			console.log('Deadline Passed => ' + (respondDate < today));

			if (this.ClaimsDetails.Status != 'Evidence gathering - tenant' //respondDate < today 
				&& this.ClaimsDetails.TT_respond_evidence_gathering__c && this.ClaimsDetails.AGLL_Respond_Evidance_Gathering__c) {
				this.isTTRespondedEviGathering = true;
			} else {
				this.isTTRespondedEviGathering = false;
			}

			let disputeItems = [];
			disputeItems.push({ key: 'Cleaning' });
			disputeItems.push({ key: 'Damage' });
			disputeItems.push({ key: 'Redecoration' });
			disputeItems.push({ key: 'Gardening' });
			disputeItems.push({ key: 'Rent arrears' });
			disputeItems.push({ key: 'Other' });

			let claimItems = result.disputeItems; //caseDetails.Dispute_Items__r;

			if (claimItems) {
				const rentItem = claimItems.find(item => item.Type__c == 'Rent');
				if (rentItem) {
					this.isShowPaymentOfRentKey = true;
				} else {
					this.isShowPaymentOfRentKey = false;
				}
			}

			console.log('disputeItems.length before');
			for (let i = 0; i < disputeItems.length; i++) {
				console.log('disputeItems.length after');
				let flag = false;
				console.log('claimItems.length before');

				for (let j = 0; j < claimItems.length; j++) {
					console.log('claimItems.length after');
					if (disputeItems[i].key.includes(claimItems[j].Type__c)) {
						flag = true;
						disputeItems[i]['isOther'] = claimItems[j].Type__c == 'Other' ? claimItems[j].Agreed_by_AGLL__c.toFixed(2) + '\n' + claimItems[j].Other_Reason__c : '';
						disputeItems[i]['requestedByAGLL'] = claimItems[j].Agreed_by_AGLL__c.toFixed(2);
						disputeItems[i]['agreedbyTenant'] = claimItems[j].Agreed_by_Tenant__c;
						disputeItems[i]['amountInDispute'] = claimItems[j].Agreed_by_AGLL__c - claimItems[j].Agreed_by_Tenant__c;
						disputeItems[i][claimItems[j].Type__c] = true;
						disputeItems[i]['isShow'] = i == 0 ? true : false;

						disputeItems[i]['Id'] = claimItems[j].Id;

						disputeItems[i]['Claim_description_for_cleaning_agll__c'] = claimItems[j].Claim_description_for_cleaning_agll__c;
						disputeItems[i]['Supporting_clause_cleaning_agll__c'] = claimItems[j].Supporting_clause_cleaning_agll__c;
						disputeItems[i]['Evidence_at_tenancystart_cleaning_agll__c'] = claimItems[j].Evidence_at_tenancystart_cleaning_agll__c;
						disputeItems[i]['Evidence_at_tenancy_end_for_cleaning_agl__c'] = claimItems[j].Evidence_at_tenancy_end_for_cleaning_agl__c;
						disputeItems[i]['Supporting_evidence_for_cleaning_agll__c'] = claimItems[j].Supporting_evidence_for_cleaning_agll__c;

						disputeItems[i]['Claim_description_for_damage_agll__c'] = claimItems[j].Claim_description_for_damage_agll__c;
						disputeItems[i]['Supporting_clause_damage_agll__c'] = claimItems[j].Supporting_clause_damage_agll__c;
						disputeItems[i]['Evidence_at_tenancystart_damage_agll__c'] = claimItems[j].Evidence_at_tenancystart_damage_agll__c;
						disputeItems[i]['Evidence_at_tenancy_end_for_damage_agll__c'] = claimItems[j].Evidence_at_tenancy_end_for_damage_agll__c;
						disputeItems[i]['Supporting_evidence_for_damage_agll__c'] = claimItems[j].Supporting_evidence_for_damage_agll__c;

						disputeItems[i]['Claim_description_for_redecoration_agll__c'] = claimItems[j].Claim_description_for_redecoration_agll__c;
						disputeItems[i]['Supporting_clause_redecoration_agll__c'] = claimItems[j].Supporting_clause_redecoration_agll__c;
						disputeItems[i]['Evidence_at_tenancystart_redecoration_ag__c'] = claimItems[j].Evidence_at_tenancystart_redecoration_ag__c;
						disputeItems[i]['Evidence_at_tenancyend_redecoration_agll__c'] = claimItems[j].Evidence_at_tenancyend_redecoration_agll__c;
						disputeItems[i]['Supporting_evidence_for_redecoration_agl__c'] = claimItems[j].Supporting_evidence_for_redecoration_agl__c;

						disputeItems[i]['Claim_description_for_gardening_agll__c'] = claimItems[j].Claim_description_for_gardening_agll__c;
						disputeItems[i]['Supporting_clause_gardening_agll__c'] = claimItems[j].Supporting_clause_gardening_agll__c;
						disputeItems[i]['Evidence_at_tenancystart_gardening_agll__c'] = claimItems[j].Evidence_at_tenancystart_gardening_agll__c;
						disputeItems[i]['Evidence_at_tenancyend_gardening_agll__c'] = claimItems[j].Evidence_at_tenancyend_gardening_agll__c;
						disputeItems[i]['Supporting_evidence_for_gardening__c'] = claimItems[j].Supporting_evidence_for_gardening__c;

						disputeItems[i]['Rent_arrears_description_agll__c'] = claimItems[j].Rent_arrears_description_agll__c;
						disputeItems[i]['Was_the_property_re_let_rent_agll__c'] = claimItems[j].Was_the_property_re_let_rent_agll__c;
						disputeItems[i]['Supporting_clause_rent_agll__c'] = claimItems[j].Supporting_clause_rent_agll__c;
						disputeItems[i]['Supporting_evidence_for_rent_agll__c'] = claimItems[j].Supporting_evidence_for_rent_agll__c;

						disputeItems[i]['Claim_breakdown_other_AGLL__c'] = claimItems[j].Claim_breakdown_other_AGLL__c;
						disputeItems[i]['Supporting_clause_other_agll__c'] = claimItems[j].Supporting_clause_other_agll__c;
						disputeItems[i]['Supporting_evidence_for_other_agll__c'] = claimItems[j].Supporting_evidence_for_other_agll__c;

						if (claimItems[j].Is_Tenant_Agree__c == 'Yes' || claimItems[j].Is_Tenant_Agree__c == 'No') {
							disputeItems[i]['Is_Tenant_Agree__c_value'] = true;
							disputeItems[i]['Is_Tenant_Agree__c'] = claimItems[j].Is_Tenant_Agree__c == 'Yes' ? true : false;
						} else {
							disputeItems[i]['Is_Tenant_Agree__c_value'] = false;
						}
						disputeItems[i]['Tenant_Disagree_comment__c'] = claimItems[j].Tenant_Disagree_comment__c;

						if (claimItems[j].Is_Tenant_Upload_Evidence__c == 'Yes' || claimItems[j].Is_Tenant_Upload_Evidence__c == 'No') {
							disputeItems[i]['Is_Tenant_Upload_Evidence__c_value'] = true;
							disputeItems[i]['Is_Tenant_Upload_Evidence__c'] = claimItems[j].Is_Tenant_Upload_Evidence__c == 'Yes' ? true : false;
							const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == claimItems[j].Type__c && evi.User_Type__c == 'Tenant');
							if (eviAttachment) {
								disputeItems[i]['evidence' + claimItems[j].Type__c] = true;
							} else {
								disputeItems[i]['evidence' + claimItems[j].Type__c] = false;
							}
						} else {
							disputeItems[i]['Is_Tenant_Upload_Evidence__c_value'] = false;
						}
					}
				}
				if (flag == false) {
					disputeItems.splice(i, 1);
					i--;
				}

			}
			this.disputeItems = disputeItems;

			let AGLLandTTCalaimDetails = [];
			AGLLandTTCalaimDetails.push({ key: 'CleaningAGLL' });
			//AGLLandTTCalaimDetails.push({key:'CleaningTT'});
			AGLLandTTCalaimDetails.push({ key: 'DamageAGLL' });
			//AGLLandTTCalaimDetails.push({key:'DamageTT'});
			AGLLandTTCalaimDetails.push({ key: 'RedecorationAGLL' });
			//AGLLandTTCalaimDetails.push({key:'RedecorationTT'});
			AGLLandTTCalaimDetails.push({ key: 'GardeningAGLL' });
			//GLLandTTCalaimDetails.push({key:'GardeningTT'});
			AGLLandTTCalaimDetails.push({ key: 'RentAGLL' });
			//AGLLandTTCalaimDetails.push({key:'RentTT'});
			AGLLandTTCalaimDetails.push({ key: 'OtherAGLL' });
			//AGLLandTTCalaimDetails.push({key:'OtherTT'});
			for (let i = 0; i < AGLLandTTCalaimDetails.length; i++) {
				console.log('AGLLandTTCalaimDetails.length after');
				let flag = false;
				console.log('claimItems.length before');

				for (let j = 0; j < claimItems.length; j++) {
					console.log('claimItems.length after');
					if (AGLLandTTCalaimDetails[i].key.includes(claimItems[j].Type__c)) {
						flag = true;
						AGLLandTTCalaimDetails[i]['isOther'] = claimItems[j].Type__c == 'Other' ? claimItems[j].Agreed_by_AGLL__c.toFixed(2) + '\n' + claimItems[j].Other_Reason__c : '';
						AGLLandTTCalaimDetails[i]['requestedByAGLL'] = claimItems[j].Agreed_by_AGLL__c.toFixed(2);
						AGLLandTTCalaimDetails[i]['agreedbyTenant'] = claimItems[j].Agreed_by_Tenant__c;
						AGLLandTTCalaimDetails[i]['amountInDispute'] = claimItems[j].Agreed_by_AGLL__c - claimItems[j].Agreed_by_Tenant__c;
						AGLLandTTCalaimDetails[i][AGLLandTTCalaimDetails[i].key] = true;
						AGLLandTTCalaimDetails[i]['isShow'] = i == 0 ? true : false;
						AGLLandTTCalaimDetails[i]['type'] = claimItems[j].Type__c;

						AGLLandTTCalaimDetails[i]['Id'] = claimItems[j].Id;

						AGLLandTTCalaimDetails[i]['Claim_description_for_cleaning_agll__c'] = claimItems[j].Claim_description_for_cleaning_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_cleaning_agll__c'] = claimItems[j].Supporting_clause_cleaning_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancystart_cleaning_agll__c'] = claimItems[j].Evidence_at_tenancystart_cleaning_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancy_end_for_cleaning_agl__c'] = claimItems[j].Evidence_at_tenancy_end_for_cleaning_agl__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_cleaning_agll__c'] = claimItems[j].Supporting_evidence_for_cleaning_agll__c;

						AGLLandTTCalaimDetails[i]['Claim_description_for_damage_agll__c'] = claimItems[j].Claim_description_for_damage_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_damage_agll__c'] = claimItems[j].Supporting_clause_damage_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancystart_damage_agll__c'] = claimItems[j].Evidence_at_tenancystart_damage_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancy_end_for_damage_agll__c'] = claimItems[j].Evidence_at_tenancy_end_for_damage_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_damage_agll__c'] = claimItems[j].Supporting_evidence_for_damage_agll__c;

						AGLLandTTCalaimDetails[i]['Claim_description_for_redecoration_agll__c'] = claimItems[j].Claim_description_for_redecoration_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_redecoration_agll__c'] = claimItems[j].Supporting_clause_redecoration_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancystart_redecoration_ag__c'] = claimItems[j].Evidence_at_tenancystart_redecoration_ag__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancyend_redecoration_agll__c'] = claimItems[j].Evidence_at_tenancyend_redecoration_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_redecoration_agl__c'] = claimItems[j].Supporting_evidence_for_redecoration_agl__c;

						AGLLandTTCalaimDetails[i]['Claim_description_for_gardening_agll__c'] = claimItems[j].Claim_description_for_gardening_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_gardening_agll__c'] = claimItems[j].Supporting_clause_gardening_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancystart_gardening_agll__c'] = claimItems[j].Evidence_at_tenancystart_gardening_agll__c;
						AGLLandTTCalaimDetails[i]['Evidence_at_tenancyend_gardening_agll__c'] = claimItems[j].Evidence_at_tenancyend_gardening_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_gardening__c'] = claimItems[j].Supporting_evidence_for_gardening__c;

						AGLLandTTCalaimDetails[i]['Rent_arrears_description_agll__c'] = claimItems[j].Rent_arrears_description_agll__c;
						AGLLandTTCalaimDetails[i]['Was_the_property_re_let_rent_agll__c'] = claimItems[j].Was_the_property_re_let_rent_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_rent_agll__c'] = claimItems[j].Supporting_clause_rent_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_rent_agll__c'] = claimItems[j].Supporting_evidence_for_rent_agll__c;

						AGLLandTTCalaimDetails[i]['Claim_breakdown_other_AGLL__c'] = claimItems[j].Claim_breakdown_other_AGLL__c;
						AGLLandTTCalaimDetails[i]['Supporting_clause_other_agll__c'] = claimItems[j].Supporting_clause_other_agll__c;
						AGLLandTTCalaimDetails[i]['Supporting_evidence_for_other_agll__c'] = claimItems[j].Supporting_evidence_for_other_agll__c;

						AGLLandTTCalaimDetails[i]['TenantEvidences'] = true;
						if (claimItems[j].Is_Tenant_Agree__c == 'Yes' || claimItems[j].Is_Tenant_Agree__c == 'No') {
							AGLLandTTCalaimDetails[i]['Is_Tenant_Agree__c_value'] = true;
							AGLLandTTCalaimDetails[i]['Is_Tenant_Agree__c'] = claimItems[j].Is_Tenant_Agree__c == 'Yes' ? true : false;
						} else {
							AGLLandTTCalaimDetails[i]['Is_Tenant_Agree__c_value'] = false;
						}
						AGLLandTTCalaimDetails[i]['Tenant_Disagree_comment__c'] = claimItems[j].Tenant_Disagree_comment__c;

						if (claimItems[j].Is_Tenant_Upload_Evidence__c == 'Yes' || claimItems[j].Is_Tenant_Upload_Evidence__c == 'No') {
							AGLLandTTCalaimDetails[i]['Is_Tenant_Upload_Evidence__c_value'] = true;
							AGLLandTTCalaimDetails[i]['Is_Tenant_Upload_Evidence__c'] = claimItems[j].Is_Tenant_Upload_Evidence__c == 'Yes' ? true : false;
							const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == claimItems[j].Type__c && evi.User_Type__c == 'Tenant');
							if (eviAttachment) {
								AGLLandTTCalaimDetails[i]['evidence' + claimItems[j].Type__c] = true;
							} else {
								AGLLandTTCalaimDetails[i]['evidence' + claimItems[j].Type__c] = false;
							}
						} else {
							AGLLandTTCalaimDetails[i]['Is_Tenant_Upload_Evidence__c_value'] = false;
						}

						if (AGLLandTTCalaimDetails[i].key.includes('AGLL')) {
							if (AGLLandTTCalaimDetails[i].key.includes('Cleaning') || AGLLandTTCalaimDetails[i].key.includes('Damage')
								|| AGLLandTTCalaimDetails[i].key.includes('Redecoration') || AGLLandTTCalaimDetails[i].key.includes('Gardening')) {
								AGLLandTTCalaimDetails[i]['AGLL_clean_damag_redecr_garden_greyText'] = true;
							}
							else if (AGLLandTTCalaimDetails[i].key.includes('Rent')) {
								AGLLandTTCalaimDetails[i]['AGLL_rent_greyText'] = true;
							}
							else if (AGLLandTTCalaimDetails[i].key.includes('Other')) {
								AGLLandTTCalaimDetails[i]['AGLL_other_greyText'] = true;
							}
						}
						else if (AGLLandTTCalaimDetails[i].key.includes('TT')) {
							if (AGLLandTTCalaimDetails[i].key.includes('Cleaning') || AGLLandTTCalaimDetails[i].key.includes('Damage')
								|| AGLLandTTCalaimDetails[i].key.includes('Redecoration') || AGLLandTTCalaimDetails[i].key.includes('Gardening')
								|| AGLLandTTCalaimDetails[i].key.includes('Other')) {
								AGLLandTTCalaimDetails[i]['TT_clean_damag_redecr_garden_other_greyText'] = true;
							}
							else if (AGLLandTTCalaimDetails[i].key.includes('Rent')) {
								AGLLandTTCalaimDetails[i]['TT_rent_greyText'] = true;
							}
						}
					}
				}
				if (flag == false) {
					AGLLandTTCalaimDetails.splice(i, 1);
					i--;
				}

			}
			this.AGLLandTTCalaimDetails = AGLLandTTCalaimDetails;

			console.log('this.AGLLandTTCalaimDetails => ' + JSON.stringify(this.AGLLandTTCalaimDetails));
		}).catch(error => {
			console.log('getclaimdetailsInTenantEvidence error => ' + JSON.stringify(error), error);
		});

		getLoggedUserAccId().then(result => {
			console.log('getLoggedUserAccId result -->' + result);
			console.log('getLoggedUserAccId result.accId -->' + result.AccountId);
			if (result != null) {
				this.loggedinUserProfileName = result.Profile.Name;
				if (this.loggedinUserProfileName == 'NI_Agent' || this.loggedinUserProfileName == 'NI_Landlord' || this.loggedinUserProfileName == 'NI_Head_Office_User' || this.loggedinUserProfileName == 'NI_ Branch Users') {
					this.isAgentViewing = true;
				} else {
					this.isAgentViewing = false;
				}
			}
		}).catch(error => {
			console.log('getLoggedUserAccId Error-->' + JSON.stringify(error));
			console.log('getLoggedUserAccId Error-->' + (error));
		});
	}

	/* handlegotoDepositSummary() {
	   if (this.isAgentViewing == true) {
		  this[NavigationMixin.Navigate]({
			 type: 'standard__namedPage',
			 attributes: {
				pageName: 'depositSummary',
			 },
			 state: {
				depositId: btoa(this.depositRecId)
			 },
		  }).then(url => {
			 window.open(url, "_self");
		  });
	   } else {
		  this[NavigationMixin.Navigate]({
			 type: 'standard__namedPage',
			 attributes: {
				pageName: 'deposit-summary',
			 },
			 state: {
				c__depositRecId: btoa(this.depositRecId)
			 },
		  }).then(url => {
			 window.open(url, "_self");
		  });
	   }
 
	} */

	handlegotoDepositSummary(event) {
		console.log('isAgentViewing>>>'+this.isAgentViewing);
		let currentURL = window.location.href;
		console.log('currentURL => ' + currentURL);
		let homeURL = currentURL.split('/ni/s');
		console.log('homeURL => ' + homeURL);
		let redirectToURL = '';
		if (this.isAgentViewing == true) {
			if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
				console.log('BranchId Present');
				redirectToURL = homeURL[0]+'/ni/s/depositSummary?depositId='+btoa(this.depositRecId)+'&branchRecId='+window.btoa(this.branchId)+'&showBranchPage='+window.btoa('false');
				/* this[NavigationMixin.Navigate]({
					type: 'standard__namedPage',
					attributes: {
						pageName: 'depositSummary',
					},
					state: {
						depositId: btoa(this.depositRecId),
						branchRecId: btoa(this.branchId),
						showBranch : btoa('false')
					}
				}); */
			} else {
				redirectToURL = homeURL[0] + '/ni/s/depositSummary?depositId=' + btoa(this.depositRecId);
			}
		} else {
			redirectToURL = homeURL[0] + '/ni/s/deposit-summary?c__depositRecId=' + btoa(this.depositRecId);
		}
		console.log('redirectToURL => ' + redirectToURL);
		window.location.href = redirectToURL;
	}

	handleGoBackStep(event) {
		let title = event.target.title;
		if (title == 'viewContinue') {
			this.ViewContinue = true;
			this.keyDocuments = false;
		}
		else if (title == 'claimBreakdown') {
			this.keyDocuments = false;
			this.showClaimBreakdown = true;
			this.showAdditionalComments = false;
			setTimeout(() => {
				console.log('isvalue true ' + this.AGLLandTTCalaimDetails[this.currentItem].Is_Tenant_Agree__c_value);
				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c_value']) {

					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('istenantagreeyes => ' + this.template.querySelector('.istenantagreeyes'));
						this.template.querySelector('.istenantagreeyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('istenantagreeno => ' + this.template.querySelector('.istenantagreeno'));
						this.template.querySelector('.istenantagreeno').classList.add('active');
					}
				}

				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c_value']) {

					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidyes => ' + this.template.querySelector('.isttuploadevidyes'));
						this.template.querySelector('.isttuploadevidyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidno => ' + this.template.querySelector('.isttuploadevidno'));
						this.template.querySelector('.isttuploadevidno').classList.add('active');
					}
				}
			}, 100);
		}
		else if (title == 'additionalComments') {
			this.showClaimBreakdown = false;
			this.showAdditionalComments = true;
			this.showReviewsubmission = false;
		}
		console.log('scroll to top');
		const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
		topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
	}

	handlegotoshowClaimBreakdown() {
		console.log("ClaimsDetails.Consent_box_TT__c => " + this.ClaimsDetails.Consent_box_TT__c);
		// if(this.ClaimsDetails.Consent_box_TT__c){
		this.ViewContinue = false;
		this.showClaimBreakdown = true;
		this.showAdditionalComments = false;
		console.log('handlegotoshowClaimBreakdown end ' + this.showClaimBreakdown);

		console.log('scroll to top');
		const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
		topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
		// }
	}

	handleChangeEviAttachmentList(event) {
		console.log('Value from Child LWC is ' + JSON.stringify(event.detail));
		var attachmensts = [];
		if (event.detail.type == 'upload') {
			// alert("upload file type" + attachmensts.length);
			let aviAttachment = event.detail.evidanceAttachment;
			attachmensts = [...this.evidenceAttachments, aviAttachment];
			//attachmensts.push(aviAttachment);

			// alert("push attachment" + attachmensts.length);
			this.evidenceAttachments = attachmensts;
			// alert("Add again attachemnt");
		} else if (event.detail.type == 'delete') {
			console.log('event.detail.deletedAttachment.Id => ' + event.detail.deletedAttachment.Id);
			for (let index in this.evidenceAttachments) {
				console.log('this.evidenceAttachments[index].Id => ' + this.evidenceAttachments[index].Id);

				if (this.evidenceAttachments[index].Id != event.detail.deletedAttachment.Id) {
					attachmensts.push(this.evidenceAttachments[index]);
				}
			}
			this.evidenceAttachments = attachmensts;
		}

		const eviAttachment = this.evidenceAttachments.find(evi =>
			evi.Evidence_Categories__c == this.AGLLandTTCalaimDetails[this.currentItem].type && evi.User_Type__c == 'Tenant'
		);
		if (eviAttachment) {
			this.AGLLandTTCalaimDetails[this.currentItem]['evidence' + this.AGLLandTTCalaimDetails[this.currentItem].type] = true;
		} else {
			this.AGLLandTTCalaimDetails[this.currentItem]['evidence' + this.AGLLandTTCalaimDetails[this.currentItem].type] = false;
		}
		console.log('this.evidenceAttachments after => ' + JSON.stringify(this.evidenceAttachments));

	}

	goToPreviousItem(event) {
		console.log('goToPreviousItem currentItem => ' + this.currentItem);
		if (this.currentItem == 0) {
			this.showClaimBreakdown = false;
			this.ViewContinue = true;
		} else {
			this.currentItem--;
			this.AGLLandTTCalaimDetails[this.currentItem].isShow = true;
			this.AGLLandTTCalaimDetails[this.currentItem + 1].isShow = false;
			setTimeout(() => {
				console.log('isvalue true ' + this.AGLLandTTCalaimDetails[this.currentItem].Is_Tenant_Agree__c_value);

				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c_value']) {
					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('exceedclaimyes => ' + this.template.querySelector('.exceedclaimyes'));
						this.template.querySelector('.istenantagreeyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('exceedclaimno => ' + this.template.querySelector('.exceedclaimno'));
						this.template.querySelector('.istenantagreeno').classList.add('active');
					}
				}

				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c_value']) {

					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidyes => ' + this.template.querySelector('.isttuploadevidyes'));
						this.template.querySelector('.isttuploadevidyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidno => ' + this.template.querySelector('.isttuploadevidno'));
						this.template.querySelector('.isttuploadevidno').classList.add('active');
					}
				}
			}, 100);
		}
		console.log('scroll to top');
		const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
		topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
	}
	goToNextItem(event) {
		if (!this.AGLLandTTCalaimDetails[this.currentItem].key.includes('AGLL')) {
			let calimItems = [];
			for (let i in this.disputeItems) {
				let claim = {
					'Id': this.disputeItems[i].Id,
					'Is_Tenant_Agree__c': this.disputeItems[i].Is_Tenant_Agree__c_value ? this.disputeItems[i].Is_Tenant_Agree__c ? 'Yes' : 'No' : null,
					'Tenant_Disagree_comment__c': this.disputeItems[i].Tenant_Disagree_comment__c,
					'Is_Tenant_Upload_Evidence__c': this.disputeItems[i].Is_Tenant_Upload_Evidence__c_value ? this.disputeItems[i].Is_Tenant_Upload_Evidence__c ? 'Yes' : 'No' : null,

					'Claim_description_for_cleaning_agll__c': this.disputeItems[i].Claim_description_for_cleaning_agll__c,
					'Supporting_clause_cleaning_agll__c': this.disputeItems[i].Supporting_clause_cleaning_agll__c,
					'Evidence_at_tenancystart_cleaning_agll__c': this.disputeItems[i].Evidence_at_tenancystart_cleaning_agll__c,
					'Evidence_at_tenancy_end_for_cleaning_agl__c': this.disputeItems[i].Evidence_at_tenancy_end_for_cleaning_agl__c,
					'Supporting_evidence_for_cleaning_agll__c': this.disputeItems[i].Supporting_evidence_for_cleaning_agll__c,

					'Claim_description_for_damage_agll__c': this.disputeItems[i].Claim_description_for_damage_agll__c,
					'Supporting_clause_damage_agll__c': this.disputeItems[i].Supporting_clause_damage_agll__c,
					'Evidence_at_tenancystart_damage_agll__c': this.disputeItems[i].Evidence_at_tenancystart_damage_agll__c,
					'Evidence_at_tenancy_end_for_damage_agll__c': this.disputeItems[i].Evidence_at_tenancy_end_for_damage_agll__c,
					'Supporting_evidence_for_damage_agll__c': this.disputeItems[i].Supporting_evidence_for_damage_agll__c,

					'Claim_description_for_redecoration_agll__c': this.disputeItems[i].Claim_description_for_redecoration_agll__c,
					'Supporting_clause_redecoration_agll__c': this.disputeItems[i].Supporting_clause_redecoration_agll__c,
					'Evidence_at_tenancystart_redecoration_ag__c': this.disputeItems[i].Evidence_at_tenancystart_redecoration_ag__c,
					'Evidence_at_tenancyend_redecoration_agll__c': this.disputeItems[i].Evidence_at_tenancyend_redecoration_agll__c,
					'Supporting_evidence_for_redecoration_agl__c': this.disputeItems[i].Supporting_evidence_for_redecoration_agl__c,

					'Claim_description_for_gardening_agll__c': this.disputeItems[i].Claim_description_for_gardening_agll__c,
					'Supporting_clause_gardening_agll__c': this.disputeItems[i].Supporting_clause_gardening_agll__c,
					'Evidence_at_tenancystart_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancystart_gardening_agll__c,
					'Evidence_at_tenancyend_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancyend_gardening_agll__c,
					'Supporting_evidence_for_gardening__c': this.disputeItems[i].Supporting_evidence_for_gardening__c,

					'Rent_arrears_description_agll__c': this.disputeItems[i].Rent_arrears_description_agll__c,
					'Was_the_property_re_let_rent_agll__c': this.disputeItems[i].Was_the_property_re_let_rent_agll__c,
					'Supporting_clause_rent_agll__c': this.disputeItems[i].Supporting_clause_rent_agll__c,
					'Supporting_evidence_for_rent_agll__c': this.disputeItems[i].Supporting_evidence_for_rent_agll__c,

					'Claim_breakdown_other_AGLL__c': this.disputeItems[i].Claim_breakdown_other_AGLL__c,
					'Supporting_clause_other_agll__c': this.disputeItems[i].Supporting_clause_other_agll__c,
					'Supporting_evidence_for_other_agll__c': this.disputeItems[i].Supporting_evidence_for_other_agll__c
				};
				calimItems.push(claim);
			}
			console.log('JSON.stringify(calimItems) => ' + JSON.stringify(calimItems));
		}
		var totalItem = this.AGLLandTTCalaimDetails.length;
		console.log('goToNextItem totalItem => ' + totalItem);
		console.log('goToNextItem currentItem => ' + this.currentItem);
		if (this.currentItem == totalItem - 1) {
			this.showClaimBreakdown = false;
			this.showAdditionalComments = true;
			// this.showClaimBreakdown = false;
			// let isAllAgreed = true;
			// for(let i in this.AGLLandTTCalaimDetails){
			//    if(!this.AGLLandTTCalaimDetails[i].key.includes('AGLL') && !this.AGLLandTTCalaimDetails[i].Is_Tenant_Agree__c){
			//       isAllAgreed = false;
			//       break;
			//    }
			// }
			// if(isAllAgreed){
			//    this.showAllClaimAgreed = true;
			// }else{
			//    this.showAdditionalComments = true;
			// }
		} else {
			this.AGLLandTTCalaimDetails[this.currentItem].isShow = false;
			this.AGLLandTTCalaimDetails[this.currentItem + 1].isShow = true;
			this.currentItem++;
			setTimeout(() => {
				console.log('isvalue true ' + this.AGLLandTTCalaimDetails[this.currentItem].Is_Tenant_Agree__c_value);
				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c_value']) {

					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('istenantagreeyes => ' + this.template.querySelector('.istenantagreeyes'));
						this.template.querySelector('.istenantagreeyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c']) {
						console.log('istenantagreeno => ' + this.template.querySelector('.istenantagreeno'));
						this.template.querySelector('.istenantagreeno').classList.add('active');
					}
				}

				if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c_value']) {

					if (this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidyes => ' + this.template.querySelector('.isttuploadevidyes'));
						this.template.querySelector('.isttuploadevidyes').classList.add('active');
					}
					else if (!this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c']) {
						console.log('isttuploadevidno => ' + this.template.querySelector('.isttuploadevidno'));
						this.template.querySelector('.isttuploadevidno').classList.add('active');
					}
				}
			}, 100);
		}
		console.log('Is_Tenant_Agree__c_value' + this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Agree__c_value']);
		console.log('Is_Tenant_Upload_Evidence__c_value' + this.AGLLandTTCalaimDetails[this.currentItem]['Is_Tenant_Upload_Evidence__c_value']);

		console.log('scroll to top');
		const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
		topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
	}
}