import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import SFChatter from '@salesforce/resourceUrl/SFChatter';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import EWC_Theme from '@salesforce/resourceUrl/EWC_Theme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getClaimDetailsByAccessCode from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.getClaimDetailsByAccessCode';
import UpdateCaseInRepaymentAgreementbyAgll from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.UpdateCaseInRepaymentAgreementbyAgll';
import updateCaseInOfferMadebyAGll from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseInOfferMadebyAGll';
import updateCaseInSelfOfferCancelledbyAGll from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseInSelfOfferCancelledbyAGll';
import updateCaseWhenAGllAcceptTenantOffer from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseWhenAGllAcceptTenantOffer';
import updateCaseWhenAGllRejectTenantOffer from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseWhenAGllRejectTenantOffer';
import updateRepaymentAdjustmentbyAGLL from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateRepaymentAdjustmentbyAGLL';
import UpdateCaseNoAgreementBYAGll from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.UpdateCaseNoAgreementBYAGll';
import updateChatFields from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateChatFields';
import updateChatHistory from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateChatHistory';
import getSecureURI from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.getSecureURI';
import saveFile from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.saveFile';
import returnUnreadMessages from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.returnUnreadMessages';
import updateCaseWheninitiateofferbyagll from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseWheninitiateofferbyagll';
import updateCaseWhenAGllmadecounterOffer from '@salesforce/apex/EI_NI_SelfResolutionJourneyClass.updateCaseWhenAGllmadecounterOffer';
// import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

// import SystemModstamp from '@salesforce/schema/Account.SystemModstamp';
import { refreshApex } from '@salesforce/apex';
export default class EI_NI_SelfResAGLL extends NavigationMixin(LightningElement) {

	dropLeftArrowIcon = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
	thankyoucircleIcon = NI_Theme + '/assets/img/circle_checked_icon.png';
	usericon = NI_Theme + '/assets/img/User_Icon.png';
	minimizeicon = NI_Theme + '/assets/img/minimize-icon.png';
	closeicon = NI_Theme + '/assets/img/close-icon.png';
	addicon = NI_Theme + '/assets/img/add-icon.png';
	sendmessage = NI_Theme + '/assets/img/send-icon.png';


	renderedCallback() {
		Promise.all([
			// loadStyle(this, SFChatter  + '/assets/css/custom.css')
			loadStyle(this, EWC_Theme + '/assets/css/custom-ni.css')
		])
			.then(() => {
				// alert('Files loaded.');
			})
			.catch(error => {
				alert(error.body.message);
			});
	}


	@track claimdetails;
	@track accessCode;
	@track Unsolvedamount;
	@track responddate;
	@track checkother = false;
	@track dispitemlist = [];
	@track agllAgreed = false;
	@track amountToAGLLIfAgllAgreement;
	@track amountToTenantIfAgllAgreement;
	@track thankyousection = false;
	@track thankYouSectionForAgree = false;
	@track thankYouSectionForMakeOffer = false;
	@track thankYouSectionForAGllAcceptAnOffer = false;
	@track thankYouSectionForAGllRejectAnOffer = false;
	@track casedata;
  @track showerrormsg = false;
	@track agllmakeoffer = false;
	@track agllMakeOfferSideGreyTab = false;
	@track agllAgreedSideGreyTab = true;
	@track offeramountbyAGlltoAGll = '';
	@track amountotenantinoffercase;
	@track offerMadeByAGll = false;
	@track offermadebyAGllamounttoAGLL;
	@track offermadebyAGllamounttoTenant;
	@track showbuttonsection = true;
	@track offerErrorMessage;
	@track isError = false;
	@track viewAndRespondOnTenantOffer = false;
	@track tenantofferamounttoAgll;
	@track amounttotenantoffermadebytenant;
	@track showforcounteroffer = false;
	@track mainfacingpage = true;
	@track doadjustment = false;
	@track disputeOldRecMap;
	@track totalTenantAmount;
	@track totalAGLLAmount;
	@track adjustmentByAGll = false;
	@track adjustmentamountAGLL;
	@track adjustmentamounttoTT;
	@track thankYouSectionForAGllDisagreeForTenant = false;
	@track thankYouSectionForNoAggrementByAGll = false;
	@track totalAdjustedAmountbyAGll = 0.00;
	@track isNotAgreedBtnClicked = false;
	@track notreachagreementcomment;
	@track isErrornew = false;
	@track errorMsgnew;
	@track disableslider = false;
	@track makebuttondisable = false;
	@track chatWrap = {};
	@track chatList = [];
	@track chatOpen = false;
	@track messageValue;
	@track showEvidenceCmp = false;
	@track fileName;
	@track message;
	@track fileLable;
	@track fileLableVisible = false;
	@track fileList;
	@track secureURI;
	@track azureLink;
	@track isadjustsubmit = true;
	@track shownotification = false;
	@track showunreadcount;
	@track noevidenceupload = true;
	@track useremailaddress = false;
	@track filelabelonchange;
	@track showDetails = true;
	@track greyOutagllAgreedAgllRequestButton = false;
	@track depositRecId;
	@track hidebutton = true;
	@api depositId;
	branchId=null;
	isLoading=false;
	showAmountError = false;

	changechattertext(event) {
		this.messageValue = event.target.value;
	}

	handleErrorMsg() {
		this.isErrornew = false;
	}

	addtwodecimalplaces(dummyamount) {
		var checkdecimalplace = dummyamount.split(".");
		if (checkdecimalplace.length < 2) {
			return dummyamount + '.00';
		}
		else {
			if (checkdecimalplace[1].length < 2)
				return dummyamount + '0';
			else {
				return dummyamount;
			}
		}


	}

	changeofferamount(event) {
		this.isError = false;
		if (!event.target.value
			//  || !event.target.value.match(/^[0-9]+$/)
		) {
			this.offeramountbyAGlltoAGll = null;
			this.amountotenantinoffercase = '£' + this.casedata.Actual_protected_amount__c.toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.amountotenantinoffercase = this.addtwodecimalplaces(this.amountotenantinoffercase);
		}
		else {

			if (!(event.target.value).includes('£')) {
				this.offeramountbyAGlltoAGll = '£' + (parseFloat(event.target.value)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.amountotenantinoffercase = '£' + (this.casedata.Actual_protected_amount__c - (parseFloat(event.target.value))).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.offeramountbyAGlltoAGll = this.addtwodecimalplaces(this.offeramountbyAGlltoAGll);
				this.amountotenantinoffercase = this.addtwodecimalplaces(this.amountotenantinoffercase);
			}
			else {
				let str = event.target.value;
				str = str.replaceAll(",", "");
				str = str.substring(1);
				this.offeramountbyAGlltoAGll = '£' + (parseFloat(str)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.amountotenantinoffercase = '£' + (this.casedata.Actual_protected_amount__c - parseFloat(str)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.offeramountbyAGlltoAGll = this.addtwodecimalplaces(this.offeramountbyAGlltoAGll);
				this.amountotenantinoffercase = this.addtwodecimalplaces(this.amountotenantinoffercase);
			}
		}
	}
	removeAmtZeroHandle(event) {
		var t = event.target.value;
		if (t.includes(".00")) {
			var arr = t.split(".");
			t = arr[0];
			console.log('line 960-->' + t);
		}
		event.target.value = t;
	}
	restrictDecimal(event) {

		const t = event.target.value;
		const charCode = (event.which) ? event.which : event.keyCode;
		const decimalIndex = t.indexOf('.');

		// Allow only one decimal point
		if (charCode === 46 && decimalIndex !== -1) {
			event.preventDefault();
		}

		// Allow only digits and a decimal point
		else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
			event.preventDefault();
		}

		// Allow only up to two digits after the decimal point
		else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
			event.preventDefault();
		}
	}


	@wire(CurrentPageReference)
	currentPageReference;
	connectedCallback() {
	//getpageRef(pageRef) {
		//   setTimeout(() => { window.history.forward();  }, 0);
		
		const queryString = window.location.search;
		const urlParams = new URLSearchParams(queryString);
		const depositRecId = urlParams.get('depositId');
		this.depositRecId = atob(depositRecId);
		

		console.log('line 223');
		getClaimDetailsByAccessCode({ depositId: this.depositRecId, timestamp: new Date().getTime() }).then(result => {
			// if(result==null){
			//   this.showDetails=false;
			//   return;
			// }
			
			console.log('line-->165' + JSON.stringify(result));
			this.showDetails = true;
			this.claimdetails = result;
			this.casedata = result[0];
			this.Unsolvedamount = result[0].Total_Agreed_by_AG_LL__c - result[0].Total_Agreed_by_Tenant__c;
			var claimdate = new Date(result[0].Respond_Date__c);
			this.amountotenantinoffercase = '£' + (result[0].Actual_protected_amount__c - this.offeramountbyAGlltoAGll).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.amountotenantinoffercase = this.addtwodecimalplaces(this.amountotenantinoffercase);
			this.notreachagreementcomment = result[0].Not_reach_an_agreement_Reason_AG_LL__c;
			if (result[0].Case_Statuses__c == 'Self-resolution - awaiting review') {
				this.hidebutton = false;
				this.showbuttonsection = false;
			}

			if (!claimdate) {
				this.responddate = '';
			}
			if (claimdate) {
				var checkdate = claimdate.getDate().toString().padStart(2, "0");;
				var checkmonth = (claimdate.getMonth() + 1).toString().padStart(2, "0");
				var checkyear = claimdate.getFullYear();
				var newDate = checkdate + '/' + checkmonth + '/' + checkyear;
				this.responddate = newDate;
			}

			//    for(let i=0; i<result[0].Case_Participants__r.length; i++){
			//     if(result[0].Case_Participants__r[i].Access_Code__c ==recId) {
			//       if(!result[0].Case_Participants__r[i].Primary_Email__c){
			//         this.useremailaddress = true;
			//         this.template.querySelector('.chatdisabled').classList.add('disablebutton');
			//       }
			//       else{
			//         this.useremailaddress = false; 
			//         this.template.querySelector('.chatdisabled').classList.remove('disablebutton');
			//       }
			//     }
			//  }

			console.log('line 267');
			// Amount spilt b/w AGLL and TT When Tenant Agreed AGll Repayment Start//
			this.amountToAGLLIfAgllAgreement = '£' + result[0].Total_Agreed_by_Tenant__c.toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.amountToAGLLIfAgllAgreement = this.addtwodecimalplaces(this.amountToAGLLIfAgllAgreement);
			this.amountToTenantIfAgllAgreement = '£' + (result[0].Actual_protected_amount__c - result[0].Total_Agreed_by_Tenant__c).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.amountToTenantIfAgllAgreement = this.addtwodecimalplaces(this.amountToTenantIfAgllAgreement);
			// Amount spilt b/w AGLL and TT When Tenant Agreed AGll Repayment End// 
			console.log('line 274');

			if (result[0].AGLL_made_Offer__c == true && result[0].AGLL_Offer_Amount__c > 0) {
				// this.offermadebyAGllamounttoAGLL = '£'+result[0].AGLL_Offer_Amount__c.toFixed(2);
				// this.offermadebyAGllamounttoTenant = '£'+(result[0].Actual_protected_amount__c-result[0].AGLL_Offer_Amount__c).toFixed(2);  

				this.offermadebyAGllamounttoAGLL = '£' + (result[0].AGLL_Offer_Amount__c).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.offermadebyAGllamounttoAGLL = this.addtwodecimalplaces(this.offermadebyAGllamounttoAGLL);

				this.offermadebyAGllamounttoTenant = '£' + (result[0].Actual_protected_amount__c - result[0].AGLL_Offer_Amount__c).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.offermadebyAGllamounttoTenant = this.addtwodecimalplaces(this.offermadebyAGllamounttoTenant);
				console.log('offer tab show: '+this.offerMadeByAGll);
				this.offerMadeByAGll = true;
				this.showbuttonsection = false;

			}

			if (result[0].TT_Made_offer__c == true && result[0].TT_Offer_Amount__c > 0) {
				this.viewAndRespondOnTenantOffer = true;
				this.showbuttonsection = true;
				this.makebuttondisable = true;
				this.showforcounteroffer = true;
				this.template.querySelector('.agreementbutton').classList.add('disablebutton');
				this.template.querySelector('.disagreebutton').classList.add('disablebutton');
				this.template.querySelector('.offerbutton').classList.add('disablebutton');

				// this.tenantofferamounttoAgll = '£'+result[0].TT_Offer_Amount__c.toFixed(2);
				// this.amounttotenantoffermadebytenant = '£'+(result[0].Total_Deposit__c-result[0].TT_Offer_Amount__c).toFixed(2);

				this.tenantofferamounttoAgll = '£' + (result[0].TT_Offer_Amount__c).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.tenantofferamounttoAgll = this.addtwodecimalplaces(this.tenantofferamounttoAgll);

				this.amounttotenantoffermadebytenant = '£' + (result[0].Actual_protected_amount__c - result[0].TT_Offer_Amount__c).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
				this.amounttotenantoffermadebytenant = this.addtwodecimalplaces(this.amounttotenantoffermadebytenant);

			}
			else {
				this.template.querySelector('.agreementbutton').classList.remove('disablebutton');
				this.template.querySelector('.disagreebutton').classList.remove('disablebutton');
				this.template.querySelector('.offerbutton').classList.remove('disablebutton');

			}




			let dispitemlist = [];
			dispitemlist.push({ label: 'Cleaning' });
			dispitemlist.push({ label: 'Damage' });
			dispitemlist.push({ label: 'Redecoration' });
			dispitemlist.push({ label: 'Gardening' });
			dispitemlist.push({ label: 'Rent' });
			dispitemlist.push({ label: 'Other' });
			for (let i = 0; i < dispitemlist.length; i++) {
				let flag = false;
				result[0].Dispute_Items__r.forEach(claimdata => {
					if (dispitemlist[i].label == claimdata.Type__c) {
						flag = true;

						dispitemlist[i]['value'] = claimdata.Type__c == 'Other' ? true : false;
						dispitemlist[i]['amountagreedbyagll'] = claimdata.Agreed_by_AGLL__c.toFixed(2);
						dispitemlist[i]['amountagreedbyagllviewonly'] = '£' + claimdata.Agreed_by_AGLL__c.toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
						dispitemlist[i]['amountagreedbyagllviewonly'] = this.addtwodecimalplaces(dispitemlist[i]['amountagreedbyagllviewonly']);
						dispitemlist[i]['placeholderagent'] = '£' + claimdata.Agreed_by_AGLL__c.toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
						dispitemlist[i]['placeholderagent'] = this.addtwodecimalplaces(dispitemlist[i]['placeholderagent']);
						dispitemlist[i]['amountagreedbytt'] = claimdata.Agreed_by_Tenant__c;
						dispitemlist[i]['placeholdertenant'] = '£' + claimdata.Agreed_by_Tenant__c.toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
						dispitemlist[i]['placeholdertenant'] = this.addtwodecimalplaces(dispitemlist[i]['placeholdertenant']);
						dispitemlist[i]['recordid'] = claimdata.Id;
						dispitemlist[i]['adjperbyAGLL'] = claimdata.Adjustment_Percentage_by_AGLL__c;
						dispitemlist[i]['AdjprcntbyTT'] = claimdata.Adjustment_Percentage_by_TT__c;
						dispitemlist[i]['initialClaimOfagll'] = claimdata.Claimed_by_Landlord__c;
						dispitemlist[i]['otherreasonagll'] = claimdata.Other_Reason__c;
						if (claimdata.Type__c == 'Other') {
							dispitemlist[i]['placeholderagent'] = this.addtwodecimalplaces(dispitemlist[i]['placeholderagent']) + '\n \n' + dispitemlist[i]['otherreasonagll'];

						}

					}
				});
				if (flag == false) {
					dispitemlist.splice(i, 1);
					i--;
				}
			}

			this.dispitemlist = dispitemlist;



			let disputOldRecMap = new Map();
			let caseItemRec = result[0].Dispute_Items__r;
			let totalamount = 0;
			let totalamountAGLL = 0;
			for (let i = 0; i < caseItemRec.length; i++) {
				var AmountObj = new Object();
				AmountObj.Amount = caseItemRec[i].Agreed_by_AGLL__c;
				AmountObj.Percentage = caseItemRec[i].Adjustment_Percentage_by_AGLL__c;
				disputOldRecMap.set(caseItemRec[i].Id, AmountObj);

				if (caseItemRec[i].Agreed_by_Tenant__c) {
					totalamount = parseFloat(totalamount) + parseFloat(caseItemRec[i].Agreed_by_Tenant__c);
				}
				if (caseItemRec[i].Agreed_by_AGLL__c) {
					totalamountAGLL = parseFloat(totalamountAGLL) + parseFloat(caseItemRec[i].Agreed_by_AGLL__c);
				}
			}
			this.totalTenantAmount = totalamount;
			this.totalAGLLAmount = totalamountAGLL;
			this.disputeOldRecMap = disputOldRecMap;
			console.log('line-->154 ' + this.disputeOldRecMap);

			this.totalAdjustedAmountbyAGLL = parseFloat(totalamountAGLL);
			// this.adjustmentamountAGLL = '£'+totalamountAGLL.toFixed(2);
			// this.adjustmentamounttoTT = '£'+(this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamountAGLL)).toFixed(2);

			this.adjustmentamountAGLL = '£' + (totalamountAGLL).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamountAGLL = this.addtwodecimalplaces(this.adjustmentamountAGLL);

			this.adjustmentamounttoTT = '£' + (this.casedata.Actual_protected_amount__c - parseFloat(totalamountAGLL)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamounttoTT = this.addtwodecimalplaces(this.adjustmentamounttoTT);

			
		}).catch(error => {
			console.log('returnselfres error--->' + error);
		});

		returnUnreadMessages({ depositId: this.depositRecId })
			.then(result => {
				this.showunreadcount = result;
				if (this.showunreadcount > 0) {
					this.shownotification = true;
				}
				else {
					this.shownotification = false;
				}


			})
			.catch(error => {
				console.log('returnUnreadMessages error--->' + JSON.stringify(error));
			});


	//}
	}

	agllAgreementoftenantrepayment() {
    this.showerrormsg  = false; 
	this.isLoading=true;
		updateCaseWheninitiateofferbyagll({ caseId: this.casedata.Id }).then(result => {
			console.log('updateCaseWheninitiateofferbyagll result => ' + result);
			if (result == 'Success') {
				this.template.querySelector('.agreementbutton').classList.add('buttoncolor');
				this.template.querySelector('.disagreebutton').classList.remove('buttoncolor');
				this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

				this.disableslider = true;
				this.agllAgreed = true;
				this.doadjustment = false;
				this.mainfacingpage = true;
				this.agllmakeoffer = false;
				this.adjustmentByAGll = false;
				this.agllMakeOfferSideGreyTab = false;
				this.agllAgreedSideGreyTab = true;
				this.isNotAgreedBtnClicked = false;
				this.isLoading=false;
			}
			if (result == 'Fail') {
				let text = "Something went wrong !.";
				if (confirm(text) == true) {
					location.reload();
				} else {
					location.reload();
				}
			}
		})
			.catch(error => {
				this.isLoading=false;
				console.log('updateCaseWheninitiateofferbyagll error--->' + JSON.stringify(error));
			});
	}

	agllAgreedAgllRequestsubmit() {
		//alert('line-->88' + typeof this.casedata);
		console.log('line-->89' + JSON.stringify(this.casedata));
		this.greyOutagllAgreedAgllRequestButton = true;
		this.isLoading=true;
		UpdateCaseInRepaymentAgreementbyAgll({ caseId: this.casedata.Id, agreedAmount: this.casedata.Total_Agreed_by_Tenant__c, depositAmount: this.casedata.Actual_protected_amount__c })
			.then(result => {
				if (result == 'Success') {
					// on success, you can bind to a tracked vars to re-render them
					console.log('UpdateCaseInRepaymentAgreementbyAgll result--->' + JSON.stringify(result));
					this.thankyousection = true;
					this.thankYouSectionForAgree = true;
					this.thankYouSectionForMakeOffer = false;
					this.thankYouSectionForAGllRejectAnOffer = false;
					this.thankYouSectionForAGllAcceptAnOffer = false;
					this.isLoading=false;
					// this[NavigationMixin.Navigate]({
					//   type: 'comm__namedPage',
					//   attributes: {
					//       pageName: 'ewithankyou'
					//   },
					//   state:{
					//       accessCode: this.accessCode,
					//       thanksfor: 'selfResForAgree'
					//   }
					// });
				}
				if (result == 'Fail') {
					let text = "Something went wrong !.";
					if (confirm(text) == true) {
						location.reload();
					} else {
						location.reload();
					}
				}
			})
			.catch(error => {
				console.log('UpdateCaseInRepaymentAgreementbyAgll error--->' + JSON.stringify(error));
			});
	}

	agllMakeOfferToTenant() {
    this.showerrormsg  = false; 
	this.isLoading=true;
		updateCaseWheninitiateofferbyagll({ caseId: this.casedata.Id }).then(result => {
			console.log('updateCaseWheninitiateofferbyagll result => ' + result);
			if (result == 'Success') {
				this.showbuttonsection = false;
				this.mainfacingpage = false;
				this.doadjustment = true;
				this.disableslider = true;
				this.agllmakeoffer = true;
				this.agllAgreed = false;
				this.adjustmentByAGll = false;
				this.agllMakeOfferSideGreyTab = true;
				this.agllAgreedSideGreyTab = false;
				this.isNotAgreedBtnClicked = false;
				this.isLoading=false;
			}
			if (result == 'Fail') {
				let text = "Something went wrong !.";
				if (confirm(text) == true) {
					location.reload();
				} else {
					location.reload();
				}
			}
		})
			.catch(error => {
				console.log('updateCaseWheninitiateofferbyagll error--->' + JSON.stringify(error));
				this.isLoading=false;
			});

	}

	submitOfferByAgll() {
		let str = this.offeramountbyAGlltoAGll;
		str = str.replaceAll(',', '');
		str = str.substring(1);
		var finalofferamount = (parseFloat(str));
		var isValid = true;



		if (!finalofferamount || finalofferamount < 0 || finalofferamount == '' || finalofferamount == undefined || finalofferamount == null) {
			isValid = false;
			this.isError = true;
			this.offerErrorMessage = "Enter valid offer amount";

		}

		if (finalofferamount > this.casedata.Total_Agreed_by_AG_LL__c) {
			isValid = false;
			this.isError = true;
			this.offerErrorMessage = "Your offer cannot exceed the requested amount";

		}


		if (finalofferamount > 0 && finalofferamount != '' && finalofferamount != undefined && finalofferamount != null) {
			if (finalofferamount < this.casedata.Total_Agreed_by_Tenant__c) {
				isValid = false;
				this.isError = true;
				this.offerErrorMessage = "You have entered less than the agreed amount by tenant. Please review your offer.";

			}
		}


		if (isValid) {
			this.isLoading=true;
			updateCaseInOfferMadebyAGll({ caseId: this.casedata.Id, offeramount: finalofferamount, depositAmount: this.casedata.Actual_protected_amount__c })
				.then(result => {

					// on success, you can bind to a tracked vars to re-render them
					console.log('updateCaseInOfferMadebyAGll result--->' + JSON.stringify(result));
					this.thankyousection = true;
					this.thankYouSectionForAgree = false;
					this.thankYouSectionForMakeOffer = true;
					this.thankYouSectionForAGllRejectAnOffer = false;
					this.thankYouSectionForAGllAcceptAnOffer = false;
					this.isLoading=false;
					// this[NavigationMixin.Navigate]({
					//   type: 'comm__namedPage',
					//   attributes: {
					//       pageName: 'ewithankyou'
					//   },
					//   state:{
					//       accessCode: this.accessCode,
					//       thanksfor: 'selfResForMakeOffer'
					//   }
					// });

				})
				.catch(error => {
					console.log('updateCaseInOfferMadebyAGll error--->' + JSON.stringify(error));
				});
		}
	}

	doNotMakeOfferByAGll() {
		// this.template.querySelector('.agreementbutton').classList.remove('buttoncolor');
		// this.template.querySelector('.disagreebutton').classList.remove('buttoncolor');
		// this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

		this.agllmakeoffer = false;
		this.isNotAgreedBtnClicked = false;
		if (this.showforcounteroffer == true) {
			this.viewAndRespondOnTenantOffer = true;
			this.showbuttonsection = true;
		}
		if (this.showforcounteroffer == false) {
			this.viewAndRespondOnTenantOffer = false;
			this.showbuttonsection = true;
		}
	}

	selfOfferCancelByAGll() {
		updateCaseInSelfOfferCancelledbyAGll({ caseId: this.casedata.Id })
			.then(result => {
				if (result == 'Success') {
					// on success, you can bind to a tracked vars to re-render them
					console.log('updateCaseInRepaymentAgreementbyTenant result--->' + JSON.stringify(result));
					this.offerMadeByAGll = false;
					this.showbuttonsection = true;
				}
				if (result == 'Fail') {
					let text = "Something went wrong !.";
					if (confirm(text) == true) {
						location.reload();
					} else {
						location.reload();
					}
				}
			})
			.catch(error => {
				console.log('updateCaseInRepaymentAgreementbyTenant error--->' + JSON.stringify(error));
			});

	}

	tenantOfferAcceptedByAGll() {
		this.isLoading=true;
		updateCaseWhenAGllAcceptTenantOffer({ caseId: this.casedata.Id, amounttoagll: this.casedata.TT_Offer_Amount__c, depositamount: this.casedata.Actual_protected_amount__c })
			.then(result => {
				if (result == 'Success') {
					// on success, you can bind to a tracked vars to re-render them
					console.log('updateCaseWhenAGllAcceptTenantOffer result--->' + JSON.stringify(result));
					this.thankyousection = true;
					this.thankYouSectionForAGllAcceptAnOffer = true;
					this.thankYouSectionForMakeOffer = false;
					this.thankYouSectionForAGllRejectAnOffer = false;
					this.thankYouSectionForAgree = false;
					this.isLoading=false;

				}
				if (result == 'Fail') {
					let text = "Something went wrong !.";
					if (confirm(text) == true) {
						location.reload();
					} else {
						location.reload();
					}
				}
			})
			.catch(error => {
				console.log('updateCaseWhenAGllAcceptTenantOffer error--->' + JSON.stringify(error));
			});

	}

	tanantOfferRejectedByAGll() {
		this.isLoading=true;
		updateCaseWhenAGllRejectTenantOffer({ caseId: this.casedata.Id })
			.then(result => {
				if (result == 'Success') {
					// on success, you can bind to a tracked vars to re-render them
					console.log('updateCaseWhenAGllRejectTenantOffer result--->' + JSON.stringify(result));
					this.thankyousection = true;
					this.thankYouSectionForAGllRejectAnOffer = true;
					this.thankYouSectionForAGllAcceptAnOffer = false;
					this.thankYouSectionForMakeOffer = false;
					this.thankYouSectionForAgree = false;
					this.isLoading=false;
					// this[NavigationMixin.Navigate]({
					//   type: 'comm__namedPage',
					//   attributes: {
					//       pageName: 'ewithankyou'
					//   },
					//   state:{
					//       accessCode: this.accessCode,
					//       thanksfor: 'selfResForAGllRejectAnOffer'
					//   }
					// });
				}
				if (result == 'Fail') {
					let text = "Something went wrong !.";
					if (confirm(text) == true) {
						location.reload();
					} else {
						location.reload();
					}
				}
			})
			.catch(error => {
				console.log('updateCaseWhenAGllRejectTenantOffer error--->' + JSON.stringify(error));
			});

	}

	counterOfferByAGll() {
		this.isLoading=true;
		updateCaseWhenAGllmadecounterOffer({ caseId: this.casedata.Id })
			.then(result => {
				if (result == 'Success') {
					this.disableslider = true;
					this.agllmakeoffer = true;
					this.mainfacingpage = false;
					this.doadjustment = true;
					this.agllAgreed = false;
					this.agllMakeOfferSideGreyTab = true;
					this.agllAgreedSideGreyTab = false;
					this.viewAndRespondOnTenantOffer = false;
					this.isNotAgreedBtnClicked = false;
					this.isLoading=false;
				}
				if (result == 'Fail') {
					let text = "Something went wrong !.";
					if (confirm(text) == true) {
						location.reload();
					} else {
						location.reload();
					}
				}
			}).catch(error => {
				console.log('updateCaseWhenAGllmadecounterOffer error--->' + JSON.stringify(error));
				this.isLoading=false;
			});
	}

	doadjustmentbyAGLL() {
		updateCaseWheninitiateofferbyagll({ caseId: this.casedata.Id }).then(result => {
			if (result == 'Success') {
				this.template.querySelector('.agreementbutton').classList.remove('buttoncolor');
				this.template.querySelector('.disagreebutton').classList.add('buttoncolor');
				this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

				console.log('line 328--->');
				this.disableslider = false;
				this.mainfacingpage = false;
				this.doadjustment = true;
				this.adjustmentByAGll = true;
				this.agllmakeoffer = false;
				this.agllAgreed = false;
				this.agllMakeOfferSideGreyTab = true;
				this.isNotAgreedBtnClicked = false;
				this.agllAgreedSideGreyTab = false;
				this.isadjustsubmit = true;
				setTimeout(() => {
					this.template.querySelector('.disablesubmit').classList.add('disablebutton');
				}, 500);
			}
			if (result == 'Fail') {
				let text = "Something went wrong !.";
				if (confirm(text) == true) {
					location.reload();
				} else {
					location.reload();
				}
			}
		})
			.catch(error => {
				console.log('updateCaseWheninitiateofferbyagll error--->' + JSON.stringify(error));
			});
	}

	handleInput(event) {
		let totalamount = 0;
		// Html input  Tag
		let selectRecordValue = event.target.value;
		if (selectRecordValue == '' || selectRecordValue == null) {
			selectRecordValue = 0.00;
		}
		let selectRecordId = event.target.name;
		console.log('recordid 332 ' + selectRecordId);
		console.log('selectRecordValue 333 ' + selectRecordValue);
		// Lightning input Tag
		// let selectRecordValue = event.getSource().get("v.value");
		// let selectRecordId = event.getSource().get("v.id");

		let disputOldRecMap = this.disputeOldRecMap;
		console.log('disputOldRecMap 339  ' + JSON.stringify(this.disputeOldRecMap));
		let claimRec = this.dispitemlist; // this.casedata.Dispute_Items__r;
		console.log('claimRec ' + JSON.stringify(claimRec));
		for (let i = 0; i < claimRec.length; i++) {
			console.log('claimRec[i].recordId ' + claimRec[i].recordid);
			console.log('disputOldRecMap.get(selectRecordId).Amount ' + disputOldRecMap.get(selectRecordId).Amount);

			if (claimRec[i].recordid == selectRecordId) {
				console.log('record ID matched ' + selectRecordValue);
				if (parseFloat(selectRecordValue) < 0) {
					claimRec[i].showerror = true;
					claimRec[i].errormsg = 'You cannot enter a negative figure';
					event.target.value = disputOldRecMap.get(selectRecordId).Amount;
					claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
					this.isadjustsubmit = true;
					this.template.querySelector('.disablesubmit').classList.add('disablebutton');
				}
				if (parseFloat(selectRecordValue) >= 0) {
					if (parseFloat(selectRecordValue) > disputOldRecMap.get(selectRecordId).Amount) {
						claimRec[i].showerror = true;
            this.showerrormsg = true;
						// claimRec[i].errormsg = 'You can only reduce the amount';
						//claimRec[i].errormsg = 'You are unable to increase the amount requested, please enter a reduced value.';
						claimRec[i].errormsg = 'This amount must be equal to or less than amount previously agreed by tenant.';
						event.target.value = disputOldRecMap.get(selectRecordId).Amount;
						claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
						this.isadjustsubmit = true;
						this.template.querySelector('.disablesubmit').classList.add('disablebutton');
					}
					else {
						if (parseFloat(selectRecordValue) < claimRec[i].amountagreedbytt) {
							claimRec[i].showerror = true;
              this.showerrormsg = true;
							claimRec[i].errormsg = 'Amount entered should be equal to or greater than amount requested by tenant';
							event.target.value = disputOldRecMap.get(selectRecordId).Amount;
							claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
							this.isadjustsubmit = true;
							this.template.querySelector('.disablesubmit').classList.add('disablebutton');
						}
						else {
							this.isadjustsubmit = false;
							console.log('entered in line 830');
							setTimeout(() => {
							this.template.querySelector('.disablesubmit').classList.remove('disablebutton');
							}, 10);
							console.log('entered in line 832');
							claimRec[i].showerror = false;
              this.showerrormsg = false;
							event.target.value = parseFloat(selectRecordValue).toFixed(2);
							claimRec[i].amountagreedbyagll = parseFloat(selectRecordValue).toFixed(2);
						}

					}
					console.log('entered in line 843');
					//claimRec[i].Agreed_by_Tenant__c = selectRecordValue;
					var AGLLResponseperc = (claimRec[i].amountagreedbyagll * 100) / claimRec[i].initialClaimOfagll;
					claimRec[i].adjperbyAGLL = AGLLResponseperc;
				}
			}

			totalamount = parseFloat(totalamount) + parseFloat(claimRec[i].amountagreedbyagll);
			this.totalAdjustedAmountbyAGLL = parseFloat(totalamount);
			// this.adjustmentamountAGLL = '£'+totalamount.toFixed(2);
			// this.adjustmentamounttoTT = '£'+(this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamount)).toFixed(2);

			this.adjustmentamountAGLL = '£' + (totalamount).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamountAGLL = this.addtwodecimalplaces(this.adjustmentamountAGLL);

			this.adjustmentamounttoTT = '£' + (this.casedata.Actual_protected_amount__c - parseFloat(totalamount)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamounttoTT = this.addtwodecimalplaces(this.adjustmentamounttoTT);

			console.log('line-->402 ' + totalamount);
		}

		this.dispitemlist = claimRec;

	}
	sliderMethod(event) {
		let totalamount = 0;
		// Html input  Tag
		let selectRecordValue = event.target.value;
		let selectRecordId = event.target.name;

		console.log('recordid 332 ' + selectRecordId);
		console.log('selectRecordValue 333 ' + selectRecordValue);
		// Lightning input Tag
		// let selectRecordValue = event.getSource().get("v.value");
		// let selectRecordId = event.getSource().get("v.id");

		let disputOldRecMap = this.disputeOldRecMap;
		console.log('disputOldRecMap 339  ' + JSON.stringify(this.disputeOldRecMap));
		let claimRec = this.dispitemlist; // this.casedata.Dispute_Items__r;
		console.log('claimRec ' + JSON.stringify(claimRec));
		for (let i = 0; i < claimRec.length; i++) {
			claimRec[i].showerror = false;
			console.log('claimRec[i].recordId ' + claimRec[i].recordid);
			console.log('disputOldRecMap.get(selectRecordId).Amount ' + disputOldRecMap.get(selectRecordId).Amount);

			if (claimRec[i].recordid == selectRecordId) {
				console.log('record ID matched ' + selectRecordValue);
				// if(selectRecordValue < 0 )
				// {
				//   claimRec[i].showerror = true;
				//   claimRec[i].errormsg = 'You cannot enter a negative figure';
				//   claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
				// }
				
				if (selectRecordValue >= 0) {
					if (parseFloat(selectRecordValue) > parseFloat(disputOldRecMap.get(selectRecordId).Percentage)) {
						
						claimRec[i].showerror = true;
            this.showerrormsg = true;
						// claimRec[i].errormsg = 'You can only reduce the amount';
						// claimRec[i].errormsg = 'You are unable to increase the amount requested, please enter a reduced value.';
						claimRec[i].errormsg = 'This amount must be equal to or less than amount previously agreed by tenant.';
						claimRec[i].adjperbyAGLL = disputOldRecMap.get(selectRecordId).Percentage;
						this.isadjustsubmit = true;
						this.template.querySelector('.disablesubmit').classList.add('disablebutton');

					}
					else {
						
						if (selectRecordValue < claimRec[i].AdjprcntbyTT) {
							
							claimRec[i].showerror = true;
              this.showerrormsg = true;
							claimRec[i].errormsg = 'Amount entered should be equal to or greater than amount requested by tenant';
							claimRec[i].adjperbyAGLL = disputOldRecMap.get(selectRecordId).Percentage;
							this.isadjustsubmit = true;
							this.template.querySelector('.disablesubmit').classList.add('disablebutton');

						}
						else {
							
							this.isadjustsubmit = false;
							requestAnimationFrame(() => {
							this.template.querySelector('.disablesubmit').classList.remove('disablebutton');
							});
							claimRec[i].showerror = false;
              this.showerrormsg = false;
							claimRec[i].adjperbyAGLL = parseFloat(selectRecordValue);
						}

					}
					
					//claimRec[i].Agreed_by_Tenant__c = selectRecordValue;
					var AGLLResponseperc = (claimRec[i].adjperbyAGLL * claimRec[i].initialClaimOfagll) / 100;
					console.log('AGLLResponseperc => ' + AGLLResponseperc);
					let selectRecordValueDEC = '£' + (AGLLResponseperc).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
					selectRecordValueDEC = this.addtwodecimalplaces(selectRecordValueDEC);
					console.log('selectRecordValueDEC => ' + selectRecordValueDEC);
					claimRec[i].amountagreedbyagll = parseFloat(AGLLResponseperc).toFixed(2);

				}

			}

			totalamount = parseFloat(totalamount) + parseFloat(claimRec[i].amountagreedbyagll);

			this.totalAdjustedAmountbyAGLL = parseFloat(totalamount);
			// this.adjustmentamountAGLL = '£'+totalamount.toFixed(2);
			// this.adjustmentamounttoTT = '£'+(this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamount)).toFixed(2);

			this.adjustmentamountAGLL = '£' + (totalamount).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamountAGLL = this.addtwodecimalplaces(this.adjustmentamountAGLL);

			this.adjustmentamounttoTT = '£' + (this.casedata.Actual_protected_amount__c - parseFloat(totalamount)).toLocaleString({ minimumFractionDigits: 2 }, { maximumFractionDigits: 2 });
			this.adjustmentamounttoTT = this.addtwodecimalplaces(this.adjustmentamounttoTT);

			console.log('line-->464 ' + totalamount);
		}
		this.dispitemlist = claimRec;
	}

	SubmitRepaymentAdjByAGLL() {
		console.log('line 949');
		this.isLoading=true;
		var claimedItemsDetailsObj = {};
		for (let ind in this.dispitemlist) {
			console.log("recordid => " + this.dispitemlist[ind].recordid);
			let detailsObj = {};
			detailsObj['amountagreedbyagll'] = this.dispitemlist[ind].amountagreedbyagll;
			detailsObj['amountagreedbytt'] = this.dispitemlist[ind].amountagreedbytt;
			detailsObj['adjperbyAGLL'] = this.dispitemlist[ind].adjperbyAGLL;
			// detailsObj['agllResponsePercentage'] = this.dispitemlist[ind].agllResponsePercentage;

			claimedItemsDetailsObj[this.dispitemlist[ind].recordid] = detailsObj;
			console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
		}
		var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
		console.log('line-->500');
		updateRepaymentAdjustmentbyAGLL({
			caseId: this.casedata.Id, depositAmount: this.casedata.Actual_protected_amount__c,
			adjustedAmount: this.totalAdjustedAmountbyAGLL, claimedItems: claimedItemsDetailsObjStr
		})
			.then(result => {
				console.log('updateRepaymentAdjustmentbyAGLL result => ' + result);
				if (result == 'SuccessFully Updated') {
					this.thankYouSectionForAGllDisagreeForTenant = true;
					this.thankyousection = true;
					this.isLoading=false;
					this.showAmountError = false;
					// this.thankYouSectionForTenantAgree =false;
					// this.thankYouSectionForMakeOffer =false;
					// this.thankYouSectionForTenantAcceptAnOffer =false;
					// this.thankYouSectionForTenantRejectAnOffer =false;
				}
				else if(result == 'Something went wrong, Amount Error!!')
      			{
        			this.showAmountError = true;
					this.thankYouSectionForAGllDisagreeForTenant = false;
					this.thankyousection = false;
					this.isLoading=false;

      			}
			}).catch(error => {
				console.log('updateRepaymentAdjustmentbyTenant error => ' + JSON.stringify(error));
				this.isLoading=false;
			})

	}

	notReachAgreementByAGll() {
		this.isNotAgreedBtnClicked = true;
		this.adjustmentByAGll = false;

	}

	doSubmitNoAggrementbyAGll() {

		var isvalid = true;
		const textareavalue = this.template.querySelector('lightning-textarea').value;
		this.notreachagreementcomment = textareavalue;


		if (this.notreachagreementcomment == undefined) {
			isvalid = false;
			this.errorMsgnew = 'Please review your comments. You are required to enter a minimum of 150 characters and no more than 500.';
			this.isErrornew = true;
			this.template.querySelector(".errorMsgDiv").scrollIntoView();
		} else {
			console.log('@@in not error');
			this.isErrornew = false;
		}

		if (textareavalue.length < 150 || textareavalue.length > 500) {
			console.log('line--> 553 ' + textareavalue.length);
			isvalid = false;
			this.errorMsgnew = 'Please review your comments. You are required to enter a minimum of 150 characters and no more than 500.';
			this.isErrornew = true;
			this.template.querySelector(".errorMsgDiv").scrollIntoView();
		} else {
			console.log('@@in not error');
			this.isErrornew = false;
		}

		if (isvalid) {
			this.isLoading=true;
			UpdateCaseNoAgreementBYAGll({ claimId: this.casedata.Id, cmnts: textareavalue })
				.then(result => {
					console.log('UpdateCaseNoAgreementBYAGll result => ' + result);
					if (result == 'Record successfully updated') {
						this.thankyousection = true;
						this.thankYouSectionForNoAggrementByAGll = true;
						this.thankYouSectionForAGllDisagreeForTenant = false;
						this.thankYouSectionForAGllRejectAnOffer = false;
						this.thankYouSectionForAGllAcceptAnOffer = false;
						this.thankYouSectionForMakeOffer = false;
						this.thankYouSectionForAgree = false;
						this.isLoading=false;
					}
				}).catch(error => {
					console.log('UpdateCaseNoAgreementBYAGll error => ' + JSON.stringify(error));
				})
		}

	}

	showchatbox() {
		// alert('line-->661' + this.chatOpen);
		this.chatOpen = true;
		// alert('line-->662' + this.chatOpen);
		updateChatFields({ caseId: this.casedata.Id })
			.then(result => {
				console.log('updateChatFields result => ' + result);
				if (result) {
					this.chatWrap = result;
					console.log('line-->714 ' + JSON.stringify(this.chatWrap.chatList));
					var chatList = [];
					for (let ind in this.chatWrap.chatList) {
						let chatObj = {};
						chatObj['Id'] = this.chatWrap.chatList[ind].Id;
						chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
						chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
						chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
						chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
						if (this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId) {
							chatObj['selfUserChat'] = true;
						} else {
							chatObj['selfUserChat'] = false;
						}
						chatList.push(chatObj);
					}
					this.chatList = chatList;
					this.showunreadcount = 0;
					this.shownotification = false;
					console.log('chatList => ' + this.chatList);
				}
			}).catch(error => {
				console.log('updateChatFields error => ' + JSON.stringify(error), error);
			})
		var chatOpen = this.chatOpen;
		/* if(chatOpen == true){
		  setTimeout(()=>{
			this.showchatbox()
		  }, 2000);
			setTimeout(getCallback(() => this.openChatBoxHelper()), 2000)
		} */

	}

	enterClicked(event) {
		var checkvaluw = this.template.querySelector('lightning-textarea[data-name="temp"]').value;
		var keyCode = (event.which) ? event.which : event.keyCode;

		// var messageval =this.messageValue;
		var messageval = checkvaluw;

		if (keyCode == 13) {
			this.template.querySelector('lightning-textarea[data-name="temp"]').value = '';
			updateChatHistory
				({
					caseId: this.casedata.Id,
					message: messageval,
					fromId: this.chatWrap.currentContactId,
					toId: this.chatWrap.otherPartyContactId,
					accessCode: this.accessCode
				})
				.then(result => {
					console.log('updateChatHistory result => ' + result);
					if (result) {
						this.chatWrap = result;
						this.messageValue = '';
						this.template.querySelector('lightning-textarea[data-name="temp"]').value = '';
						console.log('line-->7 ' + JSON.stringify(result));
						var chatList = [];
						for (let ind in this.chatWrap.chatList) {
							let chatObj = {};
							chatObj['Id'] = this.chatWrap.chatList[ind].Id;
							chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
							chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
							chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
							chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
							if (this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId) {
								chatObj['selfUserChat'] = true;
							} else {
								chatObj['selfUserChat'] = false;
							}
							chatList.push(chatObj);
						}
						this.chatList = chatList;
						console.log('chatList => ' + this.chatList);
					}
				}).catch(error => {
					console.log('updateChatHistory error => ' + JSON.stringify(error));
				})
		}
	}

	enterClicked2(event) {
		var checkvaluw = this.template.querySelector('lightning-textarea[data-name="temp"]').value;
		if (checkvaluw) {
			this.template.querySelector('lightning-textarea[data-name="temp"]').value = '';
			var keyCode = (event.which) ? event.which : event.keyCode;
			var messageval = checkvaluw;
			updateChatHistory
				({
					caseId: this.casedata.Id,
					message: messageval,
					fromId: this.chatWrap.currentContactId,
					toId: this.chatWrap.otherPartyContactId,
					accessCode: this.accessCode
				})
				.then(result => {
					if (result) {
						this.chatWrap = result;
						this.messageValue = '';
						this.template.querySelector('lightning-textarea[data-name="temp"]').value = '';
						var chatList = [];
						for (let ind in this.chatWrap.chatList) {
							let chatObj = {};
							chatObj['Id'] = this.chatWrap.chatList[ind].Id;
							chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
							chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
							chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
							chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
							if (this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId) {
								chatObj['selfUserChat'] = true;
							} else {
								chatObj['selfUserChat'] = false;
							}
							chatList.push(chatObj);
						}
						this.chatList = chatList;
					}
				}).catch(error => {
					console.log('updateChatHistory error => ' + JSON.stringify(error));
				})
		}
	}
	openFileUpload() {
		this.noevidenceupload = true;
		var chatWrap = this.chatWrap;
		if (chatWrap.numberOfEvidences >= 5) {
			return;
		}

		getSecureURI({ scheme: 'SDS' })
			.then(result => {
				console.log('getSecureURI result => ' + result);
				this.secureURI = result;
				this.showEvidenceCmp = true;
			}).catch(error => {
				console.log('getSecureURI error => ' + JSON.stringify(error));
			})


	}
	handleFilelLabelChange(event) {
		this.filelabelonchange = event.target.value;
	}
	handleFilesChange(event) {
		this.message = "";
		this.fileList = event.target.files[0];
		var files = this.fileList;
		if (files) {
			this.noevidenceupload = false;
		}
		let icon = files.name.toLowerCase();
		this.fileName = files.name;
		console.log('icon ' + icon);
		const ext = ['.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
		var fileTypeCheck = ext.some(el => icon.endsWith(el));
		if (fileTypeCheck == true) {
			this.fileLableVisible = true;
		} else {
			this.fileLableVisible = false;
		}
	}

	addEvidence() {
		var isvalid = false;
		var files = this.fileList;
		var getFileLabel = this.filelabelonchange;
		var sizeInMB = (files.size / (1024 * 1024)).toFixed(2);
		if (!files) { return; }

		if (files) {
			if (this.fileLableVisible == false) {
				let icon = files.name.toLowerCase();
				const ext = ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt', '.xls', '.xlsx', '.ods', '.msg', '.csv', '.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp', '.mp3', '.mp4', '.wmv', '.wav', '.ppt', '.pptx'];
				var fileTypeCheck = ext.some(el => icon.endsWith(el));
				if (!fileTypeCheck) {
					return alert("File type not supported!");
				} else if (sizeInMB > 20) {
					isvalid = false;
					return alert("File size is greater than 20mb");
				} else {
					isvalid = true;
				}
				if (isvalid == true) {
					this.createurl();
				}
			}

			if (this.fileLableVisible == true) {
				if (getFileLabel == undefined) {
					isvalid = false;
					this.fileLable = 'Please provide a label to upload image.';
				}
				if (getFileLabel.length > 50) {
					isvalid = false;
					this.fileLable = 'Character limit is 50.';
				}
				if (getFileLabel && getFileLabel.length <= 50) {
					isvalid = true;
				}
				if (isvalid == true) {
					this.createurl();
				}
			}

		}
	}

	createurl() {
		const currentDate = new Date();
		const timestamp = currentDate.getTime();
		var baseUrl = this.secureURI;
		var baseUrlLength = baseUrl.length;
		var indexOfQueryStart = baseUrl.indexOf("?");
		var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
		var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/' + this.casedata.Id + '-' + timestamp + '-' + this.fileList.name + sasKeys;
		var fileNameonAzure = this.casedata.Id + '-' + timestamp + '-' + this.fileList.name;

		this.azureLink = submitUri;

		var reader = new FileReader()
		reader.onload = () => {
			var base64 = reader.result.split(',')[1];
			this.uploadToAzure(this.fileList, submitUri, fileNameonAzure);
		}
		reader.readAsDataURL(this.fileList)
	}

	uploadToAzure(file, submitUri, fileNameonAzure) {
		var caseId = this.casedata.Id;
		var accessCode = this.accessCode;
		var fromId = this.chatWrap.currentContactId;
		var toId = this.chatWrap.otherPartyContactId;
		var fileName = this.fileName;
		var azureLink = this.azureLink;
		var fileType = (this.fileName).split('.').pop();
		var fileSize = this.fileList.size;
		var fileLable = this.filelabelonchange;

		var xhr = new XMLHttpRequest();
		var endPoint = submitUri;

		xhr.open("PUT", endPoint, true);
		xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
		console.log('uploadToAzure file type => ' + file.type);
		xhr.setRequestHeader('Content-Type', file.type);
		xhr.onreadystatechange = () => {
			if (xhr.readyState === 4 && xhr.status === 201) {
				// String caseId, string accessCode, String fromId, String toId, String fileName, String azureLink,
				//  String fileType, String fileSize, String fileLable, String fileNameInAzure, String scheme){
				saveFile({
					caseId: caseId,
					accessCode: accessCode,
					fromId: fromId,
					toId: toId,
					fileName: fileName,
					azureLink: azureLink,
					fileType: fileType,
					fileSize: fileSize,
					fileLable: fileLable,
					fileNameInAzure: fileNameonAzure,
					scheme: 'SDS'
				}).then(result => {
					console.log('saveFile result => ' + result);
					/* data = { ...result };
					var result1 = Object.assign({}, result)
					Object.preventExtensions(result);
					finalresult = result; */
					this.chatWrap = result;
					this.fileLableVisible = false;
					console.log("fileLableVisible => " + this.fileLableVisible)
					this.fileLable = "";
					this.fileName = "";
					this.filelabelonchange = "";
					this.showEvidenceCmp = false;
					console.log("showEvidenceCmp => " + this.showEvidenceCmp)


					var chatList = [];
					for (let ind in this.chatWrap.chatList) {
						let chatObj = {};
						chatObj['Id'] = this.chatWrap.chatList[ind].Id;
						chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
						chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
						chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
						chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
						if (this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId) {
							chatObj['selfUserChat'] = true;
						} else {
							chatObj['selfUserChat'] = false;
						}
						chatList.push(chatObj);
					}
					this.chatList = chatList;
					console.log('chatList => ' + this.chatList);


					/* Console log the user with the value returned from the server
					const toastEvent = new ShowToastEvent({
					  title: 'Info',
					  message: 'File Uploaded Successfully'+submitUri,
					  type: 'success'
					});
					this.dispatchEvent(toastEvent); */
				}).catch(error => {
					console.log("saveFile error => " + JSON.stringify(error) + error);
				});

			}
			else {
				//image error code
			}

		}
		xhr.send(file);
	}

	closeChatBox() {
		this.chatOpen = false;
	}

	closeModel2() {
		this.showEvidenceCmp = false;
		location.reload();

	}

	goToHomePage(event) {
		event.preventDefault();
		
		var urlString = window.location.search;
		var urlParams = new URLSearchParams(urlString);
		if (urlParams != undefined) {
			var branchRecId = urlParams.get('branchRecId');
			if (branchRecId != null) {
				this.branchId = atob(branchRecId);
			}
		}
		var encodeId = btoa(this.depositRecId);
		if (encodeId != null && encodeId != '' && encodeId != undefined) {
			if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
				this[NavigationMixin.Navigate]({
					type: 'comm__namedPage',
					attributes: {
						pageName: 'depositSummary'
					},
					state: {
						depositId: encodeId,
						branchRecId: btoa(this.branchId),
						showBranch: window.btoa('false')
					}
				});
			} else {
				this[NavigationMixin.Navigate]({
					type: 'comm__namedPage',
					attributes: {
						pageName: 'depositSummary'
					},
					state: {
						depositId: encodeId
					}
				});
			}
		}

	}
	
}