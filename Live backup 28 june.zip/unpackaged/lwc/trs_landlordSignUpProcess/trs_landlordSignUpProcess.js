import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import signUpController from '@salesforce/apex/TRS_LandlordSignup.signUpController';
import findAddress from '@salesforce/apex/TRS_LoqateServiceForSite.findAddress';
import retrieveAddress from '@salesforce/apex/TRS_LoqateServiceForSite.retrieveAddress';
import addressloqate from '@salesforce/label/c.NHOS_AddressLoqateKey';

const APIKEYID = addressloqate;

import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";
import trsSiteHomePageLink from "@salesforce/label/c.TRS_SiteHomePage";

export default class Trs_landlordSignUpProcess extends NavigationMixin(LightningElement) {

    label = {
        trsPortalHomePageLink
    };

    privacyPolicyPage = trsSiteHomePageLink+'trs-privacypolicypage';

    @track currentpage = 1;

    @track page1 = true;
    @track page2 = false;
    @track page3 = false;
    // @track firstcheckbox = false;
    @track secondcheckbox = false;
    @track thirdcheckbox = false;
    @track fourthcheckbox = false;
    @track completeDisabled = true;
    @track allValidationsCorrect = false;

    @track searchTerm = '';
    @track foundAddresses;
    @track selectedAddress;
    @track encodedKey = '';

    @track landlordSignUpDetails = {
        'Q1': {
            'FirstName': '',
            'LastName': '',
            'Phone': '',
            'Email': '',
            'StreetName': '',
            'AddTownCity': '',
            'County': '',
            'AddPostCode': '',
            'BaseCountry': '',
            'AddCountry': '',
            'NoofTenancies': ''
        }
    };

    apiId = APIKEYID;

    handleSearch(event) {
        this.searchTerm = event.target.value.trim();
        this.findAddress();
    }

    findAddress(secondCall) {
        let encodedSearchTerm = '';
        console.log('second call : '+secondCall);
        if(secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        }
        
        console.log('encoded : '+encodedSearchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = [];
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('error : ' + error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));
        console.log('cleanedid : '+cleanedId);

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);   
            this.findAddress(true);
        } else{
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
            .then(result => {
                this.foundAddresses = false;
                this.selectedAddress = JSON.parse(result);

                this.landlordSignUpDetails.Q1.StreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                this.landlordSignUpDetails.Q1.AddTownCity = this.selectedAddress.Items[0].City;
                this.landlordSignUpDetails.Q1.County = this.selectedAddress.Items[0].Province;
                this.landlordSignUpDetails.Q1.AddPostCode = this.selectedAddress.Items[0].PostalCode;
                this.landlordSignUpDetails.Q1.BaseCountry = 'England';
                this.landlordSignUpDetails.Q1.AddCountry = this.selectedAddress.Items[0].CountryName;

                this.searchTerm = this.selectedAddress.Items[0].PostalCode;
                this.addressValidation();
            })
            .catch(error => {
                console.log('error : ' + error);
            });
        }
        
    }

    /*handleSearch(event) {
        this.searchTerm = event.target.value.trim();
        this.findAddress();
    }

    findAddress() {
        const encodedSearchTerm = encodeURIComponent(this.searchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                const addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('Error: find ', error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));

        if (cleanedId.includes('-')) {
            this.searchTerm = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTerm);

            this.findAddress();

            return;
        } else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
                .then(result => {
                    this.selectedAddress = JSON.parse(result);

                    this.landlordSignUpDetails.Q1.StreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                    this.landlordSignUpDetails.Q1.AddTownCity = this.selectedAddress.Items[0].City;
                    this.landlordSignUpDetails.Q1.County = this.selectedAddress.Items[0].Province;
                    this.landlordSignUpDetails.Q1.AddPostCode = this.selectedAddress.Items[0].PostalCode;
                    this.landlordSignUpDetails.Q1.BaseCountry = 'England'; //this.selectedAddress.Items[0].
                    this.landlordSignUpDetails.Q1.AddCountry = this.selectedAddress.Items[0].CountryName;

                    this.foundAddresses = null;
                    this.searchTerm = this.selectedAddress.Items[0].PostalCode;

                    let searchCmp = this.template.querySelector(".streetName");
                    searchCmp.reportValidity();

                    this.validations();
                })
                .catch(error => {
                    console.log('inside eror', error);
                });
        }
    }*/

    handleAllChanges(event) {
        if (event.target.name == 'q1firstname') {
            this.landlordSignUpDetails.Q1.FirstName = event.target.value;
            this.landlordSignUpDetails.Q1.FirstName = this.landlordSignUpDetails.Q1.FirstName.trim();
        } else if (event.target.name == 'q1lastname') {
            this.landlordSignUpDetails.Q1.LastName = event.target.value;
            this.landlordSignUpDetails.Q1.LastName = this.landlordSignUpDetails.Q1.LastName.trim();
        } else if (event.target.name == 'q1phone') {
            this.landlordSignUpDetails.Q1.Phone = event.target.value;
        } else if (event.target.name == 'q1email') {
            this.landlordSignUpDetails.Q1.Email = event.target.value;
            this.landlordSignUpDetails.Q1.Email = this.landlordSignUpDetails.Q1.Email.trim();
        } else if (event.target.name == 'q1streetname') {
            this.landlordSignUpDetails.Q1.StreetName = event.target.value;
        } else if (event.target.name == 'q1towncity') {
            this.landlordSignUpDetails.Q1.AddTownCity = event.target.value;
        } else if (event.target.name == 'q1county') {
            this.landlordSignUpDetails.Q1.County = event.target.value;
        } else if (event.target.name == 'q1postcode') {
            this.landlordSignUpDetails.Q1.AddPostCode = event.target.value;
        } else if (event.target.name == 'q1country') {
            this.landlordSignUpDetails.Q1.AddCountry = event.target.value;
        } else if (event.target.name == 'q1nooftenancies') {
            this.landlordSignUpDetails.Q1.NoofTenancies = event.target.value;
        }

        this.validations();
    }

    validations() {
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var phoneCorrect = false;
        var emailcorrect = false;
        var addresscorrect = false;
        //var tenantnocorrect = false;

        if (this.landlordSignUpDetails.Q1.FirstName != '' && this.landlordSignUpDetails.Q1.FirstName != undefined) {
            const firstnamepattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!firstnamepattern.test(this.landlordSignUpDetails.Q1.FirstName)) {
                let searchCmp = this.template.querySelector(".firstname");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid first name without space");
                }
                firstNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".firstname");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                firstNameCorrect = true;
            }
        } else {
            this.template.querySelector(".firstname").setCustomValidity("");
        }

        if (this.landlordSignUpDetails.Q1.LastName != '' && this.landlordSignUpDetails.Q1.LastName != undefined) {
            const lastnamepattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!lastnamepattern.test(this.landlordSignUpDetails.Q1.LastName)) {
                let searchCmp = this.template.querySelector(".lastname");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid last name without space");
                }
                lastNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".lastname");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                lastNameCorrect = true;
            }
        } else {
            this.template.querySelector(".lastname").setCustomValidity("");
        }

        if (this.landlordSignUpDetails.Q1.Phone != null && this.landlordSignUpDetails.Q1.Phone != undefined && this.landlordSignUpDetails.Q1.Phone != '') {
            const phoneRegex = /^0\d{10}$/;
            if (!phoneRegex.test(this.landlordSignUpDetails.Q1.Phone)) {
                let searchCmp = this.template.querySelector(".phone");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
                phoneCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".phone");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                phoneCorrect = true;
            }
        } else if (this.landlordSignUpDetails.Q1.Phone == '') {
            this.template.querySelector(".phone").setCustomValidity("");
            phoneCorrect = true;
        }

        if (this.landlordSignUpDetails.Q1.Email != '' && this.landlordSignUpDetails.Q1.Email != undefined) {
            const emailRegex = /^(\s*)?[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(\s*)?$/;
            if (!emailRegex.test(this.landlordSignUpDetails.Q1.Email)) {
                let searchCmp = this.template.querySelector(".email");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid email");
                }
                emailcorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".email");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                emailcorrect = true;
            }
        } else {
            this.template.querySelector(".email").setCustomValidity("");
        }

        if ((this.landlordSignUpDetails.Q1.StreetName != undefined && this.landlordSignUpDetails.Q1.StreetName != null && this.landlordSignUpDetails.Q1.StreetName != '')
            && (this.landlordSignUpDetails.Q1.AddTownCity != null && this.landlordSignUpDetails.Q1.AddTownCity != undefined && this.landlordSignUpDetails.Q1.AddTownCity != '')
            && (this.landlordSignUpDetails.Q1.AddPostCode != null && this.landlordSignUpDetails.Q1.AddPostCode != '' && this.landlordSignUpDetails.Q1.AddPostCode != undefined)
        ) {
            addresscorrect = true;
        } else {
            addresscorrect = false;
        }

        if (this.landlordSignUpDetails.Q1.NoofTenancies != '' && this.landlordSignUpDetails.Q1.NoofTenancies != undefined) {
            const tenancyRegex = /^[0-9]+$/;
            if (!tenancyRegex.test(this.landlordSignUpDetails.Q1.NoofTenancies)) {
                let searchCmp = this.template.querySelector(".nooftenancies");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter only numbers");
                }
            } else {
                let searchCmp = this.template.querySelector(".nooftenancies");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else {
            this.template.querySelector(".nooftenancies").setCustomValidity("");
        }

        // if (firstNameCorrect && lastNameCorrect && phoneCorrect && emailcorrect && addresscorrect && this.firstcheckbox && this.secondcheckbox && this.thirdcheckbox && this.fourthcheckbox) {
        if (firstNameCorrect && lastNameCorrect && phoneCorrect && emailcorrect && addresscorrect && this.secondcheckbox && this.thirdcheckbox && this.fourthcheckbox) {
            this.completeDisabled = false;
        } else {
            this.completeDisabled = true;
        }

    }

    handleCheckbox(event) {
        // if (event.target.dataset.name == 'q1checkbox1') {
        //     this.firstcheckbox = event.target.checked;
        // }
        // else if (event.target.dataset.name == 'q1checkbox2') {
        if (event.target.dataset.name == 'q1checkbox2') {
            this.secondcheckbox = event.target.checked;
        } else if (event.target.dataset.name == 'q1checkbox3') {
            this.thirdcheckbox = event.target.checked;
        } else if (event.target.dataset.name == 'q1checkbox4') {
            this.fourthcheckbox = event.target.checked;
        }

        this.validations();
    }

    handleComplete() {
        signUpController({ landlordDet: JSON.stringify(this.landlordSignUpDetails) })
            .then(result => {
                if (Object.values(JSON.parse(result))[0] == false) {
                    let errormsg = Object.values(JSON.parse(result))[1].errorMessage;
                    if (errormsg == 'User is already present with this email') {
                        const toastEvent = new ShowToastEvent({
                            title: 'Error',
                            message: 'User is already present with this email',
                            variant: 'error',
                        });
                        this.dispatchEvent(toastEvent);
                    } else if (errormsg == 'message : Something went wrong, Please contact SF admin') {
                        const toastEvent1 = new ShowToastEvent({
                            title: 'Error',
                            message: 'Please fill correct values',
                            variant: 'error',
                        });
                        this.dispatchEvent(toastEvent1);
                    }
                } else {
                    this.currentpage++;
                    this.getexpression();
                }

            })
            .catch(error => {
                console.log('error is ', error);
            });
    }

    sendEmail() {
        this.currentpage++;
    }

    handleBackToHome() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TRS_LandlordLandingPage__c'
            }
        });
    }

    getexpression() {
        this.page1 = this.currentpage == 1 ? true : false;
        this.page2 = this.currentpage == 2 ? true : false;
        this.page3 = this.currentpage == 3 ? true : false;
    }
}