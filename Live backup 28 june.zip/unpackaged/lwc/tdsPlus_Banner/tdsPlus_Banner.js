import { LightningElement , api} from 'lwc';
// import { getContent } from "experience/cmsDeliveryApi";
// import siteId from "@salesforce/site/Id";
/**
 * @slot Content-Region
*/

export default class TdsPlus_Banner extends LightningElement {
   

    @api headding1='';
    @api heading2='';
    @api description='';
    @api btn_01_text='';
    @api btn_01_link='';
    @api btn_02_text='';
    @api btn_02_link='';

    

    get isButtontextNotNull1(){
        if(this.btn_01_text==null || this.btn_01_text==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isButtontextNotNull2(){
        if(this.btn_02_text==null || this.btn_02_text==''){
            return false;
        }
        else{
            return true;
        }
    }
    // @api contentKey;
    // data;
    // popupcontain;
   
    // @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    // onGetContent(result) {
    //   if (result.data) {
    //     this.data = result.data;
    //     // console.log('line no:15'+result.data.title);
    //     console.log('line no:17'+result.data.contentBody.Subtitle);
    //     this.popupcontain=result.data.contentBody.Subtitle;  
    //     console.log(JSON.stringify(result));
   
   
    //   }
    //   else{
    //    console.log('error line24');
    //  }   
    // }
   
       
   }