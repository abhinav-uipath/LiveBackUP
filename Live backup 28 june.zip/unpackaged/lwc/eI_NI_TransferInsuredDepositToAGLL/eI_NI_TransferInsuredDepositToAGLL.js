import { LightningElement,track,wire,api } from 'lwc';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getDepositInformation from '@salesforce/apex/EI_NI_TransferDeposit.getDepositInformation';
import getAgentLandlordTransferDetails from '@salesforce/apex/EI_NI_TransferDeposit.getAgentLandlordTransferDetails';
import ni_depositSummryUrl from '@salesforce/label/c.ni_depositSummryUrl'; 

export default class EI_NI_TransferInsuredDepositToAGLL extends NavigationMixin (LightningElement) {
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    successImage = NI_Theme + '/assets/img/thank-you.png';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    @track showThankYouPage = false;

    depositId = '';
    depositList = [];
    @track depositInfo = [];
    loggedInUser = '';
    emailNotValid = false;
    isConfirmationPopUp = false;
    isEmailBlankError=false;
    isEmailFormatError = false;
    isSameAccountError = false;
    @track isSubmitDisabled = false;
    @track showSpinner = false;
    @wire(CurrentPageReference)
    currentPageReference;
    @track emailFieldValue = '';
    @track ProtectedAmount = 0.00;
    @track goToDepositSummary = ni_depositSummryUrl;
    branchId = null;
    connectedCallback() {

        var depositRecId = `${this.currentPageReference.state.depositId}`;
        console.log('DepositId::', depositRecId);
        this.depositId = atob(depositRecId);
        console.log('Decrypt DepositId:::', this.depositId);

        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null) {
                this.branchId = window.atob(branchRecId);
            } else {
                this.branchId = null;
            }
              
            }

        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            
        ]).then(() => {
            console.log('Files loaded');

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });      
        // const param = 'dipositeId';
        // this.depositId =atob(this.getUrlParamValue(window.location.href, param));
        // console.log('Decrypt DepositId:::', this.depositId);
        //getDepositInformation()
        getDepositInformation().then(result => {
            console.log('Deposit Wrapper Response:::', JSON.stringify(result));
            this.depositList = result.depositList;
            this.loggedInUser = result.loggedInUser;
            console.log('Deposit List: '+this.depositList);
            console.log('Logged In User: '+this.loggedInUser);
            console.log('User Profile: '+this.loggedInUser.Profile.Name);
            const selectedDeposit  = this.depositList.find(deposit => deposit.Id === this.depositId);
            if (selectedDeposit) {
                this.depositInfo = selectedDeposit;
                console.log('this.depositInfo:', JSON.stringify(this.depositInfo));
                if(this.depositInfo.Deposit_Amount__c >0){
                    this.ProtectedAmount = this.depositInfo.Deposit_Amount__c.toFixed(2);
                }
                else{
                    this.ProtectedAmount= '0.00';
                }
                
            } else {
                console.log('Deposit not found');
            }
        }).catch(error => {
            console.log('Error fetching post codes:::', JSON.stringify(error));
        })
    }



    goBackHandle(event) {
        event.preventDefault();
        // var depId = `${this.currentPageReference.state.depositId}`;
        // console.log('depId: '+depId);
        // this.depositId = window.atob(depId);
        console.log('depositIdGoback==>'+this.depositId);
      //  window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId);
        if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
            window.location = window.location.origin + this.goToDepositSummary + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
           // window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
        }
        else{
            window.location = window.location.origin + this.goToDepositSummary + window.btoa(this.depositId);
            //window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId);
        }
    }
    handleEmailChange(event){
      
        this.emailFieldValue = event.target.value;
        console.log('email :'+this.emailFieldValue);
        console.log('email :'+emailFieldValue);
       
    }

    transferSingleDeposit(event){
        console.log('Submit clicked');
        event.preventDefault();
        console.log('email==>'+this.emailFieldValue);
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
        var isValid = true;
        if(this.emailFieldValue ==null || this.emailFieldValue == undefined || this.emailFieldValue == ''){
            this.isEmailBlankError=true;
            isValid = false;
        }
        
        else{
            this.isEmailBlankError=false;
            this.isEmailFormatError = false;
        }
        if((this.emailFieldValue!='') && !this.emailFieldValue.match(regExpEmailformat)){
            this.isEmailFormatError = true;
            isValid= false;
        }
        else{
            this.isEmailFormatError = false;
        }
        if(isValid){
            this.showThankYouPage = true;
        }
        
    }
    submitTransfers(event){
        event.preventDefault();
        this.showSpinner = true;
        console.log('transfer confirm clicked');
        var listDepositId =[];
        listDepositId.push(this.depositId);
        console.log('transfer confirm clicked==>'+listDepositId);
        this.isSubmitDisabled = true;
        var listProfiles = ['NI_Agent','NI_Landlord','NI_ Branch Users','NI_Head_Office_User'];
        console.log('Profile Names: '+listProfiles);
        getAgentLandlordTransferDetails({emailValue:this.emailFieldValue,listDepositId:listDepositId, profileNamesList:listProfiles,scheme:'NI Insured' })
        .then(result=>{
            console.log('Result: '+result);
            console.log('Result: '+result);
            if(result=='same account'){
                this.isSameAccountError=true;
                // isValid = false;
                this.isSubmitDisabled = false;
                this.showSpinner = false;
                console.log('Transferred within same Account error');
                this.showThankYouPage = false;
            } if(result=='non member landlord') {
                this.isSameAccountError=true;
                // isValid = false;
                this.isSubmitDisabled = false;
                this.showSpinner = false;
                console.log('Transferred to non member landlord error');
                this.showThankYouPage = false;
            } else if(result=='transferred'){
                this.showSpinner = false;
                //this.showThankYouPage = true;
                event.preventDefault();
                var depId = `${this.currentPageReference.state.depositId}`;
                console.log('depId: '+depId);
                this.depositId = window.atob(depId);
               // window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId);
                this.isConfirmationPopUp = false;
                
                if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                    window.location = window.location.origin + this.goToDepositSummary + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                    //window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                }
                else{
                    window.location = window.location.origin + this.goToDepositSummary + window.btoa(this.depositId);
                    //window.location = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + window.btoa(this.depositId);
                }
                console.log('Transferred');
                
            }
            
        })
        .catch(error=>{
            console.log('error while submitting transfer=>'+JSON.stringify(error));
        });
    }
    handleConfirmDialogNo(event){
        this.showThankYouPage = false;
        this.emailFieldValue = '';
    }
    hideBootstrapErrors(event){ 
        var button_Name = event.target.name;
        switch (button_Name) { 
            case "emailBlank":
                this.isEmailBlankError=false;
            break;
            case "emailFormat":
                this.isEmailFormatError=false;
            break;
            case "sameAccount":
                this.isSameAccountError=false;
            break;
        }
    }

}