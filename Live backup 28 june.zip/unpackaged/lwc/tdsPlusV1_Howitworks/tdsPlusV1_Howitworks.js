import { LightningElement,api,wire } from 'lwc';
import { getContent } from "experience/cmsDeliveryApi";
import siteId from "@salesforce/site/Id";


export default class TdsPlusV1_Howitworks extends LightningElement {
    @api mainheading ='';
    @api description1 ='';
    @api description2 ='';
    @api description3 ='';
    @api description4 ='';
    @api description5 ='';


    get isDescription1NotNull(){
        if(this.description1==null || this.description1==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isDescription2NotNull(){
        if(this.description2==null || this.description2==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isDescription3NotNull(){
        if(this.description3==null || this.description3==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isDescription4NotNull(){
        if(this.description4==null || this.description4==''){
            return false;
        }
        else{
            return true;
        }
    }

    get isDescription5NotNull(){
        if(this.description5==null || this.description5==''){
            return false;
        }
        else{
            return true;
        }
    }

  

}