import { LightningElement ,api,track} from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class ei_NI_TenantPagination extends NavigationMixin(LightningElement) {
    @api custodialPagination=false;
    @api registeredPagination=false;
    @api statuslistrnp=[];
    @api paginationrnplist=[];
    @track startPageRNP=0;
    @track endPageRNP=0;
    @track pageSizeRNP=10;
    @track currentPageRNP=1;
    @track totalPagesCountRNP=1;
    @track pageSize;
    @api amountLabel=false;
    pageStartRNP=false;
    pageEndRNP=false;
    connectedCallback(){
    console.log('child data: ');
    //code for pagination
    this.pageSize = this.pageSizeRNP;
    console.log('this.pageSize: '+this.pageSize);
    this.startPageRNP = 0;
    console.log('this.startPageRNP:'+this.startPageRNP);
    this.endPageRNP = this.pageSize - 1;
    console.log(' this.endPageRNP'+ this.endPageRNP);
    console.log('InputStatusListSize==>'+this.statuslistrnp.length);
    if (this.statuslistrnp && this.statuslistrnp.length > 0) {
    this.totalPagesCountRNP=Math.ceil((this.statuslistrnp.length) /this.pageSize);
    }
    console.log('totalPagesCountRNP: '+this.totalPagesCountRNP);
    console.log('this.paginationrnplist.length: '+this.paginationrnplist.length);
    console.log('custodialPagination: '+this.custodialPagination);
    //code for pagination
    if(this.startPageRNP === 0 || this.statuslistrnp.length === 0){
        this.pageStartRNP=true;
    }
    if((this.endPageRNP + 1) >= this.totalRecordsCountRNP || this.statuslistrnp.length === 0 || this.totalPagesCountRNP<=1){
        this.pageEndRNP=true;
        
    }

    var paginationList = [];
    var totalRecordsList =  this.statuslistrnp;     
    for (var i = 0; i < this.pageSize; i++) {
        if (totalRecordsList.length > i) {
            paginationList.push(totalRecordsList[i]);
        }
    }
    this.paginationrnplist = paginationList;
}

 
    navPageRNP(event){
        console.log('success 10');
        event.preventDefault();
        var sObjectList = this.statuslistrnp;
        console.log('length: '+this.statuslistrnp.length);
        console.log('line 301' +JSON.stringify(sObjectList));
        var end = this.endPageRNP;
        var start = this.startPageRNP;
        var pageSize = Number(this.pageSizeRNP);
        if (event.target.name == "nextId") {
            this.pageStartRNP=false;
            this.currentPageRNP+=1;
            var Paginationlist = [];
            var counter = 0;
            for (var i = end+1 ; i < end + pageSize+1; i++) {
                if (sObjectList.length > i) {
                    {
                        Paginationlist.push(sObjectList[i]);
                    }
                }
                counter++;
            }
                start = start + counter;
                end = end + counter;
                this.startPageRNP=start;
                this.endPageRNP=end;
                if(this.currentPageRNP==this.totalPagesCountRNP){
                    this.pageEndRNP=true;
                } 
                console.log('line 340 length: '+Paginationlist.length);
                console.log('line 69: '+JSON.stringify(Paginationlist));
                this.paginationrnplist=Paginationlist;
            }
                else if (event.target.name == "previousId") {
                this.pageEndRNP=false;
                this.currentPageRNP-=1;
                var Paginationlist = [];
                var counter = 0;
                for (var i = start - pageSize; i < start; i++) {
                    if (i > -1) {
                        {
                            Paginationlist.push(sObjectList[i]);
                        }
                        counter++;
                    } else {
                        start++;
                    }
                }
                start = start - counter;
                end = end - counter; 
                this.startPageRNP=start;
                this.endPageRNP=end;
                if(this.currentPageRNP==1){
                    this.pageStartRNP=true;
                }
                this.paginationrnplist=Paginationlist;
            } 

           
    }
    navigateToSummary(event) {
        event.preventDefault();
        var depositId = window.btoa(event.currentTarget.name);
        // var depositId = event.currentTarget.name;
        if (depositId != null && depositId != "" && depositId != undefined) {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'deposit-summary'
                },
                state: {
                    c__depositRecId: depositId
                }
            });
        }
    }

}