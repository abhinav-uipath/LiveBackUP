import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import jQuery from '@salesforce/resourceUrl/JQuery';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
// import TDSResource from '@salesforce/resourceUrl/TDSTheme';
import getAddDepositWrapper from '@salesforce/apex/EI_NI_addInsuredDeposit.addDepositWrapper';
import getPropertiesWrapper from '@salesforce/apex/EI_NI_addInsuredDeposit.getProperties';
import searchLandlord from '@salesforce/apex/EI_NI_addInsuredDeposit.serachlandlord';
import insertProperties from '@salesforce/apex/EI_NI_addInsuredDeposit.insertProperties';
import getLandlordforSummary from '@salesforce/apex/EI_NI_addInsuredDeposit.getLandlordforSummary';
import finalSave from '@salesforce/apex/EI_NI_addInsuredDeposit.finalSave';
// import getContact from '@salesforce/apex/EI_NI_addInsuredDeposit.getContactDetails';
import getAccount from '@salesforce/apex/EI_NI_addInsuredDeposit.getAccountDetails';
import getPropertiesDup from '@salesforce/apex/EI_NI_ManageProperties.fetchDupProperties';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';
import ei_NI_PostLoginChannel from '@salesforce/messageChannel/ei_NI_PostLoginChannel__c';
import { publish, MessageContext } from 'lightning/messageService';
import fetchUserType from '@salesforce/apex/ei_NI_payDepositHelper.fetchUserType';
import ni_depositSummryUrl from '@salesforce/label/c.ni_depositSummryUrl';
import NI_payDepositGoBackUrl from '@salesforce/label/c.NI_payDepositGoBackUrl';
export default class EI_NI_addInsuredDeposit extends NavigationMixin(LightningElement) {
    backBtnImg = NI_Theme + '/assets/img/md-arrow-dropleft.png';
    backArrowImg = NI_Theme + '/assets/img/md-arrow-dropleft.png';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    tooltip_iconImg = NI_Theme + '/assets/img/tooltip_icon.svg';
    featherImg = NI_Theme + '/assets/img/feather-edit.svg';
    viewIconImg = NI_Theme + '/assets/img/View_icon.svg';
    cancel_icon = NI_Theme + '/assets/img/Cancel-icon.png';
    calender_icon = NI_Theme + '/assets/img/Calendar_Icon_sf.png';

    @track dateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

    @track monthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

    @track yearList = [];

    // tenancy date
    @track tenancyDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

    @track tenancyEndDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
    { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
    { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
    { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
    { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
    { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
    { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
    { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

    @track tenancyMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

    @track tenancyEndMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
    { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
    { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
    { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

    @track tenancyYearList = [];
    @track tenancyEndYearList = [];

    @track errorMetaDataRecords = [];
    @track niPostcodeMetaDataRecords = [];
    @track phoneCodeList = [];
    @track salutation = [];
    @track defaultPhoneCode = '+44';

    // Display tracker
    isAddDeposit = true;
    isAddCustodialDeposit = true;
    isPropertySelectDisplay = true;
    @track isPropertyYesDisplay = false;
    @track isPropertyNoDisplay = false;
    isDepositDetailDisplay = false;
    isTenantDetailDisplay = false;
    isDepositSummaryDisplay = false;
    isAdditionalLandLord = false;

    // Listed Property search
    @api searchAddressString = '';                 // To store the text entered to find the respective addresses
    @track branchId = null;
    @track listedPropAddress = [];
    @track listedPropId = '';
    @track propertyDepositTenants = [];
    @track islistedPropAddressOfNI = false;
    isListedValidAddressError = false;
    isListedPropertyError = false;
    isShowListedAddress = false;
    showDupPropertyWarning = false;
    isManualAddress = false;
    isShowSelectedAddresses = false;
    @track houseNo = '';
    @track streetName = '';
    @track townCity = '';
    @track county = '';
    @track postCode = '';
    @track country = '';
    @track listedSelectedAddress = '';
    @track finalSelectedAddress = '';
    @track defaultPrimaryAddress = [];
    @track insertedPropertyId = '';   // contains selected property id
    @api searchLandlordString = '';
    @track primaryLandLordList = [];
    @track selectedPrimaryLandlord = [];
    @track primaryLandlordName = '';
    @track addLandLordList = [];
    @track additionalLandlord = [];
    @track selectedAdditionalLandLord = [];
    @track selectedjointlandlordID = [];
    isShowListedLandlord = false;
    isShowListedAddLandlord = false;
    isPrimaryLandlordError = false;
    isAdditionalLandlordError = false;
    isPrimaryLandlordNameError = false;
    isAdditionalLandlordNameError = false;

    // property no select error
    ispropertyfinalError = false;
    isWrongCharacterStreet = false;
    isPrimaryLandlord = false;
    isPropertySearch = false;
    isPostcodeErrorAlert = false;

    // deposit error
    isGenericError = false;
    isAmountCantBeLessThan1Error = false;
    isTenantNumberError = false;
    isRentAmountError = false;
    isDepositAmountError = false;
    isAmtToProtectError = false;
    isShowDepositDateError = false;
    isShowTenancyDateError = false;
    isShowTenancyEndDateError = false;
    isTenancyDateFutureError = false;
    isDepositDateFutureError = false;

    showDepositMessage = false;

    // deposit data
    @track rentAmt;
    @track depositAmt;
    @track amtToProtect;
    @track depositDay;
    @track depositMonth;
    @track depositYear;
    @track depositReceiveDateYMD;
    @track depositReceiveDateDMY;
    @track tenancyDay;
    @track tenancyMonth;
    @track tenancyYear;
    @track tenancyEndDay;
    @track tenancyEndMonth;
    @track tenancyEndYear;
    endDateError = false;
    @track tenancyStartDateYMD;
    @track tenancyStartDateDMY;
    @track tenancyEndDateYMD;
    @track tenancyEndDateDMY;
    @api numOfTenants;         // (used only in blur function)
    @track depositRef = '';
    @track todayDate = '';
    @track pickedValue;
    @track pickedendValue;
    @track receivedPickedValue;
    @track displayModal = false;
    // Property selection
    @track tenancyManagedYes = 'Not supplied';
    @track tenancyManagedNo = 'Not supplied';
    @track propertyAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
    @track primaryAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
    @track isPrimaryAddressOfNI;
    isWarningShow = false;

    // Deposit details
    @track depositReceivedDate;
    @track tenancyStartDate;
    @track tenancyEndDate;
    @api numberOfTenants;   // in use to transfer data to child component
    @track arrObj = {};
    @track leadTenantObj = {};
    @track tenantItemList = [];
    @track itemListlength;

    // Data from child
    @track childTenantData = [];
    isTenantSaveError = false;
    @track childLandlordData = [];

    @track childRelevantData = {
        isRelevantYesSelect: false, relevantCompanyYesCheck: false, relevantCompanyName: '', relevantCompanyEmail: '', relevantCompanyPhonecode: '+44', relevantCompanyMobile: '',
        relevantCompanyNoCheck: false, relevantTitle: '', relevantFirstname: '', relevantSurname: '', relevantEmail: '', relevantPhoneCode: '+44', relevantMobile: '', relevantAddress: '', relevantCorrAddress: '', primaryAddress: {}, corresAddress: {}, isSaveClick: false
    };
    @track isRelevantPresent = false;
    isRelevantSaveError = false;
    @track productType='';
    @track typeOfUser='';
    // Deposit Summary
    isDuplicateTenantEmailError = false;
    isDuplicateTenantPhoneError = false;
    isDuplicateRelevantEmailError = false;
    isCollapseOneShow = false;
    isCollapseTwoShow = false;
    isCollapseThreeShow = false;
    isCollapseFourShow = false;
    isCollapseFiveShow = false;
    isRelevantSummaryShow = false;
    isCancelDeposit = false;
    isCancelDepositInsured = false;
    isDepositCreatedMsg = false;
    isDepositErrorMsg = false;
    @track goToAddDeposit = '#';
    @track btnClicked = false;
    isLoading = false;
    InsuredDeposit;
    CustodialDeposit;
    contactRec;
    AccountRec;
    payAsYouGo = false;
    monthlyInvoicing = false;
    userAgent; //For 48
    userLandlord; //For 69
    tenantassociatedYesOrNoValueFromParent;
    relevantPersonYesOrNoValueFromParent;
    releventPersonAssociatedWithDepositCompanyYesOrNoValueFromParent;
    allTenantEmails = [];
    @track loggedInUser = [];
    isShowTenantSection = true;
    isShowRelevantPersonSection = true;
    saveAndLaterCss = 'learn-more mb-4';
    @track depositSummryUrl=ni_depositSummryUrl;
     // added variable for TGK-445 start
     @track madeDisable = false;
     protectedAmountError = false;
     // added variable for TGK-445 end
     @track goBackYes = NI_payDepositGoBackUrl;
     @track cancelDepositYes = NI_payDepositGoBackUrl;
    @wire(MessageContext)
    messageContext;
    renderedCallback() {
    }

    @wire(getAccount)
    wiredAccountRec({ error, data }) {
        if (data) {
            console.log('return Data - ' + data);
            this.AccountRec = data;
            console.log('return Data Id - ' + this.AccountRec.Id);
            if (this.AccountRec.Pay_for_Tenancies__c == 'Pay as you go') {
                this.payAsYouGo = true;
                this.monthlyInvoicing = false;
            }
            else if (this.AccountRec.Pay_for_Tenancies__c == 'Monthly Invoicing') {
                this.payAsYouGo = false;
                this.monthlyInvoicing = true;
            }
        } else if (error) {
            console.log('return Data error - ', error);
        }
    }
   
    connectedCallback() {
        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js'),
            loadScript(this, NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_Theme + '/assets/js/datepicker.js')

        ])
            .then(() => {
                console.log('Files loaded');

            })
            .catch(error => {
                console.log('Error => ', JSON.stringify(error));
            });

        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);

        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null && branchRecId != '' && branchRecId != undefined) {
                this.branchId = window.atob(branchRecId);
            }
        }

        getAddDepositWrapper()
            .then(data => {

                console.log('Line 157 Data length-->' + data.length);
                if (data.length > 0) {
                    // console.log('Line 82 -> ', JSON.stringify(data[0].errorMessageList));
                    this.errorMetaDataRecords = data[0].errorMessageList;
                    // console.log('Line 84 -> ',JSON.stringify(data[0].niPostcodeList));
                    this.niPostcodeMetaDataRecords = data[0].niPostcodeList;
                    // Salutation load
                    var conts = data[0].salutationMap;
                    for (var key in conts) {
                        this.salutation.push({ value: conts[key], key: key }); //Here we are creating the array to show on UI.
                    }
                    // console.log('Line 177 Salutation -> ', data[0].salutationMap);
                    this.loggedInUser = data[0].loggedInUser;
                    console.log('this.loggedInUser' , this.loggedInUser.Contact.Account.Insured_User__c);
                    if (this.loggedInUser.Contact.Account.Insured_User__c) {
                        let message = {showButton: true,
                            typeOfUser: true};
                        publish(this.messageContext, ei_NI_PostLoginChannel, message);
                    } else {
                        let message = {showButton: true,
                            typeOfUser: false};
                        publish(this.messageContext, ei_NI_PostLoginChannel, message);
                    }
                    console.log('line 239 User detail-->' + JSON.stringify(this.loggedInUser));
                    if (this.loggedInUser.User_Type__c == 'Landlord') {
                        this.userLandlord = true;
                        this.userAgent = false;
                        var returnedData = this.loggedInUser.Contact;
                        // console.log('Line 246 Primary Landlord returnedData--->' + JSON.stringify(returnedData));
                        var fullName;
                        if (returnedData.FirstName != undefined || returnedData.FirstName != null) {
                            fullName = returnedData.FirstName + " " + returnedData.LastName;
                        } else {
                            fullName = returnedData.LastName;
                        }
                        // console.log("fullName-->", fullName);
                        this.primaryLandlordName = fullName;
                        var primaryLL = [];
                        primaryLL = [{
                            Id: returnedData.Id, Salutation: returnedData.Salutation, FirstName: returnedData.FirstName, LastName: returnedData.LastName,
                            Email: returnedData.Email, Phone: returnedData.Phone, Landlord_reference__c: returnedData.Landlord_reference__c, AccountId: returnedData.AccountId
                        }];
                        this.selectedPrimaryLandlord = primaryLL;
                        this.selectedjointlandlordID= returnedData.Id;

                        console.log('Line 246 Primary Landlord List--->' + JSON.stringify(this.selectedPrimaryLandlord));

                    } else if (this.loggedInUser.User_Type__c == 'Agent') {
                        this.userLandlord = false;
                        this.userAgent = true;
                    }
                }
            })
            .catch(error => {
                console.error('Error calling add deposit wrapper ==> ' + JSON.stringify(error));
            })

        //let currentYear = new Date().getFullYear();
        let yearList = [];
        for (var i = 2012; i <= 2050; i++) {
            yearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
            //yearList.push({label:'selectYear'+i, key:i});
        }
        this.yearList = yearList;

        let tenancyYearList = [];
        let tenancyEndYearList = [];
        for (var i = 2012; i <= 2050; i++) {
            tenancyYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
            tenancyEndYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
            //yearList.push({label:'selectYear'+i, key:i});
        }
        this.tenancyYearList = tenancyYearList;
        this.tenancyEndYearList = tenancyEndYearList;
         //  date picker code start 
         var today = new Date();
         var todayDate = today.getDate();
         todayDate = todayDate>9 ? todayDate : '0'+todayDate;
         var todayMonth = today.getMonth()+1;
         todayMonth = todayMonth>9 ? todayMonth : '0'+todayMonth;
         var todayYear = today.getFullYear();
         this.todayDate = todayYear+'-'+todayMonth+'-'+todayDate;
         console.log(' MAx todayDate => ' + this.todayDate);
     //  date picker code end 
    }
    resetDepositStateHandle(event) {
        event.preventDefault();
        this.isAddCustodialDeposit = true;
        this.isAddDeposit = false;
    }

    goBackHandle(event) {
        // event.preventDefault();
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        var showBranchPage = '';

        var branchRecId = urlParams.get('branchRecId');
        if (branchRecId != null && branchRecId != '' && branchRecId != undefined && urlString.includes('branchRecId')) {
            this.branchId = window.atob(branchRecId);
            showBranchPage = window.btoa('false');
        }

        if (urlString.includes('branchRecId')) {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'viewbranchuser'
                }, state: {
                    branchRecId: window.btoa(this.branchId),
                    showBranch: showBranchPage
                }
            });
        } else {
            // window.location = window.location.origin + '/ni/s/';
            window.location = window.location.origin + this.goBackYes;
        }   
    }

    propertyYesHandle(event) {
        event.preventDefault();
        console.log('line 48 yes ');
        this.selectedPrimaryLandlord = [];
        this.selectedAdditionalLandLord = [];

        this.isPropertyYesDisplay = true;
        this.isPropertyNoDisplay = false;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = false;
        this.isDepositSummaryDisplay = false;
        let selectYesBtn = this.template.querySelector('[name="property_yes"]');
        selectYesBtn.style.backgroundColor = '#13185C';
        selectYesBtn.style.color = '#fff';

        this.template.querySelector('[name="property_no"]').style = '';
    }

    propertyNoHandle(event) {
        event.preventDefault();
        console.log('line 56 no');
        this.selectedPrimaryLandlord = [];
        this.selectedAdditionalLandLord = [];

        this.isPropertyYesDisplay = false;
        this.isPropertyNoDisplay = true;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = false;
        this.isDepositSummaryDisplay = false;
        
        let selectYesBtn = this.template.querySelector('[name="property_no"]');
        selectYesBtn.style.backgroundColor = '#13185C';
        selectYesBtn.style.color = '#fff';

        this.template.querySelector('[name="property_yes"]').style = '';
    }

    searchListedPropertyHandle(event) {
        this.isListedValidAddressError = false;
        this.isListedPropertyError = false;
        //this.isShowSelectedAddresses = false;
        this.isWarningShow = false;
        this.searchAddressString = this.template.querySelector('[name="searchInputAddress"]').value;
        let searchAddressStr = this.searchAddressString;
        // let originalvalue = this.searchAddressString.replace(/\n/g, ' ');
        this.listedSelectedAddress = '';
        this.listedPropAddress = [];

        if (searchAddressStr.length > 2) {
           getPropertiesWrapper({ searchField: this.searchAddressString, branchId: this.branchId })
        //    getPropertiesWrapper({ searchField: originalvalue, branchId: this.branchId })
                .then(result => {
                    if (result == null || result == '' || result == undefined) {
                        this.isListedValidAddressError = true;

                    } else {
                        this.isShowListedAddress = true;
                        let selectedrec = [];
                        selectedrec = result;
                        for (let i = 0; i < selectedrec.length; i++) {
                            if (selectedrec[i].proprty.includes('null')) {
                                var proprty = '';
                                var spltedList = selectedrec[i].proprty.split('null');
                                for (let i = 0; i < spltedList.length; i++) {
                                    proprty += spltedList[i];
                                }
                                selectedrec[i].proprty = proprty;
                                //  console.log('line 201 rec -->'+selectedrec[i].proprty);
                            }
                        }
                        this.listedPropAddress = selectedrec;
                        console.log(' listed Property Address[0] Line 215 -->' + this.listedPropAddress[0].recId);
                    }
                })
                .catch(error => {
                    console.log('Line 288 Error -> ', error);
                });
        }
    }

    handleListedAddressClick(event) {
        console.log('line 236');
        //  this.isShowSelectedAddresses=true;
        this.isShowListedAddress = false;
        this.isWarningShow = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        // console.log('Line 238 currentSelectedAddressId -> ', recordID);

        console.log(' listed Property__c Line 240 -->' + JSON.stringify(this.listedPropAddress[0].proprtyrec));
        let prop = this.listedPropAddress;
        console.log(' listed Property Address[0] Line 241 -->' + prop[0].recId);

        let selectedrec = [];
        for (let i = 0; i < prop.length; i++) {
            if (prop[i].recId == recordID) {
                selectedrec.push(prop[i].proprtyrec);
            }
        }

        // console.log('Line 369 Selected property-->' + JSON.stringify(selectedrec[0].Id));
        this.insertedPropertyId = selectedrec[0].Id;
        let depositRecord = selectedrec[0].Deposits__r;
        this.propertyDepositTenants = [];
        if (depositRecord != null || depositRecord != undefined) {
            for (let i in depositRecord) {
                console.log('line 511-->'+depositRecord[i].Status__c);
                if(depositRecord[i].Status__c!= null || depositRecord[i].Status__c!= undefined){
                    // console.log('line 512: '+depositRecord[i].Tenant_Changeover_Status__c);
                 if (depositRecord[i].Tenants_Name__c != null) {
                     var splitName = depositRecord[i].Tenants_Name__c.split(",");
                     // console.log('Line 367--->'+splitName);
                     this.propertyDepositTenants.push(...splitName);
                 }
              }
             }
              
            if (this.propertyDepositTenants != null) {
                let arr = [];
                arr = this.propertyDepositTenants;
                console.log('tenant name-->' + arr);
                //  let uniqueName = [];
                const uniqueName = new Set();
                arr.forEach((c) => {
                    console.log(c);
                   // if (!uniqueName.includes(c)) {
                       uniqueName.add(c.trim());
                  //  }
                });

                this.propertyDepositTenants = Array.from(uniqueName);
                console.log('unique tenant name-->' + this.propertyDepositTenants);

                this.isWarningShow = true;
            }
        }

        if (selectedrec[0].House_No__c != null || selectedrec[0].House_No__c != undefined) {
            this.houseNo = selectedrec[0].House_No__c;
        }
        if (selectedrec[0].Street__c != null || selectedrec[0].Street__c != undefined) {
            this.streetName = selectedrec[0].Street__c;
        }
        if (selectedrec[0].City__c != null || selectedrec[0].City__c != undefined) {
            this.townCity = selectedrec[0].City__c;
        }
        if (selectedrec[0].County__c != null || selectedrec[0].County__c != undefined) {
            this.county = selectedrec[0].County__c;
        }
        if (selectedrec[0].Postal_Code__c != null || selectedrec[0].Postal_Code__c != undefined) {
            this.postCode = selectedrec[0].Postal_Code__c;
        }
        if (selectedrec[0].Country__c != null || selectedrec[0].Country__c != undefined) {
            this.country = selectedrec[0].Country__c;
        }

        // this.country = selectedrec[0].Country__c;
        this.listedSelectedAddress = this.houseNo + ' ' + this.streetName + ' ' + this.townCity + ' ' + this.county + ' ' + this.postCode + ' ' + this.country;
        console.log('Line 266 Listed Selected address--->' + this.listedSelectedAddress);
    }
    // For handling property no add event from child component(address finder) for 'onselectingaddress' event i.e. selecting automatically
    selectingAddressHandler(event) {
        let returnedData = event.detail;
        this.isPostcodeErrorAlert = false;
        this.isPropertySearch = false;

        this.finalSelectedAddress = '';
        if (returnedData.addressType == 'Address') {
            this.propertyAddress = returnedData.addressObj;

            var isPrimaryAddressOfNiPostcode = false;
            this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                if (this.propertyAddress.Postcode.includes(postCodeRecord.Label)) {
                    isPrimaryAddressOfNiPostcode = true;
                }
            });
            //  this.showCorresAddress = !isPrimaryAddressOfNiPostcode;
            this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;
            console.log('Line 336 Check for NI postcode: ' + this.isPrimaryAddressOfNI);

        }
        console.log('Line 339 Address Selected--->' + JSON.stringify(this.propertyAddress));

        if (this.propertyAddress.houseNo != null || this.propertyAddress.houseNo != undefined) {
            this.houseNo = this.propertyAddress.houseNo;
        }
        if (this.propertyAddress.AddressLine != null || this.propertyAddress.AddressLine != undefined) {
            this.propertyAddress.Street = this.propertyAddress.AddressLine;
            this.streetName = this.propertyAddress.AddressLine;// street data getting empty so address line used
        }
        if (this.propertyAddress.Town != null || this.propertyAddress.Town != undefined) {
            this.townCity = this.propertyAddress.Town;
        }
        if (this.propertyAddress.County != null || this.propertyAddress.County != undefined) {
            this.county = this.propertyAddress.County;
        }
        if (this.propertyAddress.Postcode != null || this.propertyAddress.Postcode != undefined) {
            this.postCode = this.propertyAddress.Postcode;
        } if (this.propertyAddress.Country != null || this.propertyAddress.Country != undefined) {
            this.country = this.propertyAddress.Country;
        }
        this.finalSelectedAddress = this.houseNo + ' ' + this.streetName + ' ' + this.townCity + ' ' + this.county + ' ' + this.postCode + ' ' + this.country;
        if ((this.propertyAddress.houseNo != null && this.propertyAddress.houseNo != '' && this.propertyAddress.houseNo != undefined) ||
            (this.propertyAddress.AddressLine != null && this.propertyAddress.AddressLine != '' && this.propertyAddress.AddressLine != undefined) ||
            (this.propertyAddress.Town != null && this.propertyAddress.Town != '' && this.propertyAddress.Town != undefined) ||
            (this.propertyAddress.County != null && this.propertyAddress.County != '' && this.propertyAddress.County != undefined) ||
            (this.propertyAddress.Country != null && this.propertyAddress.Country != '' && this.propertyAddress.Country != undefined) ||
            (this.propertyAddress.Postcode != null && this.propertyAddress.Postcode != '' && this.propertyAddress.Postcode != undefined)) {
            this.searchProperties(this.propertyAddress);
        }
        this.defaultPrimaryAddress = [];
        console.log('Line 364 Listed Final Address-->' + this.finalSelectedAddress);
        if (this.finalSelectedAddress != '') {
            this.defaultPrimaryAddress.push(this.propertyAddress);
            // this.primaryAddress.push(this.currentRelevantData.primaryAddress);
        }
        this.template.querySelector('c-ei_-n-i_property-address-finder').defaultAddressUpdate(this.defaultPrimaryAddress);
    }
    // For handling property no add event from child component(address finder) for 'onfieldchange' event i.e. entering manually
    addressFieldChangeHandler(event) {
        let returnedData = event.detail;
        this.finalSelectedAddress = '';
        if (returnedData.addressType == 'Address') {
            if (returnedData.fieldName.includes("TownCity")) {
                this.primaryAddress = { ...this.primaryAddress, "Town": returnedData.value }

            } else if (returnedData.fieldName.includes("County")) {
                this.primaryAddress = { ...this.primaryAddress, "County": returnedData.value }

            } else if (returnedData.fieldName.includes("Postcode")) {
                this.primaryAddress = { ...this.primaryAddress, "Postcode": returnedData.value }
                // console.log('Line 417 House -> ', returnedData.value);
                var isPrimaryAddressOfNiPostcode = false;
                this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                    if (returnedData.value.includes(postCodeRecord.Label)) {
                        isPrimaryAddressOfNiPostcode = true;
                    }
                });
                //   this.showCorresAddress = !isPrimaryAddressOfNiPostcode;
                this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;

            } else if (returnedData.fieldName.includes("House")) {
                this.primaryAddress = { ...this.primaryAddress, "houseNo": returnedData.value }

            } else if (returnedData.fieldName.includes("Street")) {
                this.primaryAddress = { ...this.primaryAddress, "Street": returnedData.value }
            } else if (returnedData.fieldName.includes("Country")) {
                this.primaryAddress = { ...this.primaryAddress, "Country": returnedData.value }

            }
            if ((this.propertyAddress.houseNo != null && this.propertyAddress.houseNo != '' && this.propertyAddress.houseNo != undefined) &&
                (this.primaryAddress.Street != null && this.primaryAddress.Street != '' && this.primaryAddress.Street != undefined) &&
                (this.primaryAddress.Town != null && this.primaryAddress.Town != '' && this.primaryAddress.Town != undefined) &&
                (this.primaryAddress.County != null && this.primaryAddress.County != '' && this.primaryAddress.County != undefined) &&
                (this.primaryAddress.Country != null && this.primaryAddress.Country != '' && this.primaryAddress.Country != undefined) &&
                (this.primaryAddress.Postcode != null && this.primaryAddress.Postcode != '' && this.primaryAddress.Postcode != undefined)) {
                this.searchProperties(this.primaryAddress);
            }
        }

        console.log('Line 367 Address Entered manually' + JSON.stringify(this.primaryAddress));

        if (this.primaryAddress.houseNo != null || this.primaryAddress.houseNo != undefined) {
            this.houseNo = this.primaryAddress.houseNo;
            console.log('Line 391 House--->' + this.houseNo);
        }
        if (this.primaryAddress.Street != null || this.primaryAddress.Street != undefined) {
            this.streetName = this.primaryAddress.Street;
            console.log('Line 392 StreetName--->' + this.streetName);
        }
        if (this.primaryAddress.Town != null || this.primaryAddress.Town != undefined) {
            this.townCity = this.primaryAddress.Town;
            console.log('Line 393 City--->' + this.townCity);
        }
        if (this.primaryAddress.County != null || this.primaryAddress.County != undefined) {
            this.county = this.primaryAddress.County;
            console.log('Line 394 county--->' + this.county);
        }
        if (this.primaryAddress.Postcode != null || this.primaryAddress.Postcode != undefined) {
            this.postCode = this.primaryAddress.Postcode;
            console.log('Line 395 postCode--->' + this.postCode);
        } if (this.primaryAddress.Country != null || this.primaryAddress.Country != undefined) {
            this.country = this.primaryAddress.Country;
            console.log('Line 394 Country --->' + this.country);
        }

        // console.log('Line 395 postCode--->'+this.postCode);
        this.finalSelectedAddress = this.houseNo + ' ' + this.streetName + ' ' + this.townCity + ' ' + this.county + ' ' + this.postCode + ' ' + this.country;
        console.log('Line 371 Address Entered manually--->' + this.finalSelectedAddress);
        this.defaultPrimaryAddress = [];
        if (this.finalSelectedAddress != '') {
            this.defaultPrimaryAddress.push(this.primaryAddress);
            // this.primaryAddress.push(this.currentRelevantData.primaryAddress);
        }
        this.template.querySelector('c-ei_-n-i_property-address-finder').defaultAddressUpdate(this.defaultPrimaryAddress);
        console.log('Line 371 list Address Entered manually--->' + JSON.stringify(this.defaultPrimaryAddress));
    }

    searchProperties(addressStr) {
        console.log('Property to find>>>>' + JSON.stringify(addressStr.AddressLine.trim()));
        getPropertiesDup({
            "houseNo": addressStr.houseNo,
            "street": addressStr.AddressLine != "" ? addressStr.AddressLine.trim() : addressStr.Street,
            "townCity": addressStr.Town,
            "postCode": addressStr.Postcode,
            "branchId": this.branchId != null ? this.branchId : null
        }).then(result => {
            console.log('Deplicate Property>>>>' + JSON.stringify(result));
            if (result != undefined && result != null) {
                this.dupProperties = result;
                this.showDupPropertyWarning = true;
            } else {
                this.showDupPropertyWarning = false;
            }
        }).catch(error => {
            console.log('Error findind properties>>' + JSON.stringify(error));
        })
    }

    closeWarning() {
        this.showDupPropertyWarning = false;
    }
    propertyWarningShowHandle() {
        this.isWarningShow = false;
    }

    propertyYesContinueHandle(event) {
        event.preventDefault();
        console.log('Line 374 Listed Address-->' + this.listedSelectedAddress);
        if (this.listedSelectedAddress == null || this.listedSelectedAddress == undefined || this.listedSelectedAddress == '') {
            this.isListedPropertyError = true;
        } else {
            this.isPropertySelectDisplay = false;
            this.isDepositDetailDisplay = true;
            this.isTenantDetailDisplay = false;
            this.isDepositSummaryDisplay = false;

            // for cirlce select
            var state = this.template.querySelectorAll(".state-indicator");
            console.log('line 99 state lenght :' + state.length);
            state[0].classList.remove("active");
            state[1].classList.add("active");

            var primaryLL = [];
            var additionalLL = [];
            if (this.insertedPropertyId != null || this.insertedPropertyId != '' || this.insertedPropertyId != undefined) {
                getLandlordforSummary({ propertyId: this.insertedPropertyId })
                    .then(result => {
                        console.log('Line 545 Landlord for summary length--->' + result.length);
                        if (result.length > 0) {
                            var landlord = result;
                            landlord.forEach(item => {

                                if (item.Relation_to_Property__c == 'Primary Landlord') {
                                    primaryLL = [{
                                        Id: item.Contact__r.Id, Salutation: item.Contact__r.Salutation, FirstName: item.Contact__r.FirstName, LastName: item.Contact__r.LastName,
                                        Email: item.Contact__r.Email, Phone: item.Contact__r.Phone, Landlord_reference__c: item.Contact__r.Landlord_reference__c, AccountId: item.Contact__r.AccountId
                                    }];
                                } else {
                                    additionalLL.push({
                                        Id: item.Contact__r.Id, Salutation: item.Contact__r.Salutation, FirstName: item.Contact__r.FirstName, LastName: item.Contact__r.LastName,
                                        Email: item.Contact__r.Email, Phone: item.Contact__r.Phone, Landlord_reference__c: item.Contact__r.Landlord_reference__c, AccountId: item.Contact__r.AccountId
                                    });
                                }
                            });
                            this.selectedPrimaryLandlord = primaryLL;
                            this.selectedAdditionalLandLord = additionalLL;
                            console.log('Line 555 Primary Landlord--->' + JSON.stringify(this.selectedPrimaryLandlord));
                            console.log('Line 556 additional Landlord for summary--->' + JSON.stringify(this.selectedAdditionalLandLord));
                        }

                    })
                    .catch(error => {
                        console.log('Line 288 Error -> ', error);
                    })
            }
        }
    }

    managedTenancyHandle(event) {
        event.preventDefault();
        var button_Name = event.target.name;
        // console.log('Line 594 Btn name-->'+button_Name);
        console.log('Line 593 Managed value-->' + this.tenancyManagedYes);
        console.log('Line 593 Managed value-->' + this.tenancyManagedNo);
        let selectMangedBtn = this.template.querySelector('[name="managed-Btn"]');
        let selectNonManagedBtn = this.template.querySelector('[name="non-managed-Btn"]');
        switch (button_Name) {
            case "managed-Btn":
                if (this.isPropertyNoDisplay) {
                    this.tenancyManagedNo = 'Managed';
                } else if (this.isPropertyYesDisplay) {
                    this.tenancyManagedYes = 'Managed';
                }
                selectMangedBtn.style.backgroundColor = '#13185C';
                selectMangedBtn.style.color = '#fff';

                selectNonManagedBtn.style = '';
                break;
            case "non-managed-Btn":
                if (this.isPropertyNoDisplay) {
                    this.tenancyManagedNo = 'Non-managed';
                } else if (this.isPropertyYesDisplay) {
                    this.tenancyManagedYes = 'Non-managed';
                }
                selectNonManagedBtn.style.backgroundColor = '#13185C';
                selectNonManagedBtn.style.color = '#fff';
                selectMangedBtn.style = '';
                break;
        }

    }

    additionalLandLordYesHandle() {
        this.isAdditionalLandLord = true;
        let selectBtn = this.template.querySelector('[name="additionalLandlordYesBtn"]');
        selectBtn.style.backgroundColor = '#13185C';
        selectBtn.style.color = '#fff';
        this.template.querySelector('[name="additionalLandlordNoBtn"]').style = '';
    }

    additionalLandLordNoHandle() {
        this.isAdditionalLandLord = false;
        
        let selectBtn = this.template.querySelector('[name="additionalLandlordNoBtn"]');
        selectBtn.style.backgroundColor = '#13185C';
        selectBtn.style.color = '#fff';
        this.template.querySelector('[name="additionalLandlordYesBtn"]').style = '';
    }

    // to prevent space at start of search
    handleKeyDown(event) {
        if (event.key === ' ' && event.target.selectionStart === 0) {
            event.preventDefault();
        }
    }

    searchPrimaryLLHandle(event) {
        this.isPrimaryLandlordError = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        this.isShowListedLandlord = false;
        this.searchLandlordString = this.template.querySelector('[name="landlord_search"]').value;
        let searchLandlordStr = this.searchLandlordString;
        this.primaryLandLordList = [];
        // this.primaryLandlordName='';
        console.log('Line 482 Primary LL search key -> ', searchLandlordStr);
        console.log('Line 483 length -> ', searchLandlordStr.length);

        if (searchLandlordStr.length > 2) {
            searchLandlord({ searchField: this.searchLandlordString, branchId: this.branchId })
                .then(result => {
                    if (result.length == 0) {
                        this.isPrimaryLandlordNameError = true;
                        this.primaryLandLordList = [];
                    } else {
                        this.isShowListedLandlord = true;
                        this.isPrimaryLandlordNameError = false;
                        // let selectedrec = [];
                        //  selectedrec = result;
                        this.primaryLandLordList = result;
                        //  this.primaryLandlordName='';
                        console.log('result length : ' + result.length);
                        console.log('Landlord data : ' + JSON.stringify(this.primaryLandLordList));
                    }
                })
                .catch(error => {

                    console.log('Line 288 Error -> ', error);
                });
        }
    }

    primaryLandlordBlurHandle() {
        this.primaryLandLordList = [];
        this.template.querySelector('[name="landlord_search"]').value = '';
    }
    handlePrimaryLandLord(event) {
        this.isShowListedLandlord = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        console.log('landlord selectRecord ## ' + recordID);
        let primarylandlord = this.primaryLandLordList;
        //  console.log('landlord primarylandlord ## '+ primarylandlord);
        let selectedrecId = this.selectedjointlandlordID;
        console.log('line 561--->' + selectedrecId);

        let selectedPrimarylandlord = this.selectedPrimaryLandlord;
        if (selectedPrimarylandlord.length > 0) {
            if (selectedrecId.includes(selectedPrimarylandlord[0].Id)) {
                let index = selectedrecId.indexOf(selectedPrimarylandlord[0].Id);
                console.log("line 568-->" + index);
                selectedrecId.splice(index, 1);
                console.log("line 27");
            }
        }

        let selectedrec = [];
        for (let i = 0; i < primarylandlord.length; i++) {
            if (primarylandlord[i].Id == recordID) {
                if (!selectedrecId.includes(recordID)) {
                    console.log("line 93 " + primarylandlord[i].Id, primarylandlord[i].FirstName);
                    selectedrec.push(primarylandlord[i]);
                    selectedrecId.push(recordID);
                } else {
                    this.isPrimaryLandlordError = true;
                    // this.primaryLandlordName='';
                }
            }
        }
        console.log('Line 584 landlord selectedrec ## ' + JSON.stringify(selectedrec));
        var fullName;
        if (selectedrec[0].FirstName != undefined || selectedrec[0].FirstName != null) {
            fullName = selectedrec[0].FirstName + " " + selectedrec[0].LastName;
        } else {
            fullName = selectedrec[0].LastName;
        }
        console.log("fullName-->", fullName);
        this.primaryLandLordList = [];
        this.primaryLandlordName = fullName;
        this.selectedPrimaryLandlord = selectedrec;
        this.selectedjointlandlordID = selectedrecId;
    }
    // when primary landlord is created after child component call
    primaryAddLandlordDataHandle(event) {
        this.isPrimaryLandlordNameError = false;
        let returnedData = event.detail;
        console.log('Line 519 Additional Landlord--->' + JSON.stringify(returnedData));
        let selectedrecId = this.selectedjointlandlordID;
        console.log('line 561--->' + selectedrecId);

        let selectedPrimarylandlord = this.selectedPrimaryLandlord;
        if (selectedPrimarylandlord.length > 0) {
            if (selectedrecId.includes(selectedPrimarylandlord[0].Id)) {
                let index = selectedrecId.indexOf(selectedPrimarylandlord[0].Id);
                console.log("primaryAddLandlordDataHandle: " + index);
                selectedrecId.splice(index, 1);
                console.log("line 27");
            }
        }
        selectedrecId.push(returnedData.Id);
        this.selectedjointlandlordID = selectedrecId;
        //this.selectedPrimaryLandlord = returnedData;
        var fullName = returnedData.FirstName + " " + returnedData.LastName;
        console.log("fullName", fullName);
        this.primaryLandlordName = fullName;
        // this.selectedPrimaryLandlord= selectedrec;

        var primaryLL = [];
        primaryLL = [{
            Id: returnedData.Id, Salutation: returnedData.Salutation, FirstName: returnedData.FirstName, LastName: returnedData.LastName,
            Email: returnedData.Email, Phone: returnedData.Phone, Landlord_reference__c: returnedData.Landlord_reference__c, AccountId: returnedData.AccountId
        }];
        this.selectedPrimaryLandlord = primaryLL;
        this.primaryLandLordList = [];
        this.isShowListedLandlord = false;
        this.template.querySelector('[name="landlord_search"]').value='';
        console.log('Line 780 Primary Landlord List--->' + JSON.stringify(this.selectedPrimaryLandlord));
    }

    searchAddLandLordHandle() {
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        this.isShowListedAddLandlord = false;
        this.searchLandlordString = this.template.querySelector('[name="additional_landlord_search"]').value;
        let searchLandlordStr = this.searchLandlordString;
        this.addLandLordList = [];
        console.log('Line 596 Additional LL -> ', searchLandlordStr);
        console.log('Line 597 length -> ', searchLandlordStr.length);

        if (searchLandlordStr.length > 2) {
            searchLandlord({ searchField: this.searchLandlordString, branchId: this.branchId })
                .then(result => {
                    if (result.length == 0) {
                        this.isAdditionalLandlordNameError = true;
                        this.addLandLordList = [];
                    } else {
                        this.isShowListedAddLandlord = true;
                        this.isAdditionalLandlordNameError = false;
                        // let selectedrec = [];
                        //  selectedrec = result;
                        this.addLandLordList = result;
                        console.log('result length : ' + result.length);
                        console.log('Landlord data : ' + JSON.stringify(this.addLandLordList));
                    }
                })
                .catch(error => {

                    console.log('Line 288 Error -> ', error);
                });
        }
    }

    handleAdditionalLandLord(event) {
        this.isShowListedAddLandlord = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        console.log('Additional landlord selectRecord ## ' + recordID);
        let additionalLandlord = this.addLandLordList;
        let selectedrecId = this.selectedjointlandlordID;
        let selectedrec = this.selectedAdditionalLandLord;

        for (let i = 0; i < additionalLandlord.length; i++) {
            if (additionalLandlord[i].Id == recordID) {
                if (!selectedrecId.includes(recordID)) {
                    console.log("line 93 " + additionalLandlord[i].Id, additionalLandlord[i].FirstName);
                    selectedrec.push(additionalLandlord[i]);
                    selectedrecId.push(recordID);
                } else {
                    this.isAdditionalLandlordError = true;
                }
            }
        }

        this.addLandLordList = [];
        this.selectedjointlandlordID = selectedrecId;
        console.log('Line 647  Selected joint landlord ID ## ' + JSON.stringify(this.selectedjointlandlordID));
        // console.log('line 649'+JSON.stringify(selectedrec));
        this.selectedAdditionalLandLord = selectedrec;
        console.log('Line 648 Selected Add landlord ## ' + JSON.stringify(this.selectedAdditionalLandLord));

    }

    // when additional landlord is created after child component call
    additionalLandlordDataHandle(event) {

        let returnedData = event.detail;
        
        console.log('additionalLandlordDataHandle Line 716 Additional Landlord --->' + JSON.stringify(returnedData));
        var isLandlordPresent = false;
        console.log('this.selectedAdditionalLandLord: '+JSON.stringify(this.selectedAdditionalLandLord));
        for (var item in this.selectedAdditionalLandLord) {
            if (item.Id == returnedData.Id) {
                isLandlordPresent = true;
            }
        }
        console.log('1');
        setTimeout(() => {
        
        console.log('2');
        this.addLandLordList = [];
        this.isShowListedAddLandlord= false;
        this.template.querySelector('[name="additional_landlord_search"]').value='';
        if (!isLandlordPresent) {
            console.log('1.1 '+returnedData.Id);
            // this.selectedAdditionalLandLord.push(returnedData);
           // this.selectedjointlandlordID.push(returnedData.Id);
            console.log('1.2');
            this.selectedAdditionalLandLord.push({
                Id: returnedData.Id, Salutation: returnedData.Salutation, FirstName: returnedData.FirstName, LastName: returnedData.LastName,
                Email: returnedData.Email, Phone: returnedData.Phone, Landlord_reference__c: returnedData.Landlord_reference__c, AccountId: returnedData.AccountId
            });
             this.selectedjointlandlordID.push(returnedData.Id);
        }
        console.log('line 875 Selected AddLL-->' + JSON.stringify(this.selectedAdditionalLandLord));

    }, 50);

    }

    propertyNoContinueHandle(event) {
        event.preventDefault();
        const topDiv = this.template.querySelector('[data-id="property_select_view"]');
        this.isPropertySearch = false;
        this.isPostcodeErrorAlert = false;
        this.isPrimaryLandlord = false;
        console.log('Line 491  --->' + this.finalSelectedAddress);

        if (this.finalSelectedAddress == null || this.finalSelectedAddress == undefined || this.finalSelectedAddress == '') {
            this.isPropertySearch = true;
            topDiv.scrollIntoView();

        } else if (this.isPrimaryAddressOfNI == false) {
            this.isPostcodeErrorAlert = true;
            topDiv.scrollIntoView();

        } else if (this.userAgent && (this.primaryLandlordName == null || this.primaryLandlordName == undefined || this.primaryLandlordName == '')) {
            console.log('Line 691 primaryLandlordName Error');
            this.isPrimaryLandlord = true;
            topDiv.scrollIntoView();
        }
        else {
            this.isPropertySelectDisplay = false;
            this.isDepositDetailDisplay = true;
            this.isTenantDetailDisplay = false;
            this.isDepositSummaryDisplay = false;

            // for cirlce select
            var state = this.template.querySelectorAll(".state-indicator");
            console.log('line 99 state lenght :' + state.length);
            state[1].classList.add("active");
            state[0].classList.remove("active");

            let primaryLandlord = this.selectedPrimaryLandlord;
            let additionalLandlord = this.selectedAdditionalLandLord;

            console.log('Line 813 primaryLandlord--->' + JSON.stringify(primaryLandlord));
            console.log('Line 814 additionalLandlord--->' + JSON.stringify(additionalLandlord));

            insertProperties({
                houseNo: this.houseNo, street: this.streetName, city: this.townCity, postcode: this.postCode, county: this.county, country: this.country,
                primaryLandlordList: primaryLandlord, additionalLandlordList: additionalLandlord,
                branchId: this.branchId != null ? this.branchId : null
            })
                .then(result => {
                    console.log('Line 755--->' + JSON.stringify(result));
                    var property = {};
                    if (result.duplicateProperty) {
                        // console.log("Line 758 duplicate Property-->"+result.propertyCreated);
                        property = result.duplicateProperty;
                        console.log("duplicate Property-->" + JSON.stringify(property));
                        console.log("duplicate Property id-->" + property.Id);
                        this.insertedPropertyId = property.Id;
                        console.log('this.insertedPropertyId***1034****************', this.insertedPropertyId);
                    } else if (result.propertyCreated) {

                        property = result.propertyCreated;
                        console.log("property Created-->" + JSON.stringify(property));
                        this.insertedPropertyId = property.Id;
                        console.log('this.insertedPropertyId***1040****************', this.insertedPropertyId);
                    } else {
                        console.log('Error occured while property creation');
                    }

                })
                .catch(error => {
                    console.log('Line 952 Error -> ', error);
                })
        }
    }

    searchKeyChangeHandle() {
    }

    continuetolandlordHandle() {
    }

    addDepositHandle() {
        let depositReceivedDate = this.template.querySelector('[name="depositReceivedDate"]').value;
        // console.log('line 601'+depositReceivedDate);
        if (depositReceivedDate != 'Select day') {
            this.depositDay = depositReceivedDate;
        }
        //  console.log('line 605'+this.depositDay);
        let depositReceivedMonth = this.template.querySelector('[name="depositReceivedMonth"]').value;
        if (depositReceivedMonth != 'Select month') {
            this.depositMonth = depositReceivedMonth;
        }
        let depositReceivedYear = this.template.querySelector('[name="depositReceivedYear"]').value;
        if (depositReceivedYear != 'Select year') {
            this.depositYear = depositReceivedYear;
        }
        let depositDateYMD = depositReceivedYear + '-' + depositReceivedMonth + '-' + depositReceivedDate;
        let depositDateDMY = depositReceivedDate + '/' + depositReceivedMonth + '/' + depositReceivedYear;
        this.depositReceiveDateYMD = depositDateYMD;
        this.depositReceiveDateDMY = depositDateDMY;
        console.log('Line 511 Deposit Receive Date-->' + this.depositReceiveDateYMD);
        // tenancy start date
        let tenancyStartDate = this.template.querySelector('[name="tenancyStartDate"]').value;
        if (tenancyStartDate != 'Select day') {
            this.tenancyDay = tenancyStartDate;
        }
        let tenancyStartMonth = this.template.querySelector('[name="tenancyStartMonth"]').value;
        if (tenancyStartMonth != 'Select month') {
            this.tenancyMonth = tenancyStartMonth;
        }
        let tenancyStartYear = this.template.querySelector('[name="tenancyStartYear"]').value;
        if (tenancyStartYear != 'Select year') {
            this.tenancyYear = tenancyStartYear;
        }
        let tenancyDateYMD = tenancyStartYear + '-' + tenancyStartMonth + '-' + tenancyStartDate;
        let tenancyDateDMY = tenancyStartDate + '/' + tenancyStartMonth + '/' + tenancyStartYear;
        this.tenancyStartDateYMD = tenancyDateYMD;
        this.tenancyStartDateDMY = tenancyDateDMY;
        // tenancy END date
        let tenancyEndDate = this.template.querySelector('[name="tenancyEndDate"]').value;
        if (tenancyEndDate != 'Select day') {
            this.tenancyEndDay = tenancyEndDate;
        }
        let tenancyEndMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
        if (tenancyEndMonth != 'Select month') {
            this.tenancyEndMonth = tenancyEndMonth;
        }
        let tenancyEndYear = this.template.querySelector('[name="tenancyEndYear"]').value;
        if (tenancyEndYear != 'Select year') {
            this.tenancyEndYear = tenancyEndYear;
        }
        let tenancyEndDateYMD = tenancyEndYear + '-' + tenancyEndMonth + '-' + tenancyEndDate;
        let tenancyEndDateDMY = tenancyEndDate + '/' + tenancyEndMonth + '/' + tenancyEndYear;
        this.tenancyEndDateYMD = tenancyEndDateYMD;
        this.tenancyEndDateDMY = tenancyEndDateDMY;

        console.log('Line 518 Tenancy Start Date-->' + this.tenancyStartDateYMD);
        console.log('Line 518 Tenancy End Date-->' + this.tenancyEndDateYMD);
        this.numOfTenants = this.template.querySelector('[name="number_of_tenants"]').value;
        this.depositRef = this.template.querySelector('[name="Deposit_reference"]').value;
        // console.log('Line 503 Deposit Ref-->'+this.depositRef);
    }
    addAmountHandle(event) {
        var fieldName = event.target.title;
        if (fieldName == 'rent_amount') {
            this.rentAmt = parseFloat(event.target.value).toFixed(2);
        } else if (fieldName == 'deposit_amount') {
            this.depositAmt = parseFloat(event.target.value).toFixed(2);
        } else if (fieldName == 'amount_to_protect') {
            this.amtToProtect = parseFloat(event.target.value).toFixed(2);
            // TGk-445 changes start 
            if(this.amtToProtect>0 && this.depositAmt>0 &&  this.amtToProtect > this.depositAmt){
                this.madeDisable = true;
                this.protectedAmountError = true;
            }
            else{
                this.madeDisable = false;  
                this.protectedAmountError = false;
            }
            // TGk-445 changes end 
        }
        if (parseFloat(this.depositAmt) > parseFloat(this.rentAmt)) {
            this.showDepositMessage = true;
        }
        if (parseFloat(this.depositAmt) <= parseFloat(this.rentAmt)) {
            this.showDepositMessage = false;
        }
    }

    onDatePickerChangeHandler(event){
        this.pickedValue = event.target.value;
            console.log('onDatePickerChangeHandler date picker => '+ event.target.value);
            let dateVal = new Date(event.target.value);
            var day = dateVal.getUTCDate();
            var month = dateVal.getUTCMonth() + 1;
            var year = dateVal.getUTCFullYear();
    
            for(let i=0; i< this.tenancyDateList.length; i++){
                if(this.tenancyDateList[i].value == day){
                    this.tenancyDateList[i].isSelected = true;
                    this.template.querySelector('[name="tenancyStartDate"]').value = this.tenancyDateList[i].value;
    
                }else{
                    this.tenancyDateList[i].isSelected = false;  
                }
            }
            for(let i=0; i< this.tenancyMonthList.length; i++){
                if(this.tenancyMonthList[i].value == month){
                    this.tenancyMonthList[i].isSelected = true;
                    this.template.querySelector('[name="tenancyStartMonth"]').value = this.tenancyMonthList[i].value;
                }else{
                    this.tenancyMonthList[i].isSelected = false;  
                }
            }
    
            for(let i=0; i< this.tenancyYearList.length; i++){
                if(this.tenancyYearList[i].value == year){
                    this.tenancyYearList[i].isSelected = true;
                    this.template.querySelector('[name="tenancyStartYear"]').value = this.tenancyYearList[i].value;
                }else{
                    this.tenancyYearList[i].isSelected = false;  
                }
            }
           // this.checkTenancyEndDate(event);//make sure this method is in our code for date validation.
        }
        onDatePickerendDateChangeHandler(event){
            this.pickedendValue = event.target.value;
                console.log('onDatePickerendDateChangeHandler date picker => '+ event.target.value);
                let dateVal = new Date(event.target.value);
                var day = dateVal.getUTCDate();
                var month = dateVal.getUTCMonth() + 1;
                var year = dateVal.getUTCFullYear();
        
                for(let i=0; i< this.tenancyEndDateList.length; i++){
                    if(this.tenancyEndDateList[i].value == day){
                        this.tenancyEndDateList[i].isSelected = true;
                        this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyEndDateList[i].value;
        
                    }else{
                        this.tenancyEndDateList[i].isSelected = false;  
                    }
                }
                for(let i=0; i< this.tenancyEndMonthList.length; i++){
                    if(this.tenancyEndMonthList[i].value == month){
                        this.tenancyEndMonthList[i].isSelected = true;
                        this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyEndMonthList[i].value;
                    }else{
                        this.tenancyEndMonthList[i].isSelected = false;  
                    }
                }
        
                for(let i=0; i< this.tenancyEndYearList.length; i++){
                    if(this.tenancyEndYearList[i].value == year){
                        this.tenancyEndYearList[i].isSelected = true;
                        this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyEndYearList[i].value;
                    }else{
                        this.tenancyEndYearList[i].isSelected = false;  
                    }
                }
               // this.checkTenancyEndDate(event);//make sure this method is in our code for date validation.
            }

        onDatePickerReceiveDateChangeHandler(event){
            this.receivedPickedValue = event.target.value;
                console.log('onDatePickerReceiveDateChangeHandler date picker => '+ event.target.value);
                let dateVal = new Date(event.target.value);
                var day = dateVal.getUTCDate();
                var month = dateVal.getUTCMonth() + 1;
                var year = dateVal.getUTCFullYear();
        
                for(let i=0; i< this.dateList.length; i++){
                    if(this.dateList[i].value == day){
                        this.dateList[i].isSelected = true;
                        this.template.querySelector('[name="depositReceivedDate"]').value = this.dateList[i].value;
        
                    }else{
                        this.dateList[i].isSelected = false;  
                    }
                }
                for(let i=0; i< this.monthList.length; i++){
                    if(this.monthList[i].value == month){
                        this.monthList[i].isSelected = true;
                        this.template.querySelector('[name="depositReceivedMonth"]').value = this.monthList[i].value;
                    }else{
                        this.monthList[i].isSelected = false;  
                    }
                }
        
                for(let i=0; i< this.yearList.length; i++){
                    if(this.yearList[i].value == year){
                        this.yearList[i].isSelected = true;
                        this.template.querySelector('[name="depositReceivedYear"]').value = this.yearList[i].value;
                    }else{
                        this.yearList[i].isSelected = false;  
                    }
                }
               // this.checkTenancyEndDate(event);//make sure this method is in our code for date validation.
            }
    restrictDecimal(event) {

        const t = event.target.value;
        const charCode = (event.which) ? event.which : event.keyCode;
        const decimalIndex = t.indexOf('.');
        // Allow only one decimal point
        if (charCode === 46 && decimalIndex !== -1) {
            event.preventDefault();
        }
        // Allow only digits and a decimal point
        else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
            event.preventDefault();
        }
        // Allow only up to two digits after the decimal point
        else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
            event.preventDefault();
        }
    }

    removeAmtZeroHandle(event) {
        var t = event.target.value;
        if (t.includes(".00")) {
            var arr = t.split(".");
            t = arr[0];
            console.log('line 960-->' + t);
        }
        event.target.value = t;
    }
    restrictTenantDecimal(event) {
        if (event.key === '.') {
            event.preventDefault();
        }
    }

    depositContinueHandle(event) {
        event.preventDefault();
        window.scrollTo(240, 240);
        this.isGenericError = false;
        this.isAmountCantBeLessThan1Error = false;
        this.isTenantNumberError = false;
        this.isRentAmountError = false;
        this.isDepositAmountError = false;
        this.isAmtToProtectError = false;
        this.isShowDepositDateError = false;
        this.isShowTenancyDateError = false;
        this.isShowTenancyEndDateError = false;
        this.endDateError = false;
        this.isDepositDateFutureError = false;
        this.isTenancyDateFutureError = false;
        let allValid = false;
        let allValidAmount = true;
        let allDateValid = true;
        let isValidTenantNum = true;
        let arrayField = [];
        let arraydate = [];
        // to check required field
        let rentAmount = parseFloat(this.rentAmt);              
        let depositAmount = parseFloat(this.depositAmt);        
        let amountToProtect = parseFloat(this.amtToProtect);    
        let Number_of_tenants = this.template.querySelector('[name="number_of_tenants"]').value;

        // Validating all the amounts
        console.log(`Line 1192 - ${rentAmount} - ${depositAmount} - ${amountToProtect}`);
        if ((rentAmount == "" || rentAmount == undefined || rentAmount == null || rentAmount <= 0 || isNaN(rentAmount))) {
            this.isRentAmountError = true;
            allValidAmount = false;

        } else if (rentAmount < 1) {
            allValidAmount = false;
            this.isAmountCantBeLessThan1Error = true;
        }

        if ((depositAmount == "" || depositAmount == undefined || depositAmount == null || depositAmount <= 0 || isNaN(depositAmount))) {
            this.isDepositAmountError = true;
            allValidAmount = false;

        } else if (depositAmount < 1) {
            allValidAmount = false;
            this.isAmountCantBeLessThan1Error = true;
        }

        if ((amountToProtect == "" || amountToProtect == undefined || amountToProtect == null || amountToProtect <= 0 || isNaN(amountToProtect))) {
            this.isAmtToProtectError = true;
            allValidAmount = false;

        } else if (amountToProtect < 1) {
            allValidAmount = false;
            this.isAmountCantBeLessThan1Error = true;
        }

        if ((rentAmount == "" || rentAmount == undefined || rentAmount == null || rentAmount <= 0) ||
            (depositAmount == "" || depositAmount == undefined || depositAmount == null || depositAmount <= 0) ||
            (amountToProtect == "" || amountToProtect == undefined || amountToProtect == null || amountToProtect <= 0)) {
            allValidAmount = false;
            //alert('notValid');
        }

        //Validating the number of tenants
        if (Number_of_tenants > 99 || Number_of_tenants < 1 || Number_of_tenants == "" || Number_of_tenants == null
            || Number_of_tenants == undefined) {
            isValidTenantNum = false;
            this.isTenantNumberError = true;
        }

        //Array Formation for required validity check
        arrayField.push(rentAmount, depositAmount, amountToProtect, Number_of_tenants);

        //Setting today date
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        let todayDate = new Date(yyyy + '-' + mm + '-' + dd);

        //Grab Date Elements  
        let depositReceivedDate = this.template.querySelector('[name="depositReceivedDate"]').value;
        let depositReceivedMonth = this.template.querySelector('[name="depositReceivedMonth"]').value;
        let depositReceivedYear = this.template.querySelector('[name="depositReceivedYear"]').value;
        let receivedDate = depositReceivedDate + '-' + depositReceivedMonth + '-' + depositReceivedYear;
        let receivedDateYMD = depositReceivedYear + '-' + depositReceivedMonth + '-' + depositReceivedDate;
        console.log('receivedDate: ' + receivedDate);
        console.log('receivedDate: ' + validatedate(receivedDate));
        if (validatedate(receivedDate)) {
            let compareDt = new Date(receivedDateYMD);
       
        }
        else {
            this.isShowDepositDateError = true;
            allDateValid = false;
        }

        let tenancyStartDate = this.template.querySelector('[name="tenancyStartDate"]').value;
        let tenancyStartMonth = this.template.querySelector('[name="tenancyStartMonth"]').value;
        let tenancyStartYear = this.template.querySelector('[name="tenancyStartYear"]').value;
        let tenancyDate = tenancyStartDate + '-' + tenancyStartMonth + '-' + tenancyStartYear;
        let tenancyDateYMD = tenancyStartYear + '-' + tenancyStartMonth + '-' + tenancyStartDate;
        console.log('tenancyDate: ' + tenancyDate);
        console.log('tenancyDate: ' + validatedate(tenancyDate));
        if (validatedate(tenancyDate)) {
            let compareDt = new Date(tenancyDateYMD);
        }
        else {
            this.isShowTenancyDateError = true;
            allDateValid = false;
        }

        let tenancyEndDate = this.template.querySelector('[name="tenancyEndDate"]').value;
        let tenancyEndMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
        let tenancyendYear = this.template.querySelector('[name="tenancyEndYear"]').value;
        let tenancyDateEnd = tenancyEndDate + '-' + tenancyEndMonth + '-' + tenancyendYear;
        let tenancyEndDateYMD = tenancyendYear + '-' + tenancyEndMonth + '-' + tenancyEndDate;
        let tenancyEndDateDMY=tenancyEndDate +'-' + tenancyEndMonth + '-' +  tenancyendYear;
        console.log('tenancyDateend 1524: ' + tenancyDateEnd);
        console.log('tenancyDate 1525: ' + validatedate(tenancyDateEnd));
        if (!validatedate(tenancyDateEnd)) {
            this.isShowTenancyEndDateError = true;
            allDateValid = false;
        }
        this.tenancyEndDateYMD=tenancyEndDateYMD;
        this.tenancyEndDateDMY=tenancyEndDateDMY;
        if (this.tenancyEndDateYMD < this.tenancyStartDateYMD) {
            console.log('this.tenancyEndDateYMD  1423: ' + this.tenancyEndDateYMD);
            this.endDateError = true;
            allDateValid = false;
        }
        //Array Formation for Date validity check
        arraydate.push(receivedDate, tenancyDate);
        let isValidDate = validatedate(receivedDate);
        for (var i = 0; i < arrayField.length; i++) {
            allValid = requiredFieldValidation(arrayField[i]);
            if (allValid == false) {
                break;
            }
        }
        //GOD Class for Required Field Validation
        function requiredFieldValidation(x) {
            if (x == undefined || x == null || x == "") {
                return false;
            }
            else {
                return true;
            }
        }
        //GOD class to check date validity
        function validatedate(d) {
            var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
            // Match the date format through regular expression
            if (d.match(dateformat)) {
                var splittedDate = d.split('-');
                var splittedDateLength = splittedDate.length;
                if (splittedDateLength > 1) {
                    var pdate = d.split('-');
                }
                var dd = parseInt(pdate[0]);
                var mm = parseInt(pdate[1]);
                var yy = parseInt(pdate[2]);

                // Create list of days of a month [assume there is no leap year by default]
                var ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                if (mm == 1 || mm > 2) {
                    if (dd > ListofDays[mm - 1]) {
                        return false;
                    }
                }
                if (mm == 2) {
                    var lyear = false;
                    if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
                        lyear = true;
                    }
                    if ((lyear == false) && (dd >= 29)) {
                        return false;
                    }
                    if ((lyear == true) && (dd > 29)) {
                        return false;
                    }
                }
                return true;
            }
            else {
                return false;
            }
        }

        if (allValid && allDateValid) {
            this.depositReceivedDate = receivedDateYMD;
            console.log('Line 267 Deposit Date:' + this.depositReceivedDate);
            this.tenancyStartDate = tenancyDateYMD;
            console.log('Line 269 TenancyStartDate:' + this.tenancyStartDate);
            this.tenancyEndDate = tenancyEndDateYMD;
            console.log('Line 269 tenancyEndDate:' + this.tenancyEndDate);

            let itemList = [];
            let noOfTenants = parseInt(Number_of_tenants);
            this.numberOfTenants = noOfTenants;
            let emptylist = this.arrObj;

            if (!isNaN(noOfTenants)) {
                for (let i = 1; i < noOfTenants + 1; i++) {
                    itemList.push(i);
                }
            }

            let listcount = emptylist.length;
            console.log('Line 772 List count: ' + listcount);

            if (noOfTenants > 0 || listcount != noOfTenants) {
                if (listcount > noOfTenants - 1) {
                    for (let k = noOfTenants - 1; k < listcount; k++) {
                        emptylist.pop();
                    }

                } else {
                    for (let j = 1; j < noOfTenants - listcount; j++) {
                        var person = new Object();
                        person.firstName = "";
                        person.SurName = "";
                        person.email = "";
                        person.phoneCode = "+44";
                        person.phone = "";
                        person.title = "";
                        person.companyName = "";
                        person.IsOrg = false;
                        person.IsformSubmitted = false;
                        person.item = j + listcount;
                        emptylist.push(person);
                    }
                }
            }
            console.log('Empty list size-->' + emptylist.length);
            this.arrObj = emptylist;
            console.log('Line 800' + JSON.stringify(this.arrObj));
            //this.tenantItemList= itemList;
            this.itemListlength = itemList.length;
            console.log('Tenant list size-->' + this.tenantItemList.length);
            let leaddetails = this.leadTenantObj;
            if (isValidTenantNum && allValidAmount) {
                this.isTenantDetailDisplay = true;
                this.isDepositDetailDisplay = false;

                var state = this.template.querySelectorAll(".state-indicator");
                console.log('line 328:' + state.length);
                state[0].classList.remove("active");
                state[1].classList.remove("active");
                state[2].classList.add("active");
                //$('#maincon', window.parent.document).get(0).scrollIntoView();
                //document.getElementById("sf-tabContent").scrollIntoView();

                this.tenantItemList = [];
                if (this.childTenantData.length > 0)
                    this.tenantItemList = this.childTenantData;

                console.log('Line 872 weird - ' + this.tenantItemList.length);
                console.log('Line 872 weird - ' + this.childTenantData);
                let noOfIterations = 0;
                if (this.numOfTenants >= this.tenantItemList.length) {
                    noOfIterations = this.numOfTenants - this.tenantItemList.length;

                } else {
                    this.tenantItemList = [];
                    this.childTenantData = [];
                    noOfIterations = this.numOfTenants;
                }
                console.log('Line 872 weird - ' + noOfIterations);
                for (let i = this.tenantItemList.length; i < this.numOfTenants; i++) {
                    //for(let i=this.tenantItemList.length; i<noOfIterations; i++) {
                    console.log('Line 873 -> ' + i);
                    let tenantData = {};
                    tenantData.tenantYesCheck = false;
                    tenantData.tenantNoCheck = true;
                    tenantData.tenantCompanyName = '';
                    tenantData.tenantTitle = '';
                    tenantData.tenantFirstname = '';
                    tenantData.tenantLastname = '';
                    tenantData.tenantEmail = '';
                    tenantData.tenantPhoneCode = '';
                    tenantData.tenantPhone = '';
                    tenantData.isRelevantYesSelect = false;
                    tenantData.relevantCompanyYesCheck = false;
                    tenantData.relevantCompanyName = '';
                    tenantData.relevantCompanyEmail = '';
                    tenantData.relevantCompanyPhonecode = '';
                    tenantData.relevantCompanyMobile = '';
                    tenantData.relevantCompanyNoCheck = false;
                    tenantData.relevantTitle = '';
                    tenantData.relevantFirstname = '';
                    tenantData.relevantSurname = '';
                    tenantData.relevantEmail = '';
                    tenantData.relevantPhoneCode = '';
                    tenantData.relevantMobile = '';
                    tenantData.relevantAddress = '';
                    tenantData.relevantCorrAddress = '';
                    tenantData.currentTenant = i + 1;
                    tenantData.Address = '';
                    tenantData.relevantAddress = '';
                    tenantData.isSaveClick = false;
                    this.tenantItemList.push(tenantData);
                }
            }
            this.isGenericError = false;

        } else {
            if (this.isRentAmountError && this.isDepositAmountError &&
                this.isAmtToProtectError && this.isTenantNumberError &&
                this.isShowDepositDateError && this.isShowTenancyDateError && this.isShowTenancyEndDateError) {
                this.isGenericError = true;
                this.isRentAmountError = false;
                this.isDepositAmountError = false;
                this.isAmtToProtectError = false;
                this.isTenantNumberError = false;
                this.isShowDepositDateError = false;
                this.isShowTenancyDateError = false;
                this.isShowTenancyEndDateError = false;
            } else {
                this.isGenericError = false;
            }
        }
    }

    depositBackHandle() {
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 99 state lenght :' + state.length);
        state[1].classList.remove("active");
        state[2].classList.remove("active");
        //   window.history.back();
        this.isPropertySelectDisplay = true;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = false;
        this.isDepositSummaryDisplay = false;

        setTimeout(() => {
            if (this.isPropertyYesDisplay) {
                console.log('yes-->' + this.isPropertyYesDisplay);
                let selectBtn = this.template.querySelector('[name="property_yes"]');
                console.log('1==>' + selectBtn);
                selectBtn.click();
                console.log('2==>' + selectBtn);
                selectBtn.style.backgroundColor = '#13185C';
                selectBtn.style.color = '#fff';
                console.log('3==>' + selectBtn);

                if (this.tenancyManagedYes == 'Managed') {
                    // console.log('Line 1567 Managed value change-->' + this.tenancyManaged);

                    let selectBtn = this.template.querySelector('[name="managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';

                    this.template.querySelector('[name="non-managed-Btn"]').style = '';
                }
                else if (this.tenancyManagedYes == 'Non-managed') {
                    let selectBtn = this.template.querySelector('[name="non-managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';

                    this.template.querySelector('[name="managed-Btn"]').style = '';

                }
            }

            if (this.isPropertyNoDisplay) {

                console.log('no-->' + this.isPropertyNoDisplay);
                let selectBtn = this.template.querySelector('[name="property_no"]');
                selectBtn.style.backgroundColor = '#13185C';
                selectBtn.style.color = '#fff';

                console.log('Line 1567 Managed value change-->' + this.tenancyManagedNo);
                if (this.tenancyManagedNo == 'Managed') {
                    // console.log('Line 1567 Managed value change-->' + this.tenancyManaged);
                    let selectBtn = this.template.querySelector('[name="managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="non-managed-Btn"]').style = '';
                }
                else if (this.tenancyManagedNo == 'Non-managed') {
                    // console.log('Line 623 Managed value change-->' + this.tenancyManaged);
                    let selectBtn = this.template.querySelector('[name="non-managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="managed-Btn"]').style = '';
                }

                if (this.isAdditionalLandLord) {
                    let selectBtn = this.template.querySelector('[name="additionalLandlordYesBtn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="additionalLandlordNoBtn"]').style = '';
                } else if (!this.isAdditionalLandLord) {
                    console.log('Add no landlord');
                    let selectBtn = this.template.querySelector('[name="additionalLandlordNoBtn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="additionalLandlordYesBtn"]').style = '';
                }
            }
        }, 10);
    }
    //tenant data from child
    tenantdataHandle(event) {
        this.isTenantSaveError = false;
        this.isRelevantSaveError = false;
        let returnedData = event.detail;
        console.log('Line 1532 -> Initial child lenght : ' + this.childTenantData.length +
            ' --> child data : ' + JSON.stringify(this.childTenantData));
        console.log('Line 1535 Tenant data--->' + JSON.stringify(returnedData.tenantObj));

        this.allTenantEmails.push(returnedData.tenantObj.tenantEmail);
        if (this.numOfTenants != this.childTenantData.length) {
            this.childTenantData.push(returnedData.tenantObj);
        }
        else {
            for (let i = 0; i < this.childTenantData.length; i++) {
                if (this.childTenantData[i].currentTenant == returnedData.tenantObj.currentTenant) {
                    this.childTenantData.splice(i, 1);
                }
            }
            this.childTenantData.push(returnedData.tenantObj);
        }
        console.log('Line 1533 -> Final child lenghth : ' + this.childTenantData.length +
            ' --> child data : ' + JSON.stringify(this.childTenantData));

        // Firing an event from Parent to all Child tenants component START
        // let childToCall = returnedData.tenantObj.currentTenant + 1;
        this.template.querySelectorAll('c-ei_-n-i_tenant-detail').forEach(element => {
            // if(childToCall == element.currentTenant) {
            //     element.updateTenantsList(this.childTenantData);
            // }
            element.updateTenantsList(this.childTenantData);
        });
        this.template.querySelector('c-ei_-n-i_relevant-detail').updateTenantsList(this.childTenantData);
        // Firing an event from Parent to Child relevant person component END
        console.log('Line 1549 -->> Event fired');
    }

    // relevant data from child
    relevantdataHandle(event) {
        let returnedData = event.detail;
        this.childRelevantData = returnedData.relevantObj;
        this.isRelevantPresent = true;
        console.log('Line 1520 Relevant data--->' + JSON.stringify(this.childRelevantData));
        this.template.querySelectorAll('c-ei_-n-i_tenant-detail').forEach(element => {
            element.updateRelevantData(this.childRelevantData);
        });
    }

    tenantContinuekHandle(event) {
        event.preventDefault();
        var isValid = true;
        this.isTenantSaveError = false;
        this.isRelevantSaveError = false;
        this.isDuplicateTenantEmailError = false;
        this.isDuplicateTenantPhoneError = false;
        this.isDuplicateRelevantEmailError = false;
        this.isDepositCreatedMsg = false;
        this.isDepositErrorMsg = false;
        const topDiv = this.template.querySelector('[data-id="tenant_save"]');
        topDiv.scrollIntoView();

        console.log("Line 1300 Tenant detail length -->" + JSON.stringify(this.childTenantData.length));
        if (this.numOfTenants == this.childTenantData.length) {
            this.childTenantData.forEach(item => {
                console.log("Line 1309 Is save click -->" + item.isSaveClick);
                if (!item.isSaveClick) {
                    this.isTenantSaveError = true;
                    isValid = false;
                }
            });
        } else {
            this.isTenantSaveError = true;
            isValid = false;
        }

        if (this.childRelevantData.isRelevantYesSelect && !this.childRelevantData.isSaveClick) {
            this.isRelevantSaveError = true;
            isValid = false;
        }

        if (isValid) {
            this.isPropertySelectDisplay = false;
            this.isDepositDetailDisplay = false;
            this.isTenantDetailDisplay = false;
            this.isDepositSummaryDisplay = true;
            var state = this.template.querySelectorAll(".state-indicator");
            console.log('line 1375 state length :' + state.length);
            state[0].classList.remove("active");
            state[1].classList.remove("active");
            state[2].classList.remove("active");
            state[3].classList.add("active");

            this.isCollapseOneShow = false;
            this.isCollapseTwoShow = false;
            this.isCollapseThreeShow = false;
            this.isCollapseFourShow = false;
            this.isCollapseFiveShow = false;
            if (this.userLandlord) {
                var returnedData = this.loggedInUser.Contact;
                console.log('Line 1597 Primary Landlord returnedData--->' + JSON.stringify(returnedData));
                var fullName;
                if (returnedData.FirstName != undefined || returnedData.FirstName != null) {
                    fullName = returnedData.FirstName + " " + returnedData.LastName;
                } else {
                    fullName = returnedData.LastName;
                }

                console.log("fullName-->", fullName);
                this.primaryLandlordName = fullName;
                var primaryLL = [];
                primaryLL = [{
                    Id: returnedData.Id, Salutation: returnedData.Salutation, FirstName: returnedData.FirstName, LastName: returnedData.LastName,
                    Email: returnedData.Email, Phone: returnedData.Phone, Landlord_reference__c: returnedData.Landlord_reference__c, AccountId: returnedData.AccountId
                }];
                this.selectedPrimaryLandlord = primaryLL;
            }
            console.log('line 1384 Primary landlord :' + JSON.stringify(this.selectedPrimaryLandlord));
            console.log('line 1385 Additional landlord :' + JSON.stringify(this.selectedAdditionalLandLord));
        }
    }

    depositSummaryViewHandle(event) {
        var eventId = event.currentTarget.dataset.id;
        console.log('lint 1396 event-', eventId);
        switch (eventId) {
            case "property-view":
                this.isCollapseTwoShow = false;
                this.isCollapseThreeShow = false;
                this.isCollapseFourShow = false;
                this.isCollapseFiveShow = false;
                this.isCollapseOneShow = !this.isCollapseOneShow;
                break;
            case "deposit-view":
                this.isCollapseOneShow = false;
                this.isCollapseThreeShow = false;
                this.isCollapseFourShow = false;
                this.isCollapseFiveShow = false;
                this.isCollapseTwoShow = !this.isCollapseTwoShow;
                break;
            case "landlord-view":
                console.log('lin1 1392');
                this.isCollapseOneShow = false;
                this.isCollapseTwoShow = false;
                this.isCollapseFourShow = false;
                this.isCollapseFiveShow = false;
                this.isCollapseThreeShow = !this.isCollapseThreeShow;
                break;
            case "tenant-view":
                this.isCollapseOneShow = false;
                this.isCollapseTwoShow = false;
                this.isCollapseThreeShow = false;
                this.isCollapseFiveShow = false;
                this.isCollapseFourShow = !this.isCollapseFourShow;
                break;
            case "relevant-view":
                this.isCollapseOneShow = false;
                this.isCollapseTwoShow = false;
                this.isCollapseThreeShow = false;
                this.isCollapseFourShow = false;
                this.isCollapseFiveShow = !this.isCollapseFiveShow;
                break;
        }
    }

    backToPropertyHandle(event) {
        event.preventDefault();
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1441 state lenght :' + state.length);
        state[0].classList.add("active");
        state[1].classList.remove("active");
        state[2].classList.remove("active");
        state[3].classList.remove("active");
        this.isPropertySelectDisplay = true;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = false;
        this.isDepositSummaryDisplay = false;

        setTimeout(() => {
            if (this.isPropertyYesDisplay) {
                console.log('yes-->' + this.isPropertyYesDisplay);
                let selectBtn = this.template.querySelector('[name="property_yes"]');
                console.log('1==>' + selectBtn);
                selectBtn.click();
                console.log('2==>' + selectBtn);
                selectBtn.style.backgroundColor = '#13185C';
                selectBtn.style.color = '#fff';
                console.log('3==>' + selectBtn);

                if (this.tenancyManagedYes == 'Managed') {
                    let selectBtn = this.template.querySelector('[name="managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';

                    this.template.querySelector('[name="non-managed-Btn"]').style = '';
                }
                else if (this.tenancyManagedYes == 'Non-managed') {
                    let selectBtn = this.template.querySelector('[name="non-managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="managed-Btn"]').style = '';
                }
            }

            if (this.isPropertyNoDisplay) {
                console.log('no-->' + this.isPropertyNoDisplay);
                let selectBtn = this.template.querySelector('[name="property_no"]');
                selectBtn.style.backgroundColor = '#13185C';
                selectBtn.style.color = '#fff';

                console.log('Line 1567 Managed value change-->' + this.tenancyManagedNo);
                if (this.tenancyManagedNo == 'Managed') {
                    let selectBtn = this.template.querySelector('[name="managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="non-managed-Btn"]').style = '';
                }
                else if (this.tenancyManagedNo == 'Non-managed') {
                    let selectBtn = this.template.querySelector('[name="non-managed-Btn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="managed-Btn"]').style = '';
                }

                if (this.isAdditionalLandLord) {
                    let selectBtn = this.template.querySelector('[name="additionalLandlordYesBtn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="additionalLandlordNoBtn"]').style = '';
                } else if (!this.isAdditionalLandLord) {
                    console.log('Add no landlord');
                    let selectBtn = this.template.querySelector('[name="additionalLandlordNoBtn"]');
                    selectBtn.style.backgroundColor = '#13185C';
                    selectBtn.style.color = '#fff';
                    this.template.querySelector('[name="additionalLandlordYesBtn"]').style = '';
                }
            }
        }, 10);
    }

    backToDepositHandle(event) {
        event.preventDefault();
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1455 state lenght :' + state.length);
        state[0].classList.add("active");
        state[1].classList.add("active");
        state[2].classList.remove("active");
        state[3].classList.remove("active");
        this.isPropertySelectDisplay = false;
        this.isDepositDetailDisplay = true;
        this.isTenantDetailDisplay = false;
        this.isDepositSummaryDisplay = false;
        var depositDate = this.depositReceiveDateDMY;
        console.log('line 1465==>: ' + depositDate);
        for (let ind in this.dateList) {
            if (depositDate.substring(0, 2) == this.dateList[ind].value) {
                console.log('Line 1470 Deposit date-->' + this.dateList[ind].value);
                this.dateList[ind].isSelected = true;
            }
            else {
                this.dateList[ind].isSelected = false;
            }
        }

        for (let ind in this.monthList) {
            if (depositDate.substring(3, 5) == this.dateList[ind].value) {
                console.log('Line 1481 Deposit month-->' + this.monthList[ind].value);
                this.monthList[ind].isSelected = true;
            }
            else {
                this.monthList[ind].isSelected = false;

            }
        }

        for (let ind in this.yearList) {
            if (depositDate.substring(6, 10) == this.yearList[ind].value) {
                console.log('Line 1492 Deposit month-->' + this.yearList[ind].value);
                this.yearList[ind].isSelected = true;
            }
            else {
                this.yearList[ind].isSelected = false;
            }
        }

        var tenancyDate = this.tenancyStartDateDMY;
        console.log('line 1501-->: ' + tenancyDate);
        for (let ind in this.tenancyDateList) {
            if (tenancyDate.substring(0, 2) == this.tenancyDateList[ind].value) {
                console.log('Line 1506 Deposit date-->' + this.tenancyDateList[ind].value);
                this.tenancyDateList[ind].isSelected = true;
            }
            else {
                this.tenancyDateList[ind].isSelected = false;
            }
        }

        for (let ind in this.tenancyMonthList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyDate.substring(3, 5) == this.tenancyMonthList[ind].value) {
                console.log('Line 1517 Deposit month-->' + this.tenancyMonthList[ind].value);
                this.tenancyMonthList[ind].isSelected = true;
            }
            else {
                this.tenancyMonthList[ind].isSelected = false;
            }
        }

        for (let ind in this.tenancyYearList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyDate.substring(6, 10) == this.tenancyYearList[ind].value) {
                console.log('Line 1528 Deposit month-->' + this.tenancyYearList[ind].value);
                this.tenancyYearList[ind].isSelected = true;
            }
            else {
                this.tenancyYearList[ind].isSelected = false;
            }
        }

        var tenancyEndDate = this.tenancyEndDateDMY;
        console.log('line 1465==>: ' + tenancyEndDate);
        //  console.log('line 935 date-->'+depositDate.substring(3, 5));
        for (let ind in this.tenancyEndDateList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyEndDate.substring(0, 2) == this.tenancyEndDateList[ind].value) {
                console.log('Line 1470 Deposit date-->' + this.tenancyEndDateList[ind].value);
                this.tenancyEndDateList[ind].isSelected = true;
            }
            else {
                this.tenancyEndDateList[ind].isSelected = false;

            }
        }

        for (let ind in this.tenancyEndMonthList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyEndDate.substring(3, 5) == this.tenancyEndMonthList[ind].value) {
                console.log('Line 1481 Deposit month-->' + this.tenancyEndMonthList[ind].value);
                this.tenancyEndMonthList[ind].isSelected = true;
            }
            else {
                this.tenancyEndMonthList[ind].isSelected = false;

            }
        }

        for (let ind in this.tenancyEndYearList) {
            // console.log('Line 326-->'+this.otherPhoneCodeList[ind].key)
            if (tenancyEndDate.substring(6, 10) == this.tenancyEndYearList[ind].value) {
                console.log('Line 1492 Deposit month-->' + this.tenancyEndYearList[ind].value);
                this.tenancyEndYearList[ind].isSelected = true;
            }
            else {
                this.tenancyEndYearList[ind].isSelected = false;

            }
        }
    }

    backToTenantHandle(event) {
        event.preventDefault();
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1540 state lenght :' + state.length);
        state[0].classList.add("active");
        state[1].classList.add("active");
        state[2].classList.add("active");
        state[3].classList.remove("active");

        this.isPropertySelectDisplay = false;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = true;
        this.isDepositSummaryDisplay = false;
        this.isShowTenantSection = true;
        this.isShowRelevantPersonSection = false;

        this.tenantItemList = [];
        // Sorting tenants on the basis of tenant number
        this.childTenantData.sort((a, b) => parseInt(a.currentTenant) - parseInt(b.currentTenant));
        this.tenantItemList = this.childTenantData;

        const topDiv = this.template.querySelector('[data-id="top_div"]');
        topDiv.scrollIntoView();
    }

    backToRelevantPersonHandle(event) {
        event.preventDefault();
        console.log('tetant back page');
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1540 state lenght :' + state.length);
        state[0].classList.remove("active");
        state[1].classList.remove("active");
        state[2].classList.add("active");
        state[3].classList.remove("active");

        this.isPropertySelectDisplay = false;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = true;
        this.isDepositSummaryDisplay = false;
        this.isShowTenantSection = false;
        this.isShowRelevantPersonSection = true;

        this.tenantItemList = [];
        this.tenantItemList = this.childTenantData;

        const topDiv = this.template.querySelector('[data-id="top_div"]');
        topDiv.scrollIntoView();
    }

    backToTenantRelevantHandle(event) {
        event.preventDefault();
        console.log('tetant back page');
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1540 state lenght :' + state.length);
        state[0].classList.remove("active");
        state[1].classList.remove("active");
        state[2].classList.add("active");
        state[3].classList.remove("active");

        this.isPropertySelectDisplay = false;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = true;
        this.isDepositSummaryDisplay = false;
        this.isShowTenantSection = true;
        this.isShowRelevantPersonSection = true;

        this.tenantItemList = [];
        // Sorting tenants on the basis of tenant number
        this.childTenantData.sort((a, b) => parseInt(a.currentTenant) - parseInt(b.currentTenant));
        this.tenantItemList = this.childTenantData;

        const topDiv = this.template.querySelector('[data-id="top_div"]');
        topDiv.scrollIntoView();
    }
    depositSummaryBackHandle() {
        this.isPropertySelectDisplay = false;
        this.isDepositDetailDisplay = false;
        this.isTenantDetailDisplay = true;
        this.isDepositSummaryDisplay = false;

        // for cirlce select
        var state = this.template.querySelectorAll(".state-indicator");
        console.log('line 1564 state lenght :' + state.length);
        state[3].classList.remove("active");

        this.tenantItemList = [];
        this.tenantItemList = this.childTenantData;
    }

    cancelDepositHandles(event) {
        console.log('test1');
        let cancelbtn = this.template.querySelector('[name="canceldepositbtns"]');
        cancelbtn.classList.add("active");
        console.log('test2');
        this.isCancelDeposit = true;
        console.log('test3');
    }
    cancelDepositHandle(event) {
        let cancelbtn = this.template.querySelector('[name="canceldepositbtn"]');
        cancelbtn.classList.add("active");
        this.isCancelDepositInsured = true;
    }

    cancelDepositPopupHandles(event) {
        let cancelbtn = this.template.querySelector('[name="canceldepositbtns"]');
        cancelbtn.classList.remove("active");
        this.isCancelDeposit = false;
    }
    cancelDepositPopupHandle(event) {
        let cancelbtn = this.template.querySelector('[name="canceldepositbtn"]');
        cancelbtn.classList.remove("active");
        this.isCancelDepositInsured = false;
    }

    depositPopupYesHandle(event) {
        event.preventDefault();
        // window.location = window.location.origin + '/ni/s';
        window.location = window.location.origin + this.cancelDepositYes;
    }

    finalDataSave(event) {
        // event.preventDefault();
        const topDiv = this.template.querySelector('[data-id="deposit_summary_error"]');
        topDiv.scrollIntoView();
        this.isDuplicateTenantEmailError = false;
        this.isDuplicateTenantPhoneError = false;
        this.isDuplicateRelevantEmailError = false;
        this.isDepositCreatedMsg = false;
        this.isDepositErrorMsg = false;
        this.btnClicked = true;
        this.saveAndLaterCss = 'learn-more disabled-link'

        let addBtn = this.template.querySelector('[data-id="add_deposit_btn"]');
        let saveBtn = this.template.querySelector('[data-id="save_pay_later_btn"]');
        let payBtn = this.template.querySelector('[data-id="pay_deposit_protection_charge_btn"]');

        let PayDepositProtectionCharge;
        if (event.currentTarget.dataset.id == 'pay_deposit_protection_charge_btn') {
            PayDepositProtectionCharge = true;
        } else {
            PayDepositProtectionCharge = false;
        }
        let buttonDataSetId = event.currentTarget.dataset.id;

        let addAnotherDiposit;
        if (event.currentTarget.dataset.id == 'add_deposit_btn') {
            addAnotherDiposit = true;
        } else {
            addAnotherDiposit = false;
        }
        let addtoInvoice;
        if (event.currentTarget.dataset.id == 'add_to_invoice') {
            addtoInvoice = true;
        } else {
            addtoInvoice = false;
        }
        console.log('line 1609 final save ');
        var depositDetail = {};
        // depositDetail.tenancyManaged = this.tenancyManaged;
        if (this.isPropertyNoDisplay) {
            depositDetail.tenancyManaged = this.tenancyManagedNo;
            console.log('line 2275 final save ');
        } else if (this.isPropertyYesDisplay) {
            depositDetail.tenancyManaged = this.tenancyManagedYes;
            console.log('line 2278 final save ');
        }
        console.log('line 2280 final save ');
        depositDetail.rentAmt = this.rentAmt;
        depositDetail.depositAmt = this.depositAmt;
        depositDetail.amtToProtect = this.amtToProtect;
        depositDetail.depositReceiveDate = this.depositReceiveDateYMD;
        depositDetail.tenancyStartDate = this.tenancyStartDateYMD;
        depositDetail.tenancyEndDate = this.tenancyEndDateYMD;
        depositDetail.numOfTenants = this.numOfTenants;
        depositDetail.depositRef = this.depositRef;
        depositDetail.piClauseNumber = this.finalPLClauseNumber?.trim() != '' ? this.finalPLClauseNumber : '';
        depositDetail.piClauseWording = this.finalPLClauseWording?.trim() != '' ? this.finalPLClauseWording : '';
         let depositParamStr = JSON.stringify(depositDetail);
        //console.log('deposit detail-->' + depositParamStr);
        var isValid = true;
        const arr = this.childTenantData;
        for (let i = 0; i < arr.length; i++) {
            for (let j = 0; j < arr.length; j++) {
                // prevents the element from comparing with itself
                if (i !== j) {
                    if (arr[i].tenantEmail.length > 0 && arr[j].tenantEmail.length > 0 && arr[i].tenantEmail === arr[j].tenantEmail) {
                        // duplicate element present                                
                        isValid = false;
                        this.isDuplicateTenantEmailError = true;
                        console.log('Line 1919 duplicate email-->' + arr[i].tenantEmail);
                        break;
                    }
                    if (arr[i].tenantPhone.length > 0 && arr[j].tenantPhone.length > 0 && arr[i].tenantPhone === arr[j].tenantPhone) {
                        // duplicate element present                                
                        isValid = false;
                        this.isDuplicateTenantPhoneError = true;
                        console.log('Line 1927 duplicate phone-->' + arr[i].tenantPhone);
                        break;
                    }
                }
            }
        }
        // Commenting code as the duplicate emails and phone numbers manage on the Tenant details breadcrumb END
        if (this.childRelevantData.isRelevantYesSelect) {
            for (let i = 0; i < arr.length; i++) {
                console.log('2');
                if (arr[i].tenantEmail.length > 0 && (this.childRelevantData.relevantCompanyEmail.length > 0 || this.childRelevantData.relevantEmail.length > 0)) {
                    if (arr[i].tenantEmail === this.childRelevantData.relevantCompanyEmail || arr[i].tenantEmail === this.childRelevantData.relevantEmail) {
                        isValid = false;
                        this.isDuplicateRelevantEmailError = true;
                        console.log('Line 1611 duplicate email-->' + arr[i].tenantEmail);
                        this.btnClicked = false;
                        break;
                    }
                }
            }
        }
        let tenantParamStr = JSON.stringify(this.childTenantData);
        let relevantParamStr = JSON.stringify(this.childRelevantData);
        let relprimaryAddress = this.childRelevantData.primaryAddress;
        let paramAddress = JSON.stringify(relprimaryAddress); // address relevant person
        console.log('1867-->' + paramAddress);
        let relcrossAddress = this.childRelevantData.corresAddress;
        let paramAddress1 = JSON.stringify(relcrossAddress); // correspondence address relevant person
        console.log('1867-->' + paramAddress1);

        if (isValid) {
            console.log('1867this.selectedPrimaryLandlord-->' + this.selectedPrimaryLandlord);
            console.log('1867this.insertedPropertyId-->' + this.insertedPropertyId);
            this.isLoading = true;
            finalSave({
                branchId: this.branchId, propertyId: this.insertedPropertyId, primaryLandlordList: this.selectedPrimaryLandlord, additionalLandlordList: this.selectedAdditionalLandLord,
                depositParams: depositParamStr, tenantData: tenantParamStr, relevantData: relevantParamStr, relprimaryAddress: paramAddress, relcrossAddress: paramAddress1, postCode: this.postCode, buttonType: buttonDataSetId
            })
                .then(result => {
                    console.log('Line 1553--->' + JSON.stringify(result));
                    if (result.includes('Deposit created')) {
                        topDiv.scrollIntoView();
                        this.isDepositCreatedMsg = true;
                        this.isLoading = false;
                        if (PayDepositProtectionCharge) {
                            console.log('pay deposit protection btn line no-2156');
                            //Send user to the paying for an insured deposit journey
                            let resultList = result.split("-");
                            // console.log('Registered (not paid) btn ');
                            var encodedId = btoa(resultList[1]);
                            var en = btoa('Registered (not paid)');
                            if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                                this[NavigationMixin.Navigate]({
                                    type: 'comm__namedPage',
                                    attributes: {
                                        pageName: 'payInsuredDeposit'
                                    },
                                    state: {
                                        depositId: encodedId,
                                        status: en,
                                        branchRecId: btoa(this.branchId),
                                        showBranch: window.btoa('false')
                                    },
                                });
                            } else {
                                this[NavigationMixin.Navigate]({
                                    type: 'comm__namedPage',
                                    attributes: {
                                        pageName: 'payInsuredDeposit'
                                    },
                                    state: {
                                        depositId: encodedId,
                                        status: en
                                    },
                                });
                          }
                        }
                        else if (addAnotherDiposit) {
                            window.location.reload();
                        }
                        else {
                            console.log('Result value:', result.split("-"));
                            let resultList = result.split("-");
                            //let resultList = result;
                            let encodeDepositId = '';
                            if(this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                                // encodeDepositId = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + btoa(resultList[1]) + '&branchRecId=' + btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                                encodeDepositId = window.location.origin + this.depositSummryUrl + btoa(resultList[1]) + '&branchRecId=' + btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                            } else {
                                // encodeDepositId = window.location.origin + '/ni/s/depositinsuredsummary?depositId=' + btoa(resultList[1]);
                                encodeDepositId = window.location.origin + this.depositSummryUrl + btoa(resultList[1]);
                            }
                            if(addtoInvoice){
                                this.fetchUserTypeAndUpdateGTM();
                             }
                            setTimeout(() => {
                                // this.goToAddDeposit = window.location.origin + '/ni/s';
                                this.goToAddDeposit = encodeDepositId;
                                console.log('Line 1652-->' + this.goToAddDeposit);
                                window.location = this.goToAddDeposit;
                            }, 1000);
                        }
                    }
                    else {
                        this.isLoading = false;
                        this.isDepositErrorMsg = true;
                        this.btnClicked = false;
                    }

                })
                .catch(error => {
                    this.isLoading = false;
                    console.log('Line 1556 Error -> ', error);
                })
        }
        console.log('line 15588');
    }

    PayDepositProtectionCharge(event) {
        console.log('event.currentTarget.dataset.id', event.currentTarget.dataset.id);
    }
    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "propertyfinalError":
                this.ispropertyfinalError = false;
                break;
            case "listedValidAddressErrorMsg":
                this.isListedValidAddressError = false;
                break;
            case "listedPropertyError":
                this.isListedPropertyError = false;
                break;
            case "wrongCharacterStreetError":
                this.isWrongCharacterStreet = false;
                break;
            case "primaryLandlordError":
                this.isPrimaryLandlord = false;
                break;
            case "propertyError":
                this.isPropertySearch = false;
                break;
            case "postcodeErrorAlert":
                this.isPostcodeErrorAlert = false;
                break;
            case "genericError":
                this.isGenericError = false;
                break;
            case "amountCantBeLessThan1Error":
                this.isAmountCantBeLessThan1Error = false;
                break;
            case "tenantNumberError":
                this.isTenantNumberError = false;
                break;
            case "rentAmountError":
                this.isRentAmountError = false;
                break;
            case "depositAmountError":
                this.isDepositAmountError = false;
                break;
            case "amntToProtectError":
                this.isAmtToProtectError = false;
                break;
            case "tenantSaveError":
                this.isTenantSaveError = false;
                break;
            case "relevantSaveError":
                this.isRelevantSaveError = false;
                break;
            case "duplicateTenantEmailError":
                this.isDuplicateTenantEmailError = false;
                break;
            case "duplicateTenantEmailError":
                this.isDuplicateTenantPhoneError = false;
                break;
            case "duplicateRelevantEmailError":
                this.isDuplicateRelevantEmailError = false;
                break;
            case "depositCreatedMsg":
                this.isDepositCreatedMsg = false;
                break;
            case "depositErrorMsg":
                this.isDepositErrorMsg = false;
                break;

             // TGK-445 changes start
             case "protectedAmountError":
                this.protectedAmountError = false;
                break;
             // TGK-445 changes end
        }
    }
    openModal() {
        this.displayModal = true;
    }
    closeModal() {
        this.displayModal = false;
    }
    handlePIClauseNumber(event) {
        let plClause = event.target.value;
        if (plClause != '' && plClause != null) {
            this.finalPLClauseNumber = plClause;
        } else {
            this.finalPLClauseNumber = '';
        }
        console.log('Final PL Clause>>' + this.finalPLClauseNumber);
    }
    handlePIClauseWording(event) {
        let piClauseWord = event.target.value;
        if (piClauseWord != '' && piClauseWord != null) {
            this.finalPLClauseWording = piClauseWord;
        } else {
            this.finalPLClauseWording = '';
        }
    }
    savePLClause() {
        this.displayModal = false;
    }
    fetchUserTypeAndUpdateGTM() {
        fetchUserType()
            .then(result => {
                console.log('currentUser for GTM:', JSON.stringify(result));
                if((result.Account.Type_of_Scheme__c!=undefined) ||(result.Account.Type_of_Scheme__c!=null) ){
                this.productType = result.Account.Type_of_Scheme__c;
                }
                else if(result.Account.Custodial_User__c==true){
                    this.productType="Custodial";
                }
                console.log('productType for Google Analytics: '+this.productType);
                this.typeOfUser = result.User_Type__c;
                console.log('customerType for Google Analytics: '+this.typeOfUser);
                document.dispatchEvent(new CustomEvent("updateGTMdataLayer", { "detail" : { event: "depositProtectionEvent", customerType:this.typeOfUser, productType: this.productType} }));
                
            })
            .catch(error => {
               console.error('Error fetching for currentUser:', error);
            });
    }
}