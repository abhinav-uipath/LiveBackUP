import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import jQuery from '@salesforce/resourceUrl/JQuery';

import getBrachUserMap from '@salesforce/apex/ei_NI_BranchManagement.getBranchMap';
import getSelectedBranchUser from '@salesforce/apex/ei_NI_BranchManagement.fetchSelectedBranchUser';
import deactivateUser from '@salesforce/apex/ei_NI_BranchManagement.suspendUser';
import reactivateUser from '@salesforce/apex/ei_NI_BranchManagement.activateUser';
import updateBranchUser from '@salesforce/apex/ei_NI_BranchManagement.updateBranchUser';

export default class Ei_NI_ViewEditBranchUser extends NavigationMixin(LightningElement) {
    back_icon = NI_THEME + '/assets/img/ew-arrow-dropleft.png';

    branchId;
    contactId;
    showSuccessScreen = false;
    showSpinner = false;
    @track isActive = true;
    @track contactRec = {};
    @track userRec = {};
    @track selectedPermissions = [];
    @track selectedBranchRecs = [];

    @track jobRoles = [];
    @track additionalPerms = [];
    @track branches = [];
    @track salutations = [];
    @track phoneCodes = [];

    @track currentPageReference;
    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        this.currentPageReference = currentPageReference;
        this.branchId = window.atob(this.currentPageReference?.state?.c__branchId);
        this.contactId = window.atob(this.currentPageReference?.state?.c__recId);
        console.log('ContactId::' + this.contactId + '::BranchId::' + this.branchId);
    }

    connectedCallback() {
        loadScript(this, jQuery).then(() => {
            console.log('View/Edit BranchUser Script loaded');
        }).catch(error => {
            console.log('Failed to load the JQuery : ' + error);
        });
        Promise.all([
            getSelectedBranchUser({ conId: this.contactId, branchId: this.branchId }).then(result => {
                this.contactRec = result.conRec;
                this.userRec = result.usrRec;
                this.selectedPermissions = result.selectedAddPerms;
                this.selectedBranchRecs = result.selectedBranches;

                /* result.selectedBranches.forEach(item => {
                    this.selectedBranchRecs.push({
                        lable : item.Branch_Name__c,
                        value : item.Id
                    });
                }); */

                getBrachUserMap({}).then(result => {
                    var selectedJob = false;
                    result.jobRoles.forEach(item => {
                        if (item == this.contactRec.Job_role__c) {
                            selectedJob = true;
                        } else {
                            selectedJob = false;
                        }
                        // this.jobRoles.push({
                        //     label: item,
                        //     value: selectedJob
                        // });
                        if (item !== "Local authority" && item !== "Affliliate" && item !== "Tenant") {
                            this.jobRoles.push({
                                label: item,
                                value: selectedJob
                            });
                        }
                    });

                    var selectedTitle = false;
                    result.salutations.forEach(item => {
                        if (item == this.contactRec.Salutation) {
                            selectedTitle = true;
                        } else {
                            selectedTitle = false;
                        }
                        this.salutations.push({
                            label: item,
                            value: selectedTitle
                        });
                    });

                    var selectedCode = false;
                    result.phoneCodes.forEach(item => {
                        if (item == this.contactRec.Phone_Code__c) {
                            selectedCode = true;
                        } else {
                            selectedCode = false;
                        }
                        this.phoneCodes.push({
                            label: item,
                            value: selectedCode
                        });
                    });

                    result.additionalPerms.forEach(item => {
                        this.additionalPerms.push({
                            label: item,
                            value: item
                        });
                    });

                    result.branchRecs.forEach(item => {
                        this.branches.push({
                            label: item.Branch_Name__c,
                            value: item.Branch_Name__c
                        });
                    });
                }).catch(error => {
                    console.log('Error at getBrachUserMap::', JSON.stringify(error));
                });
            }).catch(error => {
                console.log('Error at getSelectedBranchUser:::', JSON.stringify(error));
            }),
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')
        ]).then(() => {

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });
    }

    backToBranch() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'vieweditbranch'
            },
            state: {
                c__recId: window.btoa(this.branchId)
            }
        });
    }

    suspendUser() {
        deactivateUser({ recId: this.contactId }).then(result => {
            if (result) {
                this.userRec = result;
            }
        }).catch(error => {
            console.log('Error at suspendUser:::', JSON.stringify(error));
        })
    }

    activeUser() {
        reactivateUser({ recId: this.contactId }).then(result => {
            if (result) {
                this.userRec = result;
            }
        }).catch(error => {
            console.log('Error at activeUser::', JSON.stringify(error));
        })
    }

    updateContact(event) {
        var modifiedField = event.target.name;

        if (modifiedField == "job_role") {
            this.contactRec.Job_role__c = event.target.value;
        }
        if (modifiedField == "salutation") {
            this.contactRec.Salutation = event.target.value;
        }
        if (modifiedField == "first_name") {
            this.contactRec.FirstName = event.target.value;
        }
        if (modifiedField == "last_name") {
            this.contactRec.LastName = event.target.value;
        }
        if (modifiedField == "mobileCode") {
            this.contactRec.Phone_Code__c = event.target.value;
        }
        if (modifiedField == "mobile_number") {
            this.contactRec.Phone = event.target.value;
        }
        if (modifiedField == "email") {
            this.contactRec.Email = event.target.value;
        }
    }

    handlePerChange(event) {
        this.selectedPermissions = event.detail.value;
    }

    handleBranchChange(event) {
        this.selectedBranchRecs = event.detail.value;
    }

    updateUser() {
        this.showSpinner = true;
        updateBranchUser({
            conRec: JSON.stringify(this.contactRec),
            additionalPerms: this.selectedPermissions,
            selectedBranchRecs: this.selectedBranchRecs
        }).then(result => {
            if (result == 'success') {
                this.showSpinner = false;
                window.scrollTo(0, 0);
                this.showSuccessScreen = true;
                // alert('Branch User Updated');
                //this.connectedCallback();
            }
        }).catch(error => {
            this.showSpinner = false;
            console.log('Error at updateUser:::', JSON.stringify(error));
        })
    }

    hideBootstrapErrors(event) {
        var buttonName = event.target.name;
        switch (buttonName) {
            case "successMg":
                this.showSuccessScreen = false;
        }
    }
    onlyNumberKey(event) {
        if(!(event.key == 0 || event.key == 1 || event.key == 2 || event.key == 3 || event.key == 4 || event.key == 5 || event.key == 6 || event.key == 7 || event.key == 8 || event.key == 9)){
            event.preventDefault();
        }
    }
}