import {  LightningElement,api,wire,track } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getHeaderDetails from "@salesforce/apex/EI_EWI_ProposalSummaryClass.getHeaderDetails";
import nullifyAccessCode from "@salesforce/apex/EI_EWI_ProposalSummaryClass.nullifyAccessCode";
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

export default class EI_EWI_HeaderComponent extends NavigationMixin (LightningElement) {
Tds_logo = EWITheme + '/assets/img/The-Dispute-Service.svg';
MinistryHousingImage = EWITheme + '/assets/img/ministry-housing.png';
WelshLogo = EWITheme + '/assets/img/wal.svg';
management = EWITheme + '/assets/img/management.svg';
managementHover = EWITheme + '/assets/img/management-black.svg';
setting = EWITheme + '/assets/img/setting.svg';
settingHover = EWITheme + '/assets/img/setting-black.svg';
Tenancy_Deposit_Scheme = EWITheme + '/assets/img/Tenancy-Deposit-Scheme-1.svg';
ministry_housing = EWITheme + '/assets/img/ministry-housing.png';
wal = EWITheme + '/assets/img/wal.svg';
Icon_Menu = EWITheme + '/assets/img/Icon-menu.png';


@track caseParName;
@track caseParticipant;
@track account;
@track accessCode;
@track recordtypename;
@track participanttype;
@track IsResponded;
// @track tabselectedhomepage ="nav-link active";
// @track tabselectedmyacoount ="nav-link";
@track tabselectedhomepage ;
@track tabselectedmyacoount ;
@track isShowMyAccountTab = true;
@track caseraisedby;
@track validpage=true;
@track isIimeOut = false;
@track showDetails=false;
@track showtab  = true;
timeoutID;

renderedCallback() {

    Promise.all([
       // loadScript(this, EWITheme+'/assets/js/plugin.min.js'),
       //  loadScript(this, EWITheme+'/assets/js/jquery.dataTables.min.js'),
      //  loadScript(this, EWITheme+'/assets/js/datepicker.js'),
      //  loadScript(this, EWITheme+'/assets/js/custom.js'),
         loadStyle(this, EWITheme  + '/assets/css/custom-ew.css'),
         loadStyle(this, EWITheme  + '/assets/css/ewifont.css')
         
        //  loadStyle(this, EWITheme  + '/assets/css/header-footer.css'),
        // loadStyle(this, EWITheme  + '/assets/css/style.css')
        
        
    ])
        .then(() => {
           // alert('Files loaded.');
        })
        .catch(error => {
            alert(error.body.message);
        });
    }

    connectedCallback() {
        this._resetTimer = this.resetTimer.bind(this);
        window.addEventListener('message', this._resetTimer);
        window.addEventListener("DOMMouseScroll", this._resetTimer );
        window.addEventListener("mousewheel", this._resetTimer );
        window.addEventListener("touchmove", this._resetTimer );
        window.addEventListener("MSPointerMove", this._resetTimer );
        window.addEventListener("mousemove", this._resetTimer);
        window.addEventListener("mousedown", this._resetTimer);
        window.addEventListener("keypress", this._resetTimer);
           
       // this._handleAlert = this.handleAlert.bind(this);
       // window.addEventListener('beforeunload', this._handleAlert);      
    }

    @wire(CurrentPageReference)
    getpageRef(pageRef) {
       
       // const queryurl = window.location.href.split('/').pop();
       const queryurl =  window.location.href.split('/').pop().split('?')[0];
        console.log('queryurl => ' + queryurl);
        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const recId = urlParams.get('accessCode');

        if(recId == '' || recId == null){
            this.isIimeOut = true;
            return;
        }
    
        if(queryurl.includes('ewiemailpreferences')){
           
            this.showtab = false;
                    
        }


        if(queryurl.includes('ewitenantaccountdetails') || queryurl.includes('ewiagllaccountdetails')  ){
            this.tabselectedmyacoount = "nav-link active";
            this.tabselectedhomepage = "nav-link";        
        }
        else{
            this.tabselectedmyacoount = "nav-link";
            this.tabselectedhomepage = "nav-link active";          
        }
       
        getHeaderDetails({accessCode : recId}).then(result =>{
            console.log("success result : ", result);
          
            if(result.caseParticipants == null && result.account == null){
                this.isIimeOut = true;
                return;
            }
            if(result.caseParticipants != null){
                this.showDetails=true;
                this.caseParticipant = result.caseParticipants;
                this.caseParName = this.caseParticipant.Account__r.Name.toLowerCase(); 
                this.accessCode = this.caseParticipant.Access_Code__c;
                this.recordtypename = this.caseParticipant.Account__r.RecordType.Name;
                this.participanttype = this.caseParticipant.Type__c;
                this.isShowMyAccountTab = true;
                this.IsResponded = this.caseParticipant.AGLL_Raised_Respond__c;
                this.caseraisedby = this.caseParticipant.Case__r.Dispute_Initiated_By__c;
                    if(this.participanttype == 'Non-Member Landlord' && this.IsResponded ==false && this.caseraisedby !='Tenant'){
                    this.isShowMyAccountTab = false;
                }
                else{
                    this.isShowMyAccountTab = true;    
                }
            }
            if(result.account != null){
                this.showDetails=true;
                console.log("in IF for account");
                this.account = result.account;
                this.accessCode = this.account.AccessCode__c;
                this.caseParName = this.account.Name.toLowerCase(); 
                this.recordtypename = this.account.recordType.Name;
                this.isShowMyAccountTab = true;    
                if(recordtypename.includes('Member')){
                    this.participanttype = 'agent';
                }
                
            }
            
        }).catch(error => {
            console.log("error : ", error)
        });    

    }

    homepage(event) {
    this.tabselectedmyacoount = "nav-link";
    this.tabselectedhomepage = "nav-link active";
    window.location.href =  EWIVPlus_Link+this.accessCode;

        // this[NavigationMixin.Navigate]({
        //     type: 'comm__namedPage',
        //     attributes: {
        //         pageName: 'home'
        //     },
        //     state:{
        //         accessCode: this.accessCode
        //     }
        // });
    }

    myaccount(event) {
    // window.location.replace('https://devuat-thedisputeservice.cs87.force.com/ewi/ewimyaccount?accessCode=check12');
    this.tabselectedmyacoount = "nav-link active";
    this.tabselectedhomepage = "nav-link";
    if(this.participanttype=='Tenant'){
    this[NavigationMixin.Navigate]({
        type: 'comm__namedPage',
        attributes: {
            pageName: 'ewitenantaccountdetails'
        },
        state:{
            accessCode: this.accessCode
        }
    });
    }
    else{
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewiagllaccountdetails'
            },
            state:{
                accessCode: this.accessCode
            }
        });
        }
    }

    resetTimer(){
        if(this.showDetails==true){
            console.log('timer reset');
           clearTimeout(this.timeoutID);
           this.timeoutID = setTimeout(this.handleSessionTimeout, 1200000);
        }
     }
     
     handleAlert(event){
       // alert('handle alert');
        this.handleSessionTimeout();        
     }
 
     handleSessionTimeout(){
         console.log('Session expired');
         const queryurl =  window.location.href.split('/').pop().split('?')[0];
         const queryString = window.location.search;    
         const urlParams = new URLSearchParams(queryString);      
         const recId = urlParams.get('accessCode');
        
         nullifyAccessCode({cp_accessCode : recId }).then(result =>{
             console.log('enter in nullify');
             window.location.replace("https://www.tenancydepositscheme.com/log-in/");
             //redirect to V+
         }).catch(error => {
             console.log("error : ", error.message)
         });
     }
}