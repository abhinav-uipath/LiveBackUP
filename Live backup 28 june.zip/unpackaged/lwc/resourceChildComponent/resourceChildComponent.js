import { LightningElement, api, track } from 'lwc';
export default class ResourceChildComponent extends LightningElement {

    @api showArticleInfo;
    
    // connectedCallback() {
    //     console.log('data in child ',JSON.stringify(this.showArticleInfo));
    // }
}