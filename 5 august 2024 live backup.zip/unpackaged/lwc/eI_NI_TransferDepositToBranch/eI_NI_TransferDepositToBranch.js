import { LightningElement, track, wire, api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import fetchBranches from '@salesforce/apex/EI_NI_TransferDeposit.fetchBranches';
import fetchBranchesAll from '@salesforce/apex/EI_NI_TransferDeposit.fetchBranchesAll';
import fetchSelectedBranch from '@salesforce/apex/EI_NI_TransferDeposit.fetchSelectedBranch';
import fetchDepositInfo from '@salesforce/apex/EI_NI_TransferDeposit.fetchDepositInfo';
import updateDepositBranch from '@salesforce/apex/EI_NI_TransferDeposit.updateDepositBranch';
import fetchCurrenUserWrapper from '@salesforce/apex/EI_NI_TransferDeposit.fetchCurrenUserWrapper';
import NI_payDepositGoBackUrl from '@salesforce/label/c.NI_payDepositGoBackUrl';
import NI_CustodialDepositSummryUrl from '@salesforce/label/c.NI_CustodialDepositSummryUrl';
import Id from '@salesforce/user/Id';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

export default class EI_NI_TransferDepositToBranch extends NavigationMixin(LightningElement) {
    successImage = NI_Theme + '/assets/img/thank-you.png';
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    usrId = Id;
    PageSpinner = false;
    isRequestedDepositSection = true;
    @track selectedCount = 0;
    @track TotalDeposits = 0;
    @api PaginationList = [];
    @track currentPage = 1;
    @track totalPagesCount = 1;
    @track pageSize = 10;
    @track branchList = [];
    @track branchId;
    depositList = [];
    @wire(CurrentPageReference)
    currentPageReference;
    @api depositRecId;
    @track depositRecord = [];
    loggedInUser;
    isStartPage = true;
    isEndPage = true;
    isEndPageNav = false;
    isStartPageNav = false;
    isStartPage = true;
    isEndPage = true;
    isConfirmationPopUp = false;
    isNoDepositsSelected = false;
    showFromBranch = false;
    fromBranchName = '';
    fromBranchNumber = '';
    toBranchName = '';
    toBranchNumber = '';
    @track currentBranchId;
    errors;
    @track showThankYouPage = false;
    userBranchWrapper = [];
    @track currentUser;
    @track goToDepositSummary = NI_payDepositGoBackUrl;
    @track goBack = NI_CustodialDepositSummryUrl;
    gotoBranchManagement = false;


    async connectedCallback() {
        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js'),
            // loadScript(this,EWC_Theme + '/assets/js/jquery.dataTables.min.js'),
            // loadScript(this,EWC_Theme + '/assets/js/datepicker.js')
        ]).then(() => {
            console.log('Files loaded.');

        }).catch(error => {
            console.log(error.body.message);
            this.errors = error;
        });

        fetchCurrenUserWrapper({}).then(result => {
            console.log('fetchCurrenUserWrapper result>>>>' + JSON.stringify(result));
            this.userBranchWrapper = result[0];
            this.currentUser = this.userBranchWrapper.userData;
        }).catch(error => {
            console.log('Line 85 review transfer fetchCurrenUserWrapper error -> ' + JSON.stringify(error));
        });

        console.log('userId==>' + this.usrId);
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = window.atob(depositRecId);
        console.log('depositRecId: ' + this.depositRecId);

        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchrecId = urlParams.get('branchRecId');
            if (branchrecId != null) {
                this.branchId = atob(branchrecId);
                console.log('BranchIdFromURL==>'+this.branchId);
            }
        }

        await fetchDepositInfo({ depId: this.depositRecId })
            .then(result => {
                console.log('In side Deposit record: ' + JSON.stringify(result));
                console.log('In side objdeposit: ' + JSON.stringify(result.objdeposit));
                console.log('Deposit Id: ' + this.depositRecId);
                this.depositRecord = result.objdeposit;
                console.log('Branch: ' + this.depositRecord.Branch__c);
                console.log('BranchR: ' + this.depositRecord.Branch__r);
                console.log('BranchR Name: ' + JSON.stringify(this.depositRecord.Branch__r.Branch_Name__c));
                console.log('BranchR Num: ' + JSON.stringify(this.depositRecord.Branch__r.Branch_Auto_Number__c));
                if (this.depositRecord.Branch__r.Branch_Name__c != null || this.depositRecord.Branch__r.Branch_Name__c != undefined) {
                    console.log('Branch Name: ' + this.depositRecord.Branch__r.Branch_Name__c);
                    this.showFromBranch = true;
                    this.fromBranchName = this.depositRecord.Branch__r.Branch_Name__c;
                    console.log('showFromBranch: ' + this.showFromBranch);
                }
                if (this.depositRecord.Branch__r.Branch_Auto_Number__c != null || this.depositRecord.Branch__r.Branch_Auto_Number__c != undefined) {
                    console.log('Branch Num: ' + this.depositRecord.Branch__r.Branch_Auto_Number__c);
                    this.showFromBranch = true;
                    this.fromBranchNumber = this.depositRecord.Branch__r.Branch_Auto_Number__c;
                    console.log('showFromBranch: ' + this.showFromBranch);
                }

                if (this.depositRecord.Branch__r.Id != null || this.depositRecord.Branch__r.Id != undefined) {
                    this.currentBranchId = this.depositRecord.Branch__r.Id;
                    console.log('Current Branch Id:2 ' + this.currentBranchId);
                }

                console.log('Address: ' + JSON.stringify(this.depositRecord.Property_Address__c));
                console.log('Tenant Names: ' + JSON.stringify(this.depositRecord.Tenants_Name__c));
                console.log('Amt: ' + JSON.stringify(this.depositRecord.Protected_Amount__c));
            }).catch(error => {
                console.log('Error fetchDepositInfo:::', error);
                this.errors = JSON.stringify(error);
            });


        console.log('Current Branch Id:1 ' + this.currentBranchId);
        if(this.currentBranchId != null && this.currentBranchId != undefined && this.currentBranchId != ''){
            fetchBranches({ userId: this.usrId, currentBranchId: this.currentBranchId })
            .then(result => {
                console.log('result inside fetchBranches: ' + JSON.stringify(result));
                if (result == '') {
                    this.currentPage = 1;
                }
                else {
                    this.currentPage = 1;
                    console.log('BranchDetails==>' + JSON.stringify(result));
                }
                this.branchList = result;
                var pageSize = this.pageSize;
                var totalRecordsList = result;
                var totalLength = totalRecordsList.length;
                this.totalRecordsCountPropList = totalLength;
                this.TotalDeposits = totalLength;
                this.startPage = 0;
                this.endPage = pageSize - 1;
                var PaginationList = [];
                for (var i = 0; i < pageSize; i++) {
                    if ((this.branchList).length > i) {
                        PaginationList.push(this.branchList[i]);
                    }
                }
                this.PaginationList = PaginationList;

                this.totalPagesCount = Math.ceil(totalLength / pageSize);
                if (this.totalPagesCount > 1) {
                    this.isEndPageNav = true;
                    this.isEndPage = false;
                }
                else {
                    this.isEndPage = true;
                    this.isEndPageNav = false;
                    this.totalPagesCount = 1;
                }
            })
            .catch(error => {
                console.log('error accured while getting branch details==>' + JSON.stringify(error));
            });
        } else {
            fetchBranchesAll({ userId: this.usrId})
            .then(result => {
                console.log('result inside fetchBranches: ' + JSON.stringify(result));
                if (result == '') {
                    this.currentPage = 1;
                }
                else {
                    this.currentPage = 1;
                    console.log('BranchDetails==>' + JSON.stringify(result));
                }
                this.branchList = result;
                var pageSize = this.pageSize;
                var totalRecordsList = result;
                var totalLength = totalRecordsList.length;
                this.totalRecordsCountPropList = totalLength;
                this.TotalDeposits = totalLength;
                this.startPage = 0;
                this.endPage = pageSize - 1;
                var PaginationList = [];
                for (var i = 0; i < pageSize; i++) {
                    if ((this.branchList).length > i) {
                        PaginationList.push(this.branchList[i]);
                    }
                }
                this.PaginationList = PaginationList;

                this.totalPagesCount = Math.ceil(totalLength / pageSize);
                if (this.totalPagesCount > 1) {
                    this.isEndPageNav = true;
                    this.isEndPage = false;
                }
                else {
                    this.isEndPage = true;
                    this.isEndPageNav = false;
                    this.totalPagesCount = 1;
                }
            })
            .catch(error => {
                console.log('error accured while getting branch details==>' + JSON.stringify(error));
            });
        }



    }

    handleDataCheckboxChange(event) {
        const selectedKey = event.target.getAttribute('data-key');
        this.PaginationList = this.PaginationList.map(item => ({
            ...item,
            Selected: item.Id === selectedKey,
        }));
        this.branchId = selectedKey;
        this.selectedCount = 1;
        console.log('selected Id:' + this.branchId);
    }


    handleTransferDeposit(event) {

        console.log('count==>' + this.selectedCount);
        var isValid = true;
        if (this.selectedCount == 0) {
            this.isNoDepositsSelected = true;
            isValid = false;
        }
        else {
            this.isNoDepositsSelected = false;
        }
        if (isValid) {
            this.PageSpinner = true;
            fetchSelectedBranch({ branchId: this.branchId })
                .then(result => {
                    if (result.length > 0) {
                        console.log('Selected Branch:' + JSON.stringify(result));
                        this.toBranchName = result[0].Branch_Name__c;
                        this.toBranchNumber = result[0].Branch_Auto_Number__c;
                        console.log('to Branch Name:' + this.toBranchName);
                        console.log('to BranchNumber:' + this.toBranchNumber);
                        this.isConfirmationPopUp = true;
                    }
                }).catch(error => {
                    console.log('Error fetchSelectedBranch:::' + JSON.stringify(error));
                });
        }
        this.PageSpinner = false;
    }

    submitTransfers(event) {
        event.preventDefault();
        console.log('Inside submitTransfers');
        //this.PageSpinner = true;
        this.isSubmitDisabled = true;
        this.isConfirmationPopUp = false;

        event.preventDefault();
        this.showSpinner = true;
        console.log('transfer Branch confirm clicked this.depositRecId: ' + this.depositRecId);
        console.log('transfer Branch confirm clicked this.branchId: ' + this.branchId);
        this.isSubmitDisabled = true;

        updateDepositBranch({ depositId: this.depositRecId, branchId: this.branchId })
            .then(result => {
                if (result == 'Success') {
                    this.showSpinner = false;
                    this.showThankYouPage = true;
                    this.isConfirmationPopUp = false;
                    console.log('Transferred');
                }

            })
            .catch(error => {
                console.log('error while submitting branch transfer=>' + JSON.stringify(error));
            });
        if(this.currentUser.Profile.Name == 'NI_Head_Office_User'){
            this.gotoBranchManagement = true;
        }
        this.PageSpinner = false;
    }

    handleConfirmDialogNo(event) {
        this.isConfirmationPopUp = false;
    }
    navigationHandle(event) {
        event.preventDefault();
        var sObjectList = this.branchList;

        var pageSize = Number(this.pageSize);
        var start = this.startPage;
        var end = this.endPage;
        console.log('navigationHandle ===' + event.target.dataset.id);
        var navigate = event.target.dataset.id;

        if (navigate == 'propNextId') {
            var sObjectList = this.branchList;
            var listName = 'prop';
            console.log('navigationHandle in  propNextId');
            console.log('navigationHandle in  propNextId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage + 1;
            this.next(listName, sObjectList, end, start, pageSize);
        }
        else if (navigate == 'propPreviousId') {
            var sObjectList = this.branchList;
            var listName = 'prop';
            console.log('navigationHandle in  propPreviousId');
            this.currentPage = this.currentPage - 1;
            this.previous(listName, sObjectList, end, start, pageSize);
        }


    }
    next(listName, sObjectList, end, start, pageSize) {
        console.log('SobjectList==>' + sObjectList);
        console.log('Line116')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                Paginationlist.push(sObjectList[i]);

            }
            counter++;
        }
        console.log('line=>127==>' + Paginationlist);
        this.PageSpinner = false;
        start = start + counter;
        end = end + counter;
        this.startPage = start;
        this.endPage = end;
        if (listName == 'prop') {
            this.PaginationList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }


        if (this.currentPage == 1) {
            this.isStartPage = true;
            this.isStartPageNav = false;
        } else {
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if (this.currentPage == this.totalPagesCount) {
            this.isEndPage = true;
            this.isEndPageNav = false;
        } else {
            this.isEndPage = false;
            this.isEndPageNav = true;
        }

    }
    previous(listName, sObjectList, end, start, pageSize) {
        console.log('Line155')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {

                Paginationlist.push(sObjectList[i]);
                counter++;
            } else {
                start++;
            }
        }
        this.PageSpinner = false;
        start = start - counter;
        end = end - counter;
        this.startPage = start;
        this.endPage = end;
        if (listName == 'prop') {
            this.PaginationList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }
        if (this.currentPage == 1) {
            this.isStartPage = true;
            this.isStartPageNav = false;
        } else {
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if (this.currentPage == this.totalPagesCount) {
            this.isEndPage = true;
            this.isEndPageNav = false;
        } else {
            this.isEndPage = false;
            this.isEndPageNav = true;
        }

    }

    handleDepositSummary(event) {

       // event.preventDefault();
        var depId = `${this.currentPageReference.state.depositId}`;
        console.log('depId: ' + depId);
        this.depositId = window.atob(depId);
        if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
            window.location = window.location.origin + this.goToDepositSummary +'/viewbranchuser?branchRecId=' + window.btoa(this.currentBranchId) + '&showBranch=' + window.btoa('false');
            //window.location = window.location.origin + '/ni/s/viewbranchuser?branchRecId=' + window.btoa(this.currentBranchId) + '&showBranch=' + window.btoa('false');
            // console.log('BranchId==>'+this.branchId);
            // this[NavigationMixin.Navigate]({
            //     type: 'comm__namedPage',
            //     attributes: {
            //         pageName: 'viewbranchuser'
            //     },
            //     state: {
            //        // depositId: btoa(this.depositId),
            //         branchRecId: btoa(this.currentBranchId),
            //         showBranch: window.btoa('false')
            //     }
            // });
        }
        else{
            window.location = window.location.origin + this.goToDepositSummary + '/viewbranchuser?depositId=' + window.btoa(this.depositId);
            //window.location = window.location.origin + '/ni/s/viewbranchuser?depositId=' + window.btoa(this.depositId);
        }
       

    }

    goBranchManagementHandle(event) {
        window.location = window.location.origin + this.goToDepositSummary;
        //window.location = window.location.origin + '/ni/s/';
     }

    goBackHandle(event) {
       // event.preventDefault();
            window.location = window.location.origin + this.goBack + window.btoa(this.depositRecId)  + '&branchRecId=' + window.btoa(this.currentBranchId) + '&showBranch=' + window.btoa('false');
            //window.location = window.location.origin + '/ni/s/depositSummary?depositId=' + window.btoa(this.depositRecId)  + '&branchRecId=' + window.btoa(this.currentBranchId) + '&showBranch=' + window.btoa('false');
            
    }
    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "NoDepositsSelected":
                this.isNoDepositsSelected = false;
                break;
        }
    }
}