import { LightningElement, wire } from 'lwc';

import getTestimonials from '@salesforce/apex/TRS_testimonialController.getTestimonial';

export default class TestimonialAndSuccessStory extends LightningElement {
    testimonials;
    isPublishTestimonial = false;

    @wire(getTestimonials)
    wiredStories({ error, data }) {
        if (data) {
            this.isPublishTestimonial = true;
            this.testimonials = data;
            // console.log('## this.testimonials', this.testimonials);
        } else if (error) {
            // Handle error
        }
    }
}