import { LightningElement, track, wire } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import saveproperty from '@salesforce/apex/EI_NI_ManageProperties.saveproperty';
import getLandlordWrapper from '@salesforce/apex/EI_NI_createLandlord.createLandlordWrapper';
import getLandlords from '@salesforce/apex/EI_NI_ManageProperties.getLandlords';
import searchLandlord from '@salesforce/apex/EI_NI_ManageProperties.serachlandlord';
import insertProperties from '@salesforce/apex/EI_NI_ManageProperties.insertProperties';
import getUserDetails from '@salesforce/apex/EI_NI_ManageProperties.getUserDetails';
import getPropertiesDup from '@salesforce/apex/EI_NI_ManageProperties.fetchDupProperties';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';



export default class EI_NI_AddProperty extends LightningElement {

    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    backArrowImg = NI_Theme + '/assets/img/nhos-arrow-dropleft.svg`';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    cancel_icon = NI_Theme + '/assets/img/Cancel-icon.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    quesCircleImg = NI_Theme + '/assets/img/question-circle.png';
    featherImg = NI_Theme + '/assets/img/feather-edit.svg';
    viewIconImg = NI_Theme + '/assets/img/View_icon.png';


    @track dupProperties = {};
    showDupPropertyWarning = false;
    isDuplicatePrperty = false;
    @track niPostcodeMetaDataRecords = [];
    @track errorMetaDataRecords = [];
    @track propertyAddress = '';
    @track isStreetError = false;
    @track isTownError = false;
    @track isValuesMissimgErrorMsg = false;
    @track isErrorMsg = false;
    @track isShowFields = true;
    @track selectedPrimaryLandlordId = [];
    @track primaryLandLordList = [];
    @track addLandLordList = [];
    @track isShowListedLandlord = false;
    @track isAdditionalLandLord = false;
    @track isShowListedAddLandlord = false;
    @track selectedAdditionalLandLord = [];
    @track selectedjointlandlordID = [];
    @track selectedPrimaryLandlord = [];
    isLandlordYesDisplay = false;
    isLandlordNoDisplay = false;
    //isprimaryLandLordList = false;
    isPrimaryLandlordDisplay = false;
    isPrimaryLandlordNameError = false;
    isAdditionalLandlordNameError = false;
    ispropertySuccessMessage = false;
    ispropertyErrorMessage = false;
    isAgentTrue = false;
    propertySuccessMessage = '';
    propertyErrorMessage = '';
    searchLandlordString = '';
    primaryLandlordName = '';
    isPropertySearch = false;
    isPostcodeErrorAlert = false;
    isPropertyErrorAlert = false;
    isSelectPrimaryLLError = false;
    isPrimaryLandlord = false;
    finalSelectedAddress = '';
    isPrimaryAddressOfNI = false;
    isWarningShow = false;
    houseNo = '';
    streetName = '';
    townCity = '';
    county = '';
    postCode = '';

    branchId = null;

    // address 
    @track propertyAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
    @track primaryAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };


    connectedCallback() {
        var queryString = window.location.href;
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if(branchRecId != null && branchRecId != '' && branchRecId != undefined) {
                this.branchId = atob(branchRecId);
            } else {
                this.branchId = null;
            }
        }
        console.log('URL String:::' + JSON.stringify(queryString));

        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js'),
            loadScript(this, NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_Theme + '/assets/js/datepicker.js')

        ]).then(() => {
            console.log('Files loaded');

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });

        getLandlordWrapper()
            .then(data => {

                console.log('Line 104 Data length-->' + data.length);
                // console.log('Line 79 -> ', JSON.stringify(data));
                //this.errorMetaDataRecords = data;
                if (data.length > 0) {
                    // console.log('Line 82 -> ', JSON.stringify(data[0].errorMessageList));
                    this.errorMetaDataRecords = data[0].errorMessageList;
                    // console.log('Line 84 -> ',JSON.stringify(data[0].niPostcodeList));
                    this.niPostcodeMetaDataRecords = data[0].niPostcodeList;
                    // console.log('Line 86 weird1 -> ',JSON.stringify(data[0].countryPhoneCodeList));

                    // Salutation load
                    //  var conts = data[0].salutationMap;
                    //  for(var key in conts){
                    //      this.salutation.push({value:conts[key], key:key}); //Here we are creating the array to show on UI.
                    //        }   
                    //  console.log('Line 120 Salutation -> ',JSON.stringify( this.salutation));

                    //  // Phonecode
                    //  for (var key in data[0].countryPhoneCodeList) {  

                    //        if( data[0].countryPhoneCodeList[key]=='+44' ){
                    //       this.phoneCodeList.push({ key: data[0].countryPhoneCodeList[key], value: true});
                    //      }
                    //      else{
                    //       this.phoneCodeList.push({ key: data[0].countryPhoneCodeList[key], value: false});
                    //     }
                    //    }
                    // console.log('Line 120 Phonecode List -> ',this.phoneCodeList);



                }

            })
            .catch(error => {
                console.error('Error calling sign up wrapper ==> ' + JSON.stringify(error));
            })
        //Fetching user details
        console.log('data--->125');
        getUserDetails().then(data => {
            console.log('data--->126' + JSON.stringify(data));
            if (data) {


                this.userType = data.Profile.Name;
                console.log('line 128--->userProfile---->' + this.userType);
                if (this.userType == 'NI_Agent'|| this.userType=='NI_ Branch Users'||this.userType=='NI_Head_Office_User') {
                    this.isAgentTrue = true;
                }

            }



        }).catch(error => { })

    }

    //     renderedCallback(){
    //         if (this.isAgentTrue == true) {

    //             let selectYesBtn = this.template.querySelector('[name="landlord_yes"]');

    //             selectYesBtn.classList.add("active");

    //     }
    // }

    @wire(getLandlords)
    wiredData({ error, data }) {
        if (data) {
            //this.primaryLandlordList = data;
            let options = [];

            for (var key in data) {
                // Here key will have index of list of records starting from 0,1,2,....
                options.push({ label: data[key].Name, value: data[key].Id });

                // Here Name and Id are fields from sObject list.
            }
            // this.primaryLandlordList = options;
            //this.isShowListedLandlord= options;
            console.log('Data', data);
        } else if (error) {
            console.error('Error:', error);
        }
    }
    searchPrimaryLLHandle(event) {
        this.isShowListedLandlord = false;
        this.isPrimaryLandlordError = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        this.searchLandlordString = this.template.querySelector('[name="landlord_search"]').value;
        let searchLandlordStr = this.searchLandlordString;
        this.primaryLandLordList = [];
        // this.primaryLandlordName='';
        console.log('Line 482 Primary LL search key -> ', searchLandlordStr);
        console.log('Line 483 length -> ', searchLandlordStr.length);

        //if (searchLandlordStr.length > 2) {
            searchLandlord({ searchField: this.searchLandlordString, branchId: this.branchId })
                .then(result => {
                    console.log('result==>' + JSON.stringify(result));
                    if (result.length == 0) {
                        this.isPrimaryLandlordNameError = true;
                        this.isShowListedLandlord = false;
                        this.primaryLandLordList = [];

                    } else {
                        this.isShowListedLandlord = true;
                        // let selectedrec = []; 
                        //  selectedrec = result;
                        this.primaryLandLordList = result;
                        //  this.primaryLandlordName='';
                        console.log('result length : ' + result.length);
                        console.log('Landlord data : ' + JSON.stringify(this.primaryLandLordList));
                    }


                })
                .catch(error => {

                    console.log('Line 288 Error -> ', error);
                });

        //}

    }

    // openModelPopUp(){
    //    console.log('openModelPopUp');
    //   this.isAddLandlordSection = true;    
    //}
    goToLoginPage() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'login'

            }
        });
    }

    handleCancel() {
        console.log('handleCancel');
    }

    popupCancelHandle() {
        console.log('popupCancelHandle');
    }
    // For handling event from child component(address finder) for 'onfieldchange' event i.e. entering manually
    // addressFieldChangeHandler(event) {
    //     console.log('addressFieldChangeHandler');
    //     let returnedData = event.detail;
    //     console.log('returnedData == ' + JSON.stringify(returnedData));
    //     if (returnedData.addressType == 'Address') {
    //         if (returnedData.fieldName.includes("TownCity")) {
    //             this.primaryAddress = { ...this.primaryAddress, "Town": returnedData.value }

    //         } else if (returnedData.fieldName.includes("County")) {
    //             this.primaryAddress = { ...this.primaryAddress, "County": returnedData.value }

    //         } else if (returnedData.fieldName.includes("Postcode")) {
    //             this.primaryAddress = { ...this.primaryAddress, "PostCode": returnedData.value }
    //             var isPrimaryAddressOfNiPostcode = false;
    //             this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
    //                 if (returnedData.value.includes(postCodeRecord.Label)) {
    //                     isPrimaryAddressOfNiPostcode = true;
    //                 }
    //             });
    //             this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;

    //         } else if (returnedData.fieldName.includes("Country")) {
    //             this.primaryAddress = { ...this.primaryAddress, "Country": returnedData.value }

    //         } else if (returnedData.fieldName.includes("House")) {
    //             this.primaryAddress = { ...this.primaryAddress, "houseNo": returnedData.value }

    //         } else if (returnedData.fieldName.includes("Street")) {
    //             this.primaryAddress = { ...this.primaryAddress, "Street": returnedData.value }
    //         }

    //         console.log('Line 213 Address--->' + JSON.stringify(this.primaryAddress));
    //         this.propertyAddress = this.primaryAddress.Street + ' ' + this.primaryAddress.Town + ' ' + this.primaryAddress.County + ' ' + this.primaryAddress.Postcode + ' ' + this.primaryAddress.Country;
    //         console.log('Line 371 Address Entered manually--->' + this.propertyAddress);
    //         if ((this.propertyAddress.houseNo != null && this.propertyAddress.houseNo != '' && this.propertyAddress.houseNo != undefined) &&
    //             (this.primaryAddress.Street != null && this.primaryAddress.Street != '' && this.primaryAddress.Street != undefined) &&
    //             (this.primaryAddress.Town != null && this.primaryAddress.Town != '' && this.primaryAddress.Town != undefined) &&
    //             (this.primaryAddress.County != null && this.primaryAddress.County != '' && this.primaryAddress.County != undefined) &&
    //             (this.primaryAddress.Country != null && this.primaryAddress.Country != '' && this.primaryAddress.Country != undefined) &&
    //             (this.primaryAddress.Postcode != null && this.primaryAddress.Postcode != '' && this.primaryAddress.Postcode != undefined)) {
    //             this.searchProperties(this.primaryAddress);
    //         }
    //     }

    // }
    addressFieldChangeHandler(event) {
        let returnedData = event.detail;

        this.finalSelectedAddress = '';
        if (returnedData.addressType == 'Address') {
            if (returnedData.fieldName.includes("TownCity")) {
                this.primaryAddress = { ...this.primaryAddress, "Town": returnedData.value }

            } else if (returnedData.fieldName.includes("County")) {
                this.primaryAddress = { ...this.primaryAddress, "County": returnedData.value }

            } else if (returnedData.fieldName.includes("Postcode")) {
                this.primaryAddress = { ...this.primaryAddress, "Postcode": returnedData.value }
                // console.log('Line 417 House -> ', returnedData.value);
                var isPrimaryAddressOfNiPostcode = false;
                this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                    if (returnedData.value.includes(postCodeRecord.Label)) {
                        isPrimaryAddressOfNiPostcode = true;
                    }
                });
                //   this.showCorresAddress = !isPrimaryAddressOfNiPostcode;
                this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;

            } else if (returnedData.fieldName.includes("House")) {
                this.primaryAddress = { ...this.primaryAddress, "houseNo": returnedData.value }

            } else if (returnedData.fieldName.includes("Street")) {
                this.primaryAddress = { ...this.primaryAddress, "Street": returnedData.value }
            } else if (returnedData.fieldName.includes("Country")) {
                this.primaryAddress = { ...this.primaryAddress, "Country": returnedData.value }

            }
            if ((this.propertyAddress.houseNo != null && this.propertyAddress.houseNo != '' && this.propertyAddress.houseNo != undefined) &&
                (this.primaryAddress.Street != null && this.primaryAddress.Street != '' && this.primaryAddress.Street != undefined) &&
                (this.primaryAddress.Town != null && this.primaryAddress.Town != '' && this.primaryAddress.Town != undefined) &&
                (this.primaryAddress.County != null && this.primaryAddress.County != '' && this.primaryAddress.County != undefined) &&
                (this.primaryAddress.Country != null && this.primaryAddress.Country != '' && this.primaryAddress.Country != undefined) &&
                (this.primaryAddress.Postcode != null && this.primaryAddress.Postcode != '' && this.primaryAddress.Postcode != undefined)) {
                this.searchProperties(this.primaryAddress);
            }
        }

        console.log('Line 367 Address Entered manually' + JSON.stringify(this.primaryAddress));

        if (this.primaryAddress.houseNo != null || this.primaryAddress.houseNo != undefined) {
            this.houseNo = this.primaryAddress.houseNo;
         //   console.log('Line 391 House--->' + this.houseNo);
        }
        if (this.primaryAddress.Street != null || this.primaryAddress.Street != undefined) {
            this.streetName = this.primaryAddress.Street;
         //   console.log('Line 392 StreetName--->' + this.streetName);
        }
        if (this.primaryAddress.Town != null || this.primaryAddress.Town != undefined) {
            this.townCity = this.primaryAddress.Town;
          //  console.log('Line 393 City--->' + this.townCity);
        }
        if (this.primaryAddress.County != null || this.primaryAddress.County != undefined) {
            this.county = this.primaryAddress.County;
          //  console.log('Line 394 county--->' + this.county);
        }
        if (this.primaryAddress.Postcode != null || this.primaryAddress.Postcode != undefined) {
            this.postCode = this.primaryAddress.Postcode;
           // console.log('Line 395 postCode--->' + this.postCode);
        }

        if (this.primaryAddress.Country != null || this.primaryAddress.Country != undefined) {
            this.country = this.primaryAddress.Country;
            // console.log('Line 394 Country --->' + this.country);
        }

        // console.log('Line 395 postCode--->'+this.postCode);
        this.finalSelectedAddress = this.houseNo + ' ' + this.streetName + ' ' + this.townCity + ' ' + this.county + ' ' + this.postCode + ' ' + this.country;
       // console.log('Line 371 Address Entered manually--->' + this.finalSelectedAddress);
        this.defaultPrimaryAddress = [];
        if (this.finalSelectedAddress != '') {
            this.defaultPrimaryAddress.push(this.primaryAddress);
            // this.primaryAddress.push(this.currentRelevantData.primaryAddress);
        }
        this.template.querySelector('c-ei_-n-i_property-address-finder').defaultAddressUpdate(this.defaultPrimaryAddress);
        console.log('Line 371 list Address Entered manually--->' + JSON.stringify(this.defaultPrimaryAddress));

    }

    // For handling event from child component(address finder) for 'onselectingaddress' event i.e. selecting automatically
    selectingAddressHandler(event) {
        let returnedData = event.detail;
        this.isPostcodeErrorAlert = false;
        this.isPropertySearch = false;


        if (returnedData.addressType == 'Address') {
            this.propertyAddress = returnedData.addressObj;

            var isPrimaryAddressOfNiPostcode = false;
            this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                if (this.propertyAddress.Postcode.includes(postCodeRecord.Label)) {
                    isPrimaryAddressOfNiPostcode = true;
                }
            });
            //  this.showCorresAddress = !isPrimaryAddressOfNiPostcode;
            this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;
            console.log('Line 336 Check for NI postcode: ' + this.isPrimaryAddressOfNI);

        }
        console.log('Line 339 Address Selected--->' + JSON.stringify(this.propertyAddress));

        if (this.propertyAddress.houseNo != null || this.propertyAddress.houseNo != undefined) {
            this.houseNo = this.propertyAddress.houseNo;
        }
        if (this.propertyAddress.AddressLine != null || this.propertyAddress.AddressLine != undefined) {
            this.streetName = this.propertyAddress.AddressLine;// street data getting empty so address line used
        }
        if (this.propertyAddress.Town != null || this.propertyAddress.Town != undefined) {
            this.townCity = this.propertyAddress.Town;
        }
        if (this.propertyAddress.County != null || this.propertyAddress.County != undefined) {
            this.county = this.propertyAddress.County;
        }
        if (this.propertyAddress.Postcode != null || this.propertyAddress.Postcode != undefined) {
            this.postCode = this.propertyAddress.Postcode;
        }
        this.finalSelectedAddress = this.houseNo + ' ' + this.streetName + ' ' + this.townCity + ' ' + this.county + ' ' + this.postCode;
        console.log('Line 364 Listed Final Address-->' + this.finalSelectedAddress);
        if ((this.propertyAddress.houseNo != null && this.propertyAddress.houseNo != '' && this.propertyAddress.houseNo != undefined) ||
            (this.propertyAddress.AddressLine != null && this.propertyAddress.AddressLine != '' && this.propertyAddress.AddressLine != undefined) ||
            (this.propertyAddress.Town != null && this.propertyAddress.Town != '' && this.propertyAddress.Town != undefined) ||
            (this.propertyAddress.County != null && this.propertyAddress.County != '' && this.propertyAddress.County != undefined) ||
            (this.propertyAddress.Country != null && this.propertyAddress.Country != '' && this.propertyAddress.Country != undefined) ||
            (this.propertyAddress.Postcode != null && this.propertyAddress.Postcode != '' && this.propertyAddress.Postcode != undefined)) {
            this.searchProperties(this.propertyAddress);
        }

    }
    

    searchProperties(addressStr) {
        console.log('line 363'+addressStr.houseNo);
        console.log('Property to find>>>>' + JSON.stringify(addressStr.AddressLine.trim()));
        getPropertiesDup({
            "houseNo": addressStr.houseNo,
            "street": addressStr.AddressLine != "" ? addressStr.AddressLine.trim() : addressStr.Street,
            "townCity": addressStr.Town,
            "postCode": addressStr.Postcode,
            "branchId": this.branchId != null ? this.branchId : null
        }).then(result => {
            console.log('Deplicate Property>>>>' + JSON.stringify(result));
            if (result != undefined && result != null) {
                this.dupProperties = result;
                this.showDupPropertyWarning = true;
                this.isDuplicatePrperty = true;
            } else {
                this.showDupPropertyWarning = false;
                this.isDuplicatePrperty = false;
                this.ispropertyErrorMessage = false;

            }
        }).catch(error => {
            console.log('Error findind properties>>' + JSON.stringify(error));
        })
    }

    closeWarning() {
        this.showDupPropertyWarning = false;
    }

    hideErrors() {
        this.isStreetError = false;
        this.isTownError = false;
        this.isValuesMissimgErrorMsg = false;
    }

    clickSaveHandle(event) {
        console.log('clickSaveHandle');
        event.preventDefault();
        let valid = false;
        // if(this.primaryAddress.Street == null || this.primaryAddress.Street == '' || this.primaryAddress.Street == undefined){
        //     this.isStreetError = true;
        // }
        // else if(this.primaryAddress.Town == null || this.primaryAddress.Town == '' || this.primaryAddress.Town == undefined){
        //     this.isTownError = true;
        // }
        // else if(this.primaryAddress.County == null || this.primaryAddress.County == '' || this.primaryAddress.County == undefined){

        // }
        if (this.primaryAddress.Street == null || this.primaryAddress.Street == '' || this.primaryAddress.Street == undefined ||
            this.primaryAddress.Town == null || this.primaryAddress.Town == '' || this.primaryAddress.Town == undefined ||
            this.primaryAddress.County == null || this.primaryAddress.County == '' || this.primaryAddress.County == undefined ||
            this.primaryAddress.Postcode == null || this.primaryAddress.Postcode == '' || this.primaryAddress.Postcode == undefined ||
            this.primaryAddress.County == null || this.primaryAddress.County == '' || this.primaryAddress.County == undefined
        ) {
            valid = false;
            this.isValuesMissimgErrorMsg = true;
        }
        else {
            valid = true;
        }
        if (valid) {
            let paramStr = JSON.stringify(this.primaryAddress);
            console.log('Line 501 paramStr -> ', paramStr);
            saveproperty({ receivedParams: paramStr })
                .then(result => {
                    this.primaryAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
                    console.log('saveproperty result --->' + JSON.stringify(result));
                    this.isShowFields = false;
                    if (result != null) {



                    } else {
                        console.log('Some error occured');
                        this.isErrorMsg = true;
                    }

                })
                .catch(error => {
                    console.log('Line 288 Error -> ', error);
                });
        }

    }
    landlordYesHandle(event) {
        event.preventDefault();
        console.log('line 48 yes ');

        this.selectedPrimaryLandlord = [];
        this.selectedAdditionalLandLord = [];
        this.primaryLandlordName = '';

        this.isPrimaryLandlordDisplay = true;
        this.isLandlordYesDisplay = true;
        this.isLandlordNoDisplay = false;

        let selectBtn = this.template.querySelector('[name="landlord_yes"]');

        selectBtn.style.backgroundColor = '#13185C';

        selectBtn.style.color = '#fff';



        this.template.querySelector('[name="landlord_no"]').style = '';



    }

    landlordNoHandle(event) {
        event.preventDefault();
        console.log('line 56 no');
        this.isShowListedLandlord = false;
        this.selectedPrimaryLandlord = [];
        this.selectedAdditionalLandLord = [];
        this.primaryLandlordName = '';

        this.isPrimaryLandlordDisplay = true;
        this.isLandlordYesDisplay = false;
        this.isLandlordNoDisplay = true;

        let selectBtn = this.template.querySelector('[name="landlord_no"]');

        selectBtn.style.backgroundColor = '#13185C';

        selectBtn.style.color = '#fff';



        this.template.querySelector('[name="landlord_yes"]').style = '';




    }
    backHandler() {
        console.log('handleCancel');
        const myEvent = new CustomEvent('back', {
            detail: ''
        });

        this.dispatchEvent(myEvent);

    }
    createProperty(event) {
        event.preventDefault();
        const topDiv = this.template.querySelector('[data-id="landlord_select_view"]');
        this.isPropertySearch = false;
        this.isPostcodeErrorAlert = false;
        this.isPrimaryLandlord = false;
        this.isPropertyErrorAlert = false;
        this.isSelectPrimaryLLError = false;
        this.ispropertyErrorMessage = false;
        console.log('Line 491  --->' + this.finalSelectedAddress);
        console.log('dupProLength==>'+this.dupProperties.length);
        if (this.finalSelectedAddress == null || this.finalSelectedAddress == undefined || this.finalSelectedAddress == '') {
            this.isPropertySearch = true;
            this.isPropertyErrorAlert = true;
            this.isPostcodeErrorAlert = false;
            //topDiv.scrollIntoView();
        }
        else if (this.isPrimaryAddressOfNI == false) {
            this.isPostcodeErrorAlert = true;
            // topDiv.scrollIntoView();

        } else if ((this.userType == 'NI_Agent'|| this.userType=='NI_ Branch Users'||this.userType=='NI_Head_Office_User') && (this.primaryLandlordName == null || this.primaryLandlordName == undefined || this.primaryLandlordName == '')) {
            console.log('Line 691 primaryLandlordName Error');
            this.isPrimaryLandlord = true;
            this.isSelectPrimaryLLError = true;
            // topDiv.scrollIntoView();
        }
        
        else if(this.isDuplicatePrperty){
            this.ispropertyErrorMessage = true;
        }
        else {
            let primaryLandlord = this.selectedPrimaryLandlord;
            let additionalLandlord = this.selectedAdditionalLandLord;

            console.log('Line 813 primaryLandlord--->' + JSON.stringify(primaryLandlord));
            console.log('Line 814 additionalLandlord--->' + JSON.stringify(additionalLandlord));
            console.log('House Number==>'+this.houseNo);
            insertProperties({
                street: this.streetName, houseNo:this.houseNo, city: this.townCity, postcode: this.postCode, county: this.county, country: this.country,
                primaryLandlordList: primaryLandlord, additionalLandlordList: additionalLandlord,
                branchId: this.branchId != null ? this.branchId : null
            })
                .then(result => {
                    console.log('Line 755--->' + JSON.stringify(result));
                    var property = {};
                    if (result.duplicateProperty) {
                        // console.log("Line 758 duplicate Property-->"+result.propertyCreated);
                        property = result.duplicateProperty;
                        console.log("duplicate Property-->" + JSON.stringify(property));
                        console.log("duplicate Property id-->" + property.Id);
                        this.insertedPropertyId = property.Id;
                        this.ispropertySuccessMessage = false;
                        this.ispropertyErrorMessage = true;
                        this.isWarningShow = true;
                        // this.propertyErrorMessage='duplicate property found: '+property.Name;
                        this.propertySuccessMessage = '';
                    } else if (result.propertyCreated) {

                        property = result.propertyCreated;
                        console.log("property Created-->" + JSON.stringify(property));
                        this.insertedPropertyId = property.Id;
                        this.ispropertySuccessMessage = true;
                        this.ispropertyErrorMessage = false;
                        this.isPostcodeErrorAlert = false;
                        this.isSelectPrimaryLLError = false;
                        
                        // this.propertySuccessMessage='Property created successfully: '+property.Name;
                        this.propertyErrorMessage = '';
                        window.location.reload();
                        this.isPropertyErrorAlert = false;
                        setTimeout(() => {
                            console.log('Successinside setTimeout-->');
                            const myEvent = new CustomEvent('propertycreated', {
                                detail: property
                            });

                            this.dispatchEvent(myEvent);

                        }, 2000);
                    } else {
                        this.ispropertySuccessMessage = false;
                        //this.ispropertyErrorMessage=true;
                        this.propertySuccessMessage = '';
                        //this.propertyErrorMessage='Error occured while property creation';
                        console.log('Error occured while property creation');

                    }


                })
                .catch(error => {
                    this.ispropertySuccessMessage = false;
                    // this.ispropertyErrorMessage=true;
                    // this.propertySuccessMessage='';
                    // this.propertyErrorMessage='Error occured while property creation';
                    console.log('Line 915 Error -> ', error);
                })
        }


    }
    additionalLandLordNoHandle() {
        this.isAdditionalLandLord = false;
        this.isShowListedAddLandlord = false;
        let selectBtn = this.template.querySelector('[name="additionalLandlordNoBtn"]');

        selectBtn.style.backgroundColor = '#13185C';

        selectBtn.style.color = '#fff';

        this.template.querySelector('[name="additionalLandlordYesBtn"]').style = '';

    }
    additionalLandLordYesHandle() {
        this.isAdditionalLandLord = true;
        this.searchLandlordString = '';
        let selectBtn = this.template.querySelector('[name="additionalLandlordYesBtn"]');
        selectBtn.style.backgroundColor = '#13185C';
        selectBtn.style.color = '#fff';
        this.template.querySelector('[name="additionalLandlordNoBtn"]').style = '';

    }

    searchAddLandLordHandle() {
        this.addLandLordList = false;
        this.isShowListedAddLandlord=false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        this.searchLandlordString = this.template.querySelector('[name="additional_landlord_search"]').value;
        let searchLandlordStr = this.searchLandlordString;
        this.addLandLordList = [];
        console.log('Line 596 Additional LL -> ', searchLandlordStr);
        console.log('Line 597 length -> ', searchLandlordStr.length);
        console.log('this.branchId' + this.branchId);
        //if (searchLandlordStr.length > 2) {
            searchLandlord({ searchField: this.searchLandlordString, branchId: this.branchId })
                .then(result => {
                    if (result.length == 0) {
                        this.isAdditionalLandlordNameError = true;
                        //this.isPrimaryLandlordNameError = true;
                        this.addLandLordList = [];
                        this.addLandLordList = false;
                        this.isShowListedAddLandlord=false;
                    } else {
                        this.isShowListedAddLandlord = true;
                        // let selectedrec = []; 
                        //  selectedrec = result;
                        this.addLandLordList = result;
                        console.log('result length : ' + result.length);
                        console.log('Landlord data : ' + JSON.stringify(this.addLandLordList));
                    }

                })
                .catch(error => {

                    console.log('Line 288 Error -> ', error);
                });
        //}


    }
    handleAdditionalLandLord(event) {
        this.isShowListedAddLandlord = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        console.log('Additional landlord selectRecord ## ' + recordID);
        let additionalLandlord = this.addLandLordList;
        let selectedrecId = this.selectedjointlandlordID;
        let selectedrec = this.selectedAdditionalLandLord;
        console.log('selected Landlord data : ' + JSON.stringify(additionalLandlord));
        console.log('selected selectedrecId : ' + JSON.stringify(selectedrecId));
        for (let i = 0; i < additionalLandlord.length; i++) {
            if (additionalLandlord[i].Id == recordID) {
                if (!selectedrecId.includes(recordID)) {
                    console.log("line 93 addLL " + additionalLandlord[i].Id, additionalLandlord[i].FirstName);
                    selectedrec.push(additionalLandlord[i]);
                    selectedrecId.push(recordID);
                } else {
                    this.isAdditionalLandlordError = true;
                }
            }
        }

        this.addLandLordList = [];
        this.selectedjointlandlordID = selectedrecId;
        console.log('Line 647  Selected joint landlord ID ## ' + JSON.stringify(this.selectedjointlandlordID));
        // console.log('line 649'+JSON.stringify(selectedrec));
        this.selectedAdditionalLandLord = selectedrec;
        console.log('Line 648 Selected Add landlord ## ' + JSON.stringify(this.selectedAdditionalLandLord));

    }
    handlePrimaryLandLord(event) {
        this.isShowListedLandlord = false;
        this.isPrimaryLandlordNameError = false;
        this.isPrimaryLandlordError = false;
        this.isAdditionalLandlordError = false;
        this.isAdditionalLandlordNameError = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        console.log('landlord selectRecord ## ' + recordID);
        let primarylandlord = this.primaryLandLordList;
        //  console.log('landlord primarylandlord ## '+ primarylandlord);
        let selectedrecId = this.selectedjointlandlordID;
        console.log('line 561--->' + selectedrecId);

        let selectedPrimarylandlord = this.selectedPrimaryLandlord;
        console.log("line 28" + JSON.stringify(selectedPrimarylandlord));
        if (selectedPrimarylandlord.length > 0) {
            console.log("line 29");
            if (selectedrecId.includes(selectedPrimarylandlord[0].Id)) {
                console.log("line 30");
                let index = selectedrecId.indexOf(selectedPrimarylandlord[0].Id);
                console.log("line 568-->" + index);
                selectedrecId.splice(index, 1);
                console.log("line 27");
            }
        }
        console.log('line 562--->' + selectedrecId);
        let selectedrec = [];
        for (let i = 0; i < primarylandlord.length; i++) {
            if (primarylandlord[i].Id == recordID) {
                if (!selectedrecId.includes(recordID)) {
                    console.log("line 93 primaryLL " + primarylandlord[i].Id, primarylandlord[i].FirstName);
                    selectedrec.push(primarylandlord[i]);
                    selectedrecId.push(recordID);
                } else {
                    this.isPrimaryLandlordError = true;
                    // this.primaryLandlordName='';
                }
            }
        }
        console.log('Line 584 landlord selectedrec ## ' + JSON.stringify(selectedrec));
        var fullName;
        if (selectedrec[0].FirstName != undefined || selectedrec[0].FirstName != null) {
            fullName = selectedrec[0].FirstName + " " + selectedrec[0].LastName;
        } else {
            fullName = selectedrec[0].LastName;
        }
        console.log("fullName-->", fullName);
        this.primaryLandLordList = [];
        this.primaryLandlordName = fullName;
        this.selectedPrimaryLandlord = selectedrec;
        this.selectedjointlandlordID = selectedrecId;

       
    }
    handleLandlordCreated(event) {
        console.log('inside addproperty handleLandlordCreated 1' + JSON.stringify(event));
        console.log('SearchKyAferSelClicked==>'+this.searchLandlordString);
        console.log('inside1 ' + event.detail);
        console.log('inside2 ' + event.calledfrom);
        var createdContact = event.detail.landLordCreated;
        var calledfrom = event.detail.calledfrom;
        if (calledfrom == 'addPropertyPrimary') {
            this.isShowListedLandlord = false;
            this.primaryLandlordName = createdContact.FirstName + ' ' + createdContact.LastName;
            this.selectedPrimaryLandlord.push(createdContact);
            
            
        }
        if (calledfrom == 'addPropertyAdditional') {
            console.log('SearchKyAferAddLLSel==>'+this.searchLandlordString);
            this.isShowListedAddLandlord = false;
            this.searchLandlordString = '';
            this.selectedAdditionalLandLord.push(createdContact);
            this.selectedPrimaryLandlord.push(selectedrec);
            
        }

    }
    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "postcodeErrorAlert":
                this.isPostcodeErrorAlert = false;
                break;
            case "propertyCreatedMsg":
                this.ispropertySuccessMessage = false;

            case "primaryLLErrorMsg":
                this.isSelectPrimaryLLError = false;
                break;
            case "propertyErrorMsg":
                this.isPropertyErrorAlert = false;
                break;
            case "propertyDuplicateMsg":
                this.ispropertyErrorMessage = false;
                break;
        }
    }
}