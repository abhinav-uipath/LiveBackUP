import { LightningElement, wire } from 'lwc';

import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";
import getCareers from '@salesforce/apex/TRS_Careers.getCareers';

export default class TRS_Careers extends LightningElement {
    
    label = {
        trsPortalHomePageLink
    };

    vacancy;
    isVacancyAvailable = false;

    @wire(getCareers)
    wiredStories({ error, data }) {
        if (data) {
            this.isVacancyAvailable = true;
            this.vacancy = data;
        } else if (error) {
            this.data = error;
            // console.log('error')
            // Handle error
        }
    }
}