({

	showSpinner: function(component) {
		component.set("v.showSpinner", true);
	},

	hideSpinner: function(component) {
		component.set("v.showSpinner", false);
	},

	showToastMessage: function(title, message, type) {
        var toastMessage = $A.get("e.force:showToast");

        toastMessage.setParams({
            title: title,
            message: message,
            type: type,
            duration: '500',
            key: 'info_alt',
            mode: 'pester'
        });

        toastMessage.fire();
    },

    goBackToDashboard: function(component) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let homeUrl = baseUrl;
        window.open(homeUrl, '_self');
    }
})