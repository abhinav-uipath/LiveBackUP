({
	// to handle the event to go back to the complaint management page
	handleGoBackToComplaintManagementDashboard: function (component, event, helper) {
		let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let encodeURL = baseUrl;
        window.open(encodeURL, '_self');
	},
	// to cancel the complaint and fire the event to go back to the complaint management page
	handleCancelComplaint: function (component, event, helper) {
		helper.showSpinner(component);

		let caseId = component.get("v.caseId");

		var action = component.get("c.cancelComplaint");

		action.setParams({
			caseId: caseId
		});

		action.setCallback(this, function (response) {
			let state = response.getState();
			let responseValue = response.getReturnValue();

			if (state == 'SUCCESS') {
				if (responseValue) {
					helper.hideSpinner(component);
					helper.showToastMessage('SUCCESS', 'Complaint Canceled Successfully', 'success');

					helper.goBackToDashboard(component);
				} else {
					helper.hideSpinner(component);
					helper.showToastMessage('ERROR!', 'Something went to wrong, failed to cancel complaint', 'error');
				}
			} else {
				helper.hideSpinner(component);
				helper.showToastMessage('ERROR!', 'Something went to wrong, failed to cancel complaint', 'error');
			}
		});

		$A.enqueueAction(action);
	},
})