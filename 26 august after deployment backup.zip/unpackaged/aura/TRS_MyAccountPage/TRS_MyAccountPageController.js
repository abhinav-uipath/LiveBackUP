({
    doInit : function(component, event, helper) {
        try {
            let sURL = decodeURIComponent(window.location.href);
            
            if (window.location.href.indexOf("id=") > -1) {
                let accountId = sURL.split('id=')[1];
                component.set("v.accountId", atob(accountId));
            }
            
            var action = component.get("c.getComplainantInfo");

            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();

                if (state == 'SUCCESS') {
					let user = responseValue.currentLoggedInUser;
                    component.set("v.accountId", user.AccountId);
                    component.set("v.currentUserFirstName", user.FirstName);
                    component.set("v.customLabelMap", responseValue.customLabelMap);
                    component.set("v.showFooterComponent", true);
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showMyAccountComponent", true);
                    component.set("v.showSpinner", false);
                } else {
                    component.set("v.showFooterComponent", true);
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showMyAccountComponent", true);
                    component.set("v.showSpinner", false);
                }
            });

            $A.enqueueAction(action);
            
            
        } catch(error) {
            console.log('error in trs my account page : '+error);
        }
    },
    
    goToHomePage: function(component, event, helper) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let encodeURL = baseUrl;
        window.open(encodeURL, '_self');
    }
})