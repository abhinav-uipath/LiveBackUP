({
	doInit : function(component, event, helper) { 
        console.log("accountId=" +component.get("v.accountId"));
        console.log("depositResponse=" +component.get("v.depositeList"));
        
        var depositResponse = component.get("v.depositeList");
        if(depositResponse.length > 0){
            
            console.log("Result="+depositResponse);
            component.set("v.spinner",false);
            
            var pageSize = component.get("v.pageSize");
            var totalRecordsList = depositResponse;
            var totalLength = totalRecordsList.length;
            component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPage", 0);
            component.set("v.endPage", pageSize - 1);
            var PaginationLst = [];
            for (var i = 0; i < pageSize; i++) {
                if (component.get("v.depositeList").length > i) {
                    PaginationLst.push(depositResponse[i]);
                }
            }
            component.set("v.PaginationList", PaginationLst);
            component.set("v.selectedCount", 0);
            //use Math.ceil() to Round a number upward to its nearest integer
            component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
            
            component.set("v.showDepositList", true);
        }
        
    },
    
    navigation : function(component, event, helper){
        var sObjectList = component.get("v.depositeList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        //var whichBtn = event.getSource().get("v.name");
        //
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
        
    },   
    
    onClickNext:function(component, event, helper) { 
        component.set("v.noRecordSelected", false);
        var selectedCheckBoxes =  component.get("v.selectedCheckBoxes");
        if(selectedCheckBoxes.length == 0){
            component.set("v.noRecordSelected", true);
        }else{
            component.set("v.showDepositList", false);
            component.set("v.showUserEmail",true);
            console.log("showUserEmail="+component.get("v.showUserEmail"));
        }
    },
    
    backtodeposits : function(component, event, helper) {
        component.set("v.isDisableTransferDepositBtn", false);
        component.set("v.isSuccessTransfer", false);
        component.set("v.showUserEmail",false);
        component.set("v.showDepositList", true);
        component.set("v.emailBelongToOtherProfile", false);
        component.set("v.userNotExistError", false);
    },
    
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listOfAllDeposits = component.get("v.depositeList");
        var PaginationList = component.get("v.PaginationList");
        var selectedRecords = component.get("v.selectedCount");
        // play a for loop on all records list 
        let startind = component.get("v.startPage");
        let endind = component.get("v.endPage");
        
        let checkedRecCount = 0;
        for (var i = 0; i < PaginationList.length; i++) {
            if (PaginationList[i].isSelected == true) {
                checkedRecCount++;
            }
        }
        
        if((selectedRecords +(endind-startind+1) - checkedRecCount) > 50){
            alert("you can not select more then 10 record at a time");
            component.find("selectAllId").set("v.value", false);
        }
        else{
            for (var i = 0; i < listOfAllDeposits.length; i++) {
                // check if header checkbox is 'true' then update all checkbox with true and update selected records count
                // else update all records with false and set selectedCount with 0  
                if(i == startind &&  i <= endind){
                    if (selectedHeaderCheck == true) {
                        listOfAllDeposits[i].isSelected = true;
                    } else {
                        listOfAllDeposits[i].isSelected = false;
                    }
                }
                updatedAllRecords.push(listOfAllDeposits[i]);
            }
            // update the checkbox for 'PaginationList' based on header checbox 
            for (var i = 0; i < PaginationList.length; i++) {
                if (selectedHeaderCheck == true) {
                    PaginationList[i].isSelected = true;
                } else {
                    PaginationList[i].isSelected = false;
                }
                updatedPaginationList.push(PaginationList[i]);
            }
            component.set("v.depositeList", updatedAllRecords);
            component.set("v.PaginationList", updatedPaginationList);
            console.log("depositeList after => " + component.get("v.depositeList"));
            var allRecords = component.get("v.depositeList");
            var selectedRecords = [];
            for (var i = 0; i < allRecords.length; i++) {
                if (allRecords[i].isSelected) {
                    console.log('allRecords['+i+'] => ' + JSON.stringify(allRecords[i].depositObj));
                    selectedRecords.push(allRecords[i].depositObj.Id);
                }
            }
            
            component.set("v.selectedCheckBoxes",selectedRecords);
            component.set("v.selectedCount", selectedRecords.length);
            console.log("selectedRecords => " + selectedRecords);
        }
    },
    
    selectedproduct : function(component, event, helper) {
        console.log("selectedproduct");
        var capturedCheckboxName = event.getSource().get("v.name");
        var capturedCheckboxValue = event.getSource().get("v.value");
        console.log("capturedCheckboxName="+capturedCheckboxName);
        console.log("capturedCheckboxValue="+capturedCheckboxValue);
        var depositeList = component.get("v.depositeList");
        var PaginationList = component.get("v.PaginationList");
        var selectedCheckBoxes = component.get("v.selectedCheckBoxes");
        
        var getSelectedNumber = component.get("v.selectedCount");
        if (capturedCheckboxValue == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        console.log("getSelectedNumber="+getSelectedNumber);
        if(getSelectedNumber > 50){
            alert("you can not select more then 10 record at a time");
            component.find("selectAllId").set("v.value", false);
            
            for(var i=0;i<depositeList.length;i++){
                if(depositeList[i].depositObj.Id==capturedCheckboxName){
                    depositeList[i].isSelected = false;
                }
            }
            for(var i=0;i<PaginationList.length;i++){
                if(PaginationList[i].depositObj.Id==capturedCheckboxName){
                    PaginationList[i].isSelected = false;
                }
            }
        }
        else{
            if(capturedCheckboxValue== true){
                selectedCheckBoxes.push(capturedCheckboxName);
                for(var i=0;i<depositeList.length;i++){
                    if(depositeList[i].depositObj.Id==capturedCheckboxName){
                        depositeList[i].isSelected = true;
                    }
                }
                for(var i=0;i<PaginationList.length;i++){
                    if(PaginationList[i].depositObj.Id==capturedCheckboxName){
                        PaginationList[i].isSelected = true;
                    }
                }
            }
            else{
                for(var i=0;i<selectedCheckBoxes.length;i++){
                    if(selectedCheckBoxes[i]==capturedCheckboxName){
                        selectedCheckBoxes.splice(selectedCheckBoxes.indexOf(i), 1);
                    }
                }
                for(var i=0;i<depositeList.length;i++){
                    if(depositeList[i].depositObj.Id==capturedCheckboxName){
                        depositeList[i].isSelected = false;
                    }
                }
                for(var i=0;i<PaginationList.length;i++){
                    if(PaginationList[i].depositObj.Id==capturedCheckboxName){
                        PaginationList[i].isSelected = false;
                    }
                }
            }
        }
        component.set("v.selectedCheckBoxes", selectedCheckBoxes);
        component.set("v.depositeList", depositeList);
        component.set("v.PaginationList", PaginationList);
        component.set("v.selectedCount", selectedCheckBoxes.length);
        console.log("selectedCheckBoxes="+selectedCheckBoxes);
        console.log("length="+selectedCheckBoxes.length);
        
        let checkedRecCount = 0;
        for (var i = 0; i < PaginationList.length; i++) {
            if(PaginationList[i].isSelected == true) {
                checkedRecCount++;
            }
        }
        if(checkedRecCount == PaginationList.length){
            component.find("selectAllId").set("v.value", true);
        }else{
            component.find("selectAllId").set("v.value", false);
        }
    },
    
    checkEmailDetails : function(component, event, helper) {
        component.set("v.emailRequiredError", false);
        component.set("v.emailNotValid", false);
        component.set("v.userNotExistError", false);
        component.set("v.emailBelongToOtherProfile", false);
        component.set("v.showBranchSection",false);
        
        var emailValue = component.get("v.emailValue"); //event.getSource().get("v.value");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
        console.log("emailValue="+emailValue);
        if(emailValue== '' || emailValue== null || emailValue== undefined){
            console.log("email required");
            component.set("v.emailRequiredError", true);
        }
        /*else if(emailValue.match(regExpEmailformat)){
            console.log("email not valid");
            component.set("v.emailNotValid", true);
        }*/
        else{
            console.log("email valid");
            var action = component.get("c.getUserDetails");
            console.log("email valid emailValue =>" + emailValue);
            action.setParams({
                userEmail : emailValue
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log("Line 44 State="+state);
                if (state === "SUCCESS") {
                    var branchWrapper =response.getReturnValue();
                    console.log('branchWrapper => '+JSON.stringify(branchWrapper));
                    if(branchWrapper.length > 0) {
                        var userList = branchWrapper[0].userList;
                        console.log('userList => ' + userList)
                        
                        if(userList.length > 0){
                            component.set("v.showUserSection",true);
                            var radioGroupUserList = [];
                            for(var i=0; i<userList.length; i++) {
                                radioGroupUserList.push(userList[i]);
                                //radioGroupUserList.push({'label': userList[i].Name+ '\t' + userList[i].Username, 'value': userList[i].Id});
                            }
                            component.set("v.radioGroupOfUser",radioGroupUserList);
                        }else{
                            console.log('userNotExistError');
                            component.set("v.userNotExistError", true);
                        }
                        var branchList = []; branchList = branchWrapper[0].branchList;
                        if(branchList.length > 0){
                            console.log('branchList => ' + JSON.stringify(branchList));
                            component.set("v.radioGroupOfBranches",branchList);
                            console.log('radioGroupOfBranches => '+ JSON.stringify(component.get("v.radioGroupOfBranches")));
                        }
                    }else{
                            console.log('userNotExistError');
                            component.set("v.userNotExistError", true);
                        }
                } else {
                    console.log("Line 44 State error="+ JSON.stringify(response.getError()));
                }
            });
            $A.enqueueAction(action);   
        }
        
    },
    
    onselectBranch: function(component, event, helper){
        console.log("onselectBranch");
        var branchId = document.getElementById("selectBranchId").value;
        console.log("branchId => " +branchId);
        component.set("v.selectedBranch", branchId);
        component.set("v.isShowTransferDepositBtn",true);
    },
    onselectUser: function(component, event, helper){
        console.log("onselectUser");
        var userId = event.target.id;
       // var userId = document.getElementById("selectUserId").value;
        console.log("userId => " +userId);
        component.set("v.selectedUser", userId);
        var branchList = component.get("v.radioGroupOfBranches");
        console.log('on Select branchList => ' + JSON.stringify(branchList));
        if(branchList.length > 0) {
            var radioGroupBranchList = [];
            radioGroupBranchList.push({'label' : '--none--', 'value': null});
            for(var i=0; i<branchList.length; i++) {
                if(branchList[i].User == userId){
                    radioGroupBranchList.push({'label' : branchList[i].branchName, 'value': branchList[i].Id});
                }
            }
            component.set("v.radioGroupOfBranches",radioGroupBranchList);
            if(radioGroupBranchList.length > 0){
                component.set("v.showBranchSection",true);
            }else{
                component.set("v.isShowTransferDepositBtn",true);
            }
            console.log('radioGroupOfBranches -> '+ JSON.stringify(component.get("v.radioGroupOfBranches")));
        }else{
            component.set("v.isShowTransferDepositBtn",true);
        }
    },
    
    transferdeposits: function(component, event, helper) {
        console.log('Line 133 -> '+component.get("v.selectedBranch"));
        console.log("transfer deposit botton clicked");
        component.set("v.isDisableTransferDepositBtn" , true);
        
        var depositeList = component.get("v.depositeList");
        var PaginationList = component.get("v.PaginationList");
        
        var emailFieldValue = component.get("v.emailValue");
        var accountId = component.get("v.accountId");
        var branchId = component.get("v.selectedBranch");
        var selectedCheckBoxes = component.get("v.selectedCheckBoxes");
        var selectedUserId = component.get("v.selectedUser");
         console.log("selectedUserId => "+ selectedUserId);
        console.log("accountId => "+ accountId);
        console.log("branchId => "+ branchId);
            
        var action = component.get("c.transferDeposits");
        action.setParams({
            fromUserAccId: accountId,
            depositstobeTransfered: selectedCheckBoxes,
            usertoTransfer: selectedUserId,//emailFieldValue,
            branchId: branchId
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log("State="+state);
            if (state == "SUCCESS") {
                var result =response.getReturnValue();
                console.log("Result="+result);
                if(result == 'Success'){
                    console.log("depositeList before => " + depositeList);
                    //alert.log("Result="+result);
                    for(var i=0;i<depositeList.length;i++){
                        if(depositeList[i].isSelected == true){
                            console.log("depositeList WIP => " + depositeList[i]);
                            depositeList.splice(i, 1);
                            i--;
                        }
                    }
                    console.log("depositeList after => " + depositeList);
                    component.set("v.depositeList", depositeList);
                    
                    if(depositeList.length > 0){
                        
                        var pageSize = component.get("v.pageSize");
                        var totalRecordsList = depositeList;
                        var totalLength = totalRecordsList.length;
                        component.set("v.totalRecordsCount", totalLength);
                        component.set("v.startPage", 0);
                        component.set("v.endPage", pageSize - 1);
                        var PaginationLst = [];
                        for (var i = 0; i < pageSize; i++) {
                            if (component.get("v.depositeList").length > i) {
                                PaginationLst.push(depositeList[i]);
                            }
                        }
                        component.set("v.PaginationList", PaginationLst);
                        component.set("v.selectedCount", 0);
                        //use Math.ceil() to Round a number upward to its nearest integer
                        component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
                    }
                    component.set("v.selectedCheckBoxes", []);
                    component.set("v.emailValue", '');
                    //component.set("v.showUserEmail", false);
                    component.set("v.showBranchSection", false);
                    component.set("v.showUserSection", false);
                    component.set("v.isSuccessTransfer", true);
                }
            }else{
                alert("ERROR => " + response.getError());
                component.set("v.isDisableTransferDepositBtn" , false);
            }
        });
        $A.enqueueAction(action);
    },

    // function automatic called by aura:waiting event  
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for displaying loading spinner 
        
        component.set("v.spinner", true); 
        
    },
    
    // function automatic called by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hiding loading spinner  
        component.set("v.spinner", false); 
    },
    
})