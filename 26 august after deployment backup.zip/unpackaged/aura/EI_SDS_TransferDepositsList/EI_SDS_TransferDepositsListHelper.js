({
    
    
    
    // navigate to next pagination record set
    next: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
        
        let checkedRecCount = 0;
        for (var i = 0; i < Paginationlist.length; i++) {
            if(Paginationlist[i].isSelected == true) {
                checkedRecCount++;
            }
        }
        if(checkedRecCount == Paginationlist.length){
            component.find("selectAllId").set("v.value", true);
        }else{
            component.find("selectAllId").set("v.value", false);
        }
    },
    
    previous: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
        
        let checkedRecCount = 0;
        for (var i = 0; i < Paginationlist.length; i++) {
            if(Paginationlist[i].isSelected == true) {
                checkedRecCount++;
            }
        }
        if(checkedRecCount == Paginationlist.length){
            component.find("selectAllId").set("v.value", true);
        }else{
            component.find("selectAllId").set("v.value", false);
        }
    } 
	/*downloadPdfFile : function(component,event,helper,IdList){

        
        
        this.downloadPdfFile2(IdList,0,helper)
        
            
},
    downloadPdfFile2 : function(IdList,idx,helper){
        window.location ="/apex/EI_DownloadPost?Id="+IdList[idx];
        if(idx < IdList.length - 1){
            
            window.setTimeout(helper.downloadPdfFile2,2000,IdList, idx+1,helper);
        }
    
    },
    showToast : function(title,msg,type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message:msg,
            duration:' 5000',
            key: 'info_alt',
            type: type,
            mode: 'dismissible'
            
        });
        toastEvent.fire();
    },*/
    
})