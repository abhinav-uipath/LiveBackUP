({
	doInit: function (component, event, helper) {
		try {
			let sURL = decodeURIComponent(window.location.href);

			if (window.location.href.indexOf("id=") > -1) {
				let caseId = sURL.split('id=')[1];
				component.set("v.caseId", atob(caseId));
			}

			var action = component.get("c.getComplainantInfo");

			action.setParams({
				caseId: component.get("v.caseId")
			});

			action.setCallback(this, function (response) {
				let state = response.getState();
				let responseValue = response.getReturnValue();

				if (state == 'SUCCESS') {
					let caseRecord = responseValue.caseRecord;
					let user = responseValue.currentLoggedInUser;

					if (user.Profile.Name == 'TRS Tenant') {
						component.set("v.currentUserType", 'Tenant');
					} else if (user.Profile.Name == 'TRS Landlord') {
						component.set("v.currentUserType", 'Landlord');
					}

					component.set("v.accountId", user.AccountId);
					component.set("v.currentUserFirstName", user.FirstName);
					component.set("v.complaintRaisedBy", caseRecord.TRS_Complaint_raised_by__c);

					component.set("v.customLabelMap", responseValue.customLabelMap);

					component.set("v.showHeaderComponent", true);
					component.set("v.showFooterComponent", true);

					helper.setComponentVisibility(component, caseRecord.Case_Statuses__c);
					component.set("v.showSpinner", false);
				} else {
					component.set("v.showHeaderComponent", true);
					component.set("v.showFooterComponent", true);
					component.set("v.showSpinner", false);
				}
			});

			$A.enqueueAction(action);
		} catch (error) {
			//console.log('error in trs summary of complaint page : ' + error);
		}
	},

	handleGoToMyAccountPage: function (component, event, helper) {
		let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
		let accountId = component.get("v.accountId");
		let encodeId = btoa(accountId);
		let encodeURL = baseUrl + "s/my-account?id=" + encodeId;
		window.open(encodeURL, '_self');
	}
})