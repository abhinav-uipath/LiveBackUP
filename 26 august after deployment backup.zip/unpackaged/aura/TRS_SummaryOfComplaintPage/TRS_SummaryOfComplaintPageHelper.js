({
    setCustomLabelValues: function (component, customLabels) {
        if (customLabels.trsSiteHome) {
            component.set("v.TRS_SiteHome", customLabels.trsSiteHome);
        }
        if (customLabels.trsAboutUS) {
            component.set("v.TRS_AboutUS", customLabels.trsAboutUS);
        }
        if (customLabels.trsTenants) {
            component.set("v.TRS_Tenants", customLabels.trsTenants);
        }
        if (customLabels.trsLandlord) {
            component.set("v.TRS_Landlord", customLabels.trsLandlord);
        }
        if (customLabels.trsResourceCentre) {
            component.set("v.TRS_ResourceCentre", customLabels.trsResourceCentre);
        }
    },

    setComponentVisibility: function (component, caseStatus) {
        let userType = component.get("v.currentUserType");
        let complaintRaisedBy = component.get("v.complaintRaisedBy");

        if (complaintRaisedBy == 'Tenant') {
            if (caseStatus == 'Tenant evidence submission in progress') {
                if (userType == 'Tenant') {
                    component.set("v.showComplaintSummaryComponent", true);
                } else if (userType == 'Landlord') {
                    component.set("v.showComplaintSummaryOtherPartyComponent", true);
                }
            }
            if (caseStatus == 'Landlord evidence submission in progress') {
                if (userType == 'Tenant') {
                    component.set("v.showComplaintSummaryReadOnlyComponent", true);
                } else if (userType == 'Landlord') {
                    component.set("v.showComplaintSummaryOtherPartyComponent", true);
                }
            }
            if (caseStatus == 'Case review in progress' || caseStatus == 'Portal closed - adjudicator review in progress' ||
                caseStatus == 'Awaiting adjudicator draft decision' || caseStatus == 'Draft decision issued' ||
                caseStatus == 'Deadline for comments passed - pending final decision' || caseStatus == 'Final decision issued - awaiting tenants acceptance' ||
                caseStatus == 'Final decision issued - awaiting landlords acceptance' || caseStatus == 'Case closed') {
                component.set("v.showComplaintSummaryReadOnlyComponent", true);
            }
        } else if (complaintRaisedBy == 'Landlord') {
            if (caseStatus == 'Landlord evidence submission in progress') {
                if (userType == 'Tenant') {
                    component.set("v.showComplaintSummaryOtherPartyComponent", true);
                } else if (userType == 'Landlord') {
                    component.set("v.showComplaintSummaryComponent", true);
                }
            }
            if (caseStatus == 'Tenant evidence submission in progress') {
                if (userType == 'Tenant') {
                    component.set("v.showComplaintSummaryOtherPartyComponent", true);
                } else if (userType == 'Landlord') {
                    component.set("v.showComplaintSummaryReadOnlyComponent", true);
                }
            }
            if (caseStatus == 'Case review in progress' || caseStatus == 'Portal closed - adjudicator review in progress' ||
                caseStatus == 'Awaiting adjudicator draft decision' || caseStatus == 'Draft decision issued' ||
                caseStatus == 'Deadline for comments passed - pending final decision' || caseStatus == 'Final decision issued - awaiting tenants acceptance' ||
                caseStatus == 'Final decision issued - awaiting landlords acceptance' || caseStatus == 'Case closed') {
                component.set("v.showComplaintSummaryReadOnlyComponent", true);
            }
        }

    }
})