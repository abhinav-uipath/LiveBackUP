({
	doInit : function(component, event, helper) {
        var isChecked = localStorage.getItem('rememberMe');

        if (isChecked === 'true') {
            var username = localStorage.getItem('username');
            var password = localStorage.getItem('password');
            component.find('uname').getElement().value = username;
            component.find('pass').getElement().value = password;
        }

        setTimeout(function(){  
            component.set("v.pageSpinner", false); 
        }, 1000);
	},
    // to submit the login form on clicking of enter button anytime keypress in login form
    handleLoginButtonEnterButtonPress : function(component, event, helper) {
        if (event.keyCode == 13) {
			$A.enqueueAction(component.get("c.handleSubmit"));
		}
    },
    // to submit the reset password form on clicking of the enter button anytime keypress in reset password form
    handleResetPasswordEnterButtonPress : function(component, event, helper) {
        if (event.keyCode == 13) {
			$A.enqueueAction(component.get("c.handleResetPassword"));
		}
    },
    // to show or hide the password inside the password field on click of the eye icon
    handleShowHidePassword : function(component, event, helper) {
        let passwordType = component.get("v.passwordType");
        
        if(passwordType == 'password') {
            component.set("v.passwordType", 'text');
        } else {
            component.set("v.passwordType", 'password');
        }
    },
    // to hide all the error message once thier respective close button is clicked
    handleHideErrMessage : function(component, event, helper) {
        let buttonName = event.target.name;
        
        switch (buttonName) {
            case "userAttempt": 
                component.set("v.showLoginErrorMessage", false);
                break;
            case "userName":
                component.set("v.showUserNameErrorMessage", false);
                break;
            case "password":
                component.set("v.showPasswordErrorMessage", false);
                break;
            case "resetPassword":
                component.set("v.showResetPasswordErrorMessage", false);
                break;
        }
    },
    // to submit the login form with all the details on the click of the submit button or anytime enter key is pressed during input of login form
    handleSubmit : function(component, event, helper) {
        let isValid = true;
        
        let userEmail = component.find('uname').getElement().value;
        let password = component.find('pass').getElement().value;
        
        if(typeof userEmail == 'undefined' || userEmail == '' || userEmail == null) {
            isValid = false;
            component.set("v.showUserNameErrorMessage", true);
        }
        if(typeof password == 'undefined' || password == '' || password == null) {  
            isValid = false;
            component.set("v.showPasswordErrorMessage", true);
        }

        if(isValid) {
            component.set("v.showLoginErrorMessage", false);
            component.set("v.showUserNameErrorMessage", false);
            component.set("v.showPasswordErrorMessage", false);

            let userName = userEmail + '.trs.' + component.get("v.userType");

            var action = component.get("c.checkPortal");
            console.log('action : '+JSON.stringify(action));
            action.setParams({
                userName: userName,
                password: password,
                isEncoded: false
            });

            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();
                console.log('state : '+state);
                console.log('response : '+responseValue);
                if(state == "SUCCESS") {
                    if (responseValue == 'Login Error') {
                        component.set("v.loginErrorMessage", 'Please make sure the Username and Password are correct.');
                        component.set("v.showLoginErrorMessage", true);
                    } else if(responseValue == 'Your login attempt has failed. Make sure the username and password are correct.') {
                        component.set("v.loginErrorMessage", 'Please make sure the Username and Password are correct.');
                        component.set("v.showLoginErrorMessage", true);
                    }

                    let isChecked = component.find('rememberMe').getElement().checked;
                    if (isChecked) {
                        localStorage.setItem('username', userEmail);
                        localStorage.setItem('password', password);
                    }
                } else {
                    component.set("v.loginErrorMessage", 'Unexpected error while login, please try again later');
                    component.set("v.showLoginErrorMessage", true);
                }
            });

            $A.enqueueAction(action);
        }
	},
    // to submit the reset password form with the email address on the click of submit button or anytime enter key is pressed during input of reset password form
    handleResetPassword : function(component, event, helper) {
        let isValid = true;

        let userEmail = component.find('resetPasswordUserName').getElement().value;
        let userType = component.get("v.userType");

        if(typeof userEmail == 'undefined' || userEmail == '' || userEmail == null) {
            isValid = false;
            component.set("v.resetPasswordErrorMessage", 'Please enter Email Address');
            component.set("v.showResetPasswordErrorMessage", true);
        } else {
            let emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

            if(!userEmail.match(emailFormat)) {
                isValid = false;
                component.set("v.resetPasswordErrorMessage", 'Please enter a valid Email Address');
                component.set("v.showResetPasswordErrorMessage", true);
            }
        }

        if(isValid) {
            component.set("v.resetPasswordErrorMessage", '');
            component.set("v.showResetPasswordErrorMessage", false);

            let userName = userEmail + '.trs.' + userType;

            var action = component.get("c.resetPassword");

            action.setParams({
                "userName" : userName
            });

            action.setCallback(this, function(response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();
                console.log('state : '+state+', response : '+responseValue);
                if(state == "SUCCESS") {
                    if(responseValue == 'Reset') {
                        // success reponse
                        isValid = false;
                        window.setTimeout(component.set("v.showResetModal", false), 1000);
                    } else if(responseValue == 'NotFound') {
                        // user not found
                        isValid = false;
                        window.setTimeout(component.set("v.showResetModal", false), 1000);
                    }
                }
            });

            $A.enqueueAction(action);
        }
    },
    // to close the reset password modal on clicking the cross icon on the modal or on clicking the close button on the modal
    handleCloseResetPasswordModal : function() {
        // document.getElementsByClassName('custom-model')[0].style.visibility = 'hidden';
    },
    // to select the user type, whether he/she is a Tenant or Landlord and then can proceed further
    handleUserTypeSelection : function(component, event, helper) {
        let userType = event.getSource().get('v.value');
        
        component.set("v.userType", userType);
        component.set("v.isUserTypeSelected", true);
    },
    // to back to the previous screen to select the type of user Tenant or Landlord
    handleGoBackToUserSelection : function(component, event, helper) {
        component.set("v.loginErrorMessage", '');
        component.set("v.resetPasswordErrorMessage", '');
        component.set("v.showLoginErrorMessage", false);
        component.set("v.showUserNameErrorMessage", false);
        component.set("v.showPasswordErrorMessage", false);
        component.set("v.showResetPasswordErrorMessage", false);

        component.set("v.userType", '');
        component.set("v.isUserTypeSelected", false);
    },
    // to return the focus to its corresponding input field once the pencil icon is pressed
    handleFieldEdit : function(component, event, helper) {
        let buttonName = event.target.name;
        
        switch (buttonName) {
            case "editUsername":
                var userName = component.find('uname').getElement();
                userName.focus();
                break;
            case "editPassword":
                var password = component.find('pass').getElement();
                password.focus();
                break;
        }
	},
})