({
	doInit: function (component, event, helper) {
		try {
			helper.getComplaintDetails(component);
		} catch (error) {
			//console.log('error in trs complaint summary ready only do in it : ' + error);
		}
	},

	handleAccordionSelection: function (component, event, helper) {
		try {
			let accordionId = event.currentTarget.id;
			let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

			for (let i = 0; i < areasOfComplaintWrapperList.length; i++) {
				if (areasOfComplaintWrapperList[i].areaOfComplaintRecord.Complaint_Type__c == accordionId) {
					if (!areasOfComplaintWrapperList[i].isSelected) {
						areasOfComplaintWrapperList[i].isSelected = true;
					} else {
						areasOfComplaintWrapperList[i].isSelected = false;
					}
				}

				if (areasOfComplaintWrapperList[i].isSelected == true && areasOfComplaintWrapperList[i].areaOfComplaintRecord.Complaint_Type__c != accordionId) {
					areasOfComplaintWrapperList[i].isSelected = false;
				}
			}

			component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
		} catch (error) {
			//console.log('error in handleAccordionSelection : ' + error);
		}
	},

	handleCommentDetailsChange: function (component, event, helper) {
		let commentId = event.target.id;
		let comment = event.target.value;
		let caseRecord = component.get("v.caseRecord");

		if (commentId == 'tenantsCommentOnDraftDecision') {
			caseRecord.CS_Additional_Comments_on_Draft_Decision__c = comment;
		} else if (commentId == 'landlordsCommentOnDraftDecision') {
			caseRecord.RD_Additional_Comments_on_Draft_Decision__c = comment;
		}

		component.set("v.caseRecord", caseRecord);
	},

	handleSaveCaseParticipantsComment: function (component, event, helper) {
		component.set("v.showSpinner", true);
		try {
			let isValid = true;
			let caseId = component.get("v.caseId");
			let caseRecord = component.get("v.caseRecord");
			let currentUserType = component.get("v.currentUserType");

			if (currentUserType == 'Tenant') {
				if (caseRecord.CS_Additional_Comments_on_Draft_Decision__c == null || caseRecord.CS_Additional_Comments_on_Draft_Decision__c == '') {
					isValid = false;
					let errorMessageElement = document.getElementById('tenantsCommentId');
					errorMessageElement.classList.remove('displayNone');
            		errorMessageElement.classList.add('displayBlock');
				}
			} else if (currentUserType == 'Landlord') {
				if (caseRecord.RD_Additional_Comments_on_Draft_Decision__c == null || caseRecord.RD_Additional_Comments_on_Draft_Decision__c == '') {
					isValid = false;
					let errorMessageElement = document.getElementById('landlordsComment');
					errorMessageElement.classList.remove('displayNone');
            		errorMessageElement.classList.add('displayBlock');
				}
			}

			if (isValid) {
				var action = component.get("c.saveCaseParticipantsCommentsOnDraftDescision");

				action.setParams({
					caseId: caseId,
					tenantsComment: caseRecord.CS_Additional_Comments_on_Draft_Decision__c,
					landlordsComment: caseRecord.RD_Additional_Comments_on_Draft_Decision__c
				});

				action.setCallback(this, function (response) {
					let state = response.getState();
					let responseValue = response.getReturnValue();

					if (state == 'SUCCESS') {
						helper.hideErrorMessage();
						helper.showToastMessage('SUCCESS', 'Comment Saved Successfully', 'success');
						component.set("v.showSpinner", false);
					} else {
						helper.showToastMessage('ERROR', 'Failed to save the Comment Successfully', 'error');
						component.set("v.showSpinner", false);
					}
				});

				$A.enqueueAction(action);
			} else {
				component.set("v.showSpinner", false);
			}

		} catch (error) {
			//console.log('error : ' + error);
			component.set("v.showSpinner", false);
		}

	},

	handleHideErrorMessages: function (component, event, helper) {
		try {
			let errorMessageId = event.target.name;
			let errorMessageElement = document.getElementById(errorMessageId);
			if (errorMessageElement) {
				document.getElementById(errorMessageId).classList.remove('displayBlock');
				document.getElementById(errorMessageId).classList.add('displayNone');
			}
		} catch (error) {
			//console.log('error in handleHideErrorMessages : ' + error);
		}
	}
})