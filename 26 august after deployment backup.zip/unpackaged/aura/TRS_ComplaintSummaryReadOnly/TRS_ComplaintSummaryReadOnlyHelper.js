({
	getComplaintDetails: function (component) {
		let caseId = component.get("v.caseId");

		var action = component.get("c.getComplaintDetails");

		action.setParams({
			caseId: caseId
		});

		action.setCallback(this, function(response) {
			let state = response.getState();
			let responseValue = response.getReturnValue();

			if(state == 'SUCCESS') {
				component.set("v.currentUserType", responseValue.currentUserType);
				component.set("v.caseRecord", responseValue.caseRecord);
				component.set("v.areasOfComplaintWrapperList", responseValue.areasOfComplaintWrapperList);
				component.set("v.evidenceAttachmentList", responseValue.evidenceAttachmentList);
				
				if(responseValue.caseRecord.Case_Statuses__c == 'Draft decision issued' || responseValue.caseRecord.Case_Statuses__c == 'Deadline for comments passed - pending final decision') {
					component.set("v.adjudicationReportDraftDecisionList", responseValue.draftDecisionList);
					component.set("v.draftDecisionIssuedDate", responseValue.draftDecisionIssuedDate);
					component.set("v.showAdjudicatorDecision", true);
					component.set("v.showDraftDecision", true);
				}
				if(responseValue.caseRecord.Case_Statuses__c == 'Final decision issued - awaiting tenants acceptance' || responseValue.caseRecord.Case_Statuses__c == 'Final decision issued - awaiting landlords acceptance') {
					component.set("v.adjudicationReportFinalDecisionList", responseValue.finalDecisionList);
					component.set("v.finalDecisionIssuedDate", responseValue.finalDecisionIssuedDate);
					component.set("v.showAdjudicatorDecision", true);
					component.set("v.showFinalDecision", true);
					
				}

				if(responseValue.caseRecord.TRS_Complaint_raised_by__c == 'Tenant') {
					if(responseValue.currentUserType == 'Tenant') {
                        component.set("v.showCancelComplaintButton", true);
                    }
					component.set("v.isComplaintRaisedByTenant", true);
				} else {
					component.set("v.isComplaintRaisedByTenant", false);
				}

				if(responseValue.currentUserType == 'Tenant') {
					component.set("v.isLandlordsCommentDisabled", true);
				} else if(responseValue.currentUserType == 'Landlord') {
					component.set("v.isTenantsCommentDisabled", true);
				}

				let respondDate = new Date(responseValue.caseRecord.Respond_Date__c);

                component.set("v.respondDate", respondDate.toISOString());
			}
		});

		$A.enqueueAction(action);
	},

	handleGoToMyAccountPage: function(component, event, helper) {
        let accountId = component.get("v.accountId");
		let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let encodeId = btoa(accountId);
        let encodeURL = baseUrl;
        window.open(encodeURL, '_blank');
    },

	hideErrorMessage: function () {
		try {
			let userType = component.get("v.currentUserType");

			if (userType == 'Tenant') {
				let errorMessageElementTenant = document.getElementById('tenantsCommentId');
				errorMessageElementTenant.classList.remove('displayBlock');
				errorMessageElementTenant.classList.add('displayNone');
			} else if (userType == 'Landlord') {
				let errorMessageElementLandlord = document.getElementById('landlordsComment');
				errorMessageElementLandlord.classList.remove('displayBlock');
				errorMessageElementLandlord.classList.add('displayNone');
			}
		} catch (error) {
			//console.log('error : ' + error);
		}
	}, 

	showToastMessage: function(title, message, type) {
        var toastEvent = $A.get("e.force:showToast");

        toastEvent.setParams({
            title: title,
            message: message,
            type: type,
            duration: '500',
            key: 'info_alt',
            mode: 'pester'
        });

        toastEvent.fire();
    },
})