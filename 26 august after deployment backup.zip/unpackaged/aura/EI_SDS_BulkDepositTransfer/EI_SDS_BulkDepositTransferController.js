({
    doInit : function(component, event, helper) {
        let currentURL = window.location.href;
        let AccessCode = currentURL.split("id=")[1];
        if(AccessCode =='SuccessMsg')
        {
            component.set("v.showSuccessMsg",true);
            let usrls = currentURL.split("id=")[0]+'id=1****3';
            history.pushState(null, '',usrls);
        }
        else
        {
            component.set("v.showSuccessMsg",false);
        }        
        
        // get branchId
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
      //   alert(urlParams);
        var myName;
        var branchId = urlParams.get('branchId');
         if(branchId != null){ 
                const branchIdList = atob(urlParams.get('branchId'));
         		const myArray = branchIdList.split("&");
            //    alert(myArray.length);
             if(myArray.length >2){
              myName = myArray[0]+'&'+myArray[1];
               branchId = myArray[2];
              }else{
                  
                myName = myArray[0];
                  branchId = myArray[1];
               } 
            } 
    
           component.set("v.branchId",branchId);  
    helper.onLoadHelper(component, event, helper,branchId);
    },
    /* Code for TGK-60 Start */
    clearSearch:function(component, event, helper) {
     //   console.log('line98'+component.get("v.searchValue"));
        component.set("v.searchValue", '');
        var searchKey = '';
        helper.clearSearch(component) ;
        console.log('End of clearSearch');
    },
 /* Code for TGK-60 End */
   
           /* Search Code*/
    handleSearchNew : function(component, event, helper) { /* Code Modified for TGK-60 */
        var searchKey = document.getElementById("searchValue").value.trim();  
        component.set('v.searchValue', searchKey);
   //     console.log('@@ '+searchKey);
        helper.searchRecords(component,searchKey) ;
        
    }, 
   
    transferrabledeposits : function(component, event, helper) {
        component.set("v.transfermultipledeposit",true);
        component.set("v.transferdepositonebranch", false); 
        component.set("v.showDeposits", false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.useremailsection",false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.clickedyes",false);
        component.set("v.showAwatingTransfered",false);
        component.set("v.transferthedeposits",false);
        component.set("v.transfertoaglld",false);
        component.set("v.viewtransferred",false);
          $A.get('e.force:refreshView').fire();
    },
    viewtransffered : function(component, event, helper) {
        component.set("v.transfermultipledeposit",false);
        component.set("v.transferdepositonebranch", false); 
        component.set("v.showDeposits",false);  
        component.set("v.transferthedeposits",false);
        component.set("v.clickedyes",false);
        component.set("v.useremailsection",false);
        component.set("v.showAwatingTransfered",false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.transfertoaglld",false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.viewtransferred",true);
    },
    transfertoonebranch : function(component,event,helper){
        component.set("v.transfermultipledeposit",false);
        component.set("v.transferthedeposits",false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.showDeposits",false);  
        component.set("v.viewtransffered",false);  
        component.set("v.clickedyes",false);
        component.set("v.transfertoaglld",false);
        
        let currentURL = window.location.href;
        let AccessCode = currentURL.split("id=")[1];
        if(AccessCode =='SuccessMsg')
        {
            component.set("v.showSuccessMsg",true);
            let usrls = currentURL.split("id=")[0]+'id=1****3';
            history.pushState(null, '',usrls);
        }
        else
        {
            component.set("v.showSuccessMsg",false);
        }       
        const queryString = window.location.search;
        console.log('Print queryString '+queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('Print urlParams '+urlParams);
        const branchId = component.get("v.branchId");
        console.log("Line109"+branchId);

      var action1 = component.get("c.getdepositbranchforBranchtransfer");
        action1.setParams({
            branchId: branchId }); 
        action1.setCallback(this,function(a) {
            var allValuesbranch = a.getReturnValue();
            var state = a.getState();
            if (state == "SUCCESS") {
                console.log("118");
                console.log("Length=>"+allValuesbranch.length);
                //// if(allValues.length >= 0){
                console.log("120");
                component.set("v.listOfAllDeposits", allValuesbranch);
                var pageSize = component.get("v.pageSize");
                var totalRecordsListbranch = allValuesbranch;
                var totalLengthofbranch = totalRecordsListbranch.length ;
                component.set("v.totalRecordsCountofbranches", totalLengthofbranch);
                component.set("v.startPage",0);
                component.set("v.endPage",pageSize-1);
                console.log("129");
                var PaginationList = [];
                for(var i=0; i < pageSize; i++){
                    if(component.get("v.listOfAllDeposits").length > i){
                        PaginationList.push(allValuesbranch[i]);    
                    } 
                }
                                    
                component.set('v.PaginationList1', PaginationList);
                component.set("v.selectedCountofBranches" , 0);
                component.set("v.totalRecordsCountofbranches", Math.ceil(totalLengthofbranch / pageSize));  
                console.log("138");
                
                component.set("v.transferdepositonebranch",true);                    
                //    }
                /*  else{
                    component.set("v.bNoRecordsFound" , true);
                } */
                
          }               
            
            else{
                console.log("line122");
            }
        });
        $A.enqueueAction(action1);    
        
         var action = component.get("c.getdepositforBranchtransfer");
        action.setParams({
            branchId: branchId }); 
        
        action.setCallback(this,function(a) {
            var allValues = a.getReturnValue();
            var state = a.getState();
            if (state == "SUCCESS") {
                console.log("118");
                console.log("Length=>"+allValues.length);
                //// if(allValues.length >= 0){
                console.log("120");
                component.set("v.listOfAllDeposits", allValues);
                var pageSize = component.get("v.pageSize");
                var totalRecordsList = allValues;
                var totalLength = totalRecordsList.length ;
                component.set("v.totalRecordsCount", totalLength);
                component.set("v.startPage",0);
                component.set("v.endPage",pageSize-1);
                console.log("129");
                var PaginationLst = [];
                for(var i=0; i < pageSize; i++){
                    if(component.get("v.listOfAllDeposits").length > i){
                        PaginationLst.push(allValues[i]);    
                    } 
                }
                component.set('v.PaginationList', PaginationLst);
                component.set("v.selectedCount" , 0);
                component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));  
                console.log("138");
                
                component.set("v.transferdepositonebranch",true);                    
                //    }
                /*  else{
                    component.set("v.bNoRecordsFound" , true);
                } */
                
            }               
            
            else{
                console.log("line122");
            }
        });
        $A.enqueueAction(action);    

    },
    
    yesclicked : function(component,event,helper){
        let currentURL = window.location.href;
        let AccessCode = currentURL.split("id=")[1];
        if(AccessCode =='SuccessMsg')
        {
            component.set("v.showSuccessMsg",true);
            let usrls = currentURL.split("id=")[0]+'id=1****3';
            history.pushState(null, '',usrls);
        }
        else
        {
            component.set("v.showSuccessMsg",false);
        }
        const queryString = window.location.search;
        console.log('Print queryString '+queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('Print urlParams '+urlParams);
        const branchId = component.get("v.branchId");
        console.log("Line109"+branchId);

        let selectedData = component.get("v.PaginationList2");
        console.log("selectedData=>"+JSON.stringify(selectedData));
        var pageSize = component.get("v.pageSize");
        var PaginationLst;
        for(var i=0; i < pageSize; i++){
            if(selectedData.length > i){
                PaginationLst = selectedData[i].Id;    
             //   console.log('Line 266'+JSON.stringify(PaginationLst));
            } 
        }
        console.log('Log at 269 '+JSON.stringify(PaginationLst));
         var PaginationLstDep = [];
         let selectedDepId = component.get("v.PaginationList");
        console.log('@@ '+JSON.stringify(selectedDepId));
         for(var i=0; i < pageSize; i++){
            if(selectedDepId.length > i){
                console.log('ii '+i);
                PaginationLstDep.push(selectedDepId[i].objDeposit.Id);    
                console.log(selectedDepId[i].objDeposit.Id+' --Line 266-- '+JSON.stringify(PaginationLstDep));
            } 
        }
                console.log('Log at 2766666--- '+JSON.stringify(PaginationLstDep));
        var action = component.get("c.gettransfertobranch");
        console.log("Line141");
        action.setParams({
            selectedDepositIds: PaginationLstDep,
            branchId: PaginationLst
        });
        console.log('Params Set');
        action.setCallback(this,function(a) {
            var allValues = a.getReturnValue();
            var state = a.getState();
            console.log('Params allValues '+allValues);
              console.log('state allValues '+state);
            if (state == "SUCCESS") {
                if(allValues=='deposit transferred'){
                    console.log("line465");
                    component.set("v.clickedyes",true);
                    component.set("v.transferthedeposits",false);   
                    console.log("line467");
                }else{
                    console.log("line469");
                                     
                }
            }
        });
        
        $A.enqueueAction(action);    
       
    },
    
   
    noclicked : function(component,event,helper){
         $A.get('e.force:refreshView').fire();
       /* component.find("navServiceMyProperty").navigate({
            type: "comm__namedPage",
            attributes: {
                pageName: "bulkactions"
            },
            state: {  }
            
        })*/
    },
    
    transferMultipleDepositSubTabs : function(component, event, helper) {
        component.set("v.transfermultipledeposit",false);
        component.set("v.showDeposits", false);
        component.set("v.clickedyes",false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.transferthedeposits",false);
        component.set("v.viewtransferred",false);
        component.set("v.passSuccessMessage", false);
        
        //$(".org-detail-list").slideToggle();
        if(component.get("v.showSubTabs")) {
            var regMultDepTab =  component.find("leftSideSubTabs");
            $A.util.removeClass(regMultDepTab, "openSubTab");
            $A.util.addClass(regMultDepTab, "closeSubTab");
            component.set("v.showSubTabs", false);
        } else {
            var regMultDepTab =  component.find("leftSideSubTabs");
            $A.util.removeClass(regMultDepTab, "closeSubTab");
            $A.util.addClass(regMultDepTab, "openSubTab");
            component.set("v.showSubTabs", true);
        }
    },
    
    transfertoaglld : function(component,event,helper){
        component.set("v.transfermultipledeposit",false);
        component.set("v.showDeposits", true);
        component.set("v.clickedyes",false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.transferthedeposits",false);
        component.set("v.viewtransferred",false);
        component.set("v.passSuccessMessage", false);
        
    },
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.listOfAllDeposits");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        //var whichBtn = event.getSource().get("v.name");
        //
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    
        //new added
      navigationselect: function(component, event, helper) {
        var sObjectList = component.get("v.selectedDepositIds");
        var endselect = component.get("v.endPageselecteddeposit");
        var startselect = component.get("v.startPageselecteddeposit");
        var pageSizeselect = component.get("v.pageSizeselecteddepst");

        if (event.target.id == "nextIdselect") {
            component.set("v.currentPageselect", component.get("v.currentPageselect") + 1);
            helper.nextselect(component, event, sObjectList, endselect, startselect, pageSizeselect);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousIdselect") {
            component.set("v.currentPageselect", component.get("v.currentPageselect") - 1);
            helper.previousselect(component, event, sObjectList, endselect, startselect, pageSizeselect);
        }
    },
    
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        console.log('Selected Count -- '+getSelectedNumber);
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
        
        var selectedDeposits = [];       
        var checkvalue = component.find("checkDeposit");
        console.log('checkvalue => ' + checkvalue)
        if(!Array.isArray(checkvalue)){
            if (checkvalue.get("v.value")) {
                selectedDeposits.push(checkvalue.get("v.text"));
            }
        }else{
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                    selectedDeposits.push(checkvalue[i].get("v.text"));
                }
            }
        }
        component.set("v.selectedDepositIds",selectedDeposits);
        console.log("Print189 "+selectedDeposits.length);
        var records = component.get("v.selectedDepositIds");
        var totalDepositAmt=0.0;
        for ( var i = 0; i < records.length; i++ ) {
            totalDepositAmt += records.Actual_Protected_Amount__c;
            console.log("Print193"+JSON.stringify(records[i]));
            //alert(records[i].objDeposit.Id);  
            console.log("totalDepositAmt "+totalDepositAmt);
        }
    },
    
     checkboxSelectonBranch: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
         console.log('GetselectedData = > '+JSON.stringify(selectedRec));
        var getSelectedNumber = component.get("v.selectedCountofBranches");
         console.log('getSelectedNumber = > '+JSON.stringify(getSelectedNumber));
        if (selectedRec == true) {
            getSelectedNumber++;
            console.log('getSelectedNumberadd-'+getSelectedNumber);
        } else {
            getSelectedNumber--;
            console.log('getSelectedNumbersub-'+getSelectedNumber);
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCountofBranches", getSelectedNumber);
         console.log('getSelectedNumber352'+getSelectedNumber);
        if (getSelectedNumber == component.get("v.totalRecordsCountofbranches")) {
            component.find("selectAllId").set("v.value", true);
        }
        console.log('422 Selected => '+selectedRec);
        var selectedDeposits = [];
        var checkvalue = component.find("checkDepositofbranch");
        console.log('checkvalue => ' + checkvalue)
        if(!Array.isArray(checkvalue)){
            console.log('Inside 427 => '+checkvalue.get("v.value"));
            if (checkvalue.get("v.value")) {
                selectedDeposits.push(checkvalue.get("v.text"));
            }
        }else{
            console.log('Inside 432 => '+checkvalue.length);
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                    selectedDeposits.push(checkvalue[i].get("v.text"));
                }
            }
        }
        console.log("Print450 "+selectedDeposits.length);
         

         
        if(selectedDeposits.length > 1)
         {
             selectedDeposits= selectedDeposits.slice(1);
             var selectedlength = selectedDeposits.length;
             component.set('v.selectedlength', selectedlength);

             var toastEvent = $A.get("e.force:showToast");
             toastEvent.setParams({
                 title : 'Error',
                 message: 'Please select only one branch',
                 duration:' 5000',
                 key: 'info_alt',
                 type: 'info',
                 mode: 'dismissible'
             });
             toastEvent.fire();

         } 
         console.log("Print451 After=>"+JSON.stringify(selectedDeposits));
         console.log("Print451 length=>"+(selectedDeposits.length));
         component.set("v.PaginationList2",selectedDeposits);

    },

    selectAllCheckbox: function(component, event, helper) {
    var selectedHeaderCheck = event.getSource().get("v.value");
    var updatedAllRecords = [];
    var updatedPaginationList = [];
    var listOfAllDeposits = component.get("v.listOfAllDeposits");
    console.log('List of Selected Deposits'+JSON.stringify(listOfAllDeposits));
    var PaginationList = component.get("v.PaginationList");
    // play a for loop on all records list 
    for (var i = 0; i < listOfAllDeposits.length; i++) {
        // check if header checkbox is 'true' then update all checkbox with true and update selected records count
        // else update all records with false and set selectedCount with 0  
        if (selectedHeaderCheck == true) {
            listOfAllDeposits[i].isChecked = true;
            component.set("v.selectedCount", listOfAllDeposits.length);
        } else {
            listOfAllDeposits[i].isChecked = false;
            component.set("v.selectedCount", 0);
        }
        updatedAllRecords.push(listOfAllDeposits[i]);
    }
    // update the checkbox for 'PaginationList' based on header checbox 
    for (var i = 0; i < PaginationList.length; i++) {
        if (selectedHeaderCheck == true) {
            PaginationList[i].isChecked = true;
        } else {
            PaginationList[i].isChecked = false;
        }
        updatedPaginationList.push(PaginationList[i]);
    }
    component.set("v.listOfAllDeposits", updatedAllRecords);
    component.set("v.PaginationList", updatedPaginationList);
    
        var allRecords = component.get("v.listOfAllDeposits");
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].objDeposit);
            }
        }
        component.set("v.selectedDepositIds",selectedRecords);
    },
    
    regMultipleDepositSubTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "registermultipledeposits"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "registermultipledeposits"
                },
                state: {  }
            }); 
        }
    },
    
    downloadMultiplecertificatesTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadbulkcertificates"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadbulkcertificates"
                },
                state: {  }
            }); 
        }
    },
    
    downloadPIFormsTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadpiforms"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadpiforms"
                },
                state: {  }
            }); 
        }
    },
        //code added for TGK-64 start
     repaymenteposits : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "repaybulkdeposits"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceMyProperty").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "repaybulkdeposits"
                },
                state: {  }
            }); 
        }
    },
    //code added for TGK-64 End
    
    hideBootstrapErrors: function(component, event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "nodeposit":
                component.set("v.nodepositSelected", false);
                break;
            case "singleBlank":
                component.set("v.singleBlankValue", false);
                break;
            case "pSuccessMessage":
                component.set("v.showSuccessMsg", false);
                break;
            case "nobranch":    
                component.set("v.nobranchSelected", false);
                break;
            case "validemailcheck":    
                component.set("v.emailNotValid", false);
                break;
        }
    },
    
    submitTransfers: function(component, event, helper) {
        if(component.get("v.selectedCount")==0 || component.get("v.selectedCount")==undefined)
        {
            component.set("v.nodepositSelected", true);
            
        }
        else{
            component.set("v.nodepositSelected", false);
            component.set("v.showDeposits",false); 
            component.set("v.transferthedeposits",false);
            component.set("v.transfertoaglld",false);
            component.set("v.clickedyes",false);
            component.set("v.useremailsection",true);
            component.set("v.transferdepositonebranch", false); 
        }
    },
    
    submitmultipleTransfers : function(component,event,helper){
        if(component.get("v.selectedCount")==0 || component.get("v.selectedCount")==undefined)
        {
            component.set("v.nodepositSelected", true);
            
        }
        else{
            console.log('Inside transfer to branch');
            let selectedData = component.get("v.PaginationList2");
            console.log("selectedData=>"+JSON.stringify(selectedData));
            component.set("v.nodepositSelected", false);
            component.set("v.showDeposits",false);
            component.set("v.clickedyes",false);
            component.set("v.transfertoaglld",false);
            component.set("v.useremailsection",false);
            component.set("v.transferdepositonebranch", false); 
            var pageSize = component.get("v.pageSize");
            var PaginationLst = [];
            for(var i=0; i < pageSize; i++){
                if(selectedData.length > i){
                    PaginationLst.push(selectedData[i]);    
                    console.log('Line 667'+JSON.stringify(PaginationLst));
                } 
            }
            console.log('Log at 674 '+JSON.stringify(selectedData));
            component.set('v.PaginationList2', PaginationLst);
            console.log('PaginationList2 673 '+JSON.stringify(PaginationLst));
            component.set("v.transferthedeposits",true);

        }
    },
    
    backtodeposits : function(component, event, helper) {
        component.set("v.showDeposits",true);
        component.set("v.useremailsection",false);  
        component.set("v.clickedyes",false);
        component.set("v.transfertoaglld",false);
        component.set("v.transferthedeposits",false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.transferdepositonebranch",false);
    },
    
    
    //Process the selected deposits
    transferdeposits: function(component, event, helper) {
        helper.transferdeposits1(component,event,helper);
    },
    
    confirmTransfer:function(component, event, helper) 
    {   
         var selectedData = component.get("v.selectedDepositIds");
        var selectedDataID= [];
        for(var i =0;i<selectedData.length;i++){
            selectedDataID.push(selectedData[i].Id);
        }
        //alert('selectedDataID '+selectedDataID);
        // let emailValue = component.get("v.emailValue");
        var action = component.get("c.transferDeposit");
               component.set("v.disableBtn",true);

        console.log("Line141 "+component.get("v.emailValue"));
        //   console.log("Line141 "+ JSON.stringify(component.get("v.selectedDepositIds")));
        action.setParams({
            emailValue: component.get("v.emailValue"),
            selectedDepositID: selectedDataID
        });
        action.setCallback(this,function(a) {
            var allValues = a.getReturnValue();
            var state = a.getState();
            
            if (state == "SUCCESS") {
                if(allValues=='deposit transferred'){
                    console.log("line465");
                    component.set("v.showSuccessMsg",true);
                    component.set("v.ProceedFurther",false);
                    console.log("line467");
                    component.set("v.disableBtn",true);
                }
                else if(allValues=='Batch Processed'){
                    alert('batch true');
                    component.set("v.showSuccessMsg",true);
                    component.set("v.ProceedFurther",false);
                    console.log("line467");
                    component.set("v.disableBtn",true);
                }
                else{
                    console.log("line469");
                    component.set("v.showErrorMsg",true);
                     component.set("v.disableBtn",false);
                }
            }else{
                 component.set("v.disableBtn",false);
            }
        });

        $A.enqueueAction(action);

    },
    
    transferAwatingApproval:function(component, event, helper)
    {
        component.set("v.showDeposits",false);  
        component.set("v.useremailsection",false);
        component.set("v.viewtransferred",false);
        component.set("v.transfertoaglld",false);
        component.set("v.selectedrowsdeposit",false);
        component.set("v.clickedyes" , false);
        component.set("v.bNoRecordsFound" , false);
        component.set("v.transfermultipledeposit",false);
        component.set("v.showAwatingTransfered",true);
        
        
    }

    
})