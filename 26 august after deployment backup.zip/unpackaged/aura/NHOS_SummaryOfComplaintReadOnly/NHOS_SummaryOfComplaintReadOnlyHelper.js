({
	helperExpandDetailSection: function (component, event, helper) 
    {
      
		component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.SellingDetailedSection", true);
		} 
       // else 
        if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.LegalInspectionCompletionDetailedSection", true);
		} 
       // else 
        if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.AfterSalesDetailedSection", true);
		} 
        // else 
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.OtherDetailedSection", true);
		}
        // else 
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.WarrantyProviderDetailedSection", true);
		} 
        
	},
    
    helperReviewExpandDetailSection: function (component, event, helper) 
    {
      
		component.set("v.reviewSellingDetailedSection", false);
		component.set("v.reviewLegalInspectionCompletionDetailedSection", false);
		component.set("v.reviewAfterSalesDetailedSection", false);
		component.set("v.reviewWarrantyProviderDetailedSection", false);
		component.set("v.reviewOtherDetailedSection", false);
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.reviewSellingDetailedSection", true);
		} 
       // else 
        if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.reviewLegalInspectionCompletionDetailedSection", true);
		} 
       // else 
        if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.reviewAfterSalesDetailedSection", true);
		} 
        // else 
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.reviewOtherDetailedSection", true);
		}
        // else 
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.reviewWarrantyProviderDetailedSection", true);
		} 
        
	},
    
    helperAccordionEvent: function (component, event, helper, Selling, LegalInspectionCompletion, AfterSales, WarrantyProvider, Other) 
    {
		component.set("v.SellingDetailedSection", Selling);
		component.set("v.LegalInspectionCompletionDetailedSection", LegalInspectionCompletion);
		component.set("v.AfterSalesDetailedSection", AfterSales);
		component.set("v.WarrantyProviderDetailedSection", WarrantyProvider);
		component.set("v.OtherDetailedSection", Other);
        
		//var offsets = document.getElementById("DetailedSection");
		//window.scroll({top: offsets.offsetTop + 150,behavior: 'smooth'});
	},
    helperAccordionEventReview: function (component, event, helper, Selling, LegalInspectionCompletion, AfterSales, WarrantyProvider, Other) 
    {
		component.set("v.reviewSellingDetailedSection", Selling);
		component.set("v.reviewLegalInspectionCompletionDetailedSection", LegalInspectionCompletion);
		component.set("v.reviewAfterSalesDetailedSection", AfterSales);
		component.set("v.reviewWarrantyProviderDetailedSection", WarrantyProvider);
		component.set("v.reviewOtherDetailedSection", Other);
        
		//var offsets = document.getElementById("ReviewSection");
		//window.scroll({top: offsets.offsetTop + 500,behavior: 'smooth'});
	},
})