({
	handleSummaryOfComplaint: function (component, event, helper) 
    {
                
                   helper.helperExpandDetailSection(component, event, helper) ;
		            document.body.scrollTop = 0;
					document.documentElement.scrollTop = 0;
					component.set("v.summarySection", false);
					component.set("v.detailedSection", true);
					component.set("v.reviewSection", false);
                    component.set("v.thankYouSection", false);
		
	},
    
    
    accordionSellingDetailedSection: function (component, event, helper) 
    {
		helper.helperAccordionEvent(component, event, helper, !component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
	    $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 25 },500);
    },
    
    
	accordionLegalInspectionCompletionDetailedSection: function (component, event, helper) 
    {
		helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), !component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
         $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
		
	},
    
    
	accordionAfterSalesDetailedSection: function (component, event, helper) 
    {
	    helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), !component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
	},
    
    
	accordionWarrantyProviderDetailedSection: function (component, event, helper) 
    {
		        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), !component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
		},
    
    
	accordionOtherDetailedSection: function (component, event, helper) 
    {
	helper.helperAccordionEvent(component, event, helper, component.get("v.DetailWarrantyProvider1"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), !component.get("v.OtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
		},
    
    
    goBackFromDetailedSubmission: function (component, event, helper) 
    {
        window.scroll({top: 0,behavior: 'smooth'});
		component.set("v.summarySection", true);
		component.set("v.detailedSection", false);
		component.set("v.reviewSection", false);
        component.set("v.thankYouSection", false);
    },
    
    saveAndContinueFromDetailedSubmission: function (component, event, helper) 
    {
		component.set("v.summarySection", false);
                        component.set("v.detailedSection", false);
                        component.set("v.reviewSection", true);
                        component.set("v.thankYouSection", false);
                        
                        component.set("v.reviewSubmitCount",0);
                        component.set("v.reviewSaveWarningMsg",false);
                        component.set("v.reviewSubmitWarningMsg",false);
                        component.set("v.isActiveReviewContinueBtn",false);
                        window.scroll({top: 0,behavior: 'smooth'});
        helper.helperReviewExpandDetailSection(component, event, helper) ;
    }  ,  
    
    
    
    accordionSellingReviewSection: function (component, event, helper) 
    {
		helper.helperAccordionEventReview(component, event, helper, !component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
	    $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 25 },500);
    },
    
    
	accordionLegalInspectionCompletionReviewSection: function (component, event, helper) 
    {
	 helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), !component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
       },
    
    
	accordionAfterSalesReviewSection: function (component, event, helper) 
    {
	 helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), !component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
        },
    
    
	accordionWarrantyProviderReviewSection: function (component, event, helper) 
    {
	helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), !component.get("v.reviewWarrantyProviderDetailedSection"), component.get("v.reviewOtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
        },
    
    
	accordionOtherReviewSection: function (component, event, helper) 
    {
	    helper.helperAccordionEventReview(component, event, helper, component.get("v.reviewSellingDetailedSection"), component.get("v.reviewLegalInspectionCompletionDetailedSection"), component.get("v.reviewAfterSalesDetailedSection"), component.get("v.reviewWarrantyProviderDetailedSection"), !component.get("v.reviewOtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
        },
    
    goBackFromReviewSubmission: function (component, event, helper) 
    {
       helper.helperExpandDetailSection(component, event, helper);
        
		window.scroll({top: 0,behavior: 'smooth'});
		component.set("v.summarySection", false);
		component.set("v.detailedSection", true);
		component.set("v.reviewSection", false);
        component.set("v.thankYouSection", false); 
    },
    goToDashboard: function (component, event, helper) 
    {
        let redirectURL = $A.get("$Label.c.NHOS_CommunityName");
        window.location.replace(redirectURL); 
    }
})