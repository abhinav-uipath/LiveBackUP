({
	doInit : function(component, event, helper) {
        var sURL = decodeURIComponent(window.location.href);
        if (window.location.href.indexOf("id=") > -1) 
        {
            var contacctId = sURL.split('id=')[1];
            component.set("v.contacctId", atob(contacctId));
        }
        helper.contactDetails(component,event,helper); 
	},
    
    clickContactDetails: function(component, event, helper) {
     $("html, body").animate(
      { scrollTop: $("#account-detail").offset().top - 30 },
      1000
    );
     },
   
    
    clickPasswordChange: function(component, event, helper) {
     $("html, body").animate(
      { scrollTop: $("#Passwordchange").offset().top - 100 },
      1000
    );
     },
    
    clickAdditionalUsersMenu: function(component, event, helper) {
     $("html, body").animate(
      { scrollTop: $("#additional-user").offset().top - 100 },
      1000
    );
     }, 
    
     parentPress: function (component, event, helper) {
        var objChild = component.find("compB");
        component.set("v.orgAdd.Country__c", objChild.get("v.Country"));
        component.set("v.orgAdd.Postcode__c", objChild.get("v.PostCode"));
        component.set("v.orgAdd.Town_City__c", objChild.get("v.Town"));
        component.set("v.orgAdd.County__c", objChild.get("v.County"));
         component.set("v.orgAdd.Base_County__c", objChild.get("v.BaseCountry"));
         component.set("v.orgAdd.House_No__c", objChild.get("v.houseNo"));
        var StreetAddress;
        if (objChild.get("v.AddressLine1") != "undefined " && objChild.get("v.AddressLine1") != undefined 
             && objChild.get("v.Street") != "undefined " && objChild.get("v.Street") != undefined) {
            StreetAddress =
                objChild.get("v.AddressLine1") + "\n " + objChild.get("v.Street");
        }
         else if (objChild.get("v.AddressLine1") != "undefined " && objChild.get("v.AddressLine1") != undefined ) {
            StreetAddress =
                objChild.get("v.AddressLine1") ;
        }
         else if(objChild.get("v.Street") != "undefined " && objChild.get("v.Street") != undefined){
            StreetAddress = objChild.get("v.Street");
        }
        component.set("v.orgAdd.Address__c", StreetAddress);
        component.set("v.editOrgDetails", true); 
   
  },
    
    closeEditAdd: function(component, event, helper) {
        component.set("v.editAddress",false);
    },
     editAdd: function(component, event, helper) {
        component.set("v.editAddress",true);
    },
    
    clearPhoneNumber: function(component, event) {
        var dropdown_Name = event.target.name;
        console.log('%%%%%%%%',dropdown_Name);
        switch (dropdown_Name) {
            case "customerPhoneCode":
                 document.getElementById("sf-Telephone").value = "";
                break;
                
            case "bCompanyPhoneCode":
                 document.getElementById("bCompanyPhone").value = "";
                break; 
                
           case "phoneCodeId":
                 document.getElementById("sf-Telephone").value = "";
                break; 
                
           case "sf-newpopup-phoneCode1":
                 document.getElementById("sf-newpopup-Mobile").value = "";
                break;   
                
           case "sf-editpopup-phoneCode1":
                 document.getElementById("sf-editPopup-Mobile").value = "";
                break;     
        }
    },
    
   hideBootstrapErrors: function(component, event) {
    var button_Name = event.target.name;
    switch (button_Name) {
       case "passSuccessMessage":
       	 	component.set("v.passwordSuccessMsg", false);
       break;
       case "passErrorMessage":
        	component.set("v.passwordErrorMsg", false);
       break;
       case "passwordFieldMandatoryMsg":
        	component.set("v.passwordFieldMandatoryMsg", false);
       break;  
       case "newPasswordFieldMandatoryMsg":
        	component.set("v.newPasswordFieldMandatoryMsg", false);
       break;     
        case "confirmPasswordFieldMandatoryMsg":
        	component.set("v.confirmPasswordFieldMandatoryMsg", false);
       break;     
       case "SuccessMessage":
        component.set("v.successMsg", false);
        break;
       case "ErrorMessage":
        component.set("v.errorMsg", false);
        break;
      case "title":
        component.set("v.titleError", false);
        break;
      case "firstName":
        component.set("v.firstNameError", false);
        break;
      case "surName":
        component.set("v.SurNameError", false);
        break;
      case "emailOfUser":
        component.set("v.EmailError", false);
        break;
      case "mobileNumber":
        component.set("v.mobileError", false);
        break;
      case "companyPhoneNumber":
        component.set("v.companyPhoneError", false);
        break;      
      case "landlineNumber":
        component.set("v.landlineError", false);
        break;
      case "marketingPreference":
        component.set("v.marketingError", false);
        break;
      case "newsLetter":
        component.set("v.newsLetterError", false);
        break;
      case "generalEmail":
        component.set("v.grnlEmailError", false);
        break;
      case "disputeEmail":
        component.set("v.disputeEmailError", false);
        break;
      case "financeEmail":
        component.set("v.financeEmailError", false);
        break;
      case "extraEmailSuccessMessage":
        component.set("v.extraEmailSuccessMessage", false);
        break;
      case "extraEmailErrorMessage":
        component.set("v.extraEmailErrorMessage", false);
        break;
      case "accountNameError":
        component.set("v.accountNameError", false);
        break;
      case "companyNameError":
        component.set("v.companyNameError", false);
        break;
      case "tradingNameError":
        component.set("v.tradingNameError", false);
        break;
      case "companyRegistationNumberError":
        component.set("v.companyRegistationNumberError", false);
        break;
      case "telephoneNumberError":
        component.set("v.telephoneNumberError", false);
        break;
      case "Phonelength":
        component.set("v.PhonelengthError", false);
      	break;
      case "phoneNotValid":
        component.set("v.MessagePhone", false);
        break;
      case "addressError":
        component.set("v.addressError", false);
        break;
      case "usernameError":
        component.set("v.usernameErrorMessage", false);
        break;
      case "newUserErrorAlert":
        component.set("v.errorNewUserMsg", false);
        break;
	  case "newUserSuccessAlert":
        component.set("v.successNewUserMsg", false);
        break;
	  case "titleNewUserErrorAlert":
        component.set("v.titleNewUserError", false);
        break;
	  case "firstNameNewUserErrorAlert":
        component.set("v.firstNameNewUserError", false);
        break;
	  case "SurNameNewUserErrorAlert":
        component.set("v.SurNameNewUserError", false);
        break;
	  case "UserNameNewUserErrorAlert":
        component.set("v.usernameNewUserErrorMessage", false);
        break;
	  case "EmailNewUserErrorAlert":
        component.set("v.EmailNewUserError", false);
        break;
	  case "MobileNewUserErrorAlert":
        component.set("v.mobileNewUserError", false);
        break;
      case "editUserErrorAlert":
        component.set("v.errorEditUserMsg", false);
        break;
	  case "editUserSuccessAlert":
        component.set("v.successEditUserMsg", false);
        break;
	  case "titleEditUserErrorAlert":
        component.set("v.titleEditUserError", false);
        break;
	  case "firstNameEditUserErrorAlert":
        component.set("v.firstNameEditUserError", false);
        break;
	  case "SurNameEditUserErrorAlert":
        component.set("v.SurNameEditUserError", false);
        break;
	  case "UserNameEditUserErrorAlert":
        component.set("v.usernameEditUserErrorMessage", false);
        break;
	  case "EmailEditUserErrorAlert":
        component.set("v.EmailEditUserError", false);
        break;
	  case "MobileEditUserErrorAlert":
        component.set("v.mobileEditUserError", false);
        break;
            
      case "suspendAndReactiveUserErrorAlert":
        component.set("v.suspendAndReactiveUserErrorAlert", false);
        break;
	  case "suspendAndReactiveSuccessAlert":
        component.set("v.suspendAndReactiveSuccessAlert", false);
        break;
            
      case "companyPhonelength":
        component.set("v.companyPhonelengthError", false);
        break;
            
     case "mobileLenghtNewUserAlert":
        component.set("v.mobileLenghtNewUserError", false);
        break; 
     case "mobileLenghtEditUserErrorAlert":
        component.set("v.mobileLenghtEditUserError", false);
        break;  
    case "invalidEmailErrorAlert":
    	component.set("v.invalidEmailError", false);
        break; 	
             // Change for TGK-327
     case "invalidSecondaryEmailErrorAlert":
         component.set("v.invalidSecondaryEmailError", false);
         break; 	
    case "NoPrimarywithSecondaryEmailErrorAlert":
        component.set("v.NoPrimarywithSecondaryEmailError", false);
        break; 
	 case "PrimarySecondarySameEmailErrorAlert":
        component.set("v.PrimarySecondarySameEmailError", false);
        break;
 // Change for TGK-327            
    case "invalidcompanyPhoneErrorAlert":	
    	component.set("v.invalidcompanyPhoneError", false);
        break;
    case "companyLandlineErrorAlert":
    	component.set("v.companyLandlineError", false);
        break;
    case "invalidcompanyLandlineErrorAlert":
    	component.set("v.invalidcompanyLandlineError", false);
        break;
    case "invalidMobileAlert":
    	component.set("v.invalidMobileError", false);
         break;
   case "landlineErrorAlert":
    	component.set("v.landlineError", false);
        break;
    case "invalidLandlineAlert":
    	component.set("v.invalidLandlineError", false);
        break;
    case "invalidEmailNewUserErrorAlert":
    	component.set("v.invalidEmailNewUserError", false);
         break;
    case "invalidMobileNewUserErrorAlert":
    	component.set("v.invalidMobileNewUserError", false);
        break;
    case "invalidEmailEditUserErrorAlert":
    	component.set("v.invalidEmailEditUserError", false);
         break;
    case "invalidMobileEditUserErrorAlert":
        component.set("v.nvalidMobileEditUserError", false);
        break;
            
         case "houseNoCurrentErrorId":
        component.set("v.houseNoCurrentError", false);
        break;
		
	case "streetCurrentErrorId":
        component.set("v.streetCurrentError", false);
        break;
		
	case "cityCurrentErrorId":
        component.set("v.cityCurrentError", false);
        break;
		
	case "postcodeCurrentErrorId":
        component.set("v.postcodeCurrentError", false);
        break;
		
	case "baseCountryCurrentErrorId":
        component.set("v.baseCountryCurrentError", false);
        break;
		
	case "countryCurrentErrorId":
        component.set("v.countryCurrentError", false);
        break;       
    }
  },

    
    
     handleSaveClick: function(component, event, helper) {
 
         var isValid = true;
         
         var contactSalutation = document.getElementById("salutationId").value;
         var firstName = document.getElementById("sf-First").value;
         var lastName = document.getElementById("sf-Surname").value;
         var PhoneCode = document.getElementById("phoneCodeId").value;
         var phonecheck = document.getElementById("sf-Telephone").value;
         var Landlinecheck = document.getElementById("sf-Landline").value;
         var emailcheck = document.getElementById("sf-email").value;
         var Secondaryemailcheck =document.getElementById("sf-Secondaryemail").value;
         
         
        
         component.set("v.titleError", false);
         component.set("v.firstNameError", false);
         component.set("v.SurNameError", false);
         component.set("v.EmailError", false);
         component.set("v.mobileError", false);
         component.set("v.PhonelengthError",false);
         component.set("v.addressError", false);
         component.set("v.usernameErrorMessage", false);
         component.set("v.successMsg", false);
         component.set("v.errorMsg", false);
         
         component.set("v.invalidMobileError", false);
         component.set("v.landlineError", false);
         component.set("v.invalidLandlineError", false);
         component.set("v.invalidEmailError", false);
         component.set("v.invalidSecondaryEmailError", false);
         component.set("v.NoPrimarywithSecondaryEmailError", false);
         component.set("v.PrimarySecondarySameEmailError", false);
         component.set("v.houseNoCurrentError", false);
                 component.set("v.streetCurrentError", false);
                 component.set("v.cityCurrentError", false);
                 component.set("v.postcodeCurrentError", false);
                 component.set("v.baseCountryCurrentError", false);
          		 component.set("v.countryCurrentError", false);
         
         var letters = /^[0-9]+$/;
         
         
         
      if (contactSalutation == undefined || contactSalutation == "" || contactSalutation == null || contactSalutation == "-- Select Title --") 
      {
          component.set("v.titleError", true);
          isValid = false;
      }
      
      if (firstName == undefined || firstName == "" || firstName == null) {
          component.set("v.firstNameError", true);
          isValid = false;
      }
      
         
      if (lastName == undefined || lastName == "" || lastName == null) {
          component.set("v.SurNameError", true);
          isValid = false;
      }
      
      var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
   
      if (emailcheck == undefined || emailcheck == "" || emailcheck == null) {
          component.set("v.EmailError", true);
          isValid = false;
      }
       else if(emailcheck.match(regExpEmailformat) == null ){
			  component.set("v.invalidEmailError", true);
              isValid = false;
          }
         
         
         if (Secondaryemailcheck != null && Secondaryemailcheck != '' && Secondaryemailcheck != undefined) {
            if (emailcheck == Secondaryemailcheck) {
            isValid = false;
            component.set("v.PrimarySecondarySameEmailError", true);
            }
            else{
            component.set("v.PrimarySecondarySameEmailError", false);    
            }
            if (emailcheck == "" || emailcheck == null || emailcheck == undefined) {
            isValid = false;
            component.set("v.NoPrimarywithSecondaryEmailError", true);
            }
            else{
            component.set("v.NoPrimarywithSecondaryEmailError", false);    
            }
            if(Secondaryemailcheck.match(regExpEmailformat) == null ){
            isValid = false;
			component.set("v.invalidSecondaryEmailError", true);
            }
            else{
            component.set("v.invalidSecondaryEmailError", false);    
            }
            }
         
         
      if (phonecheck == undefined || phonecheck == "" || phonecheck == null) {
          component.set("v.mobileError", true);
              isValid = false;
          }
         else if(phonecheck.match(letters) == null ){
			  component.set("v.invalidMobileError", true);
              isValid = false;
          }
          else if (PhoneCode == "+44" && (phonecheck.length != 11 || !phonecheck.startsWith("07"))) {
                component.set("v.PhonelengthError",true);    
                isValid = false;
          }
    
        var Landlinecheck1 = Landlinecheck.replace(/ +/g, "");
          if (Landlinecheck1 == undefined || Landlinecheck1 == "" || Landlinecheck1 == null) {
         // component.set("v.landlineError", true);
            //  isValid = false;
          }
         else if(Landlinecheck1.match(letters) == null ){
			  component.set("v.invalidLandlineError", true);
              isValid = false;
          }
         
         
         
         var ContactObj = component.get("v.contact");
         ContactObj.Salutation = contactSalutation;
         ContactObj.Email = emailcheck;
         ContactObj.Phone_Code__c = PhoneCode;
         ContactObj.Phone = phonecheck;
         ContactObj.FirstName = firstName;
         ContactObj.LastName = lastName;
         ContactObj.HomePhone = Landlinecheck;
         ContactObj.Secondary_email_address__c = Secondaryemailcheck;
         
         
        var objChild = component.find("compB");
       console.log('objChild '+objChild);
      if (objChild != undefined){
        
            
          
             var enterManually = objChild.get("v.enterManually");
              if(objChild.get("v.County") != "" && objChild.get("v.County") != undefined &&  typeof objChild.get("v.County") != "undefined")
              {
                 ContactObj.MailingState = objChild.get("v.County"); 
              }
              else
              {
                 ContactObj.MailingState = null;
              }
          
          
              if(objChild.get("v.Town") != "" && objChild.get("v.Town") != undefined &&  typeof objChild.get("v.Town") != "undefined")
              {
                 ContactObj.MailingCity = objChild.get("v.Town"); 
              }
              else
              {
                  ContactObj.MailingCity = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.cityCurrentError", true);
                  }
              }
          
              if(objChild.get("v.AddressLine1") != "" && objChild.get("v.AddressLine1") != undefined &&  typeof objChild.get("v.AddressLine1") != "undefined")
              {
                  ContactObj.MailingStreet  = objChild.get("v.AddressLine1");// + " \n " + objChild.get("v.Street");
              }
          	  else
              {
                  ContactObj.MailingStreet = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.streetCurrentError", true);
                  }
              }
          
              if(objChild.get("v.Country") != "" && objChild.get("v.Country") != undefined &&  typeof objChild.get("v.Country") != "undefined")
              {
                 ContactObj.MailingCountry = objChild.get("v.Country"); 
              }
          	  else
              {
                  ContactObj.MailingCountry = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.countryCurrentError", true);
                  }
              }
          
              if(objChild.get("v.PostCode") != "" && objChild.get("v.PostCode") != undefined &&  typeof objChild.get("v.PostCode") != "undefined")
              {
                   ContactObj.MailingPostalCode = objChild.get("v.PostCode");
              }
          	 else
              {
                  ContactObj.MailingPostalCode = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.postcodeCurrentError", true);
                  }
              }
          
          
              if(objChild.get("v.BaseCountry") != "" && objChild.get("v.BaseCountry") != undefined &&  typeof objChild.get("v.BaseCountry") != "undefined")
              {
                   ContactObj.Base_Country__c = objChild.get("v.BaseCountry");
              }
           	 else
              {
                  ContactObj.Base_Country__c = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.baseCountryCurrentError", true);
                  }
              }
          
             if(objChild.get("v.houseNo") != "" && objChild.get("v.houseNo") != undefined  &&  typeof objChild.get("v.houseNo") != "undefined")
              {
                   ContactObj.House_No__c = objChild.get("v.houseNo");
              }
             else
             {
                 ContactObj.House_No__c = null;
                 if(enterManually == true)
                  {
                     isValid = false;
                     component.set("v.houseNoCurrentError", true);
                  }
             }
        
          
         // }
         }
         
         
         component.set("v.contact",ContactObj);
         
         if (isValid) {
            console.log("++++++con+++" + JSON.stringify(ContactObj));
             helper.helperUpdateContactDetails(component, event, helper);
         }
         else
         {
          // document.body.scrollTop = 0;
         //  document.documentElement.scrollTop = 0;
           $("html, body").animate( { scrollTop: $("#MyAccountErrorDiv").offset().top-5}, 500 );
         }
         

  },
    
      handleSaveBuilderClick: function(component, event, helper) {
 
         var isValid = true;
          
         var isHouseBuilderAdditionalUser = component.get("v.isHouseBuilderAdditionalUser");
         var isHouseBuilder = component.get("v.isHouseBuilder");
          
         var ContactObj = component.get("v.contact"); 
          
         var contactSalutation = document.getElementById("salutationId").value;
                 var firstName = document.getElementById("sf-First").value;
                 var lastName = document.getElementById("sf-Surname").value;
                 var phonecheck = document.getElementById("sf-Telephone").value;
                 var Landlinecheck = document.getElementById("sf-Landline").value;
                 var phoneCodecheck = document.getElementById("phoneCodeId").value;
                 var emailcheck = document.getElementById("sf-email").value;
                 
                 
                
                 component.set("v.titleError", false);
                 component.set("v.firstNameError", false);
                 component.set("v.SurNameError", false);
                 component.set("v.EmailError", false);
                 component.set("v.mobileError", false);
          		 component.set("v.PhonelengthError", false);
                 component.set("v.usernameErrorMessage", false);
                 component.set("v.successMsg", false);
                 component.set("v.errorMsg", false);
                      
                 component.set("v.invalidMobileError", false);
                 component.set("v.landlineError", false);
                 component.set("v.invalidLandlineError", false);
                 component.set("v.invalidEmailError", false);
          
          		 component.set("v.houseNoCurrentError", false);
                 component.set("v.streetCurrentError", false);
                 component.set("v.cityCurrentError", false);
                 component.set("v.postcodeCurrentError", false);
                 component.set("v.baseCountryCurrentError", false);
          		 component.set("v.countryCurrentError", false);
                 
              if (contactSalutation == undefined || contactSalutation == "" || contactSalutation == null || contactSalutation == "-- Select Title --") 
              {
                  component.set("v.titleError", true);
                  isValid = false;
              }
              
              if (firstName == undefined || firstName == "" || firstName == null) {
                  component.set("v.firstNameError", true);
                  isValid = false;
              }
              
                 
              if (lastName == undefined || lastName == "" || lastName == null) {
                  component.set("v.SurNameError", true);
                  isValid = false;
              }
              
              var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
     
              if (emailcheck == undefined || emailcheck == "" || emailcheck == null) {
                  component.set("v.EmailError", true);
                  isValid = false;
              }
               else if(emailcheck.match(regExpEmailformat) == null ){
                  component.set("v.invalidEmailError", true);
                  isValid = false;
              }
              
              var letters = /^[0-9]+$/;   
              if (phonecheck == undefined || phonecheck == "" || phonecheck == null) {
                  component.set("v.mobileError", true);
                  isValid = false;
              }
              else if(phonecheck.match(letters) == null ){
                 
              component.set("v.invalidMobileError", true);
                  isValid = false;
              }
             else if (phoneCodecheck == "+44" && (phonecheck.length != 11 || !phonecheck.startsWith("07"))) {
                component.set("v.PhonelengthError",true);    
                isValid = false;
                }
          
          var Landlinecheck1 = Landlinecheck.replace(/ +/g, "");
          if (Landlinecheck1 == undefined || Landlinecheck1 == "" || Landlinecheck1 == null) {
         // component.set("v.landlineError", true);
         //     isValid = false;
          }
         else if(Landlinecheck1.match(letters) == null ){
			  component.set("v.invalidLandlineError", true);
              isValid = false;
          }
             
                 ContactObj.Salutation = contactSalutation;
                 ContactObj.Email = emailcheck;
                 ContactObj.Phone = phonecheck;
                 ContactObj.FirstName = firstName;
                 ContactObj.LastName = lastName;
                 ContactObj.Phone_Code__c = phoneCodecheck;
                 ContactObj.HomePhone = Landlinecheck;
          
          
          
         if(isHouseBuilderAdditionalUser != true)
         {
              
             
                 var compPhoneCodecheck = document.getElementById("bCompanyPhoneCode").value;
                 var compPhonecheck = document.getElementById("bCompanyPhone").value;
                var compLandlinecheck = document.getElementById("bCompanyLandline").value;
                
                 component.set("v.companyPhoneError", false);
                 component.set("v.companyPhonelengthError", false);
                 component.set("v.invalidcompanyPhoneError", false);
             
                 component.set("v.companyLandlineError", false);
                 component.set("v.invalidcompanyLandlineError", false);
                
             if (compPhonecheck == undefined || compPhonecheck == "" || compPhonecheck == null) {
                  component.set("v.companyPhoneError", true);
                  isValid = false;
              }
             else if(compPhonecheck.match(letters) == null ){
                 
              component.set("v.invalidcompanyPhoneError", true);
                  isValid = false;
              }
              else if (compPhoneCodecheck == "+44" && (compPhonecheck.length != 11 || !compPhonecheck.startsWith("07"))) {
                component.set("v.companyPhonelengthError",true);    
                isValid = false;
                }
             
          
          var compLandlinecheck1 = compLandlinecheck.replace(/ +/g, "");
          if (compLandlinecheck1 == undefined || compLandlinecheck1 == "" || compLandlinecheck1 == null) {
          /*required component.set("v.landlineError", true);
              isValid = false;*/
          }
         else if(compLandlinecheck1.match(letters) == null ){
			  component.set("v.invalidcompanyLandlineError", true);
              isValid = false;
          }
             
             
                  
          
                 ContactObj.Account.Phone_Code__c = compPhoneCodecheck;
                 ContactObj.Account.Phone = compPhonecheck;
                 ContactObj.Account.Telephone_Number__c  = compLandlinecheck;
              
               var objChild = component.find("compB");
       console.log('objChild '+objChild);
      if (objChild != undefined){
        
          var enterManually = objChild.get("v.enterManually");
              if(objChild.get("v.County") != "" && objChild.get("v.County") != undefined &&  typeof objChild.get("v.County") != "undefined")
              {
                 ContactObj.Account.BillingState = objChild.get("v.County"); 
              }
              else
              {
                 ContactObj.Account.BillingState = null;
              }
          
          
              if(objChild.get("v.Town") != "" && objChild.get("v.Town") != undefined &&  typeof objChild.get("v.Town") != "undefined")
              {
                 ContactObj.Account.BillingCity = objChild.get("v.Town"); 
              }
              else
              {
                  ContactObj.Account.BillingCity = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.cityCurrentError", true);
                  }
              }
          
              if(objChild.get("v.AddressLine1") != "" && objChild.get("v.AddressLine1") != undefined &&  typeof objChild.get("v.AddressLine1") != "undefined")
              {
                  ContactObj.Account.BillingStreet  = objChild.get("v.AddressLine1");// + " \n " + objChild.get("v.Street");
              }
          	  else
              {
                  ContactObj.Account.BillingStreet = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.streetCurrentError", true);
                  }
              }
          
              if(objChild.get("v.Country") != "" && objChild.get("v.Country") != undefined &&  typeof objChild.get("v.Country") != "undefined")
              {
                 ContactObj.Account.BillingCountry = objChild.get("v.Country"); 
              }
          	  else
              {
                  ContactObj.Account.BillingCountry = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.countryCurrentError", true);
                  }
              }
          
              if(objChild.get("v.PostCode") != "" && objChild.get("v.PostCode") != undefined &&  typeof objChild.get("v.PostCode") != "undefined")
              {
                   ContactObj.Account.BillingPostalCode = objChild.get("v.PostCode");
              }
          	 else
              {
                  ContactObj.Account.BillingPostalCode = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.postcodeCurrentError", true);
                  }
              }
          
          
              if(objChild.get("v.BaseCountry") != "" && objChild.get("v.BaseCountry") != undefined &&  typeof objChild.get("v.BaseCountry") != "undefined")
              {
                   ContactObj.Account.Base_Country__c = objChild.get("v.BaseCountry");
              }
           	 else
              {
                  ContactObj.Account.Base_Country__c = null;
                  if(enterManually == true)
                  {
                      isValid = false;
                      component.set("v.baseCountryCurrentError", true);
                  }
              }
          
             if(objChild.get("v.houseNo") != "" && objChild.get("v.houseNo") != undefined  &&  typeof objChild.get("v.houseNo") != "undefined")
              {
                   ContactObj.Account.HouseNo__c = objChild.get("v.houseNo");
              }
             else
             {
                 ContactObj.Account.HouseNo__c = null;
                 if(enterManually == true)
                  {
                     isValid = false;
                     component.set("v.houseNoCurrentError", true);
                  }
             }
             
         // }
         }
         
              
          }
        
        component.set("v.contact",ContactObj);
         
         if (isValid) {
            console.log("++++++con+++" + JSON.stringify(ContactObj));
            helper.helperUpdateContactDetails(component, event, helper);
         }
         else
         {
          // document.body.scrollTop = 0;
          // document.documentElement.scrollTop = 0;
             $("html, body").animate( { scrollTop: $("#MyAccountErrorDiv").offset().top-5}, 500 );
         }
         

  },
    
     closePopup: function(component, event, helper) {
		 component.set("v.passwordSuccessMsg", false);
          component.set("v.passwordErrorMsg", false);
         document.getElementById("sf-popup-current_pass").value = "";
            document.getElementById("sf-popup-new_pass").value = "";
            document.getElementById("sf-popup-verify_pass").value = "";
    },
    
   updatePassword: function(component, event) {
    var isValid = true;
    var CurrentPassword = document.getElementById("sf-popup-current_pass").value;
    var newPassword = document.getElementById("sf-popup-new_pass").value;
    var verifyPassword = document.getElementById("sf-popup-verify_pass").value;
       
       component.set("v.passwordFieldMandatoryMsg", false);
       component.set("v.newPasswordFieldMandatoryMsg", false);
       component.set("v.confirmPasswordFieldMandatoryMsg", false);
       
     if (CurrentPassword == undefined || CurrentPassword == "" || CurrentPassword == null) {
          component.set("v.passwordFieldMandatoryMsg", true);
          isValid = false;
      }
      
         
      if (newPassword == undefined || newPassword == "" || newPassword == null) {
          component.set("v.newPasswordFieldMandatoryMsg", true);
          isValid = false;
      }
      
         
      if (verifyPassword == undefined || verifyPassword == "" || verifyPassword == null) {
          component.set("v.confirmPasswordFieldMandatoryMsg", true);
          isValid = false;
      }   
       
       
     if(isValid == true)
     {
         component.set("v.showSpinner",true);   
        var action = component.get("c.changeuserpassword");
        action.setParams({
          newPassword: newPassword,
          verifyNewPassword: verifyPassword,
          oldPassword: CurrentPassword
        });
        action.setCallback(this, function(response) {
          var state = response.getReturnValue();
          //  alert(state);
          if (state === "Success") {
           
            var result = response.getReturnValue();
              
             // alert(result);
              
            if(result == "Success")  
            {
                console.log("result :" + JSON.stringify(result));
                component.set("v.passwordSuccessMsg", true);
                document.getElementById("sf-popup-current_pass").value = "";
                document.getElementById("sf-popup-new_pass").value = "";
                document.getElementById("sf-popup-verify_pass").value = "";
                console.log("Modal Close");
                $A.get("e.force:refreshView").fire();
            }
            else
            {
              document.getElementById("sf-popup-current_pass").value = "";
            document.getElementById("sf-popup-new_pass").value = "";
            document.getElementById("sf-popup-verify_pass").value = "";
            component.set("v.ErrorMessage", result);
                if(result == 'Your password must be atleast 8 characters long and include letters and numbers.')
                {
                    component.set("v.ErrorMessage", 'Your password must be at least 8 characters long and include at least 1 letter and number.');
                }
                else if(result == 'Your password must include letters and numbers')
                {
                    component.set("v.ErrorMessage", 'Your password must include at least 1 letter and number.');
                }
                else if(result == 'Error: Your old password is invalid.')
                {
                    component.set("v.ErrorMessage", 'Your current password is invalid.');
                }
         
            component.set("v.passwordErrorMsg", true);  
            }
          
            //$A.get("e.force:refreshView").fire();
          } else {
            document.getElementById("sf-popup-current_pass").value = "";
            document.getElementById("sf-popup-new_pass").value = "";
            document.getElementById("sf-popup-verify_pass").value = "";
            component.set("v.ErrorMessage", state);
            if(state == 'Your password must be atleast 8 characters long and include letters and numbers.')
                {
                    component.set("v.ErrorMessage", 'Your password must be at least 8 characters long and include at least 1 letter and number.');
                }
                else if(state == 'Your password must include letters and numbers')
                {
                    component.set("v.ErrorMessage", 'Your password must include at least 1 letter and number.');
                }
                else if(state == 'Error: Your old password is invalid.')
                {
                    component.set("v.ErrorMessage", 'Your current password is invalid.');
                }
            component.set("v.passwordErrorMsg", true);
           // $A.get("e.force:refreshView").fire();
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
     }
       
    
  },
doneWaiting: function(component, event, helper) {
        setTimeout(function(){  component.set("v.PageSpinner",false); 
                              
                             }, 1000);
        
    },
    
    clickOnPersonalNav: function(component, event, helper) {
       
        var hlink= document.getElementById("left_nav-sf-organisation-tab");
         $(".org-detail-list").slideToggle();
    $(hlink).toggleClass("open");
    },
    
    
    clickOnOpenAddNewUser: function(component, event, helper) {
        component.set("v.titleNewUserError", false);
         component.set("v.firstNameNewUserError", false);
         component.set("v.SurNameNewUserError", false);
         component.set("v.EmailNewUserError", false);
         component.set("v.invalidEmailNewUserError", false);
         component.set("v.mobileNewUserError", false);
         component.set("v.invalidMobileNewUserError", false);
         component.set("v.mobileLenghtNewUserError", false);
         component.set("v.successNewUserMsg", false);
         component.set("v.errorNewUserMsg", false);
         component.set("v.mobileLenghtNewUserError", false);
        
        document.getElementById("sf-newpopup-Title").value = "-- Select Title --";
        document.getElementById("sf-newpopup-First").value = "";
        document.getElementById("sf-newpopup-Surname").value = "";
        document.getElementById("sf-newpopup-phoneCode1").value = "+44";
        document.getElementById("sf-newpopup-Mobile").value = "";
        document.getElementById("sf-newpopup-UserName").value = "";
       
    },
    
    saveAdditionalUser: function(component, event, helper) {
        
        var isValid = true;
         
         var salutation = document.getElementById("sf-newpopup-Title").value;
         var firstName = document.getElementById("sf-newpopup-First").value;
            var firstNameArr = firstName.split(" ");
            
            for (var i = 0; i < firstNameArr.length; i++) {
                firstNameArr[i] = firstNameArr[i].charAt(0).toUpperCase() + firstNameArr[i].slice(1);
            }
           firstName = firstNameArr.join(" ");
        
        
        
         var lastName = document.getElementById("sf-newpopup-Surname").value;
           var lastNameArr = lastName.split(" ");
            
            for (var i = 0; i < lastNameArr.length; i++) {
                lastNameArr[i] = lastNameArr[i].charAt(0).toUpperCase() + lastNameArr[i].slice(1);
            }
           lastName = lastNameArr.join(" ");
        
        var phonecodechk = document.getElementById("sf-newpopup-phoneCode1").value;
         var phonecheck = document.getElementById("sf-newpopup-Mobile").value;
         var emailcheck = document.getElementById("sf-newpopup-UserName").value;
        
      
         component.set("v.titleNewUserError", false);
         component.set("v.firstNameNewUserError", false);
         component.set("v.SurNameNewUserError", false);
         component.set("v.EmailNewUserError", false);
        component.set("v.invalidEmailNewUserError", false);
         component.set("v.mobileNewUserError", false);
        component.set("v.invalidMobileNewUserError", false);
         component.set("v.successNewUserMsg", false);
         component.set("v.errorNewUserMsg", false);
         component.set("v.usernameNewUserErrorMessage", false);
         component.set("v.mobileLenghtNewUserError", false);
        

      if (salutation == undefined || salutation == "" || salutation == null || salutation == "-- Select Title --") 
      {
          component.set("v.titleNewUserError", true);
          isValid = false;
      }
      
      if (firstName == undefined || firstName == "" || firstName == null) {
          component.set("v.firstNameNewUserError", true);
          isValid = false;
      }
        
      if (lastName == undefined || lastName == "" || lastName == null) {
          component.set("v.SurNameNewUserError", true);
          isValid = false;
      }
      
      var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    
      if (emailcheck == undefined || emailcheck == "" || emailcheck == null) {
          component.set("v.EmailNewUserError", true);
          isValid = false;
      }
      else if(emailcheck.match(regExpEmailformat) == null ){
			  component.set("v.invalidEmailNewUserError", true);
              isValid = false;
          }
      var letters = /^[0-9]+$/;   
    /*  if (phonecheck == undefined || phonecheck == "" || phonecheck == null) {
          component.set("v.mobileNewUserError", true);
          isValid = false;
      }
      else if(phonecheck.match(letters) == null ){
			  component.set("v.invalidMobileNewUserError", true);
              isValid = false;
      }
      else if (phonecodechk == "+44" && (phonecheck.length != 11 || !phonecheck.startsWith("07"))) {
            component.set("v.mobileLenghtNewUserError",true);    
            isValid = false;
      }*/
        
     if(isValid == true)
     {
         component.set("v.showSpinner",true);   
        var action = component.get("c.createAdditionalUser");
        action.setParams({
          firstName: firstName,
          lastName: lastName,
          phoneNo: phonecheck,
            email:emailcheck,
            title:salutation,
            phoneCode:phonecodechk,
            contId:component.get("v.contacctId")
        });
        action.setCallback(this, function(response) {
         var state = response.getState();
        
          var result = response.getReturnValue();
           
          if (state === "SUCCESS") {
              
            if(result == "Success")  
            {
                console.log("result :" + JSON.stringify(result));
                component.set("v.successNewUserMsg", true);
                
               $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
                
                  
                    
                  setTimeout(function(){ 
                     $('#addUser').modal('hide');
                          helper.helperGetAdditionalUserList(component, event, helper);
                        }, 500);
                
               /* document.getElementById("sf-popup-current_pass").value = "";
                document.getElementById("sf-popup-new_pass").value = "";
                document.getElementById("sf-popup-verify_pass").value = "";
                console.log("Modal Close");
                $A.get("e.force:refreshView").fire();*/
            }
              else if(result == "Duplicate User")  
            {
                component.set("v.usernameNewUserErrorMessage", true);
                $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
            }
            else
            {
             
            component.set("v.errorNewUserMsg", true);  
                $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
            }
          
            //$A.get("e.force:refreshView").fire();
          } else {
            if(result == "Duplicate User")  
            {
                component.set("v.usernameNewUserErrorMessage", true);
                $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
            }
            else
            {
             
            component.set("v.errorNewUserMsg", true); 
               $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
            }
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
     }
        else
        {
           
            $('#addUserHeader', window.parent.document).get(0).scrollIntoView();
        }
        
        
    },
    
    
    
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.additionUserList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = Number(component.get("v.pageSize"));
        //var whichBtn = event.getSource().get("v.name");
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    closeEditWindow: function(component, event, helper) {
        component.set("v.editUserObj",null);
        helper.helperGetAdditionalUserList(component, event, helper);
    },
    
    closeNewAddtionalUserWindow: function(component, event, helper) {
        helper.helperGetAdditionalUserList(component, event, helper);
    },
    
    getUserDetailsToEdit: function(component, event, helper) {
        
         var userId = event.target.id;
        component.set("v.titleEditUserError", false);
         component.set("v.firstNameEditUserError", false);
         component.set("v.SurNameEditUserError", false);
         component.set("v.EmailEditUserError", false);
         component.set("v.invalidEmailEditUserError", false);
         component.set("v.mobileEditUserError", false);
        component.set("v.invalidMobileEditUserError", false);
         component.set("v.successEditUserMsg", false);
         component.set("v.errorEditUserMsg", false);
        
          component.set("v.suspendAndReactiveUserErrorAlert", false);  
         component.set("v.suspendAndReactiveUserErrorMessage",null); 
         component.set("v.suspendAndReactiveSuccessAlert", false);  
         component.set("v.suspendAndReactiveSuccessMessage",null); 
        component.set("v.isSuspendSuccess",false);
        
         component.set("v.usernameEditUserErrorMessage", false);
        
        component.set("v.showSpinner",true);  
          var action = component.get("c.getAddtionalUserDetails");
         action.setParams({
          UserId:userId
         });
        action.setCallback(this, function(response) {
         var state = response.getState();
        
          var result = response.getReturnValue();
           
          if (state === "SUCCESS") {
           
           component.set("v.editUserObj",result);
              console.log("result :" + JSON.stringify(result));
            $('#editUser').modal('show');
          } else {
           
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
        
       
    },
    
    
    
    
    saveEditAdditionalUserData: function(component, event, helper) {
        
        var isValid = true;
         
         var salutation = document.getElementById("sf-editPopup-Title").value;
         var firstName = document.getElementById("sf-editPopup-First").value;
          var firstNameArr = firstName.split(" ");
            
            for (var i = 0; i < firstNameArr.length; i++) {
                firstNameArr[i] = firstNameArr[i].charAt(0).toUpperCase() + firstNameArr[i].slice(1);
            }
           firstName = firstNameArr.join(" ");
        
        
        
         var lastName = document.getElementById("sf-editPopup-Surname").value;
        	 var lastNameArr = lastName.split(" ");
            
            for (var i = 0; i < lastNameArr.length; i++) {
                lastNameArr[i] = lastNameArr[i].charAt(0).toUpperCase() + lastNameArr[i].slice(1);
            }
           lastName = lastNameArr.join(" ");
        
        var phoneCodeChk = document.getElementById("sf-editpopup-phoneCode1").value;
         var phonecheck = document.getElementById("sf-editPopup-Mobile").value;
         var emailcheck = document.getElementById("sf-editPopup-UserName").value;
         
         component.set("v.titleEditUserError", false);
         component.set("v.firstNameEditUserError", false);
         component.set("v.SurNameEditUserError", false);
         component.set("v.EmailEditUserError", false);
        component.set("v.invalidEmailEditUserError", false);
         component.set("v.mobileEditUserError", false);
        component.set("v.invalidMobileEditUserError", false);
         component.set("v.mobileLenghtEditUserError", false);
         component.set("v.successEditUserMsg", false);
         component.set("v.errorEditUserMsg", false);
         component.set("v.usernameEditUserErrorMessage", false);
        

      if (salutation == undefined || salutation == "" || salutation == null || salutation == "-- Select Title --") 
      {
          component.set("v.titleEditUserError", true);
          isValid = false;
      }
      
      if (firstName == undefined || firstName == "" || firstName == null) {
          component.set("v.firstNameEditUserError", true);
          isValid = false;
      }
        
      if (lastName == undefined || lastName == "" || lastName == null) {
          component.set("v.SurNameEditUserError", true);
          isValid = false;
      }
      
       var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    
      if (emailcheck == undefined || emailcheck == "" || emailcheck == null) {
          component.set("v.EmailEditUserError", true);
          isValid = false;
      }
        else if(emailcheck.match(regExpEmailformat) == null ){
			  component.set("v.invalidEmailEditUserError", true);
              isValid = false;
          }
        
      var letters = /^[0-9]+$/;
    /*  if (phonecheck == undefined || phonecheck == "" || phonecheck == null) {
          component.set("v.mobileEditUserError", true);
          isValid = false;
      }
        else if(phonecheck.match(letters) == null ){
			  component.set("v.invalidMobileEditUserError", true);
              isValid = false;
      }
       else if (phoneCodeChk == "+44" && (phonecheck.length != 11 || !phonecheck.startsWith("07"))) {
            component.set("v.mobileLenghtEditUserError",true);    
            isValid = false;
      }*/
      
      var userObj =   component.get("v.editUserObj");
     if(isValid == true)
     {
         component.set("v.showSpinner",true); 
         
         userObj.Title = salutation;
         userObj.FirstName = firstName;
         userObj.LastName = lastName;
         userObj.Email = emailcheck;
         userObj.Phone = phonecheck;
         userObj.Contact.Phone_Code__c = phoneCodeChk;
         
        var action = component.get("c.updateAdditionalUser");
        action.setParams({
          UserObj:userObj
        });
        action.setCallback(this, function(response) {
          var state = response.getState();
        
          var result = response.getReturnValue();
           
          if (state === "SUCCESS") {
           
            if(result == "Success")  
            {
                console.log("result :" + JSON.stringify(result));
                component.set("v.successEditUserMsg", true);
               // helper.helperGetAdditionalUserList(component, event, helper);
                
                setTimeout(function(){ 
                     $('#editUser').modal('hide');
                          helper.helperGetAdditionalUserList(component, event, helper);
                        }, 500);
                
                
            }
              else if(result == "Duplicate User")  
            {
                component.set("v.usernameEditUserErrorMessage", true);
                $('#editUserHeader', window.parent.document).get(0).scrollIntoView();
            }
            else
            {
             
            component.set("v.errorEditUserMsg", true); 
                $('#editUserHeader', window.parent.document).get(0).scrollIntoView();
            }
          
            //$A.get("e.force:refreshView").fire();
          } else {
            if(result == "Duplicate User")  
            {
                component.set("v.usernameEditUserErrorMessage", true);
                $('#editUserHeader', window.parent.document).get(0).scrollIntoView();
            }
            else
            {
             
            component.set("v.errorEditUserMsg", true); 
                $('#editUserHeader', window.parent.document).get(0).scrollIntoView();
            }
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
     }
        
        
        
    },
    suspendAdditionalUser: function(component, event, helper) {
        component.set("v.showSuspendConfirmDialog", true); 
    },
    
    handleSuspendDialogNo: function(component, event, helper) {
        component.set("v.showSuspendConfirmDialog", false); 
    },
    
    handleConfirmSuspendUser: function(component, event, helper) {
        component.set("v.showSuspendConfirmDialog", false); 
         component.set("v.suspendAndReactiveUserErrorAlert", false);  
         component.set("v.suspendAndReactiveUserErrorMessage",null); 
         component.set("v.suspendAndReactiveSuccessAlert", false);  
         component.set("v.suspendAndReactiveSuccessMessage",null); 
         component.set("v.isSuspendSuccess",false);
        
        
        component.set("v.showSpinner",true); 
        var action = component.get("c.suspendAndReactiveAdditionalUser");
        action.setParams({
          UserObj:component.get("v.editUserObj"),
            isActive:false
        });
        action.setCallback(this, function(response) {
          var state = response.getState();
        
          var result = response.getReturnValue();
           
          if (state === "SUCCESS") {
           
            if(result == "Success")  
            {
                 component.set("v.suspendAndReactiveUserErrorAlert", false);  
                 component.set("v.suspendAndReactiveUserErrorMessage",null); 
                 //component.set("v.suspendAndReactiveSuccessAlert", true);  
                // component.set("v.suspendAndReactiveSuccessMessage",'User have been successfully Suspend'); 
                component.set("v.isSuspendSuccess",true);
                component.set("v.editUserObj.User_Status__c","Suspended");
                
            }
            
            else
            {
             
            
                component.set("v.suspendAndReactiveUserErrorAlert", true);  
                 component.set("v.suspendAndReactiveUserErrorMessage",JSON.stringify(result)); 
                 component.set("v.suspendAndReactiveSuccessAlert", false);  
                 component.set("v.suspendAndReactiveSuccessMessage",null); 
            }
          
            //$A.get("e.force:refreshView").fire();
          } else {
            component.set("v.suspendAndReactiveUserErrorAlert", true);  
                 component.set("v.suspendAndReactiveUserErrorMessage",JSON.stringify(result)); 
                 component.set("v.suspendAndReactiveSuccessAlert", false);  
                 component.set("v.suspendAndReactiveSuccessMessage",null);
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
    },
    
    
    reactivateAdditionalUser: function(component, event, helper) {
         
         component.set("v.suspendAndReactiveUserErrorAlert", false);  
         component.set("v.suspendAndReactiveUserErrorMessage",null); 
         component.set("v.suspendAndReactiveSuccessAlert", false);  
         component.set("v.suspendAndReactiveSuccessMessage",null); 
        component.set("v.isSuspendSuccess",false);
        
        component.set("v.showSpinner",true); 
        var action = component.get("c.suspendAndReactiveAdditionalUser");
        action.setParams({
          UserObj:component.get("v.editUserObj"),
            isActive:true
        });
        action.setCallback(this, function(response) {
          var state = response.getState();
        
          var result = response.getReturnValue();
           
          if (state === "SUCCESS") {
           
            if(result == "Success")  
            {
             component.set("v.suspendAndReactiveUserErrorAlert", false);  
                 component.set("v.suspendAndReactiveUserErrorMessage",null); 
                 component.set("v.suspendAndReactiveSuccessAlert", true);  
                 component.set("v.suspendAndReactiveSuccessMessage",'User has been successfully reactivated'); 
                
               // helper.helperGetAdditionalUserList(component, event, helper);
                 setTimeout(function(){ 
                     $('#editUser').modal('hide');
                          helper.helperGetAdditionalUserList(component, event, helper);
                        }, 700);
                
              //  component.set("v.editUserObj.User_Status__c","Active");

            }
            
            else
            {
             
            component.set("v.suspendAndReactiveUserErrorAlert", true);  
                 component.set("v.suspendAndReactiveUserErrorMessage",JSON.stringify(result)); 
                 component.set("v.suspendAndReactiveSuccessAlert", false);  
                 component.set("v.suspendAndReactiveSuccessMessage",null);
            }
          
            //$A.get("e.force:refreshView").fire();
          } else {
           component.set("v.suspendAndReactiveUserErrorAlert", true);  
                 component.set("v.suspendAndReactiveUserErrorMessage",JSON.stringify(result)); 
                 component.set("v.suspendAndReactiveSuccessAlert", false);  
                 component.set("v.suspendAndReactiveSuccessMessage",null);
          }
            component.set("v.showSpinner",false);  
        });
        $A.enqueueAction(action);
    },
    
})