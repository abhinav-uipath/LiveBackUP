({
    setCustomLabelValues: function(component, customLabels) {
        console.log('custom labels : '+JSON.stringify(customLabels));
        if(customLabels.trsSiteHome) {
            component.set("v.TRS_SiteHome", customLabels.trsSiteHome);
        }
        if(customLabels.trsAboutUS) {
            component.set("v.TRS_AboutUS", customLabels.trsAboutUS);
        }
        if(customLabels.trsTenants) {
            component.set("v.TRS_Tenants", customLabels.trsTenants);
        }
        if(customLabels.trsLandlord) {
            component.set("v.TRS_Landlord", customLabels.trsLandlord);
        }
        if(customLabels.trsResourceCentre) {
            component.set("v.TRS_ResourceCentre", customLabels.trsResourceCentre);
        }
        if(customLabels.trsContactUs) {
            component.set("v.TRS_ContactUs", customLabels.trsContactUs);
        }
    },

})