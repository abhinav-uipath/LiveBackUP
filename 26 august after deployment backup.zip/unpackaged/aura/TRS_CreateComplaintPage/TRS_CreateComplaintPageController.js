({
    doInit: function(component, event, helper) {
        try {
            
            var action = component.get("c.getComplainantInfo");
            
            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();

                if (state == 'SUCCESS') {
                    let user = responseValue.currentLoggedInUser;
                    component.set("v.accountId", user.AccountId);
                    component.set("v.currentUserFirstName", user.FirstName);
                    
                    component.set("v.customLabelMap", responseValue.customLabelMap);
                    
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showFooterComponent", true);
                    component.set("v.showCreateComplaint", true);
                    
                    component.set("v.showSpinner", false);
                } else {
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showFooterComponent", true);
                    component.set("v.showCreateComplaint", true);
                    
                    component.set("v.showSpinner", false);
                }
            });
            
            $A.enqueueAction(action);
            
        } catch (error) {
            //console.log('error in trs home page : ' + error);
        }
    }
})