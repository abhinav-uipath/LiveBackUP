({
	
    showData : function(component, event, helper) { 
        
        component.set("v.spinner",true);
        var customerId = component.get("v.customerId");
        

        
		
        if(customerId == null || customerId == undefined || customerId == '' ){
            
            helper.showToast('Error!','Please enter the customer id','error');
            component.set("v.spinner",false);
            return ;
        }
        
        
		
		var action = component.get("c.showCustomerData");        
        action.setParams({
            customerId : customerId
            
        });
        
        action.setCallback(this, function(response) {
            component.set("v.spinner",true);
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
                if(result != null && result != undefined && result.depositList != null && result.depositList != undefined ){
                    component.set("v.messageList",result.depositList);
                    component.set("v.showtotalAmount",result.totalAmount);
                    component.set("v.showtotalLength",result.totalDeposits);
                    component.set("v.toShowSelectedAmount",false);
                    component.set("v.isCheckedHead",false)
                    
                }else{
                    component.set("v.messageList",[]);
                }
                
                component.set("v.spinner",false);
                
                
            }
            else if (state === "INCOMPLETE") {
                component.set("v.spinner",false);
                helper.showToast('Warning!','Process incomplete','warning'); 
                
                // alert('INCOMPLETE');
            }
                else if (state === "ERROR") {
                    component.set("v.spinner",false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            helper.showToast('Error!',"Error message: " +  errors[0].message,'error');
                            // component.set("v.spinner",false);
                            
                            //  alert("Error message: " +  errors[0].message);
                        }
                    } else {
                        helper.showToast('Error!','Unknown error','error');
                        //  component.set("v.spinner",false);
                        
                        //  alert("Unknown error");
                    }
                }
        });
        
        $A.enqueueAction(action);
        
    },

    // function automatic called by aura:waiting event  
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for displaying loading spinner 
        
        component.set("v.spinner", true); 
        
    },
    
    // function automatic called by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hiding loading spinner  
        component.set("v.spinner", false); 
    },
    
    searchData : function(component, event, helper) { 
        
        component.set("v.spinner",true);
        var customerId = component.get("v.customerId");
        

        
		
        if(customerId == null || customerId == undefined || customerId == '' ){
            
            helper.showToast('Error!','Please enter the customer id','error');
            component.set("v.spinner",false);
            return ;
        }
        var messageList = component.get("v.messageList");
        var sendList = [];
        
        for(var i = 0 ; i< messageList.length;i++){
            
            var element = messageList[i];
            
            if(element.isChecked){
                sendList.push(messageList[i]);
            }
            
            
        }
        if(sendList.length <= 0){
            helper.showToast('Error!','Please select any deposit','error');
            component.set("v.spinner",false);
            return ;
        }
		
		var action = component.get("c.sendDataPackage2");        
        action.setParams({
            customerId : customerId,
            wrapperList : sendList
            
        });
        
        action.setCallback(this, function(response) {
            component.set("v.spinner",true);
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
                if(result != null && result != undefined && result.depositList != null && result.depositList != undefined ){
                    helper.showToast('Success!','You will receive an email once file is ready','success');
                    //component.set("v.messageList",result.depositList);
                    //component.set("v.showtotalAmount",result.totalAmount);
                    //component.set("v.showtotalLength",result.totalDeposits);
                    //component.set("v.toShowSelectedAmount",false);
                    //component.set("v.isCheckedHead",false)
                    
                }else{
                    component.set("v.messageList",[]);
                }
                
                component.set("v.spinner",false);
                
                
            }
            else if (state === "INCOMPLETE") {
                component.set("v.spinner",false);
                helper.showToast('Warning!','Process incomplete','warning'); 
                
                // alert('INCOMPLETE');
            }
                else if (state === "ERROR") {
                    component.set("v.spinner",false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            helper.showToast('Error!',"Error message: " +  errors[0].message,'error');
                            // component.set("v.spinner",false);
                            
                            //  alert("Error message: " +  errors[0].message);
                        }
                    } else {
                        helper.showToast('Error!','Unknown error','error');
                        //  component.set("v.spinner",false);
                        
                        //  alert("Unknown error");
                    }
                }
        });
        
        $A.enqueueAction(action);
        
    },
    onCheck : function(component, event, helper){
        var messageList = component.get("v.messageList");
        let totalAmountSelected = 0.00;
        var toShowSelectedAmount = false;
        let selectedRecords = 0;
        for(var i=0;i < messageList.length;i++){
            var element = messageList[i];
            if(element.isChecked == true){
                toShowSelectedAmount = true;
                totalAmountSelected += element.deposit.Actual_Protected_Amount__c;
                selectedRecords += 1;
            }else{
                component.set("v.isCheckedHead",false)
            }
        }
        if(toShowSelectedAmount){
            component.set("v.toShowSelectedAmount",true);
            component.set("v.totalAmountSelected",totalAmountSelected);
            component.set("v.selectedRecords",selectedRecords);
        }else{
            component.set("v.toShowSelectedAmount",false);
        }
    },
    onCheckHead : function(component, event, helper) {
        var head = component.get("v.isCheckedHead");
        var messageList = component.get("v.messageList");
        var toShowSelectedAmount = false;
        for(var i = 0 ; i< messageList.length;i++){
            
            var element = messageList[i];
            
            element.isChecked = head;
            toShowSelectedAmount = head;
        }
        if(!toShowSelectedAmount){
            component.set("v.toShowSelectedAmount",false);
        }
		     
        component.set("v.messageList",messageList);
    },
    
    
    moveData : function(component, event, helper) { 
        
        component.set("v.spinner",true);
        var customerId = component.get("v.customerId");
        

        
		
        if(customerId == null || customerId == undefined || customerId == '' ){
            
            helper.showToast('Error!','Please enter the customer id','error');
            component.set("v.spinner",false);
            return ;
        }
        var messageList = component.get("v.messageList");
        var status = component.get("v.selectedStatus");
        var sendList = [];
        
        for(var i = 0 ; i< messageList.length;i++){
            
            var element = messageList[i];
            
            if(element.isChecked){
                sendList.push(messageList[i]);
            }
            
            
        }
        if(sendList.length <= 0){
            helper.showToast('Error!','Please select any deposit','error');
            component.set("v.spinner",false);
            return ;
        }
		
		var action = component.get("c.processData");        
        action.setParams({
            customerId : customerId,
            newStatus : status,
            wrapperList : sendList
            
            
        });
        
        action.setCallback(this, function(response) {
            component.set("v.spinner",true);
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
                if(result != null && result != undefined && result.depositList != null && result.depositList != undefined ){
                    helper.showToast('Success!','You will receive an email once deposits are closed','success');
                    component.set("v.isCheckedHead",false)
                    component.set("v.messageList",result.depositList);
                    component.set("v.showtotalAmount",result.totalAmount);
                    component.set("v.showtotalLength",result.totalDeposits);
                    component.set("v.toShowSelectedAmount",false);
                    
                    component.set("v.isModalOpen", false);
        			component.set("v.spinner",false);
                    
                }else{
                    component.set("v.messageList",[]);
                }
                
                component.set("v.spinner",false);
                
                
            }
            else if (state === "INCOMPLETE") {
                component.set("v.spinner",false);
                helper.showToast('Warning!','Process incomplete','warning'); 
                
                // alert('INCOMPLETE');
            }
                else if (state === "ERROR") {
                    component.set("v.spinner",false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            helper.showToast('Error!',"Error message: " +  errors[0].message,'error');
                            // component.set("v.spinner",false);
                            
                            //  alert("Error message: " +  errors[0].message);
                        }
                    } else {
                        helper.showToast('Error!','Unknown error','error');
                        //  component.set("v.spinner",false);
                        
                        //  alert("Unknown error");
                    }
                }
        });
        
        $A.enqueueAction(action);
        
    },
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        component.set("v.isModalOpen", true);
        
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        var splitList = [];
        component.set("v.isModalOpen", false);
        component.set("v.spinner",false);
        
    },
    
})