({
	    onLoadHelper :function(component, event, helper,branchId){
            var action = component.get('c.getDepositInformation');
        action.setParams({
            branchId: branchId });
        action.setCallback(this, function(response){
            var state = response.getState();
          
            if (state === "SUCCESS"){
               
                var oRes = response.getReturnValue();
                  // alert(oRes.length);
                if(oRes.length > 0){
                    console.log('Deposits-->'+JSON.stringify(oRes));
                    component.set("v.showDeposits",true);
                   	component.set("v.SuccessMessage",false);
                    component.set("v.isShowRepayAwaitingSection",false);
                    component.set("v.transferdepositonebranch",false);
                    component.set("v.transferthedeposits",false);
                    component.set("v.clickedyes",false);
                    component.set("v.bNoRecordsFound" , false);
                    component.set("v.transfertoaglld",false);
                    component.set("v.selectedrowsdeposit",false);
                    component.set("v.transfermultipledeposit",true);
                    component.set("v.isShowRepayInProgressSection",false);
                    var listOfAllDeposits = oRes;

                    // Iterate through the list and format the Start_Date__c
                    for (var i = 0; i < listOfAllDeposits.length; i++) {
                        var startDate = new Date(listOfAllDeposits[i].objDeposit.Start_Date__c);
                       
                        var day = startDate.getDate().toString().padStart(2, '0');
                        var month = (startDate.getMonth() + 1).toString().padStart(2, '0');
                        var year = startDate.getFullYear();
                        console.log('Day:', day);
                        console.log('Month:', month);
                        console.log('Year:', year);
                        
                        listOfAllDeposits[i].objDeposit.Start_Date__c = day + '/' + month + '/' + year;
                    }
                    
                    component.set("v.listOfAllDeposits", listOfAllDeposits);
                    console.log('listOfAllDeposits-->'+JSON.stringify(listOfAllDeposits));
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = listOfAllDeposits;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(listOfAllDeposits[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }
                else{
                    component.set("v.bNoRecordsFound" , true);
                }
            }
            else{
                
            }
        });        
        $A.enqueueAction(action);
        
        // open sub tabs
        var regMultDepTab =  component.find("leftSideSubTabs");
        console.log('weird regMultDepTab -> '+regMultDepTab);
        $A.util.addClass(regMultDepTab, "openSubTab");
    },
    handleDepositSearch : function(component, event, helper,searchKey) { 
        //alert('helper-->');
        var getSelectedNumber = component.get("v.selectedCount");  
        var PaginationLst = [];
        var pageSize = component.get("v.pageSize");
        const branchId = component.get("v.branchId");
        var action = component.get('c.searchdeposit');
        action.setParams({
            searchKey: searchKey });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('State==>'+response.getState());
            if (state === "SUCCESS"){
                
                var oRes = response.getReturnValue();
                console.log('searchResults==>'+JSON.stringify(oRes));
                component.set("v.listOfAllDeposits", oRes);
                //  alert(oRes.length);
                if(oRes.length > 0){
                    
                    var totalLength = oRes.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
                }
                else{
                    component.set('v.PaginationList', []);
                    
                }
            }
            else{
                console.error('Error in handleSearchNew callback: ' + response.getError());
            }
        });        
        $A.enqueueAction(action);
    },
    // navigate to next pagination record set
    next: function(component, event, sObjectList, end, start, pageSize) {
        let selectedData = component.get("v.selectedDepositIds");
        //console.log("selectedData=>"+JSON.stringify(selectedData));
        console.log("nextClick=>"+selectedData.length);
        console.log('@@@ '+sObjectList);
        var Paginationlist = [];
        var counter = 0;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
        console.log('@@ '+ JSON.stringify(component.get("v.selectedDepositIds")));
        console.log('@@137 '+ component.get("v.selectedDepositIds").length);
    },
    // navigate to previous pagination record set
    previous: function(component, event, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                {
                    Paginationlist.push(sObjectList[i]);
                }
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.PaginationList", Paginationlist);
    },
    getRepayAwaitingApproval: function(component, event, helper,branchId){
       // alert('awaitingHelper');
       /*component.set("v.isShowRepayAwaitingSection",true);
         component.set("v.showDeposits",false);
         component.set("v.SuccessMessage",false);*/
       component.set('v.PaginationList', []);
        component.set("v.totalRecordsCount", 0);
        var action = component.get('c.getRepayDepositInformation');
        action.setParams({
            branchId: branchId });
        action.setCallback(this, function(response){
            var state = response.getState();
            //alert('awaitinState-->'+state);
            if (state === "SUCCESS"){
                
                var oRes = response.getReturnValue();
                // alert(oRes.length);
                 
                console.log('AwaitingRepayList==>'+JSON.stringify(response.getReturnValue()));
                if(oRes.length > 0){
               
                    
                    var listOfAllDeposits = oRes;
                     for (var j = 0; j < listOfAllDeposits.length; j++) {
                        var startDate = new Date(listOfAllDeposits[j].objDeposit.Start_Date__c);
                        var day = startDate.getDate().toString().padStart(2, '0');
                        var month = (startDate.getMonth() + 1).toString().padStart(2, '0');
                        var year = startDate.getFullYear();
                        listOfAllDeposits[j].objDeposit.Start_Date__c = day + '/' + month + '/' + year;
                      
                      var endDate = new Date(listOfAllDeposits[j].objDeposit.End_Date__c);
                      var endday = endDate.getDate().toString().padStart(2, '0');
                      var endmonth = (endDate.getMonth() + 1).toString().padStart(2, '0');
                      var endyear = endDate.getFullYear();
                      listOfAllDeposits[j].objDeposit.End_Date__c = endday + '/' + endmonth + '/' + endyear;
                  }
					component.set("v.listOfAllDeposits", oRes);                    
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.listOfAllDeposits").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    

                }
            }
        });        
        $A.enqueueAction(action);
    }
})