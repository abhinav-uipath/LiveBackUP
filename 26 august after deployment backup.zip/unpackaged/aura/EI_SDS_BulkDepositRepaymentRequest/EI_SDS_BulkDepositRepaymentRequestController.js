({
	    doInit : function(component, event, helper) {
        let currentURL = window.location.href;
        let AccessCode = currentURL.split("id=")[1];
        if(AccessCode =='SuccessMsg')
        {
            component.set("v.showSuccessMsg",true);
            let usrls = currentURL.split("id=")[0]+'id=1****3';
            history.pushState(null, '',usrls);
        }
        else
        {
            component.set("v.showSuccessMsg",false);
        }        
        
        // get branchId
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
      //   alert(urlParams);
        var myName;
        var branchId = urlParams.get('branchId');
         if(branchId != null){ 
                const branchIdList = atob(urlParams.get('branchId'));
         		const myArray = branchIdList.split("&");
            //    alert(myArray.length);
             if(myArray.length >2){
              myName = myArray[0]+'&'+myArray[1];
               branchId = myArray[2];
              }else{
                  
                myName = myArray[0];
                  branchId = myArray[1];
               } 
            } 
    
           component.set("v.branchId",branchId);  
    helper.onLoadHelper(component, event, helper,branchId);
    },
    transferMultipleDepositSubTabs : function(component, event, helper) {
        	
             const queryString = window.location.search;
             const urlParams = new URLSearchParams(queryString);
             const branchId = urlParams.get('branchId');
             if(branchId != null){ 
                 component.find("navServiceToOtherSection").navigate({
                     type: "comm__namedPage",
                     attributes: {
                         pageName: "bulkactions"
                     },
                     state: {
                         branchId : branchId
                     }
                 }); 
             }else{
                 component.find("navServiceToOtherSection").navigate({
                     type: "comm__namedPage",
                     attributes: {
                         pageName: "bulkactions"
                     },
                     state: {  }
                 }); 
             }
         },
    
    regMultipleDepositSubTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "registermultipledeposits"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "registermultipledeposits"
                },
                state: {  }
            }); 
        }
    },
    
    downloadMultiplecertificatesTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadbulkcertificates"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadbulkcertificates"
                },
                state: {  }
            }); 
        }
    },
    
    downloadPIFormsTabs : function(component, event, helper) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadpiforms"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadpiforms"
                },
                state: {  }
            }); 
        }
    },
        goBackDepositRecord : function(component, event, helper) {
       /* const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
        if(branchId != null){ 
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "downloadpiforms"
                },
                state: {
                    branchId : branchId
                }
            }); 
        }else{*/
            component.find("navServiceToOtherSection").navigate({
                type: "comm__namedPage",
                attributes: {
                    pageName: "viewdeposit"
                },
                state: {  }
            }); 
       // }
    },
    repaydeposits: function(component, event, helper) {
       // component.set("v.showDeposits",true);
       // component.set("v.isShowRepayAwaitingSection",false);
      // alert('repayDeposits');
        component.set("v.showDeposits",true);
        component.set("v.SuccessMessage",false);
        component.set("v.isShowRepayAwaitingSection", false);
        component.set("v.isShowRepayInProgressSection",false);
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const branchId = urlParams.get('branchId');
       helper.onLoadHelper(component, event, helper,branchId);
        $A.get('e.force:refreshView').fire();
    },
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.listOfAllDeposits");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        //var whichBtn = event.getSource().get("v.name");
        //
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    
        //new added
    /*  navigationselect: function(component, event, helper) {
        var sObjectList = component.get("v.selectedDepositIds");
        var endselect = component.get("v.endPageselecteddeposit");
        var startselect = component.get("v.startPageselecteddeposit");
        var pageSizeselect = component.get("v.pageSizeselecteddepst");

        if (event.target.id == "nextIdselect") {
            component.set("v.currentPageselect", component.get("v.currentPageselect") + 1);
            helper.nextselect(component, event, sObjectList, endselect, startselect, pageSizeselect);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousIdselect") {
            component.set("v.currentPageselect", component.get("v.currentPageselect") - 1);
            helper.previousselect(component, event, sObjectList, endselect, startselect, pageSizeselect);
        }
    },*/
    
    checkboxSelect: function(component, event, helper) {
        component.set("v.nodepositSelected", false);
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        console.log('Selected Count -- '+getSelectedNumber);
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
        
        //var selectedDeposits = [];
         var selectedDeposits = [];
        var checkvalue = component.find("checkDeposit");
        console.log('checkvalue => ' + checkvalue)
        if(!Array.isArray(checkvalue)){
            if (checkvalue.get("v.value")) {
                selectedDeposits.push(checkvalue.get("v.text"));
            }
        }else{
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                    selectedDeposits.push(checkvalue[i].get("v.text"));
                }
            }
        }
        component.set("v.selectedDepositIds",selectedDeposits);
        console.log("Print189 "+selectedDeposits.length);
        var records = component.get("v.selectedDepositIds");
        var totalDepositAmt=0.0;
        for ( var i = 0; i < records.length; i++ ) {
            totalDepositAmt += records.Actual_Protected_Amount__c;
            console.log("Print193"+JSON.stringify(records[i]));
            //alert(records[i].objDeposit.Id);  
            console.log("totalDepositAmt "+totalDepositAmt);
        }
    },
    selectAllCheckbox: function(component, event, helper) {
        component.set("v.nodepositSelected", false);
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listOfAllDeposits = component.get("v.listOfAllDeposits");
        console.log('List of Selected Deposits'+JSON.stringify(listOfAllDeposits));
        var PaginationList = component.get("v.PaginationList");
        // play a for loop on all records list 
        for (var i = 0; i < listOfAllDeposits.length; i++) {
            // check if header checkbox is 'true' then update all checkbox with true and update selected records count
            // else update all records with false and set selectedCount with 0  
            if (selectedHeaderCheck == true) {
                listOfAllDeposits[i].isChecked = true;
                component.set("v.selectedCount", listOfAllDeposits.length);
            } else {
                listOfAllDeposits[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listOfAllDeposits[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.listOfAllDeposits", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
        
        var allRecords = component.get("v.listOfAllDeposits");
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].objDeposit);
            }
        }
        component.set("v.selectedDepositIds",selectedRecords);
    },
    handleSearchNew : function(component, event, helper) { 
        var searchKey = document.getElementById("searchValue").value.trim();  
        component.set('v.searchValue', searchKey);
        console.log('@@ '+searchKey);
        // helper.handleDepositSearch(component, event, helper,searchKey) ;
        var getSelectedNumber = component.get("v.selectedCount");  
        if(searchKey == 'undefined' || searchKey == '' ){
            
            //  helper.handleSearch(component, event, helper,component.get("v.branchId"));
            var pageSize = component.get("v.pageSize");
            var totalRecordsList =  component.get("v.listOfAllDeposits");
            var totalLength = totalRecordsList.length ;
            component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPage",0);
            component.set("v.endPage",pageSize-1);
            
            var PaginationLst = [];
            for(var i=0; i < pageSize; i++){
                if(component.get("v.listOfAllDeposits").length > i){
                    PaginationLst.push(totalRecordsList[i]);    
                } 
            }
            component.set('v.PaginationList', PaginationLst);
            component.set("v.selectedCount" , getSelectedNumber);
            component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));  
            
        }else{
            console.log('Search called');
            function search(nameKey, myArray){
                 let results = [];
                for (let i=0; i < myArray.length; i++) {
                    let obj = myArray[i].objDeposit;
                    if (obj.Name.includes(nameKey)|| obj.Tenants_Name__c.includes(nameKey) ||
                        (obj.Property__r && (
                            (obj.Property__r.Street__c && obj.Property__r.Street__c.includes(nameKey)) ||
                            (obj.Property__r.House_No__c && obj.Property__r.House_No__c.includes(nameKey)) ||
                            (obj.Property__r.County__c && obj.Property__r.County__c.includes(nameKey)) ||
                            (obj.Property__r.City__c && obj.Property__r.City__c.includes(nameKey)) ||
                            (obj.Property__r.Town__c && obj.Property__r.Town__c.includes(nameKey)) ||
                            (obj.Property__r.Postal_Code__c && obj.Property__r.Postal_Code__c.includes(nameKey))
                        ))
                       )  {
                       
                        results.push(myArray[i]);
                    }
                   
                }
                return results;
            }
            
            var array =  component.get("v.listOfAllDeposits");
            var resultObject = search(searchKey, array);
            component.set('v.PaginationList', resultObject);
            //  console.log('## '+resultObject.length);
            var pageSize = component.get("v.pageSize");
            var totalLength =1;
            //    console.log(pageSize+' ## '+totalLength)
            console.log('pagecount '+Math.ceil(totalLength / pageSize));
            component.set("v.selectedCount" , getSelectedNumber);
            //    component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPage",0);
            component.set("v.totalPagesCount", 1);    
        }
        
    }, 
    closePopup: function(component, event, helper) {
        component.set("v.openconfirmbox",false);
       // component.set("v.openConfirmBoxMultiple",false);
    },
    submitRepay:function(component, event, helper) {
        console.log('selectedCount');
        var processedData=[];
        var unprocessedData=[];
        var endDate = document.getElementById("endDateId").value;
        var endMonth = document.getElementById("endMonthId").value;
        var endYear = document.getElementById("endYearId").value;
        
        let selectedData = component.get("v.selectedDepositIds");
        let amountToShow =0;
        console.log("selectedData=>"+JSON.stringify(selectedData));
        
        var allRecords = component.get("v.listOfAllDeposits");
        console.log("selectedDatawithEnddate=>"+JSON.stringify(allRecords));
            var selectedRecords = [];
            for (var i = 0; i < allRecords.length; i++) {
                if (allRecords[i].isChecked) {
                    selectedRecords.push(allRecords[i].objDeposit);
                }
            }
        console.log('line326FinalSelectedList-->'+selectedRecords.length);
        console.log('line326FinalSelectedList-->'+JSON.stringify(selectedRecords));
        selectedRecords.forEach(deposit => {
            let hasNonEmptyEmail = deposit.Deposit_Allocations__r.some(allocation => 
            allocation.Deposit_Holder__r && allocation.Deposit_Holder__r.PersonEmail
            );
            
            if (hasNonEmptyEmail) {
            processedData.push(deposit);
        } else {
            unprocessedData.push(deposit);
    }
});
    		console.log("processedData=>"+JSON.stringify(processedData));
    		console.log("unprocessedData=>"+JSON.stringify(unprocessedData));
			console.log("processedDatalength=>"+processedData.length);
    		console.log("unprocessedDatalength=>"+unprocessedData.length);

			component.set("v.processedDepIdList", processedData);
			component.set("v.unprcessedDepIdList", unprocessedData);
         for(var i=0; i<selectedRecords.length; i++) {
               var listofamount = [];
               amountToShow =  selectedRecords[i].Protected_Amount__c + amountToShow ;
               console.log('depositamount-->'+amountToShow);
            }
         component.set("v.amountToShowOnPopup",parseFloat(amountToShow).toFixed(2));
        
          if(component.get("v.selectedCount")==0 || component.get("v.selectedCount")==undefined)
        {
            component.set("v.nodepositSelected", true);
            
        }
        else if((endDate=="" || endMonth=="" || endYear=="") /*|| 
           (endDate!=null && endMonth!=null && endYear!=null) ||
           (endDate!=undefined && endMonth!=undefined && endYear!=undefined)*/){
            
            component.set("v.isTenEndDateBlank", true);
        }
        else{
            if(!component.get("v.isTenEndDateValid") && !component.get("v.isFutureDateError")){
                component.set("v.nodepositSelected", false);
            	component.set("v.openconfirmbox",true);
                let tenancyEndDate = component.get("v.tenancyEndDate");
                console.log('tenancyEndDate==>'+tenancyEndDate);
            }
           
        }
    },
    confirmRepayDeposits:function (component, event, helper) {
        var tenancyEndDate = component.get("v.tenancyEndDate");
        var selectedData = component.get("v.processedDepIdList");
        var unprocessData = component.get("v.unprcessedDepIdList");
        var mapValues = component.get("v.mapValues");
       // alert('formSubmited');
        console.log('line-->443==>'+JSON.stringify(selectedData));
         var selectedDataID= [];
        for(var i =0;i<selectedData.length;i++){
            selectedDataID.push(selectedData[i].Id);
        }
       // alert('1');
        var selectedDataIds = selectedData.map(function(item) {
            return item.Id;
        });
         //alert('2');
         console.log('selectedDataIds: ' + JSON.stringify(selectedDataIds));
         console.log('mapValues: ' + JSON.stringify(mapValues));
		//console.log('line-->457==>'+JSON.stringify(updatedMapValues));
		console.log('line457@@@'+selectedDataIds.length);
		var updatedMapValues = [];
        if(selectedDataIds.length>0){
            
            updatedMapValues = mapValues.filter(function(record) {
                return selectedDataIds.includes(record.recordId);
            }); 
            component.set("v.mapValues", updatedMapValues);
        }
		
       
        console.log('line-->280==>'+JSON.stringify(selectedDataID));
        console.log('line-->2805==>'+JSON.stringify(unprocessData));
        console.log('line-->457==>'+JSON.stringify(updatedMapValues));
        console.log('line-->2805==>'+unprocessData.length);
        console.log('line-->281==>'+tenancyEndDate);
      
   var action = component.get('c.confirmrepayDeposit');
        action.setParams({
            selectedDataID: selectedDataID,
            tenancyEndDate : tenancyEndDate,
            enddateMapValues : updatedMapValues
        });
        action.setCallback(this, function(response){
            var state = response.getState();
           console.log('returnValue'+response.getReturnValue());
           console.log('state'+state);
            if (state === "SUCCESS"){
                var oRes = response.getReturnValue();
                if(oRes=='Batch Processed'){
                   /* component.set("v.openconfirmbox",false);
                    component.set("v.showDeposits",false);
                    component.set("v.SuccessMessage",true);*/
                    component.set("v.openconfirmbox",false);
                    component.set("v.listOfAllDeposits", unprocessData);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = unprocessData;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    if(unprocessData.length>0){
                        for(var i=0; i < pageSize; i++){
                            if(component.get("v.listOfAllDeposits").length > i){
                                PaginationLst.push(unprocessData[i]);    
                            } 
                        }
                        component.set('v.PaginationList', PaginationLst);
                        component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize)); 
                        component.set("v.isShowUnabletoRepayDeposits",true);
                        console.log('Line361->'+JSON.stringify(component.get("v.PaginationList")));  
                    }
                    component.set("v.showDeposits",false);
                    component.set("v.SuccessMessage",true);
                    component.set("v.isShowRepayAwaitingSection",false);
                    component.set("v.isShowRepayInProgressSection",false);
                }
            }
            else{
                alert('error accured while submitting your reqest'+state);
            }
        });        
        $A.enqueueAction(action);
    },
    viewRepayProgressDeposits: function (component, event, helper) {
        //alert('progress');
        component.set("v.isShowRepayInProgressSection",true);
        component.set('v.PaginationList', []);
        component.set("v.totalRecordsCount", 0);
        component.set("v.showDeposits",false);
        component.set("v.SuccessMessage",false);
        component.set("v.isShowRepayAwaitingSection", false);
       var selectedData=component.get("v.processedDepIdList");
       // alert('selectedDtalist'+selectedData.length);
         var PaginationLst = [];
        var pageSize = component.get("v.pageSize");
        var totalRecordsList = selectedData;
        var totalLength = totalRecordsList.length ;
        component.set("v.totalRecordsCount", totalLength);
        component.set("v.startPage",0);
        component.set("v.endPage",pageSize-1);
                    
         for(var i =0;i<selectedData.length;i++){
            PaginationLst.push(selectedData[i]);
             //alert('inloop');
        }
            component.set('v.PaginationList', PaginationLst);    
       
			 console.log('Line-468-->'+JSON.stringify(PaginationLst));    

    },
    viewRepayAwatingApproval: function (component, event, helper) {
        var branchId = component.get("v.branchId"); 
        //alert('awaiting');
        component.set("v.isShowRepayAwaitingSection",true);
        component.set("v.isShowRepayInProgressSection",false);
        component.set("v.showDeposits",false);
        component.set("v.SuccessMessage",false);
        helper.getRepayAwaitingApproval(component, event, helper,branchId);
    },
    checkTenancyEndDate: function (component, event, helper) {
        
        component.set("v.isTenEndDateValid",false);
        component.set("v.isFutureDateError",false);
        component.set("v.isTenEndDateBlank", false);
        
        var endDate = document.getElementById("endDateId").value;
        var endMonth = document.getElementById("endMonthId").value;
        var endYear = document.getElementById("endYearId").value;
        
        if(endDate!="" && endMonth!="" && endYear!="" && 
           endDate!=null && endMonth!=null && endYear!=null
           && endDate!=undefined && endMonth!=undefined && endYear!=undefined) 
        {
            component.set("v.tenancyEndDate",endDate);
            component.set("v.tenancyEndMonth",endMonth);
            component.set("v.tenancyEndYear",endYear);
            
            let tenancyEndDate = endDate+'-'+endMonth+'-'+endYear;
            let isValidDate = validatedate(tenancyEndDate);
            
            var today = new Date();
            var todayDate = today.getDate();
            var todayMonth = today.getMonth()+1;
            var todayYear = today.getFullYear();
            //component.set("v.isValidTenancyStartDate",isValidDate);
            console.log(isValidDate);
            
            if(isValidDate)
            {
                console.log(`todayDate - ${todayDate} todayMonth - ${todayMonth} - todayYear - ${todayYear}`);
                console.log(`endDate - ${endDate} endMonth - ${endMonth} - endYear - ${endYear}`);
                if(endYear == todayYear)
                {
                    //console.log('Line 84');
                    if(endMonth == todayMonth)
                    {
                        //console.log('Line 87');
                        if(endDate<=todayDate)
                        {
                            component.set("v.isValidTenancyEndDate",true);
                        } else {
                            component.set("v.isFutureDateError",true);
                        }
                    } else if(endMonth < todayMonth) {
                        component.set("v.isValidTenancyEndDate",true);
                    } else {
                        component.set("v.isFutureDateError",true);
                    }
                } else if(endYear < todayYear) {
                    component.set("v.isValidTenancyEndDate",true);
                } else {
                    component.set("v.isFutureDateError",true);
                }
                
            } else {
                component.set("v.isTenEndDateValid",true);
            }
            
            if(!isValidDate || component.get("v.isFutureDateError"))
            {
                component.set("v.buttonClicked","");
                component.set("v.isValidTenancyEndDate",false);
            }
            
            if(component.get("v.isValidTenancyEndDate"))
            {
                //let setEndDate = todayYear+'-'+todayMonth+'-'+todayDate;
                //let setEndDate = endYear+'-'+endMonth+'-'+endDate;
                let setEndDate = endDate+'/'+endMonth+'/'+endYear;
                component.set("v.tenancyEndDate",setEndDate);
                console.log('Line 573 -> ',component.get("v.tenancyEndDate"));
                
                var paginationList = component.get("v.listOfAllDeposits");
                paginationList.forEach(function(record) {
                    record.End_Date__c = setEndDate;
                });
                var mapValues = [];
                paginationList.forEach(function(record) {
                    var mapValue = {
                        recordId: record.objDeposit.Id, 
                        endDate: record.End_Date__c
                    };
                    mapValues.push(mapValue);
                });
                
                 component.set("v.mapValues", mapValues);
                 console.log('mapValueswithComonEnddate-->'+JSON.stringify(component.get("v.mapValues")));
                component.set("v.PaginationList", paginationList);
               // component.set("v.listOfAllDeposits", paginationList);
                console.log('updatedWithEndDate-->'+JSON.stringify(paginationList));
            }
            
            //GOD class to check date validity
            function validatedate(d)
            {
                var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
                // Match the date format through regular expression
                if(d.match(dateformat))
                {     
                    var splittedDate = d.split('-');
                    var splittedDateLength = splittedDate.length;
                    if (splittedDateLength>1)
                    {
                        var pdate = d.split('-');
                    }
                    var dd = parseInt(pdate[0]);
                    var mm  = parseInt(pdate[1]);
                    var yy = parseInt(pdate[2]);
                    
                    // Create list of days of a month [assume there is no leap year by default]
                    var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];
                    if (mm==1 || mm>2)
                    {
                        if (dd>ListofDays[mm-1])
                        {
                            return false;
                        }
                    }
                    if (mm==2)
                    {
                        var lyear = false;
                        if ( (!(yy % 4) && yy % 100) || !(yy % 400)) 
                        {
                            lyear = true;
                        }
                        if ((lyear==false) && (dd>=29))
                        {
                            return false;
                        }
                        if ((lyear==true) && (dd>29))
                        {
                            return false;
                        }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
    },
      
     handleUpdateFieldData : function(component, event, helper) {
        var recordId = event.getSource().get("v.title"); // Assuming title contains the recordId
        var updatedEndDate = event.getSource().get("v.value");
        var paginationList = component.get("v.listOfAllDeposits");
        var mapValues =component.get("v.mapValues");
        
        // Find the record with the matching recordId
      
        var targetRecord = paginationList.find(record => record.recordId === recordId);
        if (targetRecord) {
            // Update the tenancy end date for the targeted record
            targetRecord.End_Date__c = updatedEndDate;
        }
         var existingRecord = mapValues.find(record => record.recordId === recordId);
         if (existingRecord) {
             // Update the endDate of the existing record
             existingRecord.endDate = updatedEndDate;
         } else {
             // Create a new record object
             var updatedRecord = {
                 recordId: recordId,
                 endDate: updatedEndDate
             };
             // Push the new record object to mapValues
             mapValues.push(updatedRecord);
         }

         component.set("v.mapValues", mapValues);
         //component.set("v.listOfAllDeposits", paginationList);
         component.set("v.paginationList", paginationList);
         console.log('mapValues-->'+JSON.stringify(component.get("v.mapValues")));
         console.log('AfterAmendingEndDate-->'+JSON.stringify(paginationList));
         
    },
    hideBootstrapErrors: function(component, event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "nodeposit":
                component.set("v.nodepositSelected", false);
                break;
            case "singleBlank":
                component.set("v.singleBlankValue", false);
                break;
            case "pSuccessMessage":
                component.set("v.showSuccessMsg", false);
                break;
            case "nobranch":    
                component.set("v.nobranchSelected", false);
                break;
            case "validemailcheck":    
                component.set("v.emailNotValid", false);
                break;
        }
    }
})