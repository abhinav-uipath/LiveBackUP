({
    doInit : function(component, event, helper) {
        
        //console.log('***'+component.get("v.recordId"));
        var action = component.get("c.getPicklistvalues");
        action.setParams({
            'objectName': 'Evidence_Attachment__c',
            'category_apiname': 'Evidence_Categories__c',
            'userType_apiname': 'NHOS_Type__c',
            'recordId':component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            var state = a.getState();
            if (state === "SUCCESS"){
                component.set("v.category", a.getReturnValue().category);
                component.set("v.userType", a.getReturnValue().userType);
                console.log('user type : '+a.getReturnValue().userType);
                component.set("v.complaintType", a.getReturnValue().complaintType);
                let recordTypeName = a.getReturnValue().recordType;
                //console.log('recordTypeNameList : '+recordTypeName);
                if(recordTypeName == 'TRS Complaint') {
                    component.set("v.scheme", 'TRS');
                    helper.setSecureUri(component);
                } else if(recordTypeName == 'NHOS Complaint') {
                    component.set("v.scheme", 'NHOS');
                    helper.setSecureUri(component);
                }
            }
        });
        $A.enqueueAction(action);
        
        /*var action1 = component.get("c.getSecureURI"); 
        action1.setParams({
            scheme : component.get("v.scheme")
        });
        action1.setCallback(this, function(a) {
            let state = a.getState();
            let errors = a.getError();            
            if (state == "SUCCESS") {
                let ReturnValue = a.getReturnValue();
                console.log('ReturnValue '+ReturnValue);
                component.set("v.secureURI", ReturnValue); 
            }
        });
        $A.enqueueAction(action1);*/
        
    },
    next : function(component, event, helper) {
        if((component.find("catg").get("v.value")) && (component.find("usrTyp").get("v.value"))) {
            var action = component.get("c.getAreaOfComplaint");
            action.setParams({
                'recordId': component.get("v.recordId"),
                'catName': component.get("v.categorySelVal")
            });
            action.setCallback(this, function(a) {
                var state = a.getState();
                if (state === "SUCCESS"){
                    if(a.getReturnValue()=='limit exceed'){
                        component.set("v.showEvidenceCmp", false);
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: 'Number of file limit has been exceed.',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
                    }else{
                   	 component.set("v.areasOfComplaintId", a.getReturnValue());
                     component.set("v.showEvidenceCmp", true);
                   }
                }
            });
            $A.enqueueAction(action);   
        }else{
            alert('Both fields are required.');
        }
    },
    handleFilesChange : function(component, event, helper) {
        //var files = event.getSource().get("v.files");
        component.set("v.message", "");
        var filess = component.set("v.fileList",component.get("v.fileList")); 
        var files = component.get("v.fileList");
        let icon = files[0].name.toLowerCase();
        component.set("v.fileName", files[0].name);
        component.set("v.fileLableVisible", true);
        //const ext = ['.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
        //var fileTypeCheck = ext.some(el => icon.endsWith(el));
        /*if(fileTypeCheck==true){
            component.set("v.fileLableVisible", true);
        } */
    },
    addEvidence : function(component, event, helper) {
        //var files = event.getSource().get("v.files");
        var files = component.get("v.fileList"); 
       // console.log('***'+files);
        if(files == null || files == undefined || files == '')
        {
             var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: 'Please select a file.',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
        }
        else
        { 
          //  console.log('***111'+files);
        var getFileLabel = document.getElementById("filelabel").value;
        if(getFileLabel=='' && component.get("v.fileLableVisible")==true){
            component.set("v.fileLable", 'Please provide a lable to upload file.');
        }else if(getFileLabel.length > 50){
            component.set("v.fileLable", 'Character limit is 50.');
        }else{
            component.set("v.submitBtn", false);
            var action = component.get("c.getSecureURI"); 
            action.setParams({
                scheme : component.get("v.scheme")
            });
            action.setCallback(this, function(a) {
                let state = a.getState();
                let errors = a.getError();
               // console.log('state-->>'+state);
              //  console.log('errors-->>'+JSON.stringify(a.getError()));
                if (state == "SUCCESS") {
                    let ReturnValue = a.getReturnValue();
                    //console.log('ReturnValue'+ReturnValue);
                    component.set("v.secureURI", ReturnValue); 
                }
            });
            $A.enqueueAction(action);
            
            component.set("v.fileLable", '');
            helper.readFile(component, helper, files[0],getFileLabel);
        }}
    }
})