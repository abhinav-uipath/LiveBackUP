({
    setSecureUri: function(component) {
        var action1 = component.get("c.getSecureURI"); 
        action1.setParams({
            scheme : component.get("v.scheme")
        });
        action1.setCallback(this, function(a) {
            let state = a.getState();
            let errors = a.getError();            
            if (state == "SUCCESS") {
                let ReturnValue = a.getReturnValue();
                //console.log('ReturnValue '+ReturnValue);
                component.set("v.secureURI", ReturnValue); 
            }
        });
        $A.enqueueAction(action1);
    },

	readFile: function(component, helper, file,fileLable) {
        //console.log('read file');
        let recordId = component.get("v.recordId");
        const currentDate = new Date();
        const timestamp = currentDate.getTime();
        if (!file) return;
        
        let icon = file.name.toLowerCase();
        //const ext = ['.pdf', '.doc', '.docx', '.txt', '.rtf','.odt', '.xls', '.xlsx', '.ods', '.msg', '.csv', '.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp', '.mp3', '.mp4', '.wmv', '.wav', '.ppt', '.pptx'];
        const ext = component.get("v.fileExt"); //['.csv', '.doc', '.docx', '.pdf', '.ppt', '.pptx', '.rtf', '.txt', '.xls', '.xlsx', '.odt', '.bmp', '.jpeg', '.jpg', '.png', '.tif', '.tiff', '.mp3', '.wav', '.mov', '.mpeg', '.mpg', '.zip'];
        var fileTypeCheck = ext.some(el => icon.endsWith(el));
        if (!fileTypeCheck) {
           component.set("v.submitBtn", true);
           return alert("File type not supported!");
        }
        
        var sizeInMB = (file.size / (1024*1024)).toFixed(2);
        if(sizeInMB > component.get("v.fileMaxSize")){
             component.set("v.submitBtn", true);
             return alert("File size is greater than 20mb");
        }
        var fileName;
        //console.log('file : '+file.name);
        try {
            fileName = file.name.replaceAll(" ", "_");
        } catch(error) {
            //console.log('error : '+error);
        }
        
        //console.log('file name '+fileName);
        var baseUrl = component.get("v.secureURI");
        var baseUrlLength = baseUrl.length;
        var indexOfQueryStart = baseUrl.indexOf("?");
        var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
        var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ fileName+ baseUrl.substring(indexOfQueryStart);
        component.set("v.azureLink", baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ fileName+sasKeys);
        component.set("v.fileNameInAzure", recordId+'-'+timestamp +'-'+ fileName);
        
        var reader = new FileReader();
        reader.onload = function() {
            var dataURL = reader.result;
            helper.upload(component, file, dataURL.match(/,(.*)$/)[1],submitUri,fileLable);
        };
        reader.readAsDataURL(file);
    },
    
    upload: function(component, file, base64Data,submitUri,fileLable) {
        var xhr = new XMLHttpRequest();
        var endPoint = submitUri;
        component.set("v.message", "Uploading...");
        //console.log('endpoint : '+endPoint);
        xhr.open("PUT", endPoint, true);
        xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.onreadystatechange = function () {
            //console.log('state : '+xhr.readyState);
            
            let currentDateTime = new Date().toISOString();

            // Extract the date and time parts
            let date = JSON.stringify(new Date(file.lastModified));
            let datesplit = date.replace("T",' ');
            let finaldate = datesplit.slice(1, 20);
            
            if (xhr.readyState === 4 && xhr.status === 201) {   
                
                window.setTimeout(
                    $A.getCallback(function() {
                    })
                    ,1000);
                
                var action = component.get("c.saveFile"); 
                action.setParams({
                    parentId: component.get("v.recordId"),
                    areaOfCpml:component.get("v.areasOfComplaintId"),
                    fileName: file.name,
                    azureLink: component.get('v.azureLink'),
                    userType: component.get('v.userTypeSelVal'),
                    fileType :(file.name).split('.').pop(),	
                    fileSize :file.size,
                    fileLable :fileLable,
                    evidenceCategories : component.get('v.categorySelVal'),
                    fileNameInAzure : component.get('v.fileNameInAzure'),
                    source : 'Case Manager',
                    scheme : component.get("v.scheme"),
                    createdate : finaldate
                });
                action.setCallback(this, function(a) {
                    let state = a.getState();
                    let errors = a.getError();
                    //console.log('state save : '+JSON.stringify(state));
                    //console.log('helper errors-->>'+JSON.stringify(errors));
                    if (state == "SUCCESS") {
                        
                        
                     let resultValue = a.getReturnValue();
                        
                        if(resultValue.status == 'Error' && resultValue.message == 'File limit exceeded')
                        {
                             component.set("v.submitBtn", true);
                                alert(resultValue.message);
                                 
                        }
                        else if(resultValue.status == 'Error')
                        {
                                component.set("v.submitBtn", true);
                                alert(resultValue.message);
                        }
                        else
                        {
                            let ReturnValue = resultValue.EvidenceAttachment ;//a.getReturnValue();   
                       // let ReturnValue = a.getReturnValue();
                        //component.set("v.message", "Image uploaded");
                        component.set("v.message", "");
                        component.set("v.fileLableVisible", false); 
                        component.set("v.fileName", "");
                        component.set("v.showEvidenceCmp", false); 
                        //component.set("v.fileLable", '');
                        //document.getElementById("filelabel").value='';
                        
                        let toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Info',
                            message: 'File Uploaded Successfully',
                            duration:' 5000',
                            key: 'success_alt',
                            type: 'success',
                            mode: 'dismissible'
                        });
                        toastEvent.fire();
                        component.set("v.submitBtn", true);
                        }
                    }
                });
                $A.enqueueAction(action);
                
            }else{
                //image error code
            }
        };
        xhr.send(file);
    }
})