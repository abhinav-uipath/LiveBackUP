({
    showToast : function(title,msg,type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message:msg,
            duration:' 5000',
            key: 'info_alt',
            type: type,
            mode: 'dismissible'
            
        });
        toastEvent.fire();
    }
})