({
    navigateToeDiscoverySearchCmp : function(component, event, helper) {
        console.log('recordid => ' + component.get("v.recordId") );
        
        var action = component.get("c.DepositList");
        var recordId =  component.get("v.recordId")
        console.log("recordIdNew="+recordId);
        action.setParams({
           accountId :  component.get("v.recordId")
        });
        
        action.setCallback(this, function(response) {
           component.set("v.spinner",true);
            var state = response.getState();
            console.log("State="+state);
            if (state === "SUCCESS") {
                var depositResponse =response.getReturnValue();
                if(depositResponse.length > 0){
                    console.log("Result="+depositResponse);
                    component.set("v.depositeList", depositResponse);
                    var evt = $A.get("e.force:navigateToComponent");
                    evt.setParams({
                        componentDef : "c:EI_SDS_TransferDepositsList",
                        componentAttributes: { 
                            accountId : component.get("v.recordId") ,
                            depositeList : depositResponse
                        }
                    });  
                    evt.fire();
                }
                else{
                    component.set("v.showInputComponent", true);
                }
            }
        });
        $A.enqueueAction(action);
    } 
})