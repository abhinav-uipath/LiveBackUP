({
    
    helperSaveDataToAttribute: function (component, event, helper) 
    {
		if (component.get("v.SellingDetailedSection") == true) 
        {
			component.set("v.SellingComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", document.getElementById("SellingIdentifyCodeDeveloperBreached").value);
            component.set("v.SellingComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("SellingBreacheNotAddressedYourConcerns").value);
            component.set("v.SellingComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", document.getElementById("SellingEvidenceUploadSupportsYourCase").value);
            component.set("v.SellingComp.AreasOfComplaint.HD_Summary__c", document.getElementById("SellingSummary").value);
            component.set("v.SellingComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", document.getElementById("SellingFurtherInformationSeekingLossCost").value);
           // component.set("v.SellingComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", document.getElementById("SellingProposaltoSettletheComplaint").value);
            
		}
        
		if (component.get("v.LegalInspectionCompletionDetailedSection") == true) 
        {
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", document.getElementById("LegalIdentifyCodeDeveloperBreached").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("LegalBreacheNotAddressedYourConcerns").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", document.getElementById("LegalEvidenceUploadSupportsYourCase").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Summary__c", document.getElementById("LegalSummary").value);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", document.getElementById("LegalFurtherInformationSeekingLossCost").value);
           // component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", document.getElementById("LegalProposaltoSettletheComplaint").value);

		}
        
		if (component.get("v.AfterSalesDetailedSection") == true) 
        {
			component.set("v.AfterSalesComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", document.getElementById("AfterSalesIdentifyCodeDeveloperBreached").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("AfterSalesBreacheNotAddressedYourConcerns").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", document.getElementById("AfterSalesEvidenceUploadSupportsYourCase").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Summary__c", document.getElementById("AfterSalesSummary").value);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", document.getElementById("AfterSalesFurtherInformationSeekingLossCost").value);
          //  component.set("v.AfterSalesComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", document.getElementById("AfterSalesProposaltoSettletheComplaint").value);

		}
        
        if (component.get("v.OtherDetailedSection") == true) 
        {
			component.set("v.OtherComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", document.getElementById("OtherBreacheNotAddressedYourConcerns").value);
            component.set("v.OtherComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", document.getElementById("OtherEvidenceUploadSupportsYourCase").value);
            component.set("v.OtherComp.AreasOfComplaint.HD_Summary__c", document.getElementById("OtherSummary").value);
            component.set("v.OtherComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", document.getElementById("OtherFurtherInformationSeekingLossCost").value);
          //  component.set("v.OtherComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", document.getElementById("OtherProposaltoSettletheComplaint").value);
		}
        
		if (component.get("v.WarrantyProviderDetailedSection") == true) 
        {
			component.set("v.WarrantyProviderComp.AreasOfComplaint.HD_Summary__c", document.getElementById("WarrantyProviderSummary").value);
			
        }
     
	},
    
    helperAccordionEvent: function (component, event, helper, Selling, LegalInspectionCompletion, AfterSales, WarrantyProvider, Other) 
    {
		component.set("v.SellingDetailedSection", Selling);
		component.set("v.LegalInspectionCompletionDetailedSection", LegalInspectionCompletion);
		component.set("v.AfterSalesDetailedSection", AfterSales);
		component.set("v.WarrantyProviderDetailedSection", WarrantyProvider);
		component.set("v.OtherDetailedSection", Other);
       
     
	
	},
    
    
	helperUpdateAreaOfComplaint: function (component, event, helper, complaintList, isContinue,areaName) 
    {
		var action = component.get("c.UpdateAreaOfComplaint");
       // console.log("Result--", JSON.stringify(complaintList));
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
            caseObj: component.get("v.case")
		});
        
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
            //alert(state);
			if (state == "SUCCESS") 
            {
				if (result == 'Success') 
                {
                    if (isContinue == true) 
                    {
                       /* helper.helperExpandDetailSection(component, event, helper);
                        component.set("v.detailedSection", false);
                        component.set("v.reviewSection", true);
                        component.set("v.thankYouSection", false);
                        
                        window.scroll({top: 0,behavior: 'smooth'});*/
                         component.set("v.reviewSaveWarningMsg",true);
                        component.set("v.reviewSubmitWarningMsg",false);
                        component.set("v.isActiveReviewContinueBtn",false);
                    } 
                    else
                    {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Success',
                            message: 'Data has been saved successfully',
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'success',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                        
                        
                        if (areaName == 'Selling')//if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true &&  component.get("v.SellingDetailedSection") == true) 
                        {  
                            if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
                            {
                                component.set("v.LegalInspectionCompletionDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                                
                                $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
                            } 
                            else if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
                            {
                                component.set("v.AfterSalesDetailedSection", true);
                                //component.set("v.SellingDetailedSection",false);
                                 $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
                            } 
                            else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.SellingDetailedSection",false);
                                 $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            } 
                         
                        } 
                        else if (areaName == 'LegalInspectionCompletion')//else if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true && component.get("v.LegalInspectionCompletionDetailedSection") == true) 
                        {
                            if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
                            {
                                component.set("v.AfterSalesDetailedSection", true);
                                //component.set("v.LegalInspectionCompletionDetailedSection",false);
                                $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
                            } 
                             else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                               // component.set("v.LegalInspectionCompletionDetailedSection",false);
                                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.LegalInspectionCompletionDetailedSection",false);
                                $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            } 
                           
                        } 
                        else if (areaName == 'AfterSales')//else if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true && component.get("v.AfterSalesDetailedSection") == true) 
                        {
                            if(component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
                            {
                                component.set("v.OtherDetailedSection", true);
                               // component.set("v.AfterSalesDetailedSection",false);
                                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
  
                            }
                            else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.AfterSalesDetailedSection",false);
                                 $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            } 
                            
                        } 
                        else if (areaName == 'Other')//else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true && component.get("v.OtherDetailedSection") == true) 
                        {
                            if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
                            {
                                component.set("v.WarrantyProviderDetailedSection", true);
                               // component.set("v.OtherDetailedSection",false);
                                 $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
                            }
                        }
                      
                        
                    }
                }
                else
                {
                     var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
				
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    
    helperExpandDetailSection: function (component, event, helper) 
    {
		component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.SellingDetailedSection", true);
		} 
        else if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.LegalInspectionCompletionDetailedSection", true);
		} 
        else if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.AfterSalesDetailedSection", true);
		} 
        else if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.OtherDetailedSection", true);
		}
        else if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.WarrantyProviderDetailedSection", true);
		} 
        
	},
    
    
    
    helperSaveReviewComplaint: function (component, event, helper, complaintList, isSubmit) 
    {
		var action = component.get("c.SaveReviewComplaint");
       
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
			caseObj: component.get("v.case"),
			isSubmitCase: isSubmit
		});
        
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
			if (state == "SUCCESS") 
            {
                if(result == 'Success') 
                {
                    if(isSubmit == false)
                    {
                       component.set("v.reviewSaveWarningMsg",true);
                        component.set("v.reviewSubmitWarningMsg",false);
                        component.set("v.isActiveReviewContinueBtn",false);
                    }
                    else
                    {
                        component.set("v.detailedSection", false);
                        component.set("v.reviewSection", false);
                        component.set("v.thankYouSection",true);
                        component.set("v.isCancel",true);
                    }
                }
                else
                {
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    helperSaveAddtionalCommentComplaint: function(component, event, helper, complaintList) 
    {
    
		var action = component.get("c.SaveAdditionalComplaint");
        // alert(JSON.stringify(complaintList));
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
			caseObj: component.get("v.case"),
            isHouseBuilder: component.get("v.isHouseBuilder")
		});
       
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
          
			if (state == "SUCCESS") 
            {
                if(result == 'Success') 
                {
                    component.set("v.detailedSection", false);
                        component.set("v.reviewSection", false);
                        component.set("v.thankYouSection",true);
                    component.set("v.isCancel",true);
                   
                }
                else
                {
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
    helperSavedraftDecisionComplaint: function(component, event, helper, complaintList) 
    {
    
		var action = component.get("c.SavedraftDecisionComplaint");
        // alert(JSON.stringify(complaintList));
		component.set("v.showSpinner", true);
		action.setParams({
			areaOfComplaintList: complaintList,
			caseObj: component.get("v.case"),
            isHouseBuilder: component.get("v.isHouseBuilder")
		});
       
		action.setCallback(this, function (response) {
			var state = response.getState();
            var result = response.getReturnValue();
          
			if (state == "SUCCESS") 
            {
                if(result == 'Success') 
                {
                    component.set("v.detailedSection", false);
                        component.set("v.reviewSection", false);
                        component.set("v.thankYouSection",true);
                    component.set("v.isCancel",true);
                   
                }
                else
                {
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
			} 
            else if (state === "ERROR") 
            {
                var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: JSON.stringify(result),
                            duration:' 5000',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
            }
			component.set("v.showSpinner", false);
		});
		$A.enqueueAction(action);
	},
    
})