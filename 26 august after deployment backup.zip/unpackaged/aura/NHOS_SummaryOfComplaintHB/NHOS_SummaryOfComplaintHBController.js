({
	doInit: function (component, event, helper) 
    {
        
        var isSpoofLogin = component.get("v.isSpoofLogin");
                var caseStatus = component.get("v.case.Status");
                var isHouseBuilder = component.get("v.isHouseBuilder");
        
        component.set("v.isHouseBuilderEvidenceSubmit",true);
            component.set("v.isHouseBuilderEvidenceReadOnly",false);
            component.set("v.additionalComment1",false);
        component.set("v.additionalComment1ReadOnly",false);
      
        if((isSpoofLogin == true && caseStatus == 'Complaint accepted – awaiting developer/housebuilder response') || caseStatus == 'Developer/housebuilder evidence submitted - Review in progress'
              || caseStatus == 'Developer/housebuilder evidence submitted - supplementary comments' || caseStatus == 'Portal closed – Pre-ombudsman review' 
              || caseStatus == 'Awaiting Ombudsman draft decision' || caseStatus == 'Draft decision issued' || caseStatus == 'On Hold'
              || caseStatus == 'Deadline for comments passed – pending final decision' || caseStatus == 'Final decision issued'
              || caseStatus == 'Complaint Resolved' ||  caseStatus == 'Ombudsman Decision Issued' || caseStatus == 'Complaint cancelled'
               || caseStatus == 'Final decision accept' ||  caseStatus == 'Final decision reject'  )
        {
            component.set("v.isHouseBuilderEvidenceSubmit",false);
            component.set("v.isHouseBuilderEvidenceReadOnly",true);
            component.set("v.additionalComment1",false);
            component.set("v.additionalComment1ReadOnly",false);
            component.set("v.draftDecisionSection",false);
            component.set("v.draftDecisionReadOnly",false);
            component.set("v.finalDecisionSection",false);
            
            if(isSpoofLogin == false && caseStatus == 'Developer/housebuilder evidence submitted - supplementary comments')
            {
                component.set("v.additionalComment1",true);
                
               var HDComment1 = component.get("v.case.Registered_Developer_Additional_Comments__c")
               var HBComment1 = component.get("v.case.Customer_Additional_Comments__c")
            
            }
            
            if(caseStatus == 'Portal closed – Pre-ombudsman review' || caseStatus == 'Awaiting Ombudsman draft decision' || caseStatus == 'Complaint Resolved'
               ||  caseStatus == 'Ombudsman Decision Issued' || caseStatus == 'Draft decision issued' || caseStatus == 'On Hold'
               || caseStatus == 'Deadline for comments passed – pending final decision' 
               || caseStatus == 'Final decision issued'
               || caseStatus == 'Complaint cancelled'
               || (isSpoofLogin == true && caseStatus == 'Developer/housebuilder evidence submitted - supplementary comments'))
            {
                component.set("v.additionalComment1ReadOnly",true);
                component.set("v.additionalComment1",true);
            }
            
            if(isSpoofLogin == false && caseStatus == 'Draft decision issued')
            {
                 component.set("v.draftDecisionSection",true);
            }
            
            if( caseStatus == 'Ombudsman Decision Issued' 
               || caseStatus == 'Deadline for comments passed – pending final decision' 
               || caseStatus == 'Final decision issued'
               || caseStatus == 'Final decision accept' ||  caseStatus == 'Final decision reject'
               || (isSpoofLogin == true && caseStatus == 'Draft decision issued'))
            {
                component.set("v.draftDecisionSection",true);
                component.set("v.draftDecisionReadOnly",true);
            }
            
            if( caseStatus == 'Final decision issued' || caseStatus == 'Ombudsman Decision Issued' 
               || caseStatus == 'Final decision accept' ||  caseStatus == 'Final decision reject')
            {
               component.set("v.finalDecisionSection",true); 
            }
            
        }
        
       component.set("v.currentUserType",'Registered Developer');
     
        if (component.get("v.additionalComment1") == true)//(component.get("v.AdditionalCommentsComp.isSelected") != undefined && component.get("v.AdditionalCommentsComp.isSelected") == true) 
        {
			component.set("v.AdditionalCommentsSection", true);
        } 
        //else 
        if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			component.set("v.SellingDetailedSection", true);
		} 
        //else 
        if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			component.set("v.LegalInspectionCompletionDetailedSection", true);
		} 
       //else 
        if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			component.set("v.AfterSalesDetailedSection", true);
		} 
        //else 
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			component.set("v.OtherDetailedSection", true);
		}
        //else 
        if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			component.set("v.WarrantyProviderDetailedSection", true);
		} 
        
        if(component.get("v.finalDecisionSection") == true)
        {
           
                 setTimeout(function(){ 
                 $("html, body").animate( { scrollTop: $("#finalDecisionSectionDiv").offset().top-25}, 500 );
                 }, 100);
		} 
        else if (component.get("v.draftDecisionSection") == true &&  caseStatus != 'Complaint Resolved' && 
            caseStatus != 'Ombudsman Decision Issued' && caseStatus != 'Complaint cancelled')
         {
           
                 setTimeout(function(){ 
                 $("html, body").animate( { scrollTop: $("#draftDecisionSectionDiv").offset().top-25}, 500 );
                 }, 100);
		} 
        else if (component.get("v.additionalComment1") == true &&  caseStatus != 'Complaint Resolved' && 
            caseStatus != 'Ombudsman Decision Issued' && caseStatus != 'Complaint cancelled')
         {
           
                 setTimeout(function(){ 
                 $("html, body").animate( { scrollTop: $("#additionalComment1Div").offset().top-25}, 500 );
                 }, 100);
		}    
		
	},
    
    hideBootstrapErrors: function (component, event, helper) 
    {
        var button_Name = event.target.name;
		switch (button_Name) 
        {
		case "summariseErrorMessage":
			component.set("v.summariseError", false);
			break;
        case "SellingIdentifyCodeDeveloperBreachedName":
			component.set("v.SellingIdentifyCodeDeveloperBreachedId", false);
			break;
        case "SellingBreacheNotAddressedYourConcernsName":
			component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
			break;
        case "SellingBreacheNotAddressedYourConcernsName":
			component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
			break;
        case "SellingEvidenceUploadSupportsYourCaseName":
			component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
			break;
        case "SellingSummaryName":
			component.set("v.SellingSummaryError", false);
			break; 
        case "SellingFurtherInformationSeekingLossCostName":
			component.set("v.SellingFurtherInformationSeekingLossCostError", false);
			break;
        case "LegalIdentifyCodeDeveloperBreachedName":
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
			break;
        case "LegalBreacheNotAddressedYourConcernsName":
			component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
			break;
        case "LegalEvidenceUploadSupportsYourCaseName":
			component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
			break;
        case "LegalSummaryName":
			component.set("v.LegalSummaryError", false);
			break;
        case "LegalFurtherInformationSeekingLossCostName":
			component.set("v.LegalFurtherInformationSeekingLossCostError", false);
			break; 
         case "AfterSalesIdentifyCodeDeveloperBreachedName":
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
			break;
        case "AfterSalesBreacheNotAddressedYourConcernsName":
			component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
			break;
        case "AfterSalesEvidenceUploadSupportsYourCaseName":
			component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
			break;
        case "AfterSalesSummaryName":
			component.set("v.AfterSalesSummaryError", false);
			break;
        case "AfterSalesFurtherInformationSeekingLossCostName":
			component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
			break;
        case "OtherBreacheNotAddressedYourConcernsName":
			component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
			break; 
        case "OtherEvidenceUploadSupportsYourCaseName":
			component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
			break;
        case "OtherSummaryName":
			component.set("v.OtherSummaryError", false);
			break;
        case "OtherFurtherInformationSeekingLossCostName":
			component.set("v.OtherFurtherInformationSeekingLossCostError", false);
			break;
        case "WarrantyProviderSummaryName":
			component.set("v.WarrantyProviderSummaryError", false);
			break;
        case "HBAdditionalCommentsId":
			component.set("v.HBAdditionalCommentsError", false);
			break;
        case "HDAdditionalCommentsId":
			component.set("v.HDAdditionalCommentsError", false);
			break; 
                
       case "SellingSectionInCmpId":
			component.set("v.SellingSectionInCmp", false);
			break;
       case "LegalInspectionCompletionSectionInCmpId":
			component.set("v.LegalInspectionCompletionSectionInCmp", false);
			break;
       case "AfterSalesSectionInCmpId":
			component.set("v.AfterSalesSectionInCmp", false);
			break;
       case "WarrantyProviderSectionInCmpId":
			component.set("v.WarrantyProviderSectionInCmp", false);
			break;
       case "OtherSectionInCmpId":
			component.set("v.OtherSectionInCmp", false);
			break;
                
        case "HBDraftDecisionCommentsId":
			component.set("v.HBDraftDecisionCommentsError", false);
			break;
       case "RDDraftDecisionCommentsId":
			component.set("v.RDDraftDecisionCommentsError", false);
			break;        
              
        }
    },
    
    accordionSellingDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
		helper.helperAccordionEvent(component, event, helper, !component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
       $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 25 },500);
    
    },
    
    
	accordionLegalInspectionCompletionDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), !component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        //helper.helperAccordionEvent(component, event, helper, false, !component.get("v.LegalInspectionCompletionDetailedSection"), false, false, false);
        $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 25 },500);
    },
    
    
	accordionAfterSalesDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), !component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        //helper.helperAccordionEvent(component, event, helper, false, false, !component.get("v.AfterSalesDetailedSection"), false, false);
         $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 25 },500);
    },
    
    
	accordionWarrantyProviderDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
		helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), !component.get("v.WarrantyProviderDetailedSection"), component.get("v.OtherDetailedSection"));
        //helper.helperAccordionEvent(component, event, helper, false, false, false, !component.get("v.WarrantyProviderDetailedSection"), false);
         $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 25 },500);
    },
    
    
	accordionOtherDetailedSection: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
		helper.helperAccordionEvent(component, event, helper, component.get("v.SellingDetailedSection"), component.get("v.LegalInspectionCompletionDetailedSection"), component.get("v.AfterSalesDetailedSection"), component.get("v.WarrantyProviderDetailedSection"), !component.get("v.OtherDetailedSection"));
        //helper.helperAccordionEvent(component, event, helper, false, false, false, false, !component.get("v.OtherDetailedSection"));
        $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 25 },500);
    },
    
    SaveSellingData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("SellingIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("SellingBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("SellingEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("SellingSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("SellingFurtherInformationSeekingLossCost").value;
        
        // var ProposaltoSettletheComplaint = document.getElementById("SellingProposaltoSettletheComplaint").value;
        
		
		component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
        component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
        component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
        component.set("v.SellingSummaryError", false);
        component.set("v.SellingFurtherInformationSeekingLossCostError", false);
        component.set("v.SellingSectionInCmp", false);
		
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.SellingFurtherInformationSeekingLossCostError", true);
            component.set("v.SellingSectionInCmp", true);
			isValid = false;
		}
        
		
		if (isValid == true) 
        {
			component.set("v.SellingComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.SellingComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.SellingComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.SellingComp.AreasOfComplaint.HD_Summary__c", Summary);
            component.set("v.SellingComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
           // component.set("v.SellingComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", ProposaltoSettletheComplaint);
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'Selling'); 
		} 
        else 
        {
			
             $("html, body").animate( { scrollTop: $("#DetailSelling").offset().top-25},  500);
		}
	},
    
    
	SaveLegalInspectionCompletionData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("LegalIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("LegalBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("LegalEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("LegalSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("LegalFurtherInformationSeekingLossCost").value;
      //  var ProposaltoSettletheComplaint = document.getElementById("LegalProposaltoSettletheComplaint").value;

		
		component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
        component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
        component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
        component.set("v.LegalSummaryError", false);
        component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        component.set("v.LegalInspectionCompletionSectionInCmp", false);
	
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.LegalFurtherInformationSeekingLossCostError", true);
            component.set("v.LegalInspectionCompletionSectionInCmp", true);
			isValid = false;
		}
        
	
        
		if (isValid == true) 
        {
			component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Summary__c", Summary);
            component.set("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
          //  component.set("v.SellingComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", ProposaltoSettletheComplaint);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'LegalInspectionCompletion');
		} 
        else 
        {
			$("html, body").animate( { scrollTop: $("#DetailLegalInspectionCompletion").offset().top-25}, 500 );
		}
        
	},
    
    
	SaveAfterSalesData: function (component, event, helper) 
    {
		var isValid = true;
        
		var IdentifyCodeDeveloperBreached = document.getElementById("AfterSalesIdentifyCodeDeveloperBreached").value;
        var BreacheNotAddressedYourConcerns = document.getElementById("AfterSalesBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("AfterSalesEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("AfterSalesSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("AfterSalesFurtherInformationSeekingLossCost").value;
       // var ProposaltoSettletheComplaint = document.getElementById("AfterSalesProposaltoSettletheComplaint").value;
        
		component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
        component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
        component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
        component.set("v.AfterSalesSummaryError", false);
        component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
        component.set("v.AfterSalesSectionInCmp", false);
      
		if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
        {
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
            component.set("v.AfterSalesSectionInCmp", true);
			isValid = false;
		}
       
        
		if (isValid == true) 
        {
			component.set("v.AfterSalesComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c", IdentifyCodeDeveloperBreached);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Summary__c", Summary);
            component.set("v.AfterSalesComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
          //  component.set("v.SellingComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", ProposaltoSettletheComplaint);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'AfterSales');
		} 
        else 
        {
            $("html, body").animate( { scrollTop: $("#DetailAfterSales").offset().top-25}, 500);

			
		}
	},
    
   
	SaveOtherData: function (component, event, helper) 
    {
		var isValid = true;
        
		var BreacheNotAddressedYourConcerns = document.getElementById("OtherBreacheNotAddressedYourConcerns").value;
        var EvidenceUploadSupportsYourCase = document.getElementById("OtherEvidenceUploadSupportsYourCase").value;
        var Summary = document.getElementById("OtherSummary").value;
        var FurtherInformationSeekingLossCost = document.getElementById("OtherFurtherInformationSeekingLossCost").value;
        //var ProposaltoSettletheComplaint = document.getElementById("OtherProposaltoSettletheComplaint").value;
		
        component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
        component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
        component.set("v.OtherSummaryError", false);
        component.set("v.OtherFurtherInformationSeekingLossCostError", false);
        component.set("v.OtherSectionInCmp", false);
        
		
        if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
        {
			component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
        if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
        {
			component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
        if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
        {
			component.set("v.OtherFurtherInformationSeekingLossCostError", true);
            component.set("v.OtherSectionInCmp", true);
			isValid = false;
		}
        
	
        
		if (isValid == true) 
        {
			component.set("v.OtherComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c", BreacheNotAddressedYourConcerns);
            component.set("v.OtherComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c", EvidenceUploadSupportsYourCase);
            component.set("v.OtherComp.AreasOfComplaint.HD_Summary__c", Summary);
            component.set("v.OtherComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c", FurtherInformationSeekingLossCost);
           // component.set("v.SellingComp.AreasOfComplaint.HD_Proposal_to_Settle_the_Complaint__c", ProposaltoSettletheComplaint);
            
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'Other');
		} 
        else 
        {
			$("html, body").animate( { scrollTop: $("#DetailOther").offset().top-25}, 500 );
		}
	},
    
    
    SaveWarrantyProviderData: function (component, event, helper) 
    {
		var isValid = true;
        
		var Summary = document.getElementById("WarrantyProviderSummary").value;
        
		
        
		component.set("v.WarrantyProviderSummaryError", false);
        component.set("v.WarrantyProviderSectionInCmp", false);
		
        
        if (Summary == undefined || Summary == "" || Summary == null) 
        {
			component.set("v.WarrantyProviderSummaryError", true);
            component.set("v.WarrantyProviderSectionInCmp", true);
			isValid = false;
		}
        
		
        
		if (isValid == true) 
        {
			component.set("v.WarrantyProviderComp.AreasOfComplaint.HD_Summary__c", Summary);
            
			
			var ArrOfAreaOfComp = [];
			ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, false,'WarrantyProvider');
		} 
        else 
        {
             $("html, body").animate( { scrollTop: $("#DetailWarrantyProvider").offset().top-25}, 500 );
			//var offsets = document.getElementById("DetailedSection");
			//window.scroll({top: offsets.offsetTop + 350,behavior: 'smooth'});
		}
	},
    
    
    
    
    saveAndContinueFromDetailedSubmission: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        
		/*component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);*/
        
        component.set("v.SellingSectionInCmp", false);
         component.set("v.LegalInspectionCompletionSectionInCmp", false);
         component.set("v.AfterSalesSectionInCmp", false);
         component.set("v.OtherSectionInCmp", false);
         component.set("v.WarrantyProviderSectionInCmp", false);
        
		var isFinalValid = true;
		var ArrOfAreaOfComp = [];
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			var isValid = true;
            
            var IdentifyCodeDeveloperBreached = component.get("v.SellingComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.SellingComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.SellingComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.SellingComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.SellingComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
            
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            component.set("v.SellingSectionInCmp", false);
            
			
			if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.SellingFurtherInformationSeekingLossCostError", true);
                component.set("v.SellingSectionInCmp", true);
                isValid = false;
            }
          
            
			if (isValid == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.SellingDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			var isValid1 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
			
           
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
            component.set("v.LegalInspectionCompletionSectionInCmp", false);
          
        
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.LegalFurtherInformationSeekingLossCostError", true);
                component.set("v.LegalInspectionCompletionSectionInCmp", true);
                isValid1 = false;
            }
			
            
			if (isValid1 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.LegalInspectionCompletionDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			var isValid2 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
			
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            component.set("v.AfterSalesSectionInCmp", false);
          
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
                component.set("v.AfterSalesSectionInCmp", true);
                isValid2 = false;
            }
			
            
			if (isValid2 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.AfterSalesDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			var isValid4 = true;
            
			var BreacheNotAddressedYourConcerns = component.get("v.OtherComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.OtherComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.OtherComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.OtherComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
            
			
            
			 component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            component.set("v.OtherSectionInCmp", false);
          
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.OtherFurtherInformationSeekingLossCostError", true);
                component.set("v.OtherSectionInCmp", true);
                isValid4 = false;
            }
			
            
			if (isValid4 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.OtherDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			var isValid3 = true;
            
			var Summary = component.get("v.WarrantyProviderComp.AreasOfComplaint.HD_Summary__c");
           	
          
            
			component.set("v.WarrantyProviderSummaryError", false);
            component.set("v.WarrantyProviderSectionInCmp", false);
           
            
            
            if (Summary == undefined || Summary == "" || Summary == null) 
            {
                component.set("v.WarrantyProviderSummaryError", true);
                component.set("v.WarrantyProviderSectionInCmp", true);
                isValid3 = false;
            }
			
			if (isValid3 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			} else 
            {
				component.set("v.WarrantyProviderDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        
        var overallResponse = document.getElementById("overallResponse").value;
        component.set("v.summariseError", false);
        if (overallResponse == undefined || overallResponse == "" || overallResponse == null) 
            {
                component.set("v.summariseError", true);
                isFinalValid = false;
            }
        
        component.set("v.case.Housebuilder_Summary_Complaint__c",overallResponse);
		
		if (isFinalValid == true) 
        {
		    component.set("v.reviewSaveWarningMsg",false);
            helper.helperUpdateAreaOfComplaint(component, event, helper, ArrOfAreaOfComp, true,null);
		} 
        else 
        {
            component.set("v.reviewSaveWarningMsg",false);
			if (overallResponse == undefined || overallResponse == "" || overallResponse == null) 
            {
				$("html, body").animate( { scrollTop: $("#OverviewOfComplaint").offset().top-25}, 500 );
			} 
            else 
            {
				 if(component.get("v.SellingSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailSelling1").offset().top - 50 },500);
            }
            else if(component.get("v.LegalInspectionCompletionSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailLegalInspectionCompletion1").offset().top - 50 },500);
            }
            else if(component.get("v.AfterSalesSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailAfterSales1").offset().top - 50},500);
            }
            else if(component.get("v.OtherSectionInCmp") == true)
            {
                $("html, body").animate({ scrollTop: $("#DetailOther1").offset().top - 50 },500);
            }
            else if(component.get("v.WarrantyProviderSectionInCmp") == true)
            {
                 $("html, body").animate({ scrollTop: $("#DetailWarrantyProvider1").offset().top - 100 },500);
            }
			} 
		}
	},
    
    
    
    goBackFromReviewSubmission: function (component, event, helper) 
    {
        helper.helperSaveDataToAttribute(component, event, helper); 
		helper.helperExpandDetailSection(component, event, helper);
        
        var overallResponse = document.getElementById("overallResponse").value;
        component.set("v.case.Housebuilder_Summary_Complaint__c",overallResponse);
        
		window.scroll({top: 0,behavior: 'smooth'});
		component.set("v.detailedSection", true);
		component.set("v.reviewSection", false);
        component.set("v.thankYouSection", false);
        component.set("v.isCancel", false);
        
        component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			
			
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
           
			
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
            
           
            
			component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
          component.set("v.reviewSaveWarningMsg", false);
        component.set("v.reviewSubmitWarningMsg", false);
			
			component.set("v.WarrantyProviderSummaryError", false);
        component.set("v.isActiveReviewContinueBtn", false);
        
        component.set("v.summariseError", false);
        
	},
    
    
    
    ReviewSaveBtnClick: function (component, event, helper) 
    {
		helper.helperSaveDataToAttribute(component, event, helper);
        
		component.set("v.SellingDetailedSection", false);
		component.set("v.LegalInspectionCompletionDetailedSection", false);
		component.set("v.AfterSalesDetailedSection", false);
		component.set("v.WarrantyProviderDetailedSection", false);
		component.set("v.OtherDetailedSection", false);
        
		var isFinalValid = true;
		var ArrOfAreaOfComp = [];
        
		if (component.get("v.SellingComp.isSelected") != undefined && component.get("v.SellingComp.isSelected") == true) 
        {
			var isValid = true;
            
            var IdentifyCodeDeveloperBreached = component.get("v.SellingComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.SellingComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.SellingComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.SellingComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.SellingComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
            
			component.set("v.SellingIdentifyCodeDeveloperBreachedError", false);
            component.set("v.SellingBreacheNotAddressedYourConcernsError", false);
            component.set("v.SellingEvidenceUploadSupportsYourCaseError", false);
            component.set("v.SellingSummaryError", false);
            component.set("v.SellingFurtherInformationSeekingLossCostError", false);
            
			
			if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.SellingIdentifyCodeDeveloperBreachedError", true);
                isValid = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.SellingBreacheNotAddressedYourConcernsError", true);
                isValid = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.SellingEvidenceUploadSupportsYourCaseError", true);
                isValid = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.SellingFurtherInformationSeekingLossCostError", true);
                isValid = false;
            }
          
            
			if (isValid == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.SellingComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.SellingDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.LegalInspectionCompletionComp.isSelected") != undefined && component.get("v.LegalInspectionCompletionComp.isSelected") == true) 
        {
			var isValid1 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.LegalInspectionCompletionComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
			
           
			component.set("v.LegalIdentifyCodeDeveloperBreachedError", false);
            component.set("v.LegalBreacheNotAddressedYourConcernsError", false);
            component.set("v.LegalEvidenceUploadSupportsYourCaseError", false);
            component.set("v.LegalSummaryError", false);
            component.set("v.LegalFurtherInformationSeekingLossCostError", false);
        
          
        
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.LegalIdentifyCodeDeveloperBreachedError", true);
                isValid1 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.LegalBreacheNotAddressedYourConcernsError", true);
                isValid1 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.LegalEvidenceUploadSupportsYourCaseError", true);
                isValid1 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.LegalFurtherInformationSeekingLossCostError", true);
                isValid1 = false;
            }
			
            
			if (isValid1 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.LegalInspectionCompletionComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.LegalInspectionCompletionDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.AfterSalesComp.isSelected") != undefined && component.get("v.AfterSalesComp.isSelected") == true) 
        {
			var isValid2 = true;
            
			var IdentifyCodeDeveloperBreached = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Identify_Code_Developer_Breached__c");
            var BreacheNotAddressedYourConcerns = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.AfterSalesComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
			
			component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", false);
            component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", false);
            component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", false);
            component.set("v.AfterSalesSummaryError", false);
            component.set("v.AfterSalesFurtherInformationSeekingLossCostError", false);
          
            if (IdentifyCodeDeveloperBreached == undefined || IdentifyCodeDeveloperBreached == "" || IdentifyCodeDeveloperBreached == null) 
            {
                component.set("v.AfterSalesIdentifyCodeDeveloperBreachedError", true);
                isValid2 = false;
            }
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.AfterSalesBreacheNotAddressedYourConcernsError", true);
                isValid2 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.AfterSalesEvidenceUploadSupportsYourCaseError", true);
                isValid2 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.AfterSalesFurtherInformationSeekingLossCostError", true);
                isValid2 = false;
            }
			
            
			if (isValid2 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.AfterSalesComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.AfterSalesDetailedSection", true);
				isFinalValid = false;
			}
		}
        
        if (component.get("v.OtherComp.isSelected") != undefined && component.get("v.OtherComp.isSelected") == true) 
        {
			var isValid4 = true;
            
			var BreacheNotAddressedYourConcerns = component.get("v.OtherComp.AreasOfComplaint.HD_Breache_Not_Addressed_Your_Concerns__c");
            var EvidenceUploadSupportsYourCase = component.get("v.OtherComp.AreasOfComplaint.HD_Evidence_Upload_Supports_Your_Case__c");
            var Summary = component.get("v.OtherComp.AreasOfComplaint.HD_Summary__c");
            var FurtherInformationSeekingLossCost = component.get("v.OtherComp.AreasOfComplaint.HD_Further_Information_Seeking_Loss_Cost__c");
            
            
			
            
			 component.set("v.OtherBreacheNotAddressedYourConcernsError", false);
            component.set("v.OtherEvidenceUploadSupportsYourCaseError", false);
            component.set("v.OtherSummaryError", false);
            component.set("v.OtherFurtherInformationSeekingLossCostError", false);
            
          
            
            if (BreacheNotAddressedYourConcerns == undefined || BreacheNotAddressedYourConcerns == "" || BreacheNotAddressedYourConcerns == null) 
            {
                component.set("v.OtherBreacheNotAddressedYourConcernsError", true);
                isValid4 = false;
            }
            
            if (EvidenceUploadSupportsYourCase == undefined || EvidenceUploadSupportsYourCase == "" || EvidenceUploadSupportsYourCase == null) 
            {
                component.set("v.OtherEvidenceUploadSupportsYourCaseError", true);
                isValid4 = false;
            }
            
            if (FurtherInformationSeekingLossCost == undefined || FurtherInformationSeekingLossCost == "" || FurtherInformationSeekingLossCost == null) 
            {
                component.set("v.OtherFurtherInformationSeekingLossCostError", true);
                isValid4 = false;
            }
			
            
			if (isValid4 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.OtherComp.AreasOfComplaint"));
			} 
            else 
            {
				component.set("v.OtherDetailedSection", true);
				isFinalValid = false;
			}
		}
        
		if (component.get("v.WarrantyProviderComp.isSelected") != undefined && component.get("v.WarrantyProviderComp.isSelected") == true) 
        {
			var isValid3 = true;
            
			var Summary = component.get("v.WarrantyProviderComp.AreasOfComplaint.HD_Summary__c");
           	
          
            
			component.set("v.WarrantyProviderSummaryError", false);
            
           
            
            
            if (Summary == undefined || Summary == "" || Summary == null) 
            {
                component.set("v.WarrantyProviderSummaryError", true);
                isValid3 = false;
            }
			
			if (isValid3 == true) 
            {
				ArrOfAreaOfComp.push(component.get("v.WarrantyProviderComp.AreasOfComplaint"));
			} else 
            {
				component.set("v.WarrantyProviderDetailedSection", true);
				isFinalValid = false;
			}
		}
        
         var overallResponse = document.getElementById("overallResponse").value;
     
        component.set("v.summariseError", false);
        if (overallResponse == undefined || overallResponse == "" || overallResponse == null) 
            {
                component.set("v.summariseError", true);
                isFinalValid = false;
            }
        
         component.set("v.case.Housebuilder_Summary_Complaint__c",overallResponse);
        
		if (isFinalValid == true) 
        {
			var isSubmitBtn = 0;
			var button_Name = event.target.name;
            
			switch (button_Name) 
            {
			case "reviewSaveBtn":
				isSubmitBtn = 0;
                component.set("v.reviewSubmitCount",0);
				component.set("v.reviewSubmitWarningMsg",false);
				break;
			case "reviewSubmitBtn":
				isSubmitBtn = 1;
                component.set("v.isActiveReviewContinueBtn",true);
                component.set("v.reviewSubmitWarningMsg",true);
                component.set("v.reviewSaveWarningMsg",false);
				break;
             case "reviewContinueBtn":
				isSubmitBtn = 2;
				break;       
                    
			}
            
           if(isSubmitBtn == 0)
           {
               component.set("v.reviewSaveWarningMsg",false); 
              // var cnt = component.get("v.reviewSubmitCount");
              /* if(cnt == 0)
               {
                   component.set("v.reviewSubmitCount",1);
                   component.set("v.reviewSubmitWarningMsg",true);
               }
               if(cnt == 1)
               {*/
                   helper.helperSaveReviewComplaint(component, event, helper, ArrOfAreaOfComp, false);
               //}
           }
           else if(isSubmitBtn == 2)
           {
               helper.helperSaveReviewComplaint(component, event, helper, ArrOfAreaOfComp, true);
           }
			
		} 
        else 
        {
           
			if (overallResponse == undefined || overallResponse == "" || overallResponse == null) 
            {
				$("html, body").animate( { scrollTop: $("#OverviewOfComplaint").offset().top-25}, 500 );
			} 
            else 
            {
				 $("html, body").animate( { scrollTop: $("#OverviewOfComplaint").offset().top+300}, 500 );
			} 
		}
	},
    
    
     reviewSaveWarningMsgClose: function (component, event, helper) 
    {
        component.set("v.reviewSaveWarningMsg",false);
    },
    
    reviewSubmitWarningMsgClose: function (component, event, helper) 
    {
        component.set("v.reviewSubmitWarningMsg",false);
    },
    
    
    additionalCommentSave: function (component, event, helper) 
    {
        var isValid = true;
        var isHouseBuilder = component.get("v.isHouseBuilder");
        component.set("v.HBAdditionalCommentsError", false);
        component.set("v.HDAdditionalCommentsError", false);
        var ArrOfAreaOfComp = [];
        if(isHouseBuilder != true)
        {
            var AdditionalComments = document.getElementById("HBAdditionalComments").value;
            if (AdditionalComments == undefined || AdditionalComments == "" || AdditionalComments == null) 
            {
                component.set("v.HBAdditionalCommentsError", true);
                isValid = false;
            }
            
            component.set("v.case.Customer_Additional_Comments__c",AdditionalComments);
        }
        else
        {
            var AdditionalComments = document.getElementById("HDAdditionalComments").value;
            if (AdditionalComments == undefined || AdditionalComments == "" || AdditionalComments == null) 
            {
                component.set("v.HDAdditionalCommentsError", true);
                isValid = false;
            }
         component.set("v.case.Registered_Developer_Additional_Comments__c",AdditionalComments);

        }
        
        if(isValid == false)
         {
                $("html, body").animate( { scrollTop: $("#additionalComment1").offset().top-25},  500);
         }
        else
        {
           // 
           // ArrOfAreaOfComp.push(component.get("v.AdditionalCommentsComp.AreasOfComplaint"));
           // alert('fghj');
            helper.helperSaveAddtionalCommentComplaint(component, event, helper, null);
        }
      
        
    },
    
     draftDecisionCommentSave: function (component, event, helper) 
    {
        var isValid = true;
        var isHouseBuilder = component.get("v.isHouseBuilder");
        component.set("v.HBDraftDecisionCommentsError", false);
        component.set("v.RDDraftDecisionCommentsError", false);
        var ArrOfAreaOfComp = [];
        if(isHouseBuilder != true)
        {
            var AdditionalComments = document.getElementById("HBDraftDecisionComments").value;
            if (AdditionalComments == undefined || AdditionalComments == "" || AdditionalComments == null) 
            {
                component.set("v.HBDraftDecisionCommentsError", true);
                isValid = false;
            }
            
            component.set("v.case.CS_Additional_Comments_on_Draft_Decision__c",AdditionalComments);
        }
        else
        {
            var AdditionalComments = document.getElementById("RDDraftDecisionComments").value;
            if (AdditionalComments == undefined || AdditionalComments == "" || AdditionalComments == null) 
            {
                component.set("v.RDDraftDecisionCommentsError", true);
                isValid = false;
            }
         component.set("v.case.RD_Additional_Comments_on_Draft_Decision__c",AdditionalComments);

        }
        
        if(isValid == false)
         {
                $("html, body").animate( { scrollTop: $("#draftDecisionSection").offset().top-25},  500);
         }
        else
        {
           // 
           // ArrOfAreaOfComp.push(component.get("v.AdditionalCommentsComp.AreasOfComplaint"));
           // alert('fghj');
            helper.helperSavedraftDecisionComplaint(component, event, helper, null);
        }
      
       
    },
    
     goToDashboard: function (component, event, helper) 
        {
              let redirectURL = $A.get("$Label.c.NHOS_CommunityName");
            window.location.replace(redirectURL); 
        },    
})