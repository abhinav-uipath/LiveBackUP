({
	//This method is used for Error message
    showErrorToast : function(title,error){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": error,
            "type": "error"            
        });
        toastEvent.fire(); 
    }
})