({
    doInit : function(component, event, helper) { 
        
        var action = component.get("c.getInstallment");
        component.set("v.spinner",true);      
        action.setCallback(this, function(response) {
            component.set("v.spinner",true);
            var state = response.getState();
            if (state === "SUCCESS") {
                var result =response.getReturnValue();        
                
                
                if (result.length > 0) {
                    component.set("v.bNoRecordsFound", false);
                    
                    component.set("v.bankList", result);
                    component.set("v.spinner",false);              
                    
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = result;
                    var totalLength = totalRecordsList.length;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage", 0);
                    component.set("v.endPage", pageSize - 1);
                    var PaginationLst = [];
                    for (var i = 0; i < pageSize; i++) {
                        if (component.get("v.bankList").length > i) {
                            PaginationLst.push(result[i]);
                        }
                    }
                    component.set("v.PaginationList", PaginationLst);
                    component.set("v.selectedCount", 0);
                    //use Math.ceil() to Round a number upward to its nearest integer
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));
                } else {
                    console.log("line-->9 ELSE" );
                    component.set("v.PaginationList", "");
                    // if there is no records then display message
                    component.set("v.bNoRecordsFound", true);
                }                
                
            }
            else if (state === "INCOMPLETE") {
                component.set("v.spinner",false);
                helper.showToast('Warning!','Process incomplete','warning'); 
                
                // alert('INCOMPLETE');
            }
                else if (state === "ERROR") {
                    component.set("v.spinner",false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            helper.showToast('Error!',"Error message: " +  errors[0].message,'error');
                        }
                    } else {
                        helper.showToast('Error!','Unknown error','error');
                    }
                }
        });
        
        $A.enqueueAction(action);
        
    },
    
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for displaying loading spinner 
        
        component.set("v.spinner", true); 
        
    },
    
    // function automatic called by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hiding loading spinner  
        component.set("v.spinner", false); 
    },
    
    downloadCsv : function(component,event,helper){
        
        component.set("v.spinner",true);
        
        // get the Records [contact] list from 'ListOfContact' attribute 
        var bankList = component.get("v.bankList");
        // call the helper function which "return" the CSV data as a String   
        var csv = helper.convertArrayOfObjectsToCSV(component,bankList);   
        if (csv == null){
            component.set("v.spinner",false);
            return;
        } 
        
        // ####--code for create a temp. <a> html tag [link tag] for download the CSV file--####     
        
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; // 
        hiddenElement.download = 'SDS_Duplicate_BankDetails.csv';  // CSV file Name* you can change it.[only name not .csv] 
        document.body.appendChild(hiddenElement); // Required for FireFox browser
        hiddenElement.click(); // using click() js function to download csv file
        component.set("v.disable" ,false);
        component.set("v.spinner",false);
        
    },    
    navigation :  function(component, event, helper){
        var sObjectList = component.get("v.bankList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        //var whichBtn = event.getSource().get("v.name");
        //
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
        
    }    
    
   
    
})