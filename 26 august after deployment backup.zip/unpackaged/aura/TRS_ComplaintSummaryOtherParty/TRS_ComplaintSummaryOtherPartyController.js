({
	doInit : function(component, event, helper) {
        try {
            helper.getComplaintDetails(component);
        } catch(error) {
            //console.log('error in trs complaint summary ready only do in it : '+error);
        }
	},

	handleAccordionSelection : function(component, event, helper) {
        let divId = event.currentTarget.id;

        let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");
        
        for (let i = 0; i < areasOfComplaintWrapperList.length; i++) {
            if(areasOfComplaintWrapperList[i].complaintType == divId) {
                if(areasOfComplaintWrapperList[i].isSelected != true){
                    areasOfComplaintWrapperList[i].isSelected = true;	
                } else {
                    areasOfComplaintWrapperList[i].isSelected = false;
                }
            }
            
            if(areasOfComplaintWrapperList[i].isSelected == true && areasOfComplaintWrapperList[i].complaintType != divId){
                areasOfComplaintWrapperList[i].isSelected = false;
            }
        }
        
        component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
    },

	handleAreaOfComplaintDetailChange: function(component, event, helper) {
		try {
			let fieldId = event.target.id;
			let fieldValue = document.getElementById(fieldId).value;
			let fieldIdSplit = fieldId.split(",");
			let complaintType = fieldIdSplit[0];
			let questionNumber = fieldIdSplit[1];

			let userType = component.get("v.currentUserType");
			if(userType == 'Tenant') {
				helper.setAreasOfComplaintDetailsForTenant(component, complaintType, questionNumber, fieldValue);
			} else if(userType == 'Landlord') {
				helper.setAreasOfComplaintDetailsForLandlord(component, complaintType, questionNumber, fieldValue);
			}
		} catch(error) {
			//console.log('error in handleAreaOfComplaintDetailChange : '+error);
		}
	},

	handleAreasOfComplaintDetailsSave: function(component, event, helper) {
		try {
			helper.showSpinner(component);

			let isValid = false;
			let focusOnError = true;
			let userType = component.get("v.currentUserType");
			let showSubmitWarningMessage = component.get("v.showWarningMessageSection");

			if(userType == 'Tenant') {
				isValid = helper.validateAreasOfComplaintDetailsForTenant(component, focusOnError);
			} else if(userType == 'Landlord') {
				isValid = helper.validateAreasOfComplaintDetailsForLandlord(component, focusOnError);
			}
			if(isValid && showSubmitWarningMessage) {
				helper.updateAreasOfComplaintDetails(component);
			} else {
				component.set("v.showWarningMessageSection", true);
				helper.hideSpinner(component);
			}
		} catch(error) {
			//console.log('error in handleAreasOfComplaintDetailsSave : '+error);
		}
	},

	handleHideErrorMessages: function(component, event, helper) {
		try {
			let errorMessageId = event.target.name;
			let errorMessageElement = document.getElementById(errorMessageId);
			if (errorMessageElement) {
				document.getElementById(errorMessageId).classList.remove('displayBlock');
				document.getElementById(errorMessageId).classList.add('displayNone');
			}
		} catch(error) {
			//console.log('error in handleHideErrorMessages : '+error);
		}
	},

	handleGoToDashbord: function(component, event, helper) {
		let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
		let encodeURL = baseUrl;
        window.open(encodeURL, '_self');
	},

	handleHideReviewSaveAndSubmitMessage: function(component, event, helper) {
		try {
			component.set("v.showWarningMessageSection", false);
		} catch(error) {
			//console.log('error in handleReviewSaveAndSubmitMessage : '+error);
		}
	},
})