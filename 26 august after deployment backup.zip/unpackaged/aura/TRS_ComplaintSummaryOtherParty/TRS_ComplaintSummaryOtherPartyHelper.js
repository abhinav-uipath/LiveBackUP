({
    showSpinner: function (component) {
        component.set("v.showSpinner", true);
    },

    hideSpinner: function (component) {
        component.set("v.showSpinner", false);
    },

    showErrorMessage: function (errorMessageId) {
        var errorMessageElement = document.getElementById(errorMessageId);
        if (errorMessageElement) {
            errorMessageElement.classList.remove('displayNone');
            errorMessageElement.classList.add('displayBlock');
        }
    },

    hideErrorMessage: function (errorMessageId) {
        var errorMessageElement = document.getElementById(errorMessageId);
        if (errorMessageElement) {
            document.getElementById(errorMessageId).classList.remove('displayBlock');
            document.getElementById(errorMessageId).classList.add('displayNone');
        }
    },

    showToastMessage: function (title, message, type) {
        var toastEvent = $A.get("e.force:showToast");

        toastEvent.setParams({
            title: title,
            message: message,
            type: type,
            duration: '500',
            key: 'info_alt',
            mode: 'pester'
        });

        toastEvent.fire();
    },

    focusOnError: function (component, errorMessageIdList, areasOfComplaintWrapperList) {
        let focusOnError = true;

        let errorMessageId = errorMessageIdList[0];
        let errorMessageIdSplit = errorMessageId.split(",");
        let complaintType = errorMessageIdSplit[0];
        let questionNumber = errorMessageIdSplit[1];

        for (var i = 0; i < areasOfComplaintWrapperList.length; i++) {
            if (areasOfComplaintWrapperList[i].complaintType == complaintType) {
                if (!areasOfComplaintWrapperList[i].isSelected) {
                    areasOfComplaintWrapperList[i].isSelected = true;
                    focusOnError = false;
                    break;
                }
            }
        }

        if (!focusOnError) {
            component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
            this.validateAreasOfComplaintDetailsForTenant(component, focusOnError);
        }
    },

    getComplaintDetails: function (component) {
        let caseId = component.get("v.caseId");

        var action = component.get("c.getComplaintDetails");

        action.setParams({
            caseId: caseId
        });

        action.setCallback(this, function (response) {
            let state = response.getState();
            let responseValue = response.getReturnValue();
            
            if (state == 'SUCCESS') {
                component.set("v.currentUserType", responseValue.currentUserType);
                component.set("v.caseRecord", responseValue.caseRecord);
                component.set("v.areasOfComplaintWrapperList", responseValue.areasOfComplaintWrapperList);
                component.set("v.evidenceAttachmentList", responseValue.evidenceAttachmentList);

                if (responseValue.caseRecord.Case_Statuses__c == 'Deadline for comments passed - pending final decision') {
                    component.set("v.showAdjudicatorDecision", true);
                    component.set("v.showDraftDecision", true);
                }
                if (responseValue.caseRecord.Case_Statuses__c == 'Final decision issued - Awaiting tenants acceptance') {
                    component.set("v.showAdjudicatorDecision", true);
                    component.set("v.showFinalDecision", true);
                }

                if (responseValue.caseRecord.TRS_Complaint_raised_by__c == 'Tenant') {
                    if(responseValue.currentUserType == 'Tenant') {
                        component.set("v.showCancelComplaintButton", true);
                    }
                    component.set("v.isComplaintRaisedByTenant", true);
                } else {
                    component.set("v.isComplaintRaisedByTenant", false);
                }

                let respondDate = new Date(responseValue.caseRecord.Respond_Date__c);

                component.set("v.respondDate", respondDate.toISOString());
            }
        });

        $A.enqueueAction(action);
    },

    handleGoToMyAccountPage: function (component, event, helper) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let accountId = component.get("v.accountId");
        let encodeId = btoa(accountId);
        let encodeURL = baseUrl;
        window.open(encodeURL, '_blank');
    },

    setAreasOfComplaintDetailsForTenant: function (component, complaintType, questionNumber, fieldValue) {
        let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

        for (var i = 0; i < areasOfComplaintWrapperList.length; i++) {
            if (areasOfComplaintWrapperList[i].complaintType.includes(complaintType)) {
                if (questionNumber == 'detailedQuestion1') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Identify_Code_Developer_Breached__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion2') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Breache_Not_Addressed_Your_Concerns__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion3') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Evidence_Upload_Supports_Your_Case__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion4') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Summary__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion5') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Further_Information_Seeking_Loss_Cost__c = fieldValue;
                } else if (questionNumber == 'remedy5') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.Other_Remedy__c = fieldValue;
                }
            }
        }

        component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
    },

    setAreasOfComplaintDetailsForLandlord: function (component, complaintType, questionNumber, fieldValue) {
        let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

        for (var i = 0; i < areasOfComplaintWrapperList.length; i++) {
            if (areasOfComplaintWrapperList[i].complaintType.includes(complaintType)) {
                if (questionNumber == 'detailedQuestion1') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Identify_Code_Developer_Breached__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion2') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Breache_Not_Addressed_Your_Concerns__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion3') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Evidence_Upload_Supports_Your_Case__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion4') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Summary__c = fieldValue;
                } else if (questionNumber == 'detailedQuestion5') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Further_Information_Seeking_Loss_Cost__c = fieldValue;
                } else if (questionNumber == 'remedy5') {
                    areasOfComplaintWrapperList[i].areaOfComplaintRecord.Other_Remedy__c = fieldValue;
                }
            }
        }
        component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
    },

    validateAreasOfComplaintDetailsForTenant: function (component, focusOnError) {
        let isValid = true;
        let errorMessageIdList = [];
        let updatedAreasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

        for (var i = 0; i < updatedAreasOfComplaintWrapperList.length; i++) {
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Identify_Code_Developer_Breached__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Identify_Code_Developer_Breached__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion1Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion1Err';
                this.hideErrorMessage(errorMessageId);
            }
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Breache_Not_Addressed_Your_Concerns__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Breache_Not_Addressed_Your_Concerns__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion2Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion2Err';
                this.hideErrorMessage(errorMessageId);
            }
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Evidence_Upload_Supports_Your_Case__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Evidence_Upload_Supports_Your_Case__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion3Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion3Err';
                this.hideErrorMessage(errorMessageId);
            }
            /*if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Summary__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Summary__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion4Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion4Err';
                this.hideErrorMessage(errorMessageId);
            }*/
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Further_Information_Seeking_Loss_Cost__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.TT_Further_Information_Seeking_Loss_Cost__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion5Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion5Err';
                this.hideErrorMessage(errorMessageId);
            }

        }

        if (!isValid && focusOnError) {
            this.focusOnError(component, errorMessageIdList, updatedAreasOfComplaintWrapperList);
        }

        return isValid;
    },

    validateAreasOfComplaintDetailsForLandlord: function (component, focusOnError) {
        let isValid = true;
        let errorMessageIdList = [];
        let updatedAreasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

        for (var i = 0; i < updatedAreasOfComplaintWrapperList.length; i++) {
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Identify_Code_Developer_Breached__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Identify_Code_Developer_Breached__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion1Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion1Err';
                this.hideErrorMessage(errorMessageId);
            }
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Breache_Not_Addressed_Your_Concerns__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Breache_Not_Addressed_Your_Concerns__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion2Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion2Err';
                this.hideErrorMessage(errorMessageId);
            }
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Evidence_Upload_Supports_Your_Case__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Evidence_Upload_Supports_Your_Case__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion3Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion3Err';
                this.hideErrorMessage(errorMessageId);
            }
            /*if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Summary__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Summary__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion4Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion4Err';
                this.hideErrorMessage(errorMessageId);
            }*/
            if (updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Further_Information_Seeking_Loss_Cost__c == '' || updatedAreasOfComplaintWrapperList[i].areaOfComplaintRecord.LL_Further_Information_Seeking_Loss_Cost__c == null) {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion5Err';
                this.showErrorMessage(errorMessageId);
                isValid = false;
                errorMessageIdList.push(errorMessageId);
            } else {
                let errorMessageId = updatedAreasOfComplaintWrapperList[i].complaintType + ',detailedQuestion5Err';
                this.hideErrorMessage(errorMessageId);
            }
        }

        if (!isValid && focusOnError) {
            this.focusOnError(component, errorMessageIdList, updatedAreasOfComplaintWrapperList);
        }

        return isValid;
    },

    updateAreasOfComplaintDetails: function (component) {
        try {
            this.showSpinner(component);

            let saveOrSubmit = 'review';
            let caseId = component.get("v.caseId");
            let updatedAreaOfComplaintsWrapperList = component.get("v.areasOfComplaintWrapperList");
            var action = component.get("c.saveAreasOfComplaintDetails");

            action.setParams({
                areasOfComplaintDetailsWrapperString: JSON.stringify(updatedAreaOfComplaintsWrapperList),
                caseId: caseId,
                submitStatus: saveOrSubmit
            });

            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();

                if (state == 'SUCCESS') {
                    if (responseValue == true) {
                        this.hideSpinner(component);
                        this.showToastMessage('SUCCESS', 'Areas of Complaints Details Saved Successfully', 'SUCCESS');
                        component.set("v.showThankYouMessageSection", true);
                    } else {
                        this.hideSpinner(component);
                        this.showToastMessage('ERROR', 'Error while updating Areas of Complaint', 'ERROR');
                    }
                } else {
                    this.hideSpinner(component);
                    this.showToastMessage('ERROR', 'Error while updating Areas of Complaint', 'ERROR');
                }
            });

            $A.enqueueAction(action);
        } catch (error) {
            //console.log('error in updateAreasOfComplaintDetails : ' + error);
        }
    },
})