({
    handleButtonClick : function(component, event, helper) {
        var homePageUrl = '/lightning/page/home'; 
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": homePageUrl
        });
        urlEvent.fire();
    }
})