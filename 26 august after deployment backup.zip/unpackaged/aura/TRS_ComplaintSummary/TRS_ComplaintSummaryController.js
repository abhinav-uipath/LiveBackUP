({
	doInit: function (component, event, helper) {
		try {
			helper.getComplaintDetails(component);
		} catch (error) {
			//console.log('error in TRS_ComplaintSummary doInit : ' + error);
		}
	},

	handleSaveAndContinue: function (component, event, helper) {
		try {
			let buttonName = event.target.name;

			let userType = component.get("v.currentUserType");
			let saveAndContinue = false;
			let focusOnError = true;

			if (buttonName == 'summarySectionButton') {
				component.set("v.showComplaintSummarySection", false);
				component.set("v.showComplaintDetailedSection", true);
			}
			if (buttonName) {
				if (userType == 'Tenant') {
					saveAndContinue = helper.validateAreasOfComplaintDetailsForTenant(component, focusOnError);
				} else if (userType == 'Landlord') {
					saveAndContinue = helper.validateAreasOfComplaintDetailsForLandlord(component, focusOnError);
				}
			}
			if (buttonName == 'detailedSectionButton' && saveAndContinue) {
				component.handleAreasOfComplaintDetailsSave();
				component.set("v.showComplaintDetailedSection", false);
				component.set("v.showComplaintReviewSection", true);
			}

			window.scrollTo(0, 0);
		} catch (error) {
			//console.log('error in handleSaveAndContinue : ' + error);
		}
	},

	handleGoBack: function (component, event, helper) {
		try {
			let buttonName = event.target.name;

			if (buttonName == 'detailedSectionGoBackButton') {
				component.set("v.showComplaintSummarySection", true);
				component.set("v.showComplaintDetailedSection", false);
			}
			if (buttonName == 'reviewSectionGoBackButton') {
				component.set("v.showComplaintDetailedSection", true);
				component.set("v.showComplaintReviewSection", false);
			}

			window.scrollTo(0, 0);
		} catch (error) {
			//console.log('error in handleSaveAndContinue : ' + error);
		}
	},

	handleAccordionSelection: function (component, event, helper) {
		try {
			let accordionId = event.currentTarget.id;
			let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

			for (let i = 0; i < areasOfComplaintWrapperList.length; i++) {
				if (areasOfComplaintWrapperList[i].areaOfComplaintRecord.Complaint_Type__c == accordionId) {
					if (!areasOfComplaintWrapperList[i].isSelected) {
						areasOfComplaintWrapperList[i].isSelected = true;
					} else {
						areasOfComplaintWrapperList[i].isSelected = false;
					}
				}

				if (areasOfComplaintWrapperList[i].isSelected == true && areasOfComplaintWrapperList[i].areaOfComplaintRecord.Complaint_Type__c != accordionId) {
					areasOfComplaintWrapperList[i].isSelected = false;
				}
			}

			component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
		} catch (error) {
			//console.log('error in handleAccordionSelection : ' + error);
		}
	},

	handleAreaOfComplaintDetailChange: function (component, event, helper) {
		try {
			let fieldId = event.target.id;
			let fieldValue = document.getElementById(fieldId).value;
			let fieldIdSplit = fieldId.split(",");
			let complaintType = fieldIdSplit[0];
			let questionNumber = fieldIdSplit[1];

			let userType = component.get("v.currentUserType");

			if (userType == 'Tenant') {
				helper.setAreasOfComplaintDetailsForTenant(component, complaintType, questionNumber, fieldValue);
			} else if (userType == 'Landlord') {
				helper.setAreasOfComplaintDetailsForLandlord(component, complaintType, questionNumber, fieldValue);
			}
		} catch (error) {
			//console.log('error in handleAreaOfComplaintDetailChange : ' + error);
		}
	},

	handleCheckboxChange: function (component, event, helper) {
		try {
			let fieldId = event.target.id;
			let fieldValue = event.target.checked;

			let fieldIdSplit = fieldId.split(",");

			let complaintType = fieldIdSplit[0];
			let questionNumber = fieldIdSplit[1];

			let areasOfComplaintWrapperList = component.get("v.areasOfComplaintWrapperList");

			for (var i = 0; i < areasOfComplaintWrapperList.length; i++) {
				if (areasOfComplaintWrapperList[i].complaintType.includes(complaintType)) {
					if (questionNumber == 'remedy1') {
						areasOfComplaintWrapperList[i].areaOfComplaintRecord.An_apology__c = fieldValue;
					} else if (questionNumber == 'remedy2') {
						areasOfComplaintWrapperList[i].areaOfComplaintRecord.The_Problem_Put_Right__c = fieldValue;
					} else if (questionNumber == 'remedy3') {
						areasOfComplaintWrapperList[i].areaOfComplaintRecord.Comensation__c = fieldValue;
					} else if (questionNumber == 'remedy4') {
						areasOfComplaintWrapperList[i].areaOfComplaintRecord.Other__c = fieldValue;
						if (!fieldValue) {
							areasOfComplaintWrapperList[i].areaOfComplaintRecord.Other_Remedy__c = '';
						}
					}
				}
			}

			component.set("v.areasOfComplaintWrapperList", areasOfComplaintWrapperList);
		} catch (error) {
			//console.log('error in handleCheckboxChange : ' + error);
		}
	},

	handleAreasOfComplaintDetailsSave: function (component, event, helper) {
		try {
			helper.showSpinner(component);

			let isValid = false;
			let focusOnError = true;
			let userType = component.get("v.currentUserType");

			if (userType == 'Tenant') {
				isValid = helper.validateAreasOfComplaintDetailsForTenant(component, focusOnError);
			} else if (userType == 'Landlord') {
				isValid = helper.validateAreasOfComplaintDetailsForLandlord(component, focusOnError);
			}

			if (isValid) {
				helper.updateAreasOfComplaintDetails(component);
			} else {
				helper.hideSpinner(component);
			}
		} catch (error) {
			//console.log('error in handleAreasOfComplaintDetailsSave : ' + error);
		}
	},

	handleHideErrorMessages: function (component, event, helper) {
		try {
			let errorMessageId = event.target.name;
			let errorMessageElement = document.getElementById(errorMessageId);
			if (errorMessageElement) {
				document.getElementById(errorMessageId).classList.remove('displayBlock');
				document.getElementById(errorMessageId).classList.add('displayNone');
			}
		} catch (error) {
			//console.log('error in handleHideErrorMessages : ' + error);
		}
	},

	handleHideReviewSaveAndSubmitMessage: function (component, event, helper) {
		try {
			component.set("v.showReviewSaveWarningMessage", false);
			component.set("v.showReviewSubmitWarningMessage", false);
		} catch (error) {
			//console.log('error in handleReviewSaveAndSubmitMessage : ' + error);
		}
	},

	handleReviewAndSave: function (component, event, helper) {
		try {
			component.set("v.saveOrSubmit", 'save');

			let updatedAreaOfComplaintsWrapperList = component.get("v.areasOfComplaintWrapperList");
			let showReviewSaveWarningMessage = component.get("v.showReviewSaveWarningMessage");
			let userType = component.get("v.currentUserType");
			let saveAndContinue = false;

			if (userType == 'Tenant') {
				saveAndContinue = helper.validateAreasOfComplaintDetailsForTenant(component, event, helper, updatedAreaOfComplaintsWrapperList);
			} else if (userType == 'Landlord') {
				saveAndContinue = helper.validateAreasOfComplaintDetailsForLandlord(component, event, helper, updatedAreaOfComplaintsWrapperList);
			}

			if (saveAndContinue && showReviewSaveWarningMessage) {
				component.handleAreasOfComplaintDetailsSave();
			}

			if (!saveAndContinue) {
				component.handleHideReviewSaveAndSubmitMessage();
			} else {
				component.set("v.showReviewSaveWarningMessage", true);
				component.set("v.showReviewSubmitWarningMessage", false);
			}
		} catch (error) {
			//console.log('error in handleReviewAndSave : ' + error);
		}
	},

	handleReviewAndSubmit: function (component, event, helper) {
		try {
			component.set("v.saveOrSubmit", 'submit');

			let updatedAreaOfComplaintsWrapperList = component.get("v.areasOfComplaintWrapperList");
			let showReviewSubmitWarningMessage = component.get("v.showReviewSubmitWarningMessage");
			let userType = component.get("v.currentUserType");
			let saveAndContinue = false;

			if (userType == 'Tenant') {
				saveAndContinue = helper.validateAreasOfComplaintDetailsForTenant(component, event, helper, updatedAreaOfComplaintsWrapperList);
			} else if (userType == 'Landlord') {
				saveAndContinue = helper.validateAreasOfComplaintDetailsForLandlord(component, event, helper, updatedAreaOfComplaintsWrapperList);
			}

			if (saveAndContinue && showReviewSubmitWarningMessage) {
				component.handleAreasOfComplaintDetailsSave();
			}

			if (!saveAndContinue) {
				component.handleHideReviewSaveAndSubmitMessage();
			} else {
				component.set("v.showReviewSaveWarningMessage", false);
				component.set("v.showReviewSubmitWarningMessage", true);
			}
		} catch (error) {
			//console.log('error in handleReviewAndSubmit : ' + error);
		}
	},

	handleGoToHomePage: function (component, event, helper) {
		let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
		let encodeURL = baseUrl;
		window.open(encodeURL, '_self');
	}
})