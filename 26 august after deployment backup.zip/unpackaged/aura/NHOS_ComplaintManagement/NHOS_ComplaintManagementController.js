({
    
    doInit : function(component, event, helper) {
        component.set("v.isCancelSuccess",false);
        helper.fetchCases(component, event, helper,false);
    },
    summaryComplaint : function(component, event, helper) {
        var encodeId = btoa(event.target.id);
        var encodeURL = $A.get("$Label.c.NHOS_CommunityName")+"/summary-of-complaint?id="+encodeId;
        window.open(encodeURL, '_blank');
    },
     getArchiveComplaint : function(component, event, helper) {
        component.set("v.isCancelSuccess",false);
        helper.fetchCases(component, event, helper,true);
    },
    
     getActiveComplaint : function(component, event, helper) {
        component.set("v.isCancelSuccess",false);
        helper.fetchCases(component, event, helper,false);
    },
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.cList");
        console.log('sObjectList=='+sObjectList);
        var end = component.get("v.endPage");
        console.log('end=='+end);
        var start = component.get("v.startPage");
        console.log('start=='+start);
        var pageSize = component.get("v.pageSize");
        console.log('pageSize=='+pageSize);
        //var whichBtn = event.getSource().get("v.name");
        
        // check if whichBtn value is 'next' then call 'next' helper method
        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList, end, start, pageSize);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
 sortCol: function(component, event, helper) {
      var columnName = event.target.name;
       // alert(columnName);
       // 
       if(component.get("v.sortColumnName") == columnName)
       {
          component.set("v.descendingOrder",!component.get("v.descendingOrder"));
       }
        else
        {
            component.set("v.descendingOrder",false);
        }
         component.set("v.sortColumnName",columnName);
           
       
    var clst = component.get("v.cList");
    helper.sortBy(component, event,helper,clst,columnName);   
 },
    
    
    cancelComplaintClick : function(component, event, helper) {
        var action = component.get("c.closeCaseFrom");
        component.set("v.showSpinner",true);
         action.setParams({
          caseList: component.get("v.cList")
          });
                   
        action.setCallback(this, function(a){
            var state = a.getState();
           
            if (state === "SUCCESS") {
                if(a.getReturnValue() == 'Success'){
                    $('#cancelComplaint').modal('hide');
                   component.set("v.isCancelSuccess",true);
                   component.set("v.iscancelBtn",false);
                }
                else
                {
                    var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'ERROR!',
                            message: 'Something went to wrong',
                            duration: '500',
                            key: 'info_alt',
                            type: 'error',
                            mode: 'pester'
                        });
                        toastEvent.fire();
                }
               // alert(a.getReturnValue());
            }
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
    },
    
})