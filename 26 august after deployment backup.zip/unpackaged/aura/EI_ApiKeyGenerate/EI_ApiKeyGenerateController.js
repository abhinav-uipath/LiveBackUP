({
    doInit : function(component, event, helper) { 
        console.log('line 3 '+component.get("v.recordId"));
        var action = component.get("c.generateAPIKey");
        action.setParams({
            recId: component.get("v.recordId")
        });
        
        action.setCallback(this,function (response) {
            var state = response.getState();
            //console.log('line 11 '+state);
            if (state === "SUCCESS"){
                var serverResponse = response.getReturnValue();
                if(serverResponse=='error'){
                    component.set('v.message','API ID and API Secret Key are mandatory.');
                }else{
                    if(serverResponse=='Failed to generate HMAC, Please try after some time.')
                    {
                        component.set('v.message','Failed to generate HMAC, Please try after some time.');
                    }
                    else
                    {
                        component.set('v.message','Api Key has been generated.');
                        window.location.reload();
                        
                    }
                    
                }
               // alert('serverResponse '+serverResponse);
            }else{
                //console.log('line 16 '+JSON.stringify(response.getError()));
            }    
        });
        $A.enqueueAction(action);
    }
})