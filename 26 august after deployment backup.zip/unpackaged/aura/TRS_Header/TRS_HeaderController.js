({
    doInit: function(component, event, helper) {
        let customLabelMap = component.get("v.customLabelMap");

        component.set("v.TRS_SiteHome", customLabelMap['TRS_SiteHome']);
        component.set("v.TRS_AboutUS", customLabelMap['TRS_AboutUS']);
        component.set("v.TRS_Tenants", customLabelMap['TRS_Tenants']);
        component.set("v.TRS_Landlord", customLabelMap['TRS_Landlord']);
        component.set("v.TRS_ResourceCentre", customLabelMap['TRS_ResourceCentre']);
        component.set("v.TRS_ContactUs", customLabelMap['TRS_ContactUs']);
    },

    handleLogout : function() {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let redirectURL = baseUrl+'/secur/logout.jsp?retUrl='+baseUrl;
        window.location.replace(redirectURL);
    }
})