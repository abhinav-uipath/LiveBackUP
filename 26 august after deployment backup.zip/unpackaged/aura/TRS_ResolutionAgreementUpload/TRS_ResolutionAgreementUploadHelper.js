({
    readFile: function (component, helper, file, fileLable) {
        try {
            let recordId = component.get("v.recordId");
            const currentDate = new Date();
            const timestamp = currentDate.getTime();
            if (!file) return;

            let icon = file.name.toLowerCase();
            let fileName = file.name.replaceAll(' ', '_');

            const ext = component.get("v.fileExt");
            var fileTypeCheck = ext.some(el => icon.endsWith(el));
            if (!fileTypeCheck) {
                component.set("v.submitBtn", true);
                return alert("File type not supported!");
            }

            var sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
            if (sizeInMB > component.get("v.fileMaxSize")) {
                component.set("v.submitBtn", true);
                return alert("File size is greater than 20mb");
            }

            var baseUrl = component.get("v.secureURI");
            var baseUrlLength = baseUrl.length;
            var indexOfQueryStart = baseUrl.indexOf("?");
            var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
            var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/' + recordId + '-' + timestamp + '-' + fileName + baseUrl.substring(indexOfQueryStart);
            component.set("v.azureLink", baseUrl.substring(0, indexOfQueryStart) + '/' + recordId + '-' + timestamp + '-' + fileName + sasKeys);
            component.set("v.fileNameInAzure", recordId + '-' + timestamp + '-' + fileName);

            var reader = new FileReader();
            reader.onload = function () {
                var dataURL = reader.result;
                helper.upload(component, file, dataURL.match(/,(.*)$/)[1], submitUri, fileLable);
            };
            reader.readAsDataURL(file);
        } catch (error) {
            console.log('error in readFile : ' + error);
        }

    },

    upload: function (component, file, base64Data, submitUri, fileLable) {
        try {
            var xhr = new XMLHttpRequest();
            var endPoint = submitUri;
            component.set("v.message", "Uploading...");

            xhr.open("PUT", endPoint, true);
            xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
            xhr.setRequestHeader('Content-Type', file.type);

            xhr.onreadystatechange = function () {

                if (xhr.readyState === 4 && xhr.status === 201) {

                    window.setTimeout(
                        $A.getCallback(function () {
                        })
                        , 1000);

                    var action = component.get("c.saveReportLink");

                    action.setParams({
                        parentId: component.get("v.recordId"),
                        fileName: file.name,
                        azureLink: component.get('v.azureLink'),
                        fileNameInAzure: component.get('v.fileNameInAzure')

                    });

                    action.setCallback(this, function (a) {
                        let state = a.getState();
                        let errors = a.getError();

                        if (state == "SUCCESS") {
                            let resultValue = a.getReturnValue();

                            if (resultValue.status == 'Error' && resultValue.message == 'File limit exceeded') {
                                component.set("v.submitBtn", true);
                                alert(resultValue.message);

                            } else if (resultValue.status == 'Error') {
                                component.set("v.submitBtn", true);
                                alert(resultValue.message);
                            } else {
                                let ReturnValue = resultValue.EvidenceAttachment;

                                component.set("v.message", "");
                                component.set("v.fileLableVisible", false);
                                component.set("v.fileName", "");
                                //component.set("v.showEvidenceCmp", false);

                                let toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title: 'Info',
                                    message: 'File Uploaded Successfully',
                                    duration: ' 5000',
                                    key: 'success_alt',
                                    type: 'success',
                                    mode: 'dismissible'
                                });
                                toastEvent.fire();
                                component.set("v.submitBtn", true);
                            }
                        }
                    });

                    $A.enqueueAction(action);
                }
            };
            xhr.send(file);
        } catch (error) {
            console.log('error in upload : ' + error);
        }
    }
})