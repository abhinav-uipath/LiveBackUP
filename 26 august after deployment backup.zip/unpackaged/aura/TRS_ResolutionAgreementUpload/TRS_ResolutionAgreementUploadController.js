({
    doInit: function (component, event, helper) {
        try {
            let recordId = component.get("v.recordId");

            var action = component.get("c.getRecordTypeName");

            action.setParams({
                recordId: recordId
            });

            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();
                if (state == 'SUCCESS') {
                    if (responseValue == 'TRS Complaint') {
                        component.set("v.scheme", 'TRS');
                    } else if (responseValue == 'NHOS Complaint') {
                        component.set("v.scheme", 'NHOS');
                    }
                }
            });

            $A.enqueueAction(action);
        } catch (error) {
            console.log('error in do in it TRS_ResolutionAgreementUpload : ' + error);
        }
    },

    handleFilesChange: function (component, event, helper) {
        try {
            component.set("v.message", "");

            var filess = component.set("v.fileList", component.get("v.fileList"));
            var files = component.get("v.fileList");
            let icon = files[0].name.toLowerCase();

            component.set("v.fileName", files[0].name);
            const ext = ['.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
            var fileTypeCheck = ext.some(el => icon.endsWith(el));

            if (fileTypeCheck == true) {
                component.set("v.fileLableVisible", true);
            } else {
                component.set("v.fileLableVisible", false);
            }

            component.set("v.submitBtn", true);
        } catch (error) {
            console.log('error in handleFileChange : ' + error);
        }

    },

    uploadReport: function (component, event, helper) {
        try {
            var files = component.get("v.fileList");

            if (files == null || files == undefined || files == '') {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'ERROR!',
                    message: 'Please select a file.',
                    duration: ' 5000',
                    key: 'info_alt',
                    type: 'error',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            } else {
                let scheme = component.get("v.scheme");
                var getFileLabel = document.getElementById("filelabel").value;

                if (getFileLabel == '' && component.get("v.fileLableVisible") == true) {
                    component.set("v.fileLable", 'Please provide a lable to upload file.');
                } else if (getFileLabel.length > 50) {
                    component.set("v.fileLable", 'Character limit is 50.');
                } else {
                    console.log('action');
                    component.set("v.submitBtn", false);

                    var action = component.get("c.getSecureURI");

                    action.setParams({
                        scheme: scheme
                    });

                    action.setCallback(this, function (a) {
                        let state = a.getState();
                        let errors = a.getError();
                        if (state == "SUCCESS") {
                            let returnValue = a.getReturnValue();
                            component.set("v.secureURI", returnValue);
                            component.set("v.fileLable", '');
                            helper.readFile(component, helper, files[0], getFileLabel);
                        }
                    });

                    $A.enqueueAction(action);
                }
            }
        } catch (error) {
            console.log('error in handleFileChange : ' + error);
        }
    }
})