({
    findAddress:function (component,event,helper,SecondFind) {
        var Text = document.getElementById("searchBoxval1").value;
        var availableopts = [];
        var availableopts2 = [];
        var resultId;
        var resultVal;
        // alert('@@ '+Text);
        if (Text === "") {
            showError("Please enter an address");
            return;
        }
        
        var Container = "";
        
        
        if (SecondFind !== undefined){
            Container = SecondFind;
            // alert('@@ '+Container);
        }
        
        var Key = "HY74-ZH36-YE14-BM91",
            IsMiddleware = false,
            Origin = "",
            Countries = "GBR",
            Limit = "10",
            Language = "en-gb",
            // url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Find/v1.10/json3.ws';
            url = 'https://api.addressy.com/Capture/Interactive/Find/v1.10/json3.ws';
        var params = '';
        params += "&Key=" + encodeURIComponent(Key);
        params += "&Text=" + encodeURIComponent(Text);
        params += "&IsMiddleware=" + encodeURIComponent(IsMiddleware);
        params += "&Container=" + encodeURIComponent(Container);
        params += "&Origin=" + encodeURIComponent(Origin);
        params += "&Countries=" + encodeURIComponent(Countries);
        params += "&Limit=" + encodeURIComponent(Limit);
        //swarupa params += "&Language=" + encodeURIComponent(Language);
        params += "&Access-Control-Allow-Origin=" + "https://thedisputeservice--devuat.my.salesforce.com";
        
        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        http.setRequestHeader('Access-Control-Allow-Origin', "https://thedisputeservice--devuat.my.salesforce.com");
        http.onreadystatechange = function() {
            // alert('@@http.status '+http.status+url);
            if (http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);
                console.log('++response++++'+JSON.stringify(response));
                if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);
                }
                else {
                    if (response.Items.length == 0)
                        showError("Sorry, there were no results");
                    
                    else {
                        var resultBox = document.getElementById("result");
                        
                        if (resultBox.childNodes.length > 0) {
                            var selectBox = document.getElementById("mySelect");
                            selectBox.parentNode.removeChild(selectBox)
                        }
                        
                        
                        // availableopts2
                        if (SecondFind != undefined){
                            for (var i = 0; i < response.Items.length; i++){
                                availableopts2.push({
                                    id:response.Items[i].Id,
                                    label:response.Items[i].Text + " " + response.Items[i].Description,
                                    pType: response.Items[i].Type
                                    
                                });
                                
                                
                            }
                            
                        }else{
                            for (var i = 0; i < response.Items.length; i++){
                                availableopts.push({
                                    id:response.Items[i].Id,
                                    label:response.Items[i].Text + " " + response.Items[i].Description,
                                    pType: response.Items[i].Type
                                    
                                });
                                
                                
                            }
                            
                        }
                        
                        
                        console.log(SecondFind +' SecondFind ');
                        if (SecondFind !== undefined){
                            
                            document.getElementById("searchBoxval1").value=" ";
                            document.getElementById("searchBoxval2").focus();
                            
                            setTimeout(function(){
                                document.getElementById("searchBoxval1").focus();
                                $( "#searchBoxval1" ).keydown();
                            }, 100);
                            console.log(' focus2 '+availableopts2);
                            var searchText = document.getElementById("searchBoxval1").value.toLowerCase();
                            var isSearchContains = false;
                            for(let i = 0; i<availableopts2.length; i++){
                                console.log("enter for loop" + availableopts2[i].label);
                                console.log("searchText => " + searchText);
                                //var availableoptsSplited = availableopts2[i].label.split(' ');
                                //console.log('availableoptsSplited => ');
                                //console.log('availableoptsSplited[0] => ' + availableoptsSplited[0]);
                                var postodeText = response.Items[i].Text.toLowerCase(); //availableoptsSplited[0].toLowerCase();
                                if(postodeText.length <= 8 &&
                                   (postodeText.startsWith('ab') || postodeText.startsWith('dd') || postodeText.startsWith('dg') || postodeText.startsWith('eh')||
                                    postodeText.startsWith('fk') || postodeText.startsWith('g') || postodeText.startsWith('hs') || postodeText.startsWith('iv')||
                                    postodeText.startsWith('kw') || postodeText.startsWith('ky') || postodeText.startsWith('ml') || postodeText.startsWith('pa')||
                                    postodeText.startsWith('ph') || postodeText.startsWith('td') || postodeText.startsWith('ze') || postodeText.startsWith('ka'))
                                  ){
                                    if(searchText.length < 5){      
                                        console.log("enter second if");
                                        console.log(searchText.substring(0, searchText.length));
                                        let finalsearch1 = searchText.substring(0, searchText.length);
                                        let finalsearch2 = searchText.substring(0, 3)+' '+searchText.substring(3, searchText.length);
                                        console.log("searchText.includes 1 => " + availableopts2[i].label.toLowerCase().includes(finalsearch1));
                                        console.log("searchText.includes 2 => " + availableopts2[i].label.toLowerCase().includes(finalsearch2));
                                        if(availableopts2[i].label.toLowerCase().includes(finalsearch1)){
                                            document.getElementById("searchBoxval1").value = finalsearch1;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }else if(availableopts2[i].label.toLowerCase().includes(finalsearch2)){
                                            document.getElementById("searchBoxval1").value = finalsearch2;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }
                                    }else{
                                        console.log(searchText.substring(0, 4));
                                        console.log(searchText.substring(4, searchText.length));
                                        let finalsearch1 = searchText.substring(0, 3).trim()+' '+searchText.substring(3, searchText.length).trim();
                                        let finalsearch2 = searchText.substring(0, 4).trim()+' '+searchText.substring(4, searchText.length).trim();
                                        console.log("searchText.includes 1 => " + availableopts2[i].label.toLowerCase().includes(finalsearch1));
                                        console.log("searchText.includes 2 => " + availableopts2[i].label.toLowerCase().includes(finalsearch2));
                                        if(availableopts2[i].label.toLowerCase().includes(finalsearch1)){
                                            document.getElementById("searchBoxval1").value = finalsearch;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }else if(availableopts2[i].label.toLowerCase().includes(finalsearch2)){
                                            document.getElementById("searchBoxval1").value = finalsearch2;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }
                                    }
                                }else{
                                    if(availableopts2[i].label.toLowerCase().includes(searchText)){
                                        isSearchContains = true;
                                    }
                                }
                            }
                            console.log('isSearchContains => '+ isSearchContains);
                            
                            if(isSearchContains){
                                var searchbx = document.getElementById("searchBoxval2");
                                
                                $A.util.addClass(searchbx, "addressFind2");
                                $A.util.removeClass(searchbx, "addressFind3");
                                $( "#searchBoxval1" ).autocomplete({
                                    source: availableopts2,
                                    minLength: 0,
                                    delay:10,
                                    autoFocus:true,
                                    focus:function(event,ui){
                                        console.log('testin load2222222222222');
                                        var searchbx = document.getElementById("searchBoxval2");
                                        $A.util.addClass(searchbx, "addressFind3");
                                        $A.util.removeClass(searchbx, "addressFind2");
                                        
                                        var errorbx = document.getElementById("notFoundErrorBox");
                                        $A.util.addClass(errorbx, "addressFind3");
                                        $A.util.removeClass(errorbx, "addressFind2");
                                        component.set("v.noMatchFound", false);
                                    },
                                    select: function(event, ui) {
                                        
                                        var e = ui.item;
                                        resultId = e.id ;
                                        resultVal = e.label;
                                        var resultType = e.pType;
                                        console.log(' resultId '+resultId+' && '+resultVal);
                                        helper.selectAddress(component,event,helper,Key,resultId,resultVal,resultType);
                                        
                                    }
                                });
                            }else{
                                console.log('No matching address found!');
                                var searchbx = document.getElementById("searchBoxval2");
                                $A.util.addClass(searchbx, "addressFind3");
                                $A.util.removeClass(searchbx, "addressFind2");
                                
                                var errorbx = document.getElementById("notFoundErrorBox");
                                $A.util.addClass(errorbx, "addressFind2");
                                $A.util.removeClass(errorbx, "addressFind3");
                                component.set("v.noMatchFound", true);
                                console.log('noMatchFound => '+component.get("v.noMatchFound"));
                            }
                            
                            
                            /* document.getElementById("searchBoxval1").value=" ";
document.getElementById("searchBoxval2").focus();
console.log(' focus22222 ');
setTimeout(function(){
document.getElementById("searchBoxval1").focus();
}, 100);
console.log(' focus2 '+availableopts2);
$( "#searchBoxval1" ).autocomplete({
source: availableopts2



}).focus(function () {
console.log(' focus22222 ');
$(this).autocomplete("search"," ");
});


*/
                            
                        }
                        else{
                            console.log('testin load');
                            console.log(' focus1 '+availableopts);
                            var searchText = document.getElementById("searchBoxval1").value.toLowerCase();
                            var isSearchContains = false;
                            for(let i = 0; i<availableopts.length; i++){
                                console.log("enter for loop" + availableopts[i].label);
                                console.log("searchText => " + searchText);
                                //var availableoptsSplited = availableopts[i].label.split(' ');
                                //console.log('availableoptsSplited => ');
                                //console.log('availableoptsSplited[0] => ' + availableoptsSplited[0]);
                                var postodeText = response.Items[i].Text.toLowerCase(); //availableoptsSplited[0].toLowerCase();
                                if(postodeText.length <= 8 &&
                                   (postodeText.startsWith('ab') || postodeText.startsWith('dd') || postodeText.startsWith('dg') || postodeText.startsWith('eh')||
                                    postodeText.startsWith('fk') || postodeText.startsWith('g') || postodeText.startsWith('hs') || postodeText.startsWith('iv')||
                                    postodeText.startsWith('kw') || postodeText.startsWith('ky') || postodeText.startsWith('ml') || postodeText.startsWith('pa')||
                                    postodeText.startsWith('ph') || postodeText.startsWith('td') || postodeText.startsWith('ze') || postodeText.startsWith('ka'))
                                  ){
                                    if(searchText.length < 5){      
                                        console.log("enter second if");
                                        console.log(searchText.substring(0, searchText.length));
                                        let finalsearch1 = searchText.substring(0, searchText.length);
                                        let finalsearch2 = searchText.substring(0, 3)+' '+searchText.substring(3, searchText.length);
                                        console.log("searchText.includes 1 => " + availableopts[i].label.toLowerCase().includes(finalsearch1));
                                        console.log("searchText.includes 2 => " + availableopts[i].label.toLowerCase().includes(finalsearch2));
                                        if(availableopts[i].label.toLowerCase().includes(finalsearch1)){
                                            document.getElementById("searchBoxval1").value = finalsearch1;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }else if(availableopts[i].label.toLowerCase().includes(finalsearch2)){
                                            document.getElementById("searchBoxval1").value = finalsearch2;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }
                                    }else{
                                        console.log(searchText.substring(0, 4));
                                        console.log(searchText.substring(4, searchText.length));
                                        let finalsearch1 = searchText.substring(0, 3).trim()+' '+searchText.substring(3, searchText.length).trim();
                                        let finalsearch2 = searchText.substring(0, 4).trim()+' '+searchText.substring(4, searchText.length).trim();
                                        console.log("searchText.includes 1 => " + availableopts[i].label.toLowerCase().includes(finalsearch1));
                                        console.log("searchText.includes 2 => " + availableopts[i].label.toLowerCase().includes(finalsearch2));
                                        if(availableopts[i].label.toLowerCase().includes(finalsearch1)){
                                            document.getElementById("searchBoxval1").value = finalsearch;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }else if(availableopts[i].label.toLowerCase().includes(finalsearch2)){
                                            document.getElementById("searchBoxval1").value = finalsearch2;
                                            console.log('final search =>' +document.getElementById("searchBoxval1").value);
                                            isSearchContains = true;
                                        }
                                    }
                                }else{
                                    if(availableopts[i].label.toLowerCase().includes(searchText)){
                                        isSearchContains = true;
                                    }
                                }
                            }
                            console.log('isSearchContains => '+ isSearchContains);
                            if(isSearchContains){
                                var searchbx = document.getElementById("searchBoxval2");
                                console.log('line 288');
                                $A.util.addClass(searchbx, "addressFind2");
                                $A.util.removeClass(searchbx, "addressFind3");
                                console.log('line 292');
                                $( "#searchBoxval1" ).keydown();
                                $( "#searchBoxval1" ).autocomplete({
                                    source: availableopts,
                                    minLength: 3,
                                    delay:10,
                                    autoFocus:true,
                                    focus:function(event,ui){
                                        console.log('testin load111111');
                                        var searchbx = document.getElementById("searchBoxval2");
                                        $A.util.addClass(searchbx, "addressFind3");
                                        $A.util.removeClass(searchbx, "addressFind2");
                                        
                                        var errorbx = document.getElementById("notFoundErrorBox");
                                        $A.util.addClass(errorbx, "addressFind3");
                                        $A.util.removeClass(errorbx, "addressFind2");
                                        component.set("v.noMatchFound", false);
                                    },
                                    select: function(event, ui) {
                                        
                                        var e = ui.item;
                                        resultId = e.id ;
                                        resultVal = e.label;
                                        var resultType = e.pType;
                                        console.log(' resultId '+resultId+' && '+resultVal);
                                        helper.selectAddress(component,event,helper,Key,resultId,resultVal,resultType);
                                        
                                    }
                                });
                            }else{
                                console.log('No matching address found!');
                                var searchbx = document.getElementById("searchBoxval2");
                                $A.util.addClass(searchbx, "addressFind3");
                                $A.util.removeClass(searchbx, "addressFind2");
                                
                                var errorbx = document.getElementById("notFoundErrorBox");
                                $A.util.addClass(errorbx, "addressFind2");
                                $A.util.removeClass(errorbx, "addressFind3");
                                component.set("v.noMatchFound", true);
                                console.log('noMatchFound => '+component.get("v.noMatchFound"));
                            }
                        }
                        
                    }
                }
            }
        }
        http.send(params);
    },
    
    selectAddress:function (component,event,helper,Key,resultId,resultVal,resultType){
        // var resultList = document.getElementById("result");
        
        // if (resultList.childNodes.length > 0) {
        //
        var addressExist = false;
        if(resultType == 'Address'){
            helper.retrieveAddress(component,event,Key, resultId,resultVal);
        }else{
            
            console.log('asd12');
            
            
            
            // alert('****'+resultId);
            helper.findAddress(component,event,helper,resultId);
            
            // document.getElementById('searchBoxval1').value='';
        }
        
        
    },
    
    retrieveAddress:function (component,event,Key, Id,targetvalue){
        console.log('line-->136 ' );
        var Field1Format = "";
        // var url = 'https://services.postcodeanywhere.co.uk/Capture/Interactive/Retrieve/v1.00/json3.ws';
        var url = 'https://api.addressy.com/Capture/Interactive/Retrieve/v1.10/json3.ws';
        var params = '';
        var Origin = "",
            Countries = "GBR",
            Limit = "10";
        params += "&Key=" + encodeURIComponent(Key);
        params += "&Id=" + encodeURIComponent(Id);
        //params += "&Field1Format=" + encodeURIComponent(Field1Format);
        params += "&Field1Format=" + encodeURIComponent("{HomeNation}");
        
        
        var http = new XMLHttpRequest();
        http.open('POST', url, true);
        http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        http.onreadystatechange = function() {
            if (http.readyState == 4 && http.status == 200) {
                var response = JSON.parse(http.responseText);
                console.log("---------Result--", JSON.stringify(response));
                
                if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
                    showError(response.Items[0].Description);
                }
                else {
                    if (response.Items.length == 0)
                        showError("Sorry, there were no results");
                    else { var addressline;
                          if(response.Items[0].Line1 != '' && response.Items[0].Line2 != '' && response.Items[0].Line3 != '')
                          { addressline = response.Items[0].Line1 + '\n' +response.Items[0].Line2 +'\n'+response.Items[0].Line3 ;}
                          else if(response.Items[0].Line1 != '' && response.Items[0].Line2 == '' && response.Items[0].Line3 == ''){
                              addressline = response.Items[0].Line1; }
                              else if(response.Items[0].Line1 == '' && response.Items[0].Line2 != '' && response.Items[0].Line3 == ''){
                                  addressline = response.Items[0].Line2;
                              }
                                  else if(response.Items[0].Line1 == '' && response.Items[0].Line2 == '' && response.Items[0].Line3 != ''){
                                      addressline = response.Items[0].Line3;
                                  }
                                      else if(response.Items[0].Line1 != '' && response.Items[0].Line2 != '' && response.Items[0].Line3 == ''){
                                          addressline = response.Items[0].Line1 + '\n' +response.Items[0].Line2;
                                      }
                                          else if(response.Items[0].Line1 != '' && response.Items[0].Line2 == '' && response.Items[0].Line3 != ''){
                                              addressline = response.Items[0].Line1 + '\n' +response.Items[0].Line3;
                                          }
                                              else if(response.Items[0].Line1 == '' && response.Items[0].Line2 != '' && response.Items[0].Line3 != ''){
                                                  addressline = response.Items[0].Line2 + '\n' +response.Items[0].Line3;
                                              }
                          
                          var res = response.Items[0];
                          // console.log('line-->177 ' +JSON.stringify(res));
                          var resBox = document.getElementById("outputval1");
                          var fullAddress;
                          if(response.Items[0].Province == ''){
                              fullAddress = addressline +'\n'+response.Items[0].City+'\n'+response.Items[0].PostalCode+'\n'+response.Items[0].CountryName;
                          }else{
                              fullAddress = addressline +'\n'+response.Items[0].City+'\n'+response.Items[0].Province+'\n'+response.Items[0].PostalCode+'\n'+response.Items[0].CountryName;
                              
                          }
                          resBox.innerText = fullAddress;
                          var addressvalue = res.Label;
                          var arr ;
                          arr = addressvalue.split("\n");
                          
                          // var i;
                          
                          component.set('v.Country',response.Items[0].CountryName);
                          component.set('v.PostCode',response.Items[0].PostalCode);
                          component.set('v.Town',response.Items[0].City);
                          component.set('v.AddressLine1',addressline);
                          component.set('v.Street',response.Items[0].Line3);
                          component.set('v.County',response.Items[0].Province);
                          component.set('v.BaseCountry',response.Items[0].Field1);
                          component.set('v.houseNo',response.Items[0].BuildingNumber);
                          // alert(response.Items[0].Field1);
                          /* if(response.Items[0].BuildingNumber == ''){
component.set('v.houseNo',response.Items[0].BuildingName);
}else{
component.set('v.houseNo',response.Items[0].BuildingNumber);
}*/
                          // console.log(response.Items[0].Line3+' --<addressline-->>'+addressline);
                          // console.log('BuildingNumber-->>'+response.Items[0].BuildingNumber);
                          // console.log('BuildingName-->>'+response.Items[0].BuildingName);
                          // console.log('SubBuilding-->>'+response.Items[0].SubBuilding);
                          // console.log('Test record-->>'+response.Items[0].AdminAreaName);
                          component.set("v.localAuthorityArea", response.Items[0].AdminAreaName);
                          /* if(arr.length > 5){
var addressline = arr[arr.length-6] + ' \n ' +arr[arr.length-5];

component.set('v.AddressLine1',addressline);
}
else{
component.set('v.AddressLine1',arr[arr.length-5]);
}

*/
                          // alert( component.get('v.PostCode'));
                           var vx = component.get("v.method");
                           $A.enqueueAction(vx);
                          
                          document.getElementById("outputval1").style.display = "block";
                          document.getElementById("seperator").style.display = "block";
                          
                          document.getElementById("manualAddressval1").style.display = "none";
                          component.set("v.enterManually",false);
                          
                         }
                }
            }
        }
        http.send(params);
    }
})