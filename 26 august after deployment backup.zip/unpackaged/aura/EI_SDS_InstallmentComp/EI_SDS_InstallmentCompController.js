({
    doInit : function(component, event, helper) {
        // alert('Hi');       
        var action = component.get("c.getInstRecord");       
        action.setParams({InstallmentId:component.get("v.recordId")});
        action.setCallback(this,function(response){
            var State = response.getState();
            if(State==='SUCCESS'){
                var result=response.getReturnValue();  
                console.log('Success result='+(result));
                console.log('Success new='+JSON.stringify(result));
                component.set("v.accParticipantWrapper",result); 
               
            }
            else{
                console.log('Failed');
            }
        });      
        
        $A.enqueueAction(action);     
        
    },



   handlerSubmit:function(component, event, helper) {
      //  alert('submit');      	
       
     var InstallmentId = component.get("v.recordId");
        console.log('Line no 30' +InstallmentId);       
       var contactName = component.get("v.interPay"); 
             console.log('Line no 32 ' +contactName); 
       if(contactName != ''){
            console.log('Line no 11 ' +contactName);  
       
       var action = component.get("c.submitInstalment");       
       action.setParams({"InstallmentId":InstallmentId,"accId":contactName });        
       action.setCallback(this,function(response){ 
           var State = response.getState();
           if(State==='SUCCESS'){               
               var result=response.getReturnValue();  
               //console.log('Success new1='+JSON.stringify(result));               
               if(result == 'Instalment created'){            
                    var toastEvent = $A.get("e.force:showToast");
                   toastEvent.setParams({
                       title : 'Success',
                       message:'The record has been updated Successfully.',
                       duration:'5000',
                       key: 'info_alt',
                       type: 'Success',
                       mode: 'pester'
                   }); 
                   
                   toastEvent.fire();               
                  $A.get( "e.force:closeQuickAction" ).fire();  
                $A.get( "e.force:refreshView").fire();           
                                            
               }           
           }
           else{
               console.log('Failed');
           } 
            
       });      
       
       $A.enqueueAction(action); 
     }
       else{
             var toastEvent = $A.get("e.force:showToast");
                   toastEvent.setParams({
                       title : 'Failed',
                       message:'Please select a party to pay',
                       duration:'5000',
                       key: 'info_alt',
                       type: 'error',
                       mode: 'pester'
                   }); 
                   
                   toastEvent.fire();               
              //    $A.get( "e.force:closeQuickAction" ).fire();  
       }
},
    
    
    getContact : function(component, event, helper){        
        
       var interpayName = component.find("contactSelect").get("v.value");
         console.log('line no 183'+interpayName);
         component.set("v.interPay", interpayName);
         
    }
    
   
    
})