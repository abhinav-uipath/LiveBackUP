({
    handleClick : function(component, event, helper) {
        let currentURL = window.location.origin;
        let pathName = "/Sds/s/branches";
        window.location.href = currentURL+pathName;
    }
})