({
    doInit: function(component, event, helper) { 
        var record = component.get("v.record");
        var fieldName = component.get("v.fieldName");
        var fieldValue = record[fieldName];
        //alert(JSON.stringify(record)+fieldName+fieldValue);
        //alert(JSON.stringify(fieldName));
        if(fieldName=='Start_Date__c'){
            //alert('1');
            fieldValue = fieldValue.split('-');
            fieldValue = fieldValue[2]+'/'+fieldValue[1]+'/'+fieldValue[0];
        }
        component.set("v.fieldValue", fieldValue);
    }
})