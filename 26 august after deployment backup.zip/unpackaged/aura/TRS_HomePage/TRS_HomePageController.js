({
    doInit: function (component, event, helper) {
        try {
            var action = component.get("c.getComplainantInfo");
            
            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();

                if (state == 'SUCCESS') {
                    let user = responseValue.currentLoggedInUser;
                    component.set("v.accountId", user.AccountId);
                    component.set("v.currentUserFirstName", user.FirstName);
                    component.set("v.customLabelMap", responseValue.customLabelMap);
                    component.set("v.showFooterComponent", true);
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showComplaintManagementComponent", true);
                    component.set("v.showSpinner", false);
                } else {
                    component.set("v.showFooterComponent", true);
                    component.set("v.showHeaderComponent", true);
                    component.set("v.showComplaintManagementComponent", true);
                    component.set("v.showSpinner", false);
                }
            });
            
            $A.enqueueAction(action);
            
        } catch (error) {
            //console.log('error in trs home page : ' + error);
        }
    },
    
    handleGoToMyAccountPage: function(component, event, helper) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let accountId = component.get("v.accountId");
        let encodeId = btoa(accountId);
        let encodeURL = baseUrl+"s/my-account?id="+encodeId;
        
        window.open(encodeURL, '_self');
    },
    
})