({
    // complete Helper is for TGK 16
	openChat : function(cmp, event, helper){
        
        
        cmp.set('v.chatOpen',true);
        //var caseObject = cmp.get('v.caseObject');
        console.log('caseId ::'+cmp.get("v.ClaimsDetails[0].Id"));
        var action = cmp.get("c.updateChatFields");
        action.setParams({
            caseId : cmp.get("v.ClaimsDetails[0].Id")	//caseObject.Id
        });
        action.setCallback(this, function(response) {
			
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
                cmp.set("v.chatWrap" ,result);
                console.log('----chatOpenSuc:'+JSON.stringify(result));
                if(result.chatList.length > 0){
					setTimeout(
                        function() {
                          document.getElementById('scrollView').scrollIntoView(true); 
                        }, 500);
                    
                    cmp.set("v.unreadMessageCount", 0); 
                     
                }
                
                
                
            }
            else if (state === "INCOMPLETE") {
                
            }else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        
                    }
                } else {
                    
                }
            }
        });
        
        $A.enqueueAction(action); 

        helper.openChatBoxHelper(cmp, event, helper); 
        
    },
    readFile: function(component, helper, file,fileLable) {
        
        //var caseObject = component.get('v.caseObject');
        var recordId = component.get("v.ClaimsDetails[0].Id")	//caseObject.Id;
        
        const currentDate = new Date();
        const timestamp = currentDate.getTime();
        
        if (!file) {return;}
        

        let icon = file.name.toLowerCase();
        const ext = ['.pdf', '.doc', '.docx', '.txt', '.rtf','.odt', '.xls', '.xlsx', '.ods', '.msg', '.csv', '.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp', '.mp3', '.mp4', '.wmv', '.wav', '.ppt', '.pptx'];
        var fileTypeCheck = ext.some(el => icon.endsWith(el));
        if (!fileTypeCheck) {
           return alert("File type not supported!");
        }
        
        var sizeInMB = (file.size / (1024*1024)).toFixed(2);
        if(sizeInMB > 20){
             return alert("File size is greater than 20mb");
        }         
        var baseUrl = component.get("v.secureURI");

        var baseUrlLength = baseUrl.length;
        var indexOfQueryStart = baseUrl.indexOf("?");
        var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
        
        var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ file.name+ baseUrl.substring(indexOfQueryStart);
        
        component.set("v.azureLink", baseUrl.substring(0, indexOfQueryStart) + '/'+recordId+'-'+timestamp +'-'+ file.name+sasKeys);
        component.set("v.fileNameInAzure", recordId+'-'+timestamp +'-'+ file.name);
        
        var reader = new FileReader();
        reader.onload = function() {
            var dataURL = reader.result;
            helper.upload(component, file, dataURL.match(/,(.*)$/)[1],submitUri,fileLable);
        };
        reader.readAsDataURL(file);
    },
    upload: function(component, file, base64Data,submitUri,fileLable) {
        
        
        //var caseObject = component.get('v.caseObject');
        var chatWrap = component.get("v.chatWrap");

        var xhr = new XMLHttpRequest();
        var endPoint = submitUri;
        component.set("v.message", "Uploading...");
        
        xhr.open("PUT", endPoint, true);
        xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
        xhr.setRequestHeader('Content-Type', file.type);


        xhr.onreadystatechange = function () {
            
            if (xhr.readyState === 4 && xhr.status === 201) {               
                var action = component.get("c.saveFile"); 
                action.setParams({

                    caseId : component.get("v.ClaimsDetails[0].Id"),	//caseObject.Id,
                    fromId : chatWrap.currentContactId,
                    toId : chatWrap.otherPartyContactId,
                    fileName: file.name,
                    azureLink: component.get('v.azureLink'),
					fileType :(file.name).split('.').pop(),	
                    fileSize :file.size,
                    fileLable :fileLable,
					fileNameInAzure : component.get('v.fileNameInAzure'),
					scheme : 'Zero Deposite',
                    accessCode: component.get("v.accessCode")
                     
                });
                action.setCallback(this, function(a) {
                    let state = a.getState();
                    let errors = a.getError();
                    if (state == "SUCCESS") {
                        let result = a.getReturnValue();
                        
                        component.set("v.chatWrap" ,result);
                        component.set("v.fileLableVisible", false); 
                        component.set("v.fileName", "");
                        component.set('v.showEvidenceCmp',false);
						
						setTimeout(
                        function() {
                          document.getElementById('scrollView').scrollIntoView(true); 
                        }, 500);                         
						// Close upload file
                    }
                });
                $A.enqueueAction(action);
                
            }else{
                //image error code
            }
        };
        xhr.send(file);
    },
    openChatBoxHelper:function (cmp, event, helper){
         
        // data needs to be loaded here 
        
        var wrap = cmp.get('v.chatWrap'); 
        //var caseObject = cmp.get('v.caseObject');

        var action = cmp.get("c.updateChatFields");
        action.setParams({
            caseId : cmp.get("v.ClaimsDetails[0].Id"),	//caseObject.Id
            accessCode: cmp.get("v.accessCode")
            
            
        });
        action.setCallback(this, function(response) {
			
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var result =response.getReturnValue();
                
                cmp.set("v.chatWrap" ,result);
                if(wrap.ChatList.length != result.ChatList.length){
                    document.getElementById('scrollView').scrollIntoView(true); 
                }
                
                
            }
            else if (state === "INCOMPLETE") {
                
                
                
                // alert('INCOMPLETE');
            }else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        
                    }
                } else {
                    
                }
            }
        });
        
        $A.enqueueAction(action);         
		
         var chatOpen = cmp.get('v.chatOpen');
         if(chatOpen == true){

             setTimeout($A.getCallback(() => this.openChatBoxHelper(cmp, event, helper)), 2000)
         }
        
 	},
})