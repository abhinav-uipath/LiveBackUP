({
  doInitHelper: function (component, event, helper) {
    //console.log('do in it');
  },

  helperUpdateAccountDetails: function (component, event, helper) {
    component.set("v.usernameErrorMessage", false);
    component.set("v.successMsg", false);
    component.set("v.errorMsg", false);

    var action = component.get("c.accountInformationUpdate");
    component.set("v.showSpinner", true);
    action.setParams({
      accountObj: component.get("v.accountObject")
    });

    action.setCallback(this, function (response) {
      var state = response.getState();

      if (state == "SUCCESS") {
        var result = response.getReturnValue();

        if (result == 'Invalid') {
          component.set("v.usernameErrorMessage", true);
          $("html, body").animate({ scrollTop: $("#MyAccountErrorDiv").offset().top - 5 }, 500);
          // alert('This username has been already taken.');
        } else {
          //console.log("result :" + JSON.stringify(result));
          component.set("v.usernameErrorMessage", false);
          component.set("v.successMsg", true);
          component.set("v.errorMsg", false);
          $("html, body").animate({ scrollTop: $("#MyAccountErrorDiv").offset().top - 5 }, 500);

        }
      } else if (state === "ERROR") {
        component.set("v.errorMsg", true);
        component.set("v.successMsg", false);
        $("html, body").animate({ scrollTop: $("#MyAccountErrorDiv").offset().top - 5 }, 500);
      }
      component.set("v.showSpinner", false);
    });
    $A.enqueueAction(action);
  },
})