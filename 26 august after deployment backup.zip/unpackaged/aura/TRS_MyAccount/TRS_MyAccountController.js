({
    doInit: function (component, event, helper) {
        try {
            let accountId = component.get("v.accountId");

            var action = component.get("c.getAccountInformation");

            action.setParams({
                accountId: accountId
            });

            action.setCallback(this, function (response) {
                let state = response.getState();
                let responseValue = response.getReturnValue();

                if (state == 'SUCCESS') {
                    component.set("v.accountObject", responseValue.accountObject);
                    //component.set("v.accountObject", { Phone: '' });
                    //  component.set("v.salutationList", responseValue.salutationList);
                    component.set("v.phoneCodeList", responseValue.phoneCodeList);
                    component.set("v.propertytAddressOfTheComplaint", responseValue.propertytAddressOfTheComplaint);

                    var accountObject = responseValue.accountObject;
                    //setting Address details
                    let houseNumber = component.get("v.accountObject.HouseNo__c");
                    let streetName = component.get("v.accountObject.BillingStreet");
                    let city = component.get("v.accountObject.BillingCity");
                    let postalCode = component.get("v.accountObject.BillingPostalCode");
                    let country = component.get("v.accountObject.BillingCountry");
                    var completeMailingAddress;
                    if (accountObject != null && accountObject != undefined) {
                        /* if (component.get("v.accountObject.BillingState") != '' && component.get("v.accountObject.BillingState") != null && component.get("v.accountObject.BillingState") != undefined) {
                             //completeMailingAddress =component.get("v.accountObject.BillingStreet")+"\n"+component.get("v.accountObject.BillingCity")+"\n"+component.get("v.accountObject.BillingState")+"\n"+component.get("v.accountObject.BillingPostalCode")+"\n"+component.get("v.accountObject.Base_Country__c")+"\n"+component.get("v.accountObject.BillingCountry");
                             completeMailingAddress = component.get("v.accountObject.BillingStreet") + "\n" + component.get("v.accountObject.BillingCity") + "\n" + component.get("v.accountObject.BillingState") + "\n" + component.get("v.accountObject.BillingPostalCode") + "\n" + component.get("v.accountObject.BillingCountry");
                         } else {
                             //completeMailingAddress =component.get("v.accountObject.BillingStreet")+"\n"+component.get("v.accountObject.BillingCity")+"\n"+component.get("v.accountObject.BillingPostalCode")+"\n"+component.get("v.accountObject.Base_Country__c")+"\n"+component.get("v.accountObject.BillingCountry");
                             completeMailingAddress = component.get("v.accountObject.BillingStreet") + "\n" + component.get("v.accountObject.BillingCity") + "\n" + component.get("v.accountObject.BillingPostalCode") + "\n" + component.get("v.accountObject.BillingCountry");
                         }*/
                        completeMailingAddress = component.get("v.accountObject.BillingStreet") + "\n" + component.get("v.accountObject.BillingCity") + "\n" + component.get("v.accountObject.BillingPostalCode") + "\n" + component.get("v.accountObject.BillingCountry");
                        var House_No = component.get("v.accountObject.HouseNo__c");
                        if (House_No != null && House_No != '' && House_No != undefined && House_No != streetName) {
                            completeMailingAddress = House_No + ", " + completeMailingAddress;
                        }
                    }

                    if ((houseNumber == undefined) &&
                        (streetName == undefined) &&
                        (city == undefined) &&
                        (postalCode == undefined) &&
                        (country == undefined)) {
                        completeMailingAddress = '';
                    }
                    component.set("v.textareaval", completeMailingAddress);
                } else {

                }
            });

            $A.enqueueAction(action);
        }
        catch (ex) {
            //console.log(ex);
        }
    },

    handleFieldFocus: function (component, event, helper) {
        let fieldName = event.target.name;

        switch (fieldName) {
            case "firstName":
                let firstNameField = component.find('firstNameFld').getElement();
                firstNameField.focus();
                break;
            case "lastName":
                var lastNameField = component.find('lastNameFld').getElement();
                lastNameField.focus();
                break;
        }
    },

    handleCloseChangePasswordModal: function (component, event, helper) {

        component.set("v.showPasswordUpdatedSuccessMessage", false);
        component.set("v.passwordErrorMsg", false);
        component.set("v.showCurrentPasswordError", false);
        component.set("v.showNewPasswordError", false);
        component.set("v.showVerifyPasswordError", false);
        document.getElementById("sf-popup-current_pass").value = "";
        document.getElementById("sf-popup-new_pass").value = "";
        document.getElementById("sf-popup-verify_pass").value = "";
    },

    handleUpdatePassword: function (component, event, helper) {
        let isValid = true;

        let currentPassword = document.getElementById("sf-popup-current_pass").value;
        let newPassword = document.getElementById("sf-popup-new_pass").value;
        let verifyPassword = document.getElementById("sf-popup-verify_pass").value;

        component.set("v.showCurrentPasswordError", false);
        component.set("v.showNewPasswordError", false);
        component.set("v.showVerifyPasswordError", false);

        if (currentPassword == undefined || currentPassword == "" || currentPassword == null) {
            component.set("v.showCurrentPasswordError", true);
            isValid = false;
        }

        if (newPassword == undefined || newPassword == "" || newPassword == null) {
            component.set("v.showNewPasswordError", true);
            isValid = false;
        }

        if (verifyPassword == undefined || verifyPassword == "" || verifyPassword == null) {
            component.set("v.showVerifyPasswordError", true);
            isValid = false;
        }

        if (isValid) {
            try {
                var action = component.get("c.changeuserpassword");
                action.setParams({
                    newPassword: newPassword,
                    verifyNewPassword: verifyPassword,
                    oldPassword: currentPassword
                });
                action.setCallback(this, function (response) {
                    //var state = response.getReturnValue();
                    var result = response.getReturnValue();
                    var state = response.getState();
                    //  alert(state);               
                    if (state === "SUCCESS") {
                        // alert(result);                    
                        if (result == "Success") {
                            component.set("v.passwordSuccessMsg", true);
                            document.getElementById("sf-popup-current_pass").value = "";
                            document.getElementById("sf-popup-new_pass").value = "";
                            document.getElementById("sf-popup-verify_pass").value = "";
                            $A.get("e.force:refreshView").fire();
                        }
                        else {
                            document.getElementById("sf-popup-current_pass").value = "";
                            document.getElementById("sf-popup-new_pass").value = "";
                            document.getElementById("sf-popup-verify_pass").value = "";
                            component.set("v.ErrorMessage", result);
                            if (result == 'Your password must be atleast 8 characters long and include letters and numbers.') {
                                component.set("v.ErrorMessage", 'Your password must be at least 8 characters long and include at least 1 letter and number.');
                            } else if (result == 'Your password must include letters and numbers') {
                                component.set("v.ErrorMessage", 'Your password must include at least 1 letter and number.');
                            } else if (result == 'Error: Your old password is invalid.') {
                                component.set("v.ErrorMessage", 'Your current password is invalid.');
                            }
                            component.set("v.passwordErrorMsg", true);
                        }

                        //$A.get("e.force:refreshView").fire();
                    }
                    else {
                        document.getElementById("sf-popup-current_pass").value = "";
                        document.getElementById("sf-popup-new_pass").value = "";
                        document.getElementById("sf-popup-verify_pass").value = "";
                        component.set("v.ErrorMessage", state);
                        if (state == 'Your password must be atleast 8 characters long and include letters and numbers.') {
                            component.set("v.ErrorMessage", 'Your password must be at least 8 characters long and include at least 1 letter and number.');
                        }
                        else if (state == 'Your password must include letters and numbers') {
                            component.set("v.ErrorMessage", 'Your password must include at least 1 letter and number.');
                        }
                        else if (state == 'Error: Your old password is invalid.') {
                            component.set("v.ErrorMessage", 'Your current password is invalid.');
                        }
                        component.set("v.passwordErrorMsg", true);
                        // $A.get("e.force:refreshView").fire();
                    }
                    component.set("v.showSpinner", false);
                });
                $A.enqueueAction(action);
            }
            catch (e) {
                //console.log('Catch block update password :' + e);
            }
        }
        else {

        }
    },

    handleSubmitContactDetails: function (component, event, helper) {
        console.log('handle submit contact details');
        try {

            var isValid = true;

            // var accountSalutation = document.getElementById("salutationId").value;
            var firstName = document.getElementById("sf-First").value;
            var lastName = document.getElementById("sf-Surname").value;
            var PhoneCode = document.getElementById("phoneCodeId").value;
            var phonecheck = document.getElementById("sf-Telephone").value;
            //  var Landlinecheck = document.getElementById("sf-Landline").value;
            var emailcheck = document.getElementById("sf-email").value;

            component.set("v.successMsg", false);
            component.set("v.errorMsg", false);
            //    component.set("v.titleError", false);
            component.set("v.firstNameError", false);
            component.set("v.SurNameError", false);
            component.set("v.EmailError", false);
            component.set("v.usernameErrorMessage", false);
            component.set("v.invalidEmailError", false);
            component.set("v.mobileError", false);
            component.set("v.invalidMobileError", false);
            component.set("v.PhonelengthError", false);
            // component.set("v.invalidLandlineError",false);

            component.set("v.houseNoCurrentError", false);
            component.set("v.streetCurrentError", false);
            component.set("v.cityCurrentError", false);
            component.set("v.postcodeCurrentError", false);
            component.set("v.baseCountryCurrentError", false);
            component.set("v.countryCurrentError", false);

            var letters = /^[0-9]+$/;

            /*   if (accountSalutation == undefined || accountSalutation == "" || accountSalutation == null || accountSalutation == "-- Select Title --") {
                    component.set("v.titleError", true);
                    isValid = false;
                }*/
            if (firstName == undefined || firstName == "" || firstName == null) {
                component.set("v.firstNameError", true);
                isValid = false;
            }
            if (lastName == undefined || lastName == "" || lastName == null) {
                component.set("v.SurNameError", true);
                isValid = false;
            }

            var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

            if (emailcheck == undefined || emailcheck == "" || emailcheck == null) {
                component.set("v.EmailError", true);
                isValid = false;
            }

            else if (emailcheck.match(regExpEmailformat) == null) {
                component.set("v.invalidEmailError", true);
                isValid = false;
            }

            /*if (phonecheck == undefined || phonecheck == "" || phonecheck == null) {
                component.set("v.mobileError", true);
                isValid = false;
            }

            else if (phonecheck.match(letters) == null) {
                component.set("v.invalidMobileError", true);
                isValid = false;
            }
            else if (PhoneCode == "+44" && (phonecheck.length != 11)) {
                component.set("v.PhonelengthError", true);
                isValid = false;
            }*/

            /*   var Landlinecheck1 = Landlinecheck.replace(/ +/g, "");
           if(Landlinecheck1 == undefined || Landlinecheck1 == "" || Landlinecheck1 == null || Landlinecheck1.match(letters) == null ){
                   component.set("v.invalidLandlineError", true);
                   isValid = false;
               }*/

            //Add Address validations

            // Creating Account object 
            var AccountObj = component.get("v.accountObject");
            // AccountObj.Salutation = accountSalutation;
            AccountObj.PersonEmail = emailcheck;
            //  AccountObj.Phone_Code__c = PhoneCode;
            AccountObj.Phone = phonecheck;
            AccountObj.FirstName = firstName;
            AccountObj.LastName = lastName;
            // AccountObj.PersonHomePhone = Landlinecheck;

            var loqateObj = component.find("compB");
            console.log('loqateObj ' + loqateObj);
            if (loqateObj != undefined) {
                var enterManually = loqateObj.get("v.enterManually");
                if (loqateObj.get("v.County") != "" && loqateObj.get("v.County") != undefined && typeof loqateObj.get("v.loqateObj") != "undefined") {
                    AccountObj.BillingState = loqateObj.get("v.County");
                }
                else {
                    AccountObj.BillingState = null;
                }
                if (loqateObj.get("v.Town") != "" && loqateObj.get("v.Town") != undefined && typeof loqateObj.get("v.Town") != "undefined") {
                    AccountObj.BillingCity = loqateObj.get("v.Town");
                }
                else {
                    AccountObj.BillingCity = null;
                    if (enterManually == true) {
                        isValid = false;
                        component.set("v.cityCurrentError", true);
                    }
                }
                if (loqateObj.get("v.AddressLine1") != "" && loqateObj.get("v.AddressLine1") != undefined && typeof loqateObj.get("v.AddressLine1") != "undefined") {
                    AccountObj.BillingStreet = loqateObj.get("v.AddressLine1");// + " \n " + objChild.get("v.Street");
                }
                else {
                    AccountObj.BillingStreet = null;
                    if (enterManually == true) {
                        isValid = false;
                        component.set("v.streetCurrentError", true);
                    }
                }
                if (loqateObj.get("v.Country") != "" && loqateObj.get("v.Country") != undefined && typeof loqateObj.get("v.Country") != "undefined") {
                    AccountObj.BillingCountry = loqateObj.get("v.Country");
                }
                else {
                    AccountObj.BillingCountry = null;
                    if (enterManually == true) {
                        isValid = false;
                        component.set("v.countryCurrentError", true);
                    }
                }

                if (loqateObj.get("v.PostCode") != "" && loqateObj.get("v.PostCode") != undefined && typeof loqateObj.get("v.PostCode") != "undefined") {
                    AccountObj.BillingPostalCode = loqateObj.get("v.PostCode");
                }
                else {
                    AccountObj.BillingPostalCode = null;
                    if (enterManually == true) {
                        isValid = false;
                        component.set("v.postcodeCurrentError", true);
                    }
                }
                /*    if(loqateObj.get("v.BaseCountry") != "" && loqateObj.get("v.BaseCountry") != undefined &&  typeof loqateObj.get("v.BaseCountry") != "undefined")
                    {
                      AccountObj.Base_Country__c = loqateObj.get("v.BaseCountry");
                    }
                         else
                    {
                      AccountObj.Base_Country__c = null;
                        if(enterManually == true)
                        {
                            isValid = false;
                            component.set("v.baseCountryCurrentError", true);
                        }
                    }    */
                if (loqateObj.get("v.houseNo") != "" && loqateObj.get("v.houseNo") != undefined && typeof loqateObj.get("v.houseNo") != "undefined") {
                    AccountObj.HouseNo__c = loqateObj.get("v.houseNo");
                }
                else {
                    AccountObj.HouseNo__c = null;
                    if (enterManually == true) {
                        isValid = false;
                        component.set("v.houseNoCurrentError", true);
                    }
                }
            }

            //Update account address fields
            component.set("v.accountObject", AccountObj);

            if (isValid) {
                helper.helperUpdateAccountDetails(component, event, helper);
            }
            else {
                $("html, body").animate({ scrollTop: $("#MyAccountErrorDiv").offset().top - 5 }, 500);
            }
        }
        catch (e) {
            //console.log("catch block account contr" + e);
        }
    },

    closeEditAdd: function (component, event, helper) {
        component.set("v.editAddress", false);
    },

    editAdd: function (component, event, helper) {
        component.set("v.editAddress", true);
    },

    clickPasswordChange: function (component, event, helper) {
        $("html, body").animate(
            { scrollTop: $("#Passwordchange").offset().top - 100 },
            1000
        );
    },

    hideBootstrapErrors: function (component, event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "passSuccessMessage":
                component.set("v.showPasswordUpdatedSuccessMessage", false);
                break;
            case "passErrorMessage":
                component.set("v.passwordErrorMsg", false);
                break;
            case "passwordFieldMandatoryMsg":
                component.set("v.showCurrentPasswordError", false);
                break;
            case "newPasswordFieldMandatoryMsg":
                component.set("v.showNewPasswordError", false);
                break;
            case "showVerifyPasswordErrorMsg":
                component.set("v.showVerifyPasswordError", false);
                break;
            case "SuccessMessage":
                component.set("v.successMsg", false);
                break;
            case "ErrorMessage":
                component.set("v.errorMsg", false);
                break;
            /*  case "title":
                  component.set("v.titleError", false);
                  break;*/
            case "firstName":
                component.set("v.firstNameError", false);
                break;
            case "surName":
                component.set("v.SurNameError", false);
                break;
            case "emailOfUser":
                component.set("v.EmailError", false);
                break;
            case "mobileNumber":
                component.set("v.mobileError", false);
                break;
            case "Phonelength":
                component.set("v.PhonelengthError", false);
                break;
            case "usernameError":
                component.set("v.usernameErrorMessage", false);
                break;
            case "invalidEmailErrorAlert":
                component.set("v.invalidEmailError", false);
                break;
            case "invalidMobileAlert":
                component.set("v.invalidMobileError", false);
                break;
            /*  case "invalidLandlineAlert":
                  component.set("v.invalidLandlineError", false);
                  break;      */
        }
    },

    addressUpdate: function (component, event, helper) {
        var loqateObj = component.find("compB");

        component.set("v.orgAdd.Country__c", loqateObj.get("v.Country"));
        component.set("v.orgAdd.Postcode__c", loqateObj.get("v.PostCode"));
        component.set("v.orgAdd.Town_City__c", loqateObj.get("v.Town"));
        component.set("v.orgAdd.County__c", loqateObj.get("v.County"));
        component.set("v.orgAdd.Base_County__c", loqateObj.get("v.BaseCountry"));
        component.set("v.orgAdd.House_No__c", loqateObj.get("v.houseNo"));
        var StreetAddress;
        if (loqateObj.get("v.AddressLine1") != "undefined " && loqateObj.get("v.AddressLine1") != undefined
            && loqateObj.get("v.Street") != "undefined " && loqateObj.get("v.Street") != undefined) {
            StreetAddress =
                loqateObj.get("v.AddressLine1") + "\n " + loqateObj.get("v.Street");
        }
        else if (loqateObj.get("v.AddressLine1") != "undefined " && loqateObj.get("v.AddressLine1") != undefined) {
            StreetAddress =
                loqateObj.get("v.AddressLine1");
        }
        else if (loqateObj.get("v.Street") != "undefined " && loqateObj.get("v.Street") != undefined) {
            StreetAddress = loqateObj.get("v.Street");
        }
        component.set("v.orgAdd.Address__c", StreetAddress);
        component.set("v.editOrgDetails", true);
    },

    validatePhoneNumber: function (component, event, helper) {
        if (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46) {

        } else if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault();
        }
    }
})