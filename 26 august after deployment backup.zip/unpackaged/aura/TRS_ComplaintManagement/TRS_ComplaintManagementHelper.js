({
    showSpinner: function (component) {
        component.set("v.showSpinner", true);
    },

    hideSpinner: function (component) {
        component.set("v.showSpinner", false);
    },

    getComplaintsInformation: function (component, isActiveComplaint) {
        this.showSpinner(component);

        let accountId = component.get("v.accountId");

        var action = component.get("c.getAllComplaintsInformationWrapper");

        action.setParams({
            isActiveComplaint: isActiveComplaint,
            accountId: accountId
        });

        action.setCallback(this, function (response) {
            let state = response.getState();
            let responseValue = response.getReturnValue();

            if (state == 'SUCCESS') {
                try {

                    if (responseValue == null) {
                        this.hideSpinner(component);
                        return;
                    }

                    component.set("v.complainantType", responseValue.complainantType);
                    component.set("v.currentUserProfileName", responseValue.currentUserProfileName);

                    let caseList = responseValue.caseList;
                    let pageSize = component.get("v.pageSize");

                    component.set("v.caseList", caseList);

                    if (caseList) {
                        component.set("v.totalRecordCount", caseList.length);
                        component.set("v.startPage", 0);
                        component.set("v.endPage", pageSize - 1);

                        var paginationList = [];
                        for (let i = 0; i < pageSize; i++) {
                            if (component.get("v.caseList").length > i) {
                                paginationList.push(component.get("v.caseList")[i]);
                            }
                        }
                        let totalPageCount = Math.ceil(caseList.length / pageSize);

                        component.set("v.paginationList", paginationList);
                        component.set("v.selectedCount", 0);
                        component.set("v.totalPageCount", totalPageCount);

                        if (totalPageCount == 0) {
                            component.set("v.currentPage", totalPageCount);
                        } else {
                            component.set("v.currentPage", 1);
                        }
                    }
                } catch (error) {
                    //console.log('error in getComplaintsInformation : ' + error);
                }

                this.hideSpinner(component);
            } else {
                this.hideSpinner(component);
            }
        });

        $A.enqueueAction(action);
    },

    goToNextPage: function (component, startPage, endPage, pageSize, caseList) {
        let paginationList = [];
        let counter = 0;

        for (let i = endPage + 1; i < endPage + pageSize + 1; i++) {
            if (caseList.length > i) {
                paginationList.push(caseList[i]);
            }
            counter++;
        }

        startPage = startPage + counter;
        endPage = endPage + counter;

        component.set("v.startPage", startPage);
        component.set("v.endPage", endPage);
        component.set("v.paginationList", paginationList);
    },

    goToPreviousPage: function (component, startPage, endPage, pageSize, caseList) {
        let paginationList = [];
        let counter = 0;

        for (let i = startPage - pageSize; i < startPage; i++) {
            if (i > -1) {
                paginationList.push(caseList[i]);
                counter++;
            } else {
                startPage++;
            }
        }

        startPage = startPage - counter;
        endPage = endPage - counter;

        component.set("v.startPage", startPage);
        component.set("v.endPage", endPage);
        component.set("v.paginationList", paginationList);
    },

    downloadResolutionAgreement: function (component, downloadURL) {
        let encodeURL = downloadURL;
        window.open(encodeURL, '');
    }

})