({
    doInit: function (component, event, helper) {
        helper.getComplaintsInformation(component, true);
    },

    handleGetActiveComplaints: function (component, event, helper) {
        component.set("v.archiveComplaintClass", "go-back");
        component.set("v.activeComplaintClass", "see-all");

        component.set("v.showActiveComplaints", true);
        helper.getComplaintsInformation(component, true);
    },

    handleGetArchivedComplaints: function (component, event, helper) {
        component.set("v.archiveComplaintClass", "see-all");
        component.set("v.activeComplaintClass", "go-back");

        component.set("v.showActiveComplaints", false);
        helper.getComplaintsInformation(component, false);
    },

    handlePageNavigation: function (component, event, helper) {
        let caseList = component.get("v.caseList");
        let startPage = component.get("v.startPage");
        let endPage = component.get("v.endPage");
        let pageSize = component.get("v.pageSize");

        if (event.target.id == "nextId") {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.goToNextPage(component, startPage, endPage, pageSize, caseList);
        } else if (event.target.id == "previousId") {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.goToPreviousPage(component, startPage, endPage, pageSize, caseList);
        }
    },

    handleShowCaseSummary: function (component, event, helper) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let caseStatus = event.target.name;
        let complainantType = component.get("v.complainantType");
        let currentUserProfileName = component.get("v.currentUserProfileName");
        let downloadURL = event.target.className;

        if (caseStatus == 'On Hold' || caseStatus == 'Complaint in progress' || caseStatus == 'Complaint received by TRS' ||
            caseStatus == 'Complaint rejected' || caseStatus == 'Complaint accepted - awaiting response tenant' ||
            caseStatus == 'Complaint accepted - awaiting response landlord' || caseStatus == 'Conciliation in progress' ||
            caseStatus == 'Conciliation closed - awaiting resolution agreement report' || caseStatus == 'Case referred to TRS Adjudication' ||
            caseStatus == 'Complaint closed') {
            // do nothing
        } else if (caseStatus == 'Resolution agreement report issued' || caseStatus == 'Resolution agreement report issued - tenant' || caseStatus == 'Resolution agreement report issued - landlord' || caseStatus == 'Complaint closed') {
            helper.downloadResolutionAgreement(component, downloadURL);
        } else if (caseStatus == 'Tenant evidence submission in progress') {
            /*if(complainantType == 'Tenant') {
                if(currentUserProfileName == 'TRS Tenant') {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                }
            } else {
                if(currentUserProfileName == 'TRS Tenant') {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                } else {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                }
            }*/
            if (!(downloadURL == 'Tenant' && currentUserProfileName == 'TRS Landlord')) {
                let encodeId = btoa(event.target.id);
                let encodeURL = baseUrl + "s/summary-of-complaint?id=" + encodeId;
                window.open(encodeURL, '_self');
            }
        } else if (caseStatus == 'Landlord evidence submission in progress') {
            /*if(complainantType == 'Tenant') {
                if(currentUserProfileName == 'TRS Tenant') {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                } else {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                }
            } else {
                if(currentUserProfileName != 'TRS Tenant') {
                    let encodeId = btoa(event.target.id);
                    let encodeURL = baseUrl+"summary-of-complaint?id="+encodeId;
                    window.open(encodeURL, '_self');
                }
            }*/
            if (!(downloadURL == 'Landlord' && currentUserProfileName == 'TRS Tenant')) {
                let encodeId = btoa(event.target.id);
                let encodeURL = baseUrl + "s/summary-of-complaint?id=" + encodeId;
                window.open(encodeURL, '_self');
            }
        } else {
            let encodeId = btoa(event.target.id);
            let encodeURL = baseUrl + "s/summary-of-complaint?id=" + encodeId;
            window.open(encodeURL, '_self');
        }
    },

    handleGoToCreateComplaint: function (component, event, helper) {
        let baseUrl = $A.get("$Label.c.TRS_PortalHomePage");
        let encodeURL = baseUrl+"s/create-complaint";
        window.open(encodeURL, '_self');
    }

})