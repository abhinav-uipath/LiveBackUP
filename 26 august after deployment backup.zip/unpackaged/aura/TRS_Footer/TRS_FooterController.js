({
    doInit: function(component, event, helper) {
        let customLabelMap = component.get("v.customLabelMap");

        component.set("v.TRS_AboutUS", customLabelMap['TRS_AboutUS']);
        component.set("v.TRS_ContactUs", customLabelMap['TRS_ContactUs']);
        component.set("v.TRS_Support", customLabelMap['TRS_Support']);
        component.set("v.TRS_Independent_Complaints_Reviewer", customLabelMap['TRS_Independent_Complaints_Reviewer']);
        component.set("v.TRS_Careers", customLabelMap['TRS_Careers']);
        component.set("v.TRS_Governance", customLabelMap['TRS_Governance']);
        component.set("v.TRS_NRLA", customLabelMap['TRS_NRLA']);
        component.set("v.TRS_Media", customLabelMap['TRS_Media']);
        component.set("v.TRS_Complaining_about_the_Tenancy_Redress_Service_itself", customLabelMap['TRS_Complaining_about_the_Tenancy_Redress_Service_itself']);
        component.set("v.TRS_Scheme", customLabelMap['TRS_Scheme']);
        component.set("v.TRS_New_Home", customLabelMap['TRS_New_Home']);
    },
})