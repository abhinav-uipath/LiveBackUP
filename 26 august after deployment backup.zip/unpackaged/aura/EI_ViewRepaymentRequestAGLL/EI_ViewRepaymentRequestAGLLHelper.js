({
	 logoutHelper: function(component) {
    		var name = component.get("v.currentUser.TestName__c");
	/*	let x = document.cookie;
        console.log('cook ' + x);
       document.cookie = "UName="+name+" ; Expires = 1980-02-02T18:06:21.466Z;path=/;";
		let x2 = document.cookie;
        console.log('cook2 ' + x2);*/
      var cookie ={
          setCookie: function (strName, strValue,cntdays) {
				var days = cntdays != undefined && cntdays !== "" ? cntdays : 60,
					date = new Date(),
					domain = document.location.hostname;
				date.setTime(date.getTime() - ( 24 * 60 * 60 * 1000));
				var expires = date.toUTCString();
				// handle secure vs regular http differently for cookie purposes
				if (location.protocol == 'http:') {
					document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/";
				} else {
					document.cookie = strName + "=" + strValue + ";Expires=" + expires + ";Domain=" + domain + ";Path=/;Secure";
				}
			}
      }
         cookie.setCookie("UName",name,1);
        let currentURL = window.location.origin;
        let redirectURL = $A.get("$Label.c.Lightning_CommunityLogout_URL")+"secur/logout.jsp?retUrl="+$A.get("$Label.c.Lightning_Component_URL");
        window.location.replace(redirectURL);
  
    
	},
})