import { LightningElement, wire } from 'lwc';
import getKnowledgeArticleCategories from '@salesforce/apex/KnowledgeArticleController.getArticlesByCategory';

export default class KnowledgeArticlesTabset extends LightningElement {
    categories;

    @wire(getKnowledgeArticleCategories)
    wiredCategories({ error, data }) {
        if (data) {
            console.log('inside data ');
            console.log('## data  ',data);
            this.categories = data;
            console.log('## this.categories  ',this.categories);
        } else if (error) {
            console.log('inside error ');
            console.error('Error loading categories:', error);
        }
    }
}