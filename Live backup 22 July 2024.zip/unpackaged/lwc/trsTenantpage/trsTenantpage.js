import { LightningElement } from 'lwc';

export default class TrsTenantpage extends LightningElement {

}