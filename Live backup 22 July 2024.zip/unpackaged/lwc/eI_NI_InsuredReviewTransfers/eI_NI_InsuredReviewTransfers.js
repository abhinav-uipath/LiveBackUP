import { LightningElement,track,wire,api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import { NavigationMixin } from 'lightning/navigation';
import processRejectDeposit from '@salesforce/apex/EI_NI_TransferDeposit.processRejectDeposit';
import checkDepositAllocationMultipleTenantName from '@salesforce/apex/EI_NI_TransferDeposit.checkDepositAllocationMultipleTenantName';
import getDepositInformationTransferred from '@salesforce/apex/EI_NI_TransferDeposit.getDepositInformationTransferred';
import processMultipleAcceptDeposit from '@salesforce/apex/EI_NI_TransferDeposit.processMultipleAcceptDeposit';
import fetchCurrenUserWrapper from '@salesforce/apex/EI_NI_TransferDeposit.fetchCurrenUserWrapper';
import TDSResource from '@salesforce/resourceUrl/TDSTheme';
import ei_NI_AgllPostlogin from '@salesforce/label/c.ei_NI_AgllPostlogin';
import NI_transferInsuredDeposittoBranchUrl from '@salesforce/label/c.NI_transferInsuredDeposittoBranchUrl';
import NI_payDepositGoBackUrl from '@salesforce/label/c.NI_payDepositGoBackUrl';
export default class EI_NI_InsuredReviewTransfers extends NavigationMixin (LightningElement) {
    successImage = NI_Theme + '/assets/img/thank-you.png';
    resource3= `${TDSResource}/assets/img/question-circle.png`;
   // backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    //warningImg = NI_Theme + '/assets/img/warning-icon.png';

    @track TransferedDepositsList = [];
    @track TotalDeposits;
    @track currentPage=1;
    @track totalPagesCount=1;
    @track pageSize=50;
    @track PageSpinner = false;
    @api PaginationPropList = [];
    @track selectAllChecked = false;
    @track selectedRecords = [];
    @track listOfAllDeposits = [];
    @track selectedDepositIds = [];
    @track formattedStartDate;
    @track deposits = [];
    @track selectedDeposits=[];
    @track depositInfo = {};
    @track selectedCount = 0;
    @track resMessage;
    isCasePresentMsg = false;
    isRequestedDepositSection = true;
    isSuccessScreen = false;
    isAcceptingMsg = false;
    isRejectionMsg = false;
    isTenantvalueBlankErrorMsg = false;
    isunableErrorMsg = false;
    @track isTenantNameErrorMsg = false;
    @track isTenantNameErrorMsg1 = false;
    @track errors;
    @track tenantNames = '';

    enterTenantName = false;
    isStartPage = true;
    isEndPage = true;
    isEndPageNav = false;
    isStartPageNav = false;
    isStartPage = true;
    isEndPage = true;
    
    enterTenantNameMultiple = false;
    depositslength1 = false;
    @track totalRecordsCountPropList;
    @track isNoDepositsSelected = false;
    @track isCustodialUser = false;
    isCustodialCustomer = false;
    isGotoCustodialScreen= false;
    isCollapseOneShow = false;
    @track selectedIds = [];
    @track isNoDepositsSelectedforCustodial = false;
    @track isTransferTo ='';
    //selectCustAllChecked = true;

    @track currentAttempt = 3;
    @track isTenantNameErrorMsg = false;
    @track isTenantMaxAttemptsErrorMsg = false;
    @track disableSumbit = false;

    @track userBranchWrapper;
    @track currentUser;
    @track currentUserBranches = [];
    @track transferInsuredDeposittoBranchUrl = NI_transferInsuredDeposittoBranchUrl;
    @track goToBackDepositeSumary = NI_payDepositGoBackUrl;
    branchId ;
    showTransferToBranch = false;
    @track hardCodeUrl=ei_NI_AgllPostlogin;
    connectedCallback(){
        Promise.all([
            loadStyle(this, NI_Theme  + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme  + '/assets/js/plugin.min.js'),
            // loadScript(this, NI_Theme  + '/assets/js/custom.js'),
            // loadScript(this,NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            // loadScript(this,NI_Theme + '/assets/js/datepicker.js')
        ])
        .then(() => {
            console.log('Files loaded.');
            
        })
        .catch(error => {
            console.log(error.body.message);
        });  

        fetchCurrenUserWrapper({}).then(result => {
            console.log('fetchCurrenUserWrapper result>>>>' + JSON.stringify(result));
            this.userBranchWrapper = result[0];
            this.currentUser = this.userBranchWrapper.userData;
            this.currentUserBranches = this.userBranchWrapper.branches;

        }).catch(error => {
            console.log('Line 85 review transfer fetchCurrenUserWrapper error -> ' + JSON.stringify(error));
        })

        getDepositInformationTransferred({scheme :'Insured'})
        .then(result=>{
            if(result != null){
                console.log('DepositInformation==>'+JSON.stringify(result));
                this.TransferedDepositsList = result;
                console.log('No.of deposits==>'+this.TransferedDepositsList.length)
                this.TotalDeposits = this.TransferedDepositsList.length;
                console.log('TransferedDepositsList==>'+JSON.stringify(this.TransferedDepositsList));
                var NIDAN = result[0].objDeposit.NI_Deposit_Number__c;
                this.isCustodialUser =  result[0].objDeposit.Customer__r.Custodial_User__c;
                console.log('IsCustodial user==>'+this.isCustodialUser);
                console.log('NI==>'+NIDAN);
                console.log('No.ofAttempts==>'+result[0].objDeposit.No_of_attempt__c);
                console.log('isBulk_transfer_attempts__c==>'+result[0].objDeposit.Bulk_transfer_attempts__c);
                if(result==''){
                    this.currentPage = 1;
                }
                else {
                    this.currentPage = 1;
                }

                if(result[0].objDeposit.No_of_attempt__c!= undefined){
                    this.currentAttempt = 3-result[0].objDeposit.No_of_attempt__c;
                }
                if((result[0].objDeposit.No_of_attempt__c<=0 || result[0].objDeposit.No_of_attempt__c>=3)&& result[0].objDeposit.Bulk_transfer_attempts__c == true){
                    this.isTenantMaxAttemptsErrorMsg = true;
                    this.isTenantNameErrorMsg= false;
                    this.isTenantNameErrorMsg1 = false;
                    this.disableSumbit = true;
                }
                if(result[0].objDeposit.No_of_attempt__c==1){
                    this.isTenantNameErrorMsg1 = true;
                console.log('line 137'+this.currentAttempt);
                }
                if(result[0].objDeposit.No_of_attempt__c==2){
                    this.isTenantNameErrorMsg = true;
                }
                

                this.propertyList=result;
                console.log('propertyList111===='+ JSON.stringify(this.TransferedDepositsList));
                var pageSize = this.pageSize;
                var totalRecordsList = result;
                var totalLength = totalRecordsList.length;
                this.totalRecordsCountPropList=totalLength;
                this.startPage = 0;
                this.endPage = pageSize-1;
                var PaginationPropList = [];
                for (var i = 0; i < pageSize; i++) {
                 if ((this.propertyList).length > i) {
                    PaginationPropList.push(this.propertyList[i]);
                 }
                }
                this.PaginationPropList = PaginationPropList;
                //console.log('fetchPropertylist===='+ JSON.stringify(this.PaginationPropList));
                this.totalPagesCount=Math.ceil(totalLength / pageSize);
                if(this.totalPagesCount>1){
                    this.isEndPageNav =true;
                    this.isEndPage = false;
                   }
                   else{
                    this.isEndPage = true;
                    this.isEndPageNav = false;
                   }
             
                
            }
           console.log('line==>77')
            if(this.isCustodialUser){
                this.isCustodialCustomer = true;
            }
            else{
                this.isCustodialCustomer = false;
            }

            console.log('result[0].objDeposit.Protected_Amount__c.toFixed(2)'+result[0].objDeposit.Deposit_Amount__c);
           
        })
        .catch(error=>{
            console.log('error accured while loading data==>'+JSON.stringify(error));
        });
        
       
    }
    renderedCallback() {
        // if(this.TransferedDepositsList[0].objDeposit.No_of_attempt__c==0 && this.TransferedDepositsList[0].objDeposit.Bulk_transfer_attempts__c == true){
        //     this.isTenantMaxAttemptsErrorMsg = true;
        //     this.isTenantNameErrorMsg= false;
        //     this.disableSumbit = true;
        //     let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
        //      finalSubmit.style = 'opacity: 0.5';
        // }
    }
    addClick(event) {
        // var eventId= event.target.getAttribute('data-id') || event.target.parentNode.getAttribute('data-id');
        var eventId = event.currentTarget.dataset.id;
        const rowId = event.currentTarget.getAttribute('data-rowid');
        //var eventId = event.target.getAttribute('data-id')
        console.log('line 137 event-->', eventId);
        console.log('line 138 event rowId-->', rowId);
        const clickedTabId = event.currentTarget.dataset.rowid;
        console.log('selectedTabId==>'+clickedTabId);
        console.log('selectedDeposits==>'+JSON.stringify(this.selectedDeposits));

        var selectedDeposit = this.selectedDeposits.find(deposit => deposit.Id === rowId);
        // console.log('selectedDeposit==>'+selectedDeposit);
        // if (selectedDeposit) {
        //     selectedDeposit.isDropdownTrue = true;
            
        // }
        // else{
        //     selectedDeposit.isDropdownTrue = false;
        // }
        
        // console.log('Updated selectedDeposits:', this.selectedDeposits);
           
        if (selectedDeposit) {
            selectedDeposit.isDropdownTrue = true;
            
            // Set isDropdownTrue to false for all other deposits
            this.selectedDeposits.forEach(deposit => {
              if (deposit.Id !== rowId) {
                deposit.isDropdownTrue = false;
              }
            });
        }
    }
        // get isTabSelected() {
        //     return this.isCollapseOneShow && this.groupedDeposit.Id === this.selectedTabId;
        //   }
        
    handleSelectAllChange(event) {
        this.isNoDepositsSelected = false;
        this.selectAllChecked = event.target.checked;
        console.log('Check box ticked==>'+this.selectAllChecked);
        //var PaginationList = component.get("v.PaginationList");
        var updatedAllRecords = [];
        var listOfAllDeposits = this.PaginationPropList;
        // Get all the data checkboxes
        const dataCheckboxes = this.template.querySelectorAll('.dataCheckbox');
    
        // Iterate over each data checkbox and set their checked state
        dataCheckboxes.forEach((checkbox) => {
          checkbox.checked = this.selectAllChecked;
        });
        
        for (var i = 0; i < listOfAllDeposits.length; i++) {
            if(this.selectAllChecked){
                listOfAllDeposits[i].isChecked = true;
                this.selectedCount = listOfAllDeposits.length;
            }
            else{
                listOfAllDeposits[i].isChecked = false;
                this.selectedCount = 0;
            }
            updatedAllRecords.push(listOfAllDeposits[i]);
        }
        //this.updateSelectedRecords();
        console.log('Line=>114'+JSON.stringify(updatedAllRecords));

        
        var allRecords = listOfAllDeposits;
        var selectedRecords = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                selectedRecords.push(allRecords[i].objDeposit.Id);
            }
        }
            this.selectedDepositIds = selectedRecords;
            console.log('selectedDepIds All=>'+selectedRecords);
            console.log('No.of selected records==>'+this.selectedCount);
      }
       handleDataCheckboxChange(event) {
        this.isNoDepositsSelected = false;
       // this.selectedDeposits = this.Paginationlist
        const isChecked = event.target.checked;
        const recordId = event.target.getAttribute('data-key');
        console.log('recordId-107 => ' + recordId);
        console.log('isChecked => ' + isChecked);
        var getSelectedNumber = this.selectedCount;
        if(isChecked) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;

        }
        this.selectedCount = getSelectedNumber;
        console.log('No.of selected records single select ==>'+this.selectedCount);
      
        // Check if all individual checkboxes are checked
        const dataCheckboxes = document.querySelectorAll('.dataCheckbox');
        const allChecked = Array.from(dataCheckboxes).every((checkbox) => checkbox.checked);
        
        // Update the "Select All" checkbox based on whether all individual checkboxes are checked or not
        this.selectAllChecked = allChecked;
        if (!allChecked) {
            this.selectAllChecked = false;
            }

        this.updateSelectedRecords();
    
      }
       handleCustodialDataCheckboxChange(event) {
        this.isNoDepositsSelectedforCustodial=false;
        this.selectedIds = this.selectedDepositIds;
        const isChecked = event.target.checked;
        const recordId = event.target.getAttribute('data-key');
        console.log('recordId-235 => ' + recordId);
        console.log('isChecked => 236==>' + isChecked);
        
        const parentContainer = event.target.closest('.card-body'); // Find the parent container element
        const dataCheckboxes = parentContainer.querySelectorAll('.dataCheckbox');
      
        if (recordId === 'selectAll') {
          // If "Select All" checkbox is selected
          dataCheckboxes.forEach((checkbox) => {
            checkbox.checked = isChecked;
          });
      
          if (isChecked) {
            this.selectedIds = [...dataCheckboxes]
              .filter((checkbox) => checkbox.getAttribute('data-key') !== 'selectAll')
              .map((checkbox) => checkbox.getAttribute('data-key'));
          } else {
            //this.selectedIds = [];
          }
        } else {
          // If an individual checkbox is selected
          const selectedCheckboxIds = [...dataCheckboxes]
            .filter((checkbox) => checkbox.getAttribute('data-key') !== 'selectAll' && checkbox.checked)
            .map((checkbox) => checkbox.getAttribute('data-key'));
      
          if (isChecked) {
            if (!this.selectedIds.includes(recordId)) {
              this.selectedIds.push(recordId);
            }
          } else {
            const index = this.selectedIds.indexOf(recordId);
            if (index > -1) {
              this.selectedIds.splice(index, 1);
            }
          }
      
          // Update "Select All" checkbox based on the selected checkboxes
          const selectAllCheckbox = parentContainer.querySelector('.dataCheckbox[data-key="selectAll"]');
          selectAllCheckbox.checked = dataCheckboxes.length === selectedCheckboxIds.length;
        }
      
        // Create a new array and copy the values from the selectedIds property
        const newArray = [...this.selectedIds];
        this.selectedDepositIds = [...this.selectedIds];
        console.log('selected Records single 215==>', newArray);
        console.log('this.selectedDepositIds 281==>' + this.selectedDepositIds);

      /*  const allChecked = Array.from(dataCheckboxes).every((checkbox) => checkbox.checked);
       console.log('allcheckedFromCustodial==>'+allChecked);
       // Update the "Select All" checkbox based on whether all individual checkboxes are checked or not
       this.selectCustAllChecked = allChecked;
       if (!allChecked) {
        this.selectCustAllChecked = false;
        }*/
        
      }
      
      
    //   handleCustodialDataCheckboxChange(event) {
    //    // this.selectedDepositIds =[];
    //     const isChecked = event.target.checked;
    //     const recordId = event.target.getAttribute('data-key');
    //     console.log('recordId-235 => ' + recordId);
    //     console.log('isChecked => 236==>' + isChecked);
      
    //     const parentContainer = event.target.closest('.card-body'); // Find the parent container element
    //     const dataCheckboxes = parentContainer.querySelectorAll('.dataCheckbox');
      
    //     if (recordId === 'selectAll') {
    //       // If "Select All" checkbox is selected
    //       dataCheckboxes.forEach((checkbox) => {
    //         checkbox.checked = isChecked;
    //       });
      
    //       if (isChecked) {
    //         this.selectedIds = [...dataCheckboxes]
    //           .filter((checkbox) => checkbox.getAttribute('data-key') !== 'selectAll')
    //           .map((checkbox) => checkbox.getAttribute('data-key'));
    //       } else {
    //         this.selectedIds = [];
    //       }
    //     } else {
    //       // If an individual checkbox is selected
    //       const selectedCheckboxIds = [...dataCheckboxes]
    //         .filter((checkbox) => checkbox.checked && checkbox.getAttribute('data-key') !== 'selectAll')
    //         .map((checkbox) => checkbox.getAttribute('data-key'));
      
    //       if (isChecked) {
    //         if (!this.selectedIds.includes(recordId)) {
    //           this.selectedIds.push(recordId);
    //         }
    //       } else {
    //         const index = this.selectedIds.indexOf(recordId);
    //         if (index > -1) {
    //           this.selectedIds.splice(index, 1);
    //         }
    //       }
      
    //       // Update "Select All" checkbox based on the selected checkboxes
    //       const selectAllCheckbox = parentContainer.querySelector('.dataCheckbox[data-key="selectAll"]');
    //       selectAllCheckbox.checked = dataCheckboxes.length === selectedCheckboxIds.length;
    //     }
      
    //     // Create a new array and copy the values from the selectedIds property
    //     const newArray = [...this.selectedIds];
    //     this.selectedDepositIds = [...this.selectedIds];
    //     console.log('selected Records single 215==>', newArray);
    //     console.log('this.selectedDepositIds 281==>'+this.selectedDepositIds );
    //   }
      
    renderCheckboxes() {
        // Assuming you have a list of data objects called "depositData"
        // You can replace this with your own data source.
        this.selectedDepositIds.forEach((deposit) => {
          const isChecked = this.selectedIds.includes(deposit.objDeposit.Id);
      
          const checkboxDiv = document.createElement('div');
          checkboxDiv.classList.add('custom_checkbox');
      
          const label = document.createElement('label');
          label.classList.add('main');
      
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.checked = isChecked;
          checkbox.classList.add('dataCheckbox');
          checkbox.setAttribute('data-key', deposit.objDeposit.Id);
          checkbox.addEventListener('change', handleCustodialDataCheckboxChange);
      
          const span = document.createElement('span');
          span.classList.add('geekmark');
      
          label.appendChild(checkbox);
          label.appendChild(span);
          checkboxDiv.appendChild(label);
      
        });
      }
      
        // const checkboxes = Array.from(this.template.querySelectorAll('.dataCheckbox'));
        // const selectAllCheckbox = event.currentTarget;
        // console.log('checkboxes==>'+checkboxes);
        // console.log('selectAllCheckbox==>'+selectAllCheckbox);
        // if (selectAllCheckbox.dataset.key === 'selectAll') {
        //   // If the "Select All" checkbox is clicked, update all checkboxes accordingly
        //   const selected = selectAllCheckbox.checked ? checkboxes.map(checkbox => checkbox.dataset.key) : [];
        //   this.selectedIds = selected;
        //   console.log('ifCheck==>');
        // } else {
        //   // If a single checkbox is clicked, update the selectedIds array accordingly
        //   const selected = checkboxes.filter(checkbox => checkbox.checked && checkbox.dataset.key !== 'selectAll')
        //                             .map(checkbox => checkbox.dataset.key);
        //   this.selectedIds = selected;
        //   console.log('elseCheck==>'+this.selectedIds);
        //   // Update the "Select All" checkbox based on the checked status of all checkboxes
        //   checkboxes[0].checked = checkboxes.length === selected.length;
        // }
        // console.log('Selected ids for custodial==>'+this.selectedIds)
      //}
      
      
      
      updateSelectedRecords() {
        this.selectedDepositIds = [];
      
        // Get all the data checkboxes
        const dataCheckboxes = this.template.querySelectorAll('.dataCheckbox');
      
        dataCheckboxes.forEach((checkbox) => {
          if (checkbox.checked) {
            const recordId = checkbox.getAttribute('data-key');
            this.selectedDepositIds.push(recordId);
          }
        });
      
        console.log('selected Records single 215==>' + this.selectedDepositIds);
        console.log('No.of selected records single select ==>' + this.selectedCount);
        if(this.selectedCount==0){
            this.selectAllChecked = false;
        }
      }
      

    navigationHandle(event){
        event.preventDefault();
        var sObjectList= this.TransferedDepositsList;
        
        var pageSize = Number(this.pageSize);
        var start= this.startPage;
        var end= this.endPage;
        console.log('navigationHandle ==='+event.target.dataset.id);
        var navigate = event.target.dataset.id;

        if(navigate =='propNextId'){
            var sObjectList= this.TransferedDepositsList;
            var listName = 'prop';
            console.log('navigationHandle in  propNextId');
            console.log('navigationHandle in  propNextId sObjectList'+JSON.stringify(sObjectList));
            this.currentPage= this.currentPage + 1;
            this.next(listName,sObjectList,end,start,pageSize);
        }
        else if(navigate =='propPreviousId'){
            var sObjectList= this.TransferedDepositsList;
            var listName = 'prop';
            console.log('navigationHandle in  propPreviousId');
            this.currentPage= this.currentPage - 1;
            this.previous(listName,sObjectList,end,start,pageSize);
        }
        
        
    }
    next (listName,sObjectList,end,start,pageSize){
        console.log('SobjectList==>'+sObjectList);
        console.log('Line116')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for(var i = end + 1; i < end + pageSize + 1; i++){ 
            if(sObjectList.length > i){ 
                    Paginationlist.push(sObjectList[i]);

                }
            counter ++ ;
        }
        console.log('line=>127==>'+Paginationlist);
        this.PageSpinner = false;
        start = start + counter;
        end = end + counter;
        this.startPage = start;
        this.endPage= end;
        if(listName == 'prop'){
            this.PaginationPropList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }
       

        if(this.currentPage == 1){
            this.isStartPage = true;
            this.isStartPageNav = false;
        }else{
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if(this.currentPage==this.totalPagesCount){
            this.isEndPage = true;
            this.isEndPageNav =false;
        }else{
            this.isEndPage = false;
            this.isEndPageNav =true;
        }

    }
    previous(listName,sObjectList,end,start,pageSize){
        console.log('Line155')
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
              
                    Paginationlist.push(sObjectList[i]); 
                counter ++;
            }else{
                start++;
            }
        }
        this.PageSpinner = false;
        start = start - counter;
        end = end - counter;
        this.startPage = start;
        this.endPage= end;
        if(listName == 'prop'){
            this.PaginationPropList = Paginationlist;
            //this.TransferedDepositsList =Paginationlist
        }
        if(this.currentPage == 1){
            this.isStartPage = true;
            this.isStartPageNav = false;
        }else{
            this.isStartPage = false;
            this.isStartPageNav = true;
        }
    
        if(this.currentPage==this.totalPagesCount){
            this.isEndPage = true;
            this.isEndPageNav =false;
        }else{
            this.isEndPage = false;
            this.isEndPageNav =true;
        }

    }
    
    handleRejectMultipleDeposits(event){
        console.log('count==>'+this.selectedCount);
        var isValid = true;
        if(this.selectedCount ==0){
            this.isNoDepositsSelected = true;
            isValid = false;
        }
        else{
            this.isNoDepositsSelected = false;
        }
        if(isValid){
            processRejectDeposit({depositIds:this.selectedDepositIds})
            .then(result=>{
                if(result =='Deposit Successfully Rejected'){
                    this.isRequestedDepositSection = false;
                    this.isSuccessScreen = true;
                    this.isRejectionMsg = true;
                }
            }).catch(error=>{
                    console.log('error while rejecting==>'+error);
            });
        }
    }
    handleAcceptMultipleDepositsCustodial(event){
        console.log('depositsRecordsList=545=>' + this.selectedDepositIds.length);
        if(this.selectedDepositIds.length==0){
            alert('emptylist');
        }
    }
    handleAcceptMultipleDeposits(event) {
        const clickedElement = event.target;
        const dataIdValue = clickedElement.dataset.id;
        console.log('dataIdValue==>'+dataIdValue);
        if(dataIdValue=='insured_accept_button'){
            this.isTransferTo = 'Insured';
        }
        console.log('AcceptClicked');
        console.log('depositsRecordsList==>' + this.selectedDepositIds);
        console.log('Accepted count==>'+this.selectedCount);
        console.log('depositsRecordsList=545=>' + this.selectedDepositIds.length);
        var isValid = true;
        if(this.selectedCount ==0 || this.selectedDepositIds.length==0){
            this.isNoDepositsSelected = true;
            this.isNoDepositsSelectedforCustodial=true;
            isValid = false;
        }
        else{
            this.isNoDepositsSelected = false;
            this.isNoDepositsSelectedforCustodial=false;
        }
        if(isValid){
              processMultipleAcceptDeposit({ depositId: this.selectedDepositIds })
            .then(result => {
                if (result != null) {
                    console.log('resultLine350==>'+JSON.stringify(result));
                    console.log('resultSize==>'+result.length);
                    var conts = result;
                    for ( var key in conts ) {
                        this.deposits.push({value:conts[key], key:key});
                    }
        
                this.enterTenantNameMultiple = true;
                this.depositslength1 = true;
                this.isRequestedDepositSection = false;
                this.isGotoCustodialScreen = false;
                console.log('result311==>' + JSON.stringify(this.deposits));
                console.log('length==>' + this.deposits.length);
                }
            })
            .catch(error => {
                console.log('error==>@@' + error);
            });
      
        }
      
    }
    multipleTenantCheckValue(event){
        this.isTenantNameErrorMsg = false;
        this.isTenantNameErrorMsg1=false;
        this.isunableErrorMsg = false;
        this.isTenantvalueBlankErrorMsg = false;

        var tenantValue = event.target.value;
        var tenantId = event.target.title;
        var jsonArrayData = this.depositInfo;
        let keyfound=false;
        console.log('tenant value 368==>'+tenantValue);
        this.tenantNames = tenantValue;
        if(jsonArrayData == undefined || jsonArrayData == null)
        {	console.log(' 11111');
         jsonArrayData=[];
         jsonArrayData.push({key:tenantId,value:tenantValue}); 
        }
        else{
            if(jsonArrayData.length>0)
            {
                for(let i=0;i<jsonArrayData.length;i++)
                {	console.log(' 222333333333333333333333322');
                 //let tempobj= jsonArrayData[i];console.log(' tempobj[tenantId]'+tempobj[tenantId]);
                 console.log(' jsonArrayData[i]'+jsonArrayData[i].key);
                 if(jsonArrayData[i].key == tenantId){
                     jsonArrayData[i].value = tenantValue;
                     keyfound=true;
                     break;
                 }
                }
                if(!keyfound)
                {console.log(' 25333333333333');
                    jsonArrayData.push({key:tenantId,value:tenantValue}); 
                }
            }
            else
            {console.log(' 4444444444444444'+jsonArrayData);
             jsonArrayData=[];
             jsonArrayData.push({key:tenantId,value:tenantValue});          
            }
        }
        this.depositInfo = jsonArrayData;
        console.log('DepositInfo==>'+JSON.stringify(this.depositInfo));
    }
    acceptMultipleDepositData(event){
        event.preventDefault();
        console.log('this.selectedDepositIds==>'+this.selectedDepositIds);
        console.log('this.deposits List==>'+JSON.stringify(this.deposits));
        console.log('this.depositValues==>'+JSON.stringify(this.depositInfo));
        console.log('tnant Values==>'+this.tenantNames);
        this.isTenantNameErrorMsg = false;
        this.isTenantNameErrorMsg1=false;
        this.isunableErrorMsg = false;
        this.isTenantvalueBlankErrorMsg = false;
        var isValid = true;
        if(this.tenantNames==null ||this.tenantNames==''|| this.tenantNames==undefined ){
            this.isTenantvalueBlankErrorMsg = true;
            isValid = false;
        }
        else{
            this.isTenantvalueBlankErrorMsg = false;
        }
        if(isValid){
            this.currentAttempt--;
            console.log('CurrentAttemps==>'+this.currentAttempt);
            this.PageSpinner = true;
            console.log('Deposit(s)TransferedTo==>'+this.isTransferTo);
        checkDepositAllocationMultipleTenantName({
            listDepositId:this.selectedDepositIds,
            values : JSON.stringify(this.depositInfo),
            depositsList:JSON.stringify(this.deposits),
            scheme:'NI Custodial',
            transferedTo:this.isTransferTo,
            NoOfAttempts:this.currentAttempt
        })
        .then(result=>{
           // if(result!=null){
                console.log('acceptMultipleDep==>Result==>'+result);
                this.resMessage = result;
                if(this.resMessage=='Deposit updated and no case exist'){
                    this.enterTenantNameMultiple = false;
                    this.isRequestedDepositSection = false;
                    // this.isSuccessScreen = true;
                    // this.isAcceptingMsg = true;
                    // this.PageSpinner = false;
                    if(this.currentUser.Profile.Name == 'NI_Head_Office_User' && this.currentUserBranches.length >=1 ){
                        //alert('Deposit updated and no case exist To Branch');
                        window.location = window.location.origin + this.transferInsuredDeposittoBranchUrl + window.btoa(this.selectedDepositIds[0]);
                        //window.location = window.location.origin + '/ni/s/transferinsureddeposittobranch?depositRecId=' + window.btoa(this.selectedDepositIds[0]);
                    } else {
                        // this.isSuccessScreen = true;
                        // this.isAcceptingMsg = true;
                        this.PageSpinner = false;
                        if (this.selectedDepositIds.length > 0) {
                            var selectedId = this.selectedDepositIds[0];
                            var encodedId = btoa(selectedId);
                            console.log('encodedId==>'+encodedId);
                            var en = btoa('Deposit transfer accepted - awaiting funds');
                            this[NavigationMixin.Navigate]({
                            type: 'comm__namedPage',
                            attributes: {
                               // pageName: 'payInsuredDeposit'
                               pageName: 'depositinsuredsummary'
                            },
                            state: {
                                //depositId: encodedId,
                                //status: en
                                depositId: encodedId
                            },
                        });
                        }
                    }
                }
                else if(this.resMessage == 'Deposit updated and case exist'){
                    this.enterTenantNameMultiple = false;
                    this.isRequestedDepositSection = false;
                    // this.isSuccessScreen = true;
                    // this.isAcceptingMsg = true;
                    // this.PageSpinner = false;
                    this.isCasePresentMsg = true;
                    this.error = 'There are outstanding actions required against some of these deposits. Please see the ‘Outstanding actions’ section of your account to view these deposits and your deadlines to respond.';
                    if(this.currentUser.Profile.Name == 'NI_Head_Office_User' && this.currentUserBranches.length >=1 ){
                        //alert('Deposit updated and no case exist To Branch');
                        window.location = window.location.origin + this.transferInsuredDeposittoBranchUrl + window.btoa(this.selectedDepositIds[0]);
                        //window.location = window.location.origin + '/ni/s/transferinsureddeposittobranch?depositRecId=' + window.btoa(this.selectedDepositIds[0]);
                    } else {
                        this.isSuccessScreen = true;
                        this.isAcceptingMsg = true;
                        this.PageSpinner = false;
                        if (this.selectedDepositIds.length > 0) {
                            var selectedId = this.selectedDepositIds[0];
                            var encodedId = btoa(selectedId);
                            console.log('encodedId==>'+encodedId);
                            var en = btoa('Deposit transfer accepted - awaiting funds');
                            this[NavigationMixin.Navigate]({
                                type: 'comm__namedPage',
                                attributes: {
                                   // pageName: 'payInsuredDeposit'
                                   pageName: 'depositinsuredsummary'
                                },
                                state: {
                                    //depositId: encodedId,
                                    //status: en
                                    depositId: encodedId
                                },
                            });
                        }
                    }
                }
                else if(this.resMessage.includes("Please complete the required value for")){
                    this.isunableErrorMsg= true;
                    this.errors = this.resMessage;
                }
                // else if(this.resMessage == 'all blank'){
                //     // component.set("v.tenantValidationError",true);
                //     // component.set("v.errors", "Please enter the required value for all Deposits."); 
                //    // alert('Please enter the required value for all Deposits.'+resMessage);
                //    //this.isTenantNameErrorMsg= true;
                //     this.errors = this.resMessage;
                // }
                else if(this.resMessage == 'Deposit tranfered to custodial no case exist' || 
                        this.resMessage == 'Deposit tranfered to custodial case exist' ){
                            console.log('PaymentClicked');
                            console.log('this.selectedDepositIds==>'+this.selectedDepositIds);
                            //this.PageSpinner = false;
                            if(this.currentUser.Profile.Name == 'NI_Head_Office_User' && this.currentUserBranches.length >=2 ){
                                var isTransferTocustodial = true;
                                //alert('Deposit updated and no case exist To Branch');
                                window.location = window.location.origin + this.transferInsuredDeposittoBranchUrl + window.btoa(this.selectedDepositIds[0]) +'&transferedToCustodial='+window.btoa(isTransferTocustodial);
                                //window.location = window.location.origin + '/ni/s/transferinsureddeposittobranch?depositRecId=' + window.btoa(this.selectedDepositIds[0]) +'&transferedToCustodial='+window.btoa(isTransferTocustodial);
                            } else {
                                if (this.selectedDepositIds.length > 0) {
                                    var selectedId = this.selectedDepositIds[0];
                                    var encodedId = btoa(selectedId);
                                    console.log('encodedId==>'+encodedId);
                                   
                                    var en = btoa('Deposit transfer accepted - awaiting funds');
                                    console.log('en==>'+en);
                                    this[NavigationMixin.Navigate]({
                                        type: 'comm__namedPage',
                                        attributes: {
                                            pageName: 'payDeposit'
                                        },
                                        state: {
                                            depositId: encodedId,
                                            status: en
                                        },
                                    });
                                }
                            }
                           
                            
                        }
                else{
                   // this.isTenantNameErrorMsg = true;
                    this.PageSpinner = false;
                    if(this.currentAttempt==2){
                        this.isTenantNameErrorMsg= true;
                    }
                    else if(this.currentAttempt==1){
                        this.isTenantNameErrorMsg1 = true;
                    }
                    else if(this.currentAttempt<=0 || this.currentAttempt>=3){
                        this.isTenantMaxAttemptsErrorMsg = true;
                        this.isTenantNameErrorMsg= false;
                        this.isTenantNameErrorMsg1 = false;
                        let finalSubmit = this.template.querySelector('[name="FinalSubmit"]');
                        finalSubmit.style = 'opacity: 0.5';
                        this.disableSumbit = true;
                    }
                }
            //}
        })
        .catch(error=>{
            console.log('error-404==>'+JSON.stringify(error));
        });
        }
    }
    handleTransferDepositsToCustodail(event){
        
        // this.handleDataCheckboxChange();
        console.log('custodial clicked')
        var isValid = true;
        if(this.selectedCount ==0){
            this.isNoDepositsSelected = true;
            isValid = false;
        }
        else{
            this.isNoDepositsSelected = false;
        }
        if(isValid){
            this.isNoDepositsSelected = false;
            this.isTransferTo='Custodial';
            console.log('seleted deposits for custodial ==>'+this.selectedDepositIds);
            this.isGotoCustodialScreen= true;
            this.isSuccessScreen = false;
            this.enterTenantNameMultiple = false;
            this.isRequestedDepositSection = false;
            console.log('List of Deposits==>'+JSON.stringify(this.TransferedDepositsList));

             this.selectedDeposits = [];

         
                // for (let deposit of this.TransferedDepositsList) {
               
                // if (this.selectedDepositIds.includes(deposit.objDeposit.Id)) {
                //     let startDate = new Date(deposit.objDeposit.Transfer_Deposit_start_date__c);
                //     this.formattedStartDate = `${startDate.getDate()}/${startDate.getMonth() + 1}/${startDate.getFullYear()}`;
                //     this.selectedDeposits.push({
                //         Id: deposit.objDeposit.Id,
                //         Customer_Name__c: deposit.objDeposit.Customer_Name__c,
                //         NI_Deposit_Number__c: deposit.objDeposit.NI_Deposit_Number__c,
                //         Property_Address__c:deposit.objDeposit.Property_Address__c,
                //         Protected_Amount__c:deposit.objDeposit.Protected_Amount__c,
                //         Transfer_Deposit_start_date__c:this.formattedStartDate,
                //     });
                // }
                // }
               // console.log('Line539=>'+JSON.stringify(this.selectedDeposits));

                       
// Initialize an object to store the selected deposits by Customer_Name__c
                                 let selectedDepositsByCustomer = {};

                                
                                for (let deposit of this.TransferedDepositsList) {
                               
                                if (this.selectedDepositIds.includes(deposit.objDeposit.Id)) {

                                    const formattedDate = formatDate(deposit.objDeposit.Transfer_Deposit_start_date__c);
                                   
                                    if (!selectedDepositsByCustomer.hasOwnProperty(deposit.objDeposit.Customer_Name__c)) {
                                    selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c] = {
                                        Id:deposit.objDeposit.Id,
                                        Transfer_Deposit_start_date__c: formattedDate,
                                        Customer_Name__c: deposit.objDeposit.Customer_Name__c,
                                        no_of_deposits: 0,
                                        total_Protected_Amount__c: 0.00,
                                        deposits: [],
                                        isDropdownTrue:false,
                                    };
                                    }

                                   
                                    selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c].no_of_deposits++;
                                    if (typeof deposit.objDeposit.Deposit_Amount__c === 'number' && !isNaN(deposit.objDeposit.Deposit_Amount__c)) {
                                        selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c].total_Protected_Amount__c += deposit.objDeposit.Deposit_Amount__c;
                                    } else {
                                        // If Protected_Amount__c is not a valid number, treat it as 0.00
                                        selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c].total_Protected_Amount__c += 0.00;
                                    }

                                    //selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c].total_Protected_Amount__c += deposit.objDeposit.Protected_Amount__c;

                                    selectedDepositsByCustomer[deposit.objDeposit.Customer_Name__c].deposits.push({
                                    ...deposit,
                                    objDeposit: {
                                        ...deposit.objDeposit,
                                        
                                    },
                                    });
                                }
                                }

                                this.selectedDeposits = Object.values(selectedDepositsByCustomer);

                                // The selectedDeposits array now contains the required values of the selected deposits with the number of deposits and total Protected_Amount__c for each Customer_Name__c
                               // console.log(selectedDeposits);

                                    // Function to format the date as dd/mm/yyyy
                                    function formatDate(dateString) {
                                    const date = new Date(dateString);
                                    const day = String(date.getDate()).padStart(2, '0');
                                    const month = String(date.getMonth() + 1).padStart(2, '0');
                                    const year = String(date.getFullYear()).slice(-2);
                                    return `${day}/${month}/${year}`;
                                    }

                console.log('Line584==>'+JSON.stringify(this.selectedDeposits));

                    
            }

    }
    // Assuming you have a property named selectedDeposits containing the list of deposits

get groupedDeposits() {
    // Group deposits based on Transfer_Deposit_start_date__c and Customer_Name__c
    const grouped = this.selectedDeposits.reduce((result, deposit) => {
      const key = deposit.Transfer_Deposit_start_date__c + '_' + deposit.Customer_Name__c;
  
      if (!result[key]) {
        result[key] = {
          key,
          Transfer_Deposit_start_date__c: deposit.Transfer_Deposit_start_date__c,
          Customer_Name__c: deposit.Customer_Name__c,
          no_of_deposits: 1,
          total_Protected_Amount__c: deposit.objDeposit.Deposit_Amount__c,
          deposits: [deposit]
        };
      } else {
        result[key].no_of_deposits++;
        result[key].total_Protected_Amount__c += deposit.objDeposit.Deposit_Amount__c;
        result[key].deposits.push(deposit);
      }
  
      return result;
    }, {});
  
    // Convert the grouped object to an array
    const groupedArray = Object.values(grouped);
  
    return groupedArray;
  }
  
        hideBootstrapErrors(event){ 
        var button_Name = event.target.name;
        switch (button_Name) { 
            case "NoDepositsSelected":
                this.isNoDepositsSelected=false;
            break;

            case "NoDepositsSelectedCustodial":
                this.isNoDepositsSelectedforCustodial=false;
            break;
            
        }
    }
    goBackHandle(event){
        event.preventDefault();
        window.location = window.location.origin + this.goToBackDepositeSumary;
        //window.location = window.location.origin + '/ni/s';
    }
    goBackTransferPage(event){
        event.preventDefault();
        
        this.deposits = [];
        if(this.isTransferTo=='Insured'){
            this.selectedDepositIds=[];
            this.selectAllChecked = false;
            this.isGotoCustodialScreen = false;
            this.enterTenantNameMultiple = false;
            this.isRequestedDepositSection = true;
        }
        else if(this.isTransferTo=='Custodial'){
           
            this.isGotoCustodialScreen = true;
            this.enterTenantNameMultiple = false;
            this.isRequestedDepositSection = false;
        }
    }
    handleEnter(event){
        console.log('line 621 ');
        if(event.keyCode === 13){
            event.target.blur();
            console.log('line 623 ');
            this.acceptMultipleDepositData(event);
          }        
    }
    
}