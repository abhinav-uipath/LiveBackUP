import { LightningElement , api , wire } from 'lwc';
import { getContent} from "experience/cmsDeliveryApi";
import siteId from "@salesforce/site/Id";
import IMAGE_SUBLINK from '@salesforce/label/c.TDSPlus_Image_Sublink';


export default class TdsPlus_ImagePlusEvenMore extends LightningElement {
    @api contentKey;
     
    label = {
        imageSublink: IMAGE_SUBLINK
    };
    // imageLink = '/tdsplusv1/sfsites/c/cms/delivery/media/';
    imageLink='';
    title='';
    description='';
    buttonLabel='';
    buttonAction='';

    @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
    onGetContent({ error, data }) {
        if(data) {
            let imageContentKey = data.contentBody.Image.source.ref.contentKey;
            this.imageLink = this.label.imageSublink + imageContentKey;
            this.title = data.contentBody.Title;
            this.description = data.contentBody.Subtitle;
            this.buttonLabel = data.contentBody.Button_3_Label;
            this.buttonAction = data.contentBody.Button_3_Action;
            
            console.log(data.contentBody.Button_3_Action);
            console.log('line no:24');
        }
        else {
            console.log('Line 25 data not available ');
        }
    }

}