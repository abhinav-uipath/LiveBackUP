import { LightningElement, api, track, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

import getKnowledgeArticleCategory from '@salesforce/apex/EI_NI_knowledgeArticleDetail.getKnowledgeArticleCategory';

const fields = [        
    'Knowledge_Article_Categories__c.Article_Type__c',              
    'Knowledge_Article_Categories__c.Customer_Type__c'
];

export default class Ei_NI_HC_ArticleListingMain extends LightningElement {

    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api fifthLink;
    // @api fifthActiveLink;
    @api tenantLabel;
    @api landlordLabel;
    @api agentLabel;
    @api custodialLabel;
    @api insuredLabel;
    @api filterBannerHeading;
    @api selectProductLabel;
    @api resourceNavigationHeading;
    @api resourceNav1stLabel;
    @api resourceNav2ndLabel;
    @api resourceNav3rdLabel;
    @api resourceNav4thLabel;
    @api resourceNav5thLabel;
    @api custodialSummary;
    @api insuredSummary;
    @api articleCategoryPage;
    @api previousPageName;
    @api recordId;
    @api norelevantresultmsg;

    //@api recordTypeProp;
    // @track filterSelection = {customerType: 'Tenant', productType: 'Custodial', recordType:'FAQ'};
    @track filterSelection = {};
    @track displayedButtons = [];
    // @track linkObject = {firstLink:'', secondLink:'', thirdLink:'', fourthLink:'', firstActiveLink:'', secondActiveLink:'', thirdActiveLink:'', fourthActiveLink:''};
    @track firstActiveLink=false;
    @track secondActiveLink=false;
    @track thirdActiveLink=false;
    @track fourthActiveLink=false;
    @track isFilterSelectionFaq = false;
    @track isFilterSelectionNotFaq = false;
    @track showResourceNav = false;
    @track currentRecordType;


    /* @wire(getRecord, { recordId: '$recordId', fields: fields })
    loadKnowledgeArticleDetail({error, data}) {
        console.log('line no93 recordId -> ',this.recordId);
        console.log('line no93 -> ',data);
        console.log('line no93 error -> ',error);
        if(data) {
            console.log('Apex Class Test='+JSON.stringify(data));
            this.currentRecordType = data.fields.Article_Type__c.value;
            if(this.currentRecordType=='Casestudy') {
                this.currentRecordType = 'Case Study';
            }
            this.showResourceNav = true;
            console.log('Line 62 currentRecordType -> '+this.currentRecordType);
            
            this.filterSelection.recordType = this.currentRecordType;
            console.log('Line 62 -> '+JSON.stringify(this.filterSelection));

            if(this.filterSelection.recordType=='FAQ') {
                this.isFilterSelectionFaq = true;
            }
            else {
                this.isFilterSelectionFaq = false;
            }
            
            console.log('Line 72 isFilterSelectionFaq -> '+this.isFilterSelectionFaq);
            if(this.filterSelection.recordType=='FAQ') {
                this.firstActiveLink = true;
            }
            else if(this.filterSelection.recordType=='Casestudy') {
                this.filterSelection.recordType = 'Case Study'
                this.secondActiveLink = true;
            }
            else if(this.filterSelection.recordType=='Guide') {
                this.thirdActiveLink = true;
            }
            else if(this.filterSelection.recordType=='Template') {
                this.fourthActiveLink = true;
            }
        }
        else {
            console.error('Inside wire error -> '+JSON.stringify(error));

            this.currentRecordType = 'FAQ';
            this.filterSelection.recordType = this.currentRecordType;
        }
    } */

    @wire(getKnowledgeArticleCategory, { recordId: '$recordId'} )
    loadKnowledgeArticleDetail({error, data}) {    
        //console.log('Article Category TypeID=' +data.fields.Knowledge_Article_Category__c.value);
        //console.log('Article category TypeName=' +data.fields.Knowledge_Article_Category__r.displayValue);
        console.log('line no93 recordId -> ',this.recordId);
        console.log('line no93 -> ',data.length);
        console.log('line no93 data -> ',JSON.stringify(data));
        console.log('line no93 error -> ',error);
        if(data) {
            if(data.length>0) {
                console.log('Apex Class Test='+JSON.stringify(data));
                this.currentRecordType = data[0].Article_Type__c;
                if(this.currentRecordType=='Casestudy') {
                    this.currentRecordType = 'Case Study';
                }
                this.showResourceNav = true;
                console.log('Line 62 currentRecordType -> '+this.currentRecordType);
                
                this.filterSelection.recordType = this.currentRecordType;
                console.log('Line 62 -> '+JSON.stringify(this.filterSelection));

                if(this.filterSelection.recordType=='FAQ') {
                    this.isFilterSelectionFaq = true;
                }
                else {
                    this.isFilterSelectionNotFaq = true;
                }
                
                console.log('Line 72 isFilterSelectionFaq -> '+this.isFilterSelectionFaq);
                if(this.filterSelection.recordType=='FAQ') {
                    this.firstActiveLink = true;
                }
                else if(this.filterSelection.recordType=='Casestudy') {
                    this.filterSelection.recordType = 'Case Study'
                    this.secondActiveLink = true;
                }
                else if(this.filterSelection.recordType=='Guide') {
                    this.thirdActiveLink = true;
                }
                else if(this.filterSelection.recordType=='Template') {
                    this.fourthActiveLink = true;
                }
            }

            // this.template.querySelector('c-child-helpcentre-resource-type-nav-v2').dynamicLoad(this.currentRecordType);
        }
        else {
            console.error('Inside wire error -> '+JSON.stringify(error));

            this.currentRecordType = 'FAQ';
            // this.showResourceNav = true;
            this.filterSelection.recordType = this.currentRecordType;
            // this.template.querySelector('c-child-helpcentre-resource-type-nav-v2').dynamicLoad(this.currentRecordType);
        }
    }


    connectedCallback() {        
        // this.filterSelection.recordType = this.recordTypeProp; 
        this.filterSelection.customerType = localStorage.getItem('filterSelection.customerType') || 'Tenant';
        this.filterSelection.productType = localStorage.getItem('filterSelection.productType') || 'Custodial'; 
        // this.filterSelection.recordType = localStorage.getItem('filterSelection.recordType') || 'FAQ';

        // this.showResourceNav = true;
        console.log('Line 108 Record ID:', this.recordId);
        console.log('Line 44 ei_NI_HC_ArticleListingMain connectedCallback -> '+JSON.stringify(this.filterSelection));

        // if(this.filterSelection.recordType=='FAQ') {
        //     this.isFilterSelectionFaq = true;
        // }
        // else {
        //     this.isFilterSelectionFaq = false;
        // }

        // Setting the linkObject from meta xml attributes
        // this.linkObject.firstLink = this.firstLink;
        // this.linkObject.secondLink = this.secondLink;
        // this.linkObject.thirdLink = this.thirdLink;
        // this.linkObject.fourthLink = this.fourthLink;
        // this.linkObject.firstActiveLink = this.firstActiveLink;
        // this.linkObject.secondActiveLink = this.secondActiveLink;
        // this.linkObject.thirdActiveLink = this.thirdActiveLink;
        // this.linkObject.fourthActiveLink = this.fourthActiveLink;

        // console.log('Line 42 -> '+JSON.stringify(this.linkObject));
        this.template.querySelector('c-child-helpcentre-resource-type-nav-v2').dynamicLoad(this.filterSelection.recordType);
    }

    handleChange(event) {
        console.log('handleChange triggered by filters on parent'); 
       // this.filterSelection=event.detail.filterSelection;         
        //this.filterSelection.recordType=this.recordTypeProp;   
        let returnedData = event.detail;
		this.filterSelection.customerType = returnedData.filterSelection.customerType;
		this.filterSelection.productType = returnedData.filterSelection.productType;

        console.log('Line 96 in parent: '+JSON.stringify(returnedData));
        console.log('Line 97 in parent: '+JSON.stringify(returnedData.filterSelection.customerType));
        console.log(`Line 98 in parent: customerType - ${this.filterSelection.customerType} - productType - ${this.filterSelection.productType} - recordType - ${this.filterSelection.recordType}`);

        localStorage.setItem('filterSelection.customerType', this.filterSelection.customerType);
        localStorage.setItem('filterSelection.productType', this.filterSelection.productType);

        // Calling the child component to load the dynamic buttons
        if(this.isFilterSelectionFaq) {
            this.template.querySelector('c-child-helpcentre-article-list').loadDynamicButtons();
        }
        if(this.isFilterSelectionNotFaq) {
            this.template.querySelector('c-child-helpcentre-document-list').loadDynamicButtons();
        }
        
    }

    handleArticleTypeChangeEvent(event) {
        console.log('handleArticleTypeChangeEvent triggered by filters on parent'); 
        let returnedData = event.detail;
		this.filterSelection.recordType = returnedData.filterSelection.recordType;
		console.log('Line 117 in parent: '+JSON.stringify(returnedData.filterSelection.recordType));
        console.log(`Line 118 in parent: customerType - ${this.filterSelection.customerType} - productType - ${this.filterSelection.productType} - recordType - ${this.filterSelection.recordType}`);
        
        localStorage.setItem('filterSelection.recordType', this.filterSelection.recordType);

        if(this.filterSelection.recordType=='FAQ') {
            this.isFilterSelectionFaq = true;
            // Calling the child component to load the dynamic buttons
            this.template.querySelector('c-child-helpcentre-article-list').loadDynamicButtons();
        }
        else {
            this.isFilterSelectionFaq = false;
            // Calling the child component to load the dynamic buttons
            this.template.querySelector('c-child-helpcentre-document-list').loadDynamicButtons();
        }

    }
 
}