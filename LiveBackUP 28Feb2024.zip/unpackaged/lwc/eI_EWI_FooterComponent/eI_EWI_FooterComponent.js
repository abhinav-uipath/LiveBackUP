import {  LightningElement,api,wire,track } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';

export default class EI_EWI_FooterComponent extends LightningElement {
debugger;
TDS_Footer = EWITheme + '/assets/img/The-Dispute-Service-footer.svg';
TDS_Footer_logo = EWITheme + '/assets/img/the_dispute_service_logo.png';
Top_5_Award = EWITheme + '/assets/img/Top_5_Award-01.png';
Cyber_essential_badge = EWITheme + '/assets/img/cyber-essentials-badge.png';
cse_logo = EWITheme + '/assets/img/cse_logo.png';
bsi_iso = EWITheme + '/assets/img/bsi-iso-10002.png';
Ministry_housing = EWITheme + '/assets/img/ministry-housing.png';
wal = EWITheme + '/assets/img/wal.svg';
mastercard = EWITheme + '/assets/img/mastercard.svg';
jcbusa = EWITheme + '/assets/img/jcb.svg';
maestro = EWITheme + '/assets/img/maestro.svg';
visa = EWITheme + '/assets/img/visa.svg';
worldpay = EWITheme + '/assets/img/worldpay.svg';
googlelogo = EWITheme + '/assets/img/googlelogo_color_42x16dp.png';
cyber_essentials = EWITheme + '/assets/img/cyber-essentials.svg';
facebook = EWITheme + '/assets/img/facebook-square.png';
linkedin = EWITheme + '/assets/img/linkedin.png';
twitter = EWITheme + '/assets/img/twitter-square.png';
youtube = EWITheme + '/assets/img/youtube.png';

// renderedCallback() {

//     Promise.all([
//         // loadScript(this, EWITheme+'/assets/js/plugin.min.js'),
//         //  loadScript(this, EWITheme+'/assets/js/jquery.dataTables.min.js'),
//         //  loadScript(this, EWITheme+'/assets/js/datepicker.js'),
//         //  loadScript(this, EWITheme+'/assets/js/custom.js'),
//         loadStyle(this, EWITheme  + '/assets/css/custom-ew.css'),
//         loadStyle(this, EWITheme  + '/assets/css/header-footer.css')
        
        
//     ])
//         .then(() => {
//             alert('Files loaded.');
//         })
//         .catch(error => {
//             alert(error.body.message);
//         });
//     }






}