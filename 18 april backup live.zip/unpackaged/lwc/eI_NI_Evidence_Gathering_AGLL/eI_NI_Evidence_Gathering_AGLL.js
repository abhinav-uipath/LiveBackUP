import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import EWC_Theme from '@salesforce/resourceUrl/EWC_Theme';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';

import getclaimdetailsforevidence from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.getclaimdetailsforevidence';
import updateClaimAGLL from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.updateClaimAGLL';
import updateAdditionalComments from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.updateAdditionalComments';
import updateClaimBreakdown from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.updateClaimBreakdown';
import updatekeyDocuments from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.updatekeyDocuments';
import cancelclaimHoldingDisputedAmount from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.cancelclaimHoldingDisputedAmountForNI';
import fetchErrorLabel from '@salesforce/apex/EI_EWC_NI_AGLLEvidenceGathering.fetchErrorLabel';
import NI_Evidence_Gathering_Comment_Box_Char_Limit from '@salesforce/label/c.NI_Evidence_Gathering_Comment_Box_Char_Limit';
import ei_ni_evidenceGatheringUrl from '@salesforce/label/c.ei_ni_evidenceGatheringUrl';
export default class EI_NI_Evidence_Gathering_AGLL extends NavigationMixin(LightningElement) {
    ew_arrow_dropleft = EWC_Theme + '/assets/img/ew-arrow-dropleft.png';
    md_arrow_dropleft = EWC_Theme + '/assets/img/md-arrow-dropleft.png';
    warning_icon = NI_Theme + '/assets/img/warning-icon.png';
    question_circle = EWC_Theme + '/assets/img/question-circle.png';

    characterLimit = NI_Evidence_Gathering_Comment_Box_Char_Limit;
    @track checkin = true;
    @track checkout = true;
    @track depositRecId = '';
    @track branchId;
    @track ClaimsDetails = { isTenantObligationsEviAttachment: false, isInventorycheckEviAttachmentFound: false, isCheckoutReportEviAttachmentFound: false, isRentStatementEviAttachmentFound: false };
    @track evidenceAttachments = [];
    @track disputeItems = [];
    @track currentItem = 0;
    @track ViewContinue = true;
    @track keyDocuments = false;
    @track isShowPaymentOfRentKey = false;
    @track Isclaimamountexceed = false;
    @track showClaimBreakdown = false;
    @track showClaimBreakdownCleaning = false;
    @track showClaimBreakdownDamage = false;
    @track showClaimBreakdownRedecoration = false;
    @track showClaimBreakdownGardening = false;
    @track showClaimBreakdownRentArrears = false;
    @track showClaimBreakdownOther = false;
    @track showAdditionalComments = false;
    @track showReviewsubmission = false;
    @track showCancelDispute = false;
    @track showConfirmCancelDispute = false;
    @track isConfirmCancelDisputClicked = false;
    @track cancelFromPage = '';
    @track isHoldingDisputedFunds = false;
    @track showDisputeItemError = false;
    @track showKeyDocumentsError = false;
    @track allFieldsRequiredErrorMsg;
    @track isBankMemberNotes = false;
    @track isBankDetailsEmpty = false;
    @track bankHolderName;
    @track bankName;
    @track bankSortCode;
    @track bankAccountNo;
    @track showBankDetails = false;
    @track Sortcodelengtherror = false;
    @track invalidSortCodeError = false;
    @track sortCodeBlankError = false;
    @track bankOfAmericaSortCode = false;
    @track nameOnAccountBlankError = false;
    @track bankaccountnamelengtherror = false;
    @track nameOnAccountSpecialCharError = false;
    @track accountNumberBlankError = false;
    @track invalidAccountNumberError = false;
    @track bankSuccessMessage = false;
    @track bankErrorMessage = false;
    @track accountNumberLengthError = false;
    @track cp;
    @track NonmemberLL = false;
    @track isBankDetailsEditable = true;
    @track showDetails = true;
    @track loggedInUserProfile;
    @track RespondedBy = '';

    @track userDetails = {};
    @track accountDetails = [];
    showSpinner = false;
    @track eveGathUrl=ei_ni_evidenceGatheringUrl;

    handleDoInit(result) {
        this.isBankMemberNotes = result.isBankMemberNotes;
        this.cp = result.caseParticipants;
        if (this.cp != null && this.cp != undefined) {
            this.bankHolderName = this.cp.Bank_Account_Holder_Name__c;
            this.bankName = this.cp.Bank_Name__c;
            this.bankSortCode = this.cp.Bank_Sort_Code__c;
            this.bankAccountNo = this.cp.Bank_Account_Number__c;
        }
    }

    connectedCallback() {
        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const depositRecId = urlParams.get('depositId');
        console.log('depositRecId => ' + depositRecId);
        this.depositRecId = window.atob(depositRecId);
        console.log('depositRecId convert into atob => ' + this.depositRecId);
        const branch = urlParams.get('branchRecId');
        if (branch != null && branch != '' && branch != undefined) {
            this.branchId = window.atob(branch);
        }

        getclaimdetailsforevidence({ depositid: this.depositRecId, branchId: this.branchId }).then(result => {
            this.showDetails = true;
            console.log('ClaimDetails Response>>>>' + JSON.stringify(result) + 'Account Length>>>>>' + result.accountDetail.length);
            let caseDetails = result.claim;
            let claimItems = result.disputeItems;
            console.log('line 116'+ JSON.stringify(result.disputeItems));
            this.userDetails = result.usrData;
            this.loggedInUserProfile = result.usrData.Profile.Name;
            if(this.branchId != null){
                this.accountDetails = result.branchDetail;

                console.log('line 118'+ this.accountDetails[0].ValidInternationBankDetails__c);

                if(this.accountDetails[0].ValidInternationBankDetails__c){
                    this.isBankDetailsEmpty = false;
                } else {
                    this.isBankDetailsEmpty = true;
                }
            } else {
                this.accountDetails = result.accountDetail;

                console.log('line 118'+ this.accountDetails[0].ValidInternationBankDetails__c);

                if(this.accountDetails[0].ValidInternationBankDetails__c){
                    this.isBankDetailsEmpty = false;
                } else {
                    this.isBankDetailsEmpty = true;
                }
            }
            this.handleDoInit(result);
            this.evidenceAttachments = result.evidAttach;
            this.ClaimsDetails['AGLL_Respond_Evidance_Gathering__c'] = caseDetails.AGLL_Respond_Evidance_Gathering__c == undefined ? false : caseDetails.AGLL_Respond_Evidance_Gathering__c;
            this.ClaimsDetails['Status'] = caseDetails.Status != undefined ? caseDetails.Status : '';
            this.ClaimsDetails['Total_Protected_Amount__c'] = caseDetails.Total_Protected_Amount__c != undefined ? caseDetails.Total_Protected_Amount__c : '';
            if (caseDetails.Amount_of_Disputed_Funds_Received__c > 0) {
                this.ClaimsDetails['Amounttopaid'] = caseDetails.Total_amount_in_dispute__c < caseDetails.Amount_of_Disputed_Funds_Received__c ? caseDetails.Total_amount_in_dispute__c : caseDetails.Amount_of_Disputed_Funds_Received__c;
            } else {
                this.ClaimsDetails['Amounttopaid'] = 0.00;
            }
            this.isHoldingDisputedFunds = caseDetails.Amount_of_Disputed_Funds_Received__c > 0 ? true : false;

            this.ClaimsDetails['Total_Claimed_by_Landlord__c'] = caseDetails.Total_Claimed_by_Landlord__c != undefined ? caseDetails.Total_Claimed_by_Landlord__c : '';
            console.log('caseDetails.Total_Claimed_by_Landlord__c->' + caseDetails.Total_Claimed_by_Landlord__c + '->caseDetails.Total_Protected_Amount__c' + caseDetails.Total_Protected_Amount__c);
            if (caseDetails.Total_Claimed_by_Landlord__c >= caseDetails.Total_Protected_Amount__c) {
                this.Isclaimamountexceed = true;
            } else {
                this.Isclaimamountexceed = false;
            }

            if (claimItems) {
                const rentItem = claimItems.find(item => item.Type__c == 'Rent');
                if (rentItem) {
                    this.isShowPaymentOfRentKey = true;
                } else {
                    this.isShowPaymentOfRentKey = false;
                }
            }
            if(this.loggedInUserProfile == 'NI_Landlord'){
                console.log('line 177'+this.loggedInUserProfile);
                console.log('line 178'+this.RespondedBy);
                this.RespondedBy = 'Landlord';
            } else {
                console.log('line 180'+this.loggedInUserProfile);
                this.RespondedBy = 'Agent';
            }
            this.ClaimsDetails['Agreedamountpaidtotenant'] = parseFloat(caseDetails.Agreed_amount_paid_to_tenant__c).toFixed(2);
            this.ClaimsDetails['totalAgreedByAGLL'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c).toFixed(2);
            this.ClaimsDetails['totalAgreedByTT'] = parseFloat(caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
            this.ClaimsDetails['Agreed_amount_from_AGLL_to_TT__c'] = parseFloat(caseDetails.Agreed_amount_from_AGLL_to_TT__c).toFixed(2);
            this.ClaimsDetails['totalAmountRepaid'] = parseFloat(caseDetails.Agreed_amount_paid_to_tenant__c + caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
            this.ClaimsDetails['remainDisputeAmount'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c - caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
            this.ClaimsDetails['Id'] = caseDetails.Id;
            this.ClaimsDetails['Evidence_Attachments__r'] = caseDetails.Evidence_Attachments__r;
            this.ClaimsDetails['Dispute_Responded_By__c'] = this.RespondedBy; //caseDetails.Dispute_Responded_By__c;
            this.ClaimsDetails['Additional_comments_AGLL__c'] = caseDetails.Additional_comments_AGLL__c;
            this.ClaimsDetails['Additional_comments_AGLL__c_length'] = 0;
            if (caseDetails.Consent_box_AGLL__c == 'Yes') {
                this.ClaimsDetails['Consent_box_AGLL__c'] = true;
            } else {
                this.ClaimsDetails['Consent_box_AGLL__c'] = false;
            }
            if (caseDetails.Claim_exceed__c == 'Yes' || caseDetails.Claim_exceed__c == 'No') {
                this.ClaimsDetails['isClaimExceedValue'] = true;
                if (caseDetails.Claim_exceed__c == 'Yes') {
                    this.ClaimsDetails['claimExceed'] = true;
                } else if (caseDetails.Claim_exceed__c == 'No') {
                    this.ClaimsDetails['claimExceed'] = false;
                }
            }
            this.ClaimsDetails['claimExceedsComment'] = caseDetails.Claim_exceeds_comment_AGLL__c;
            this.ClaimsDetails['claimExceedsComment_length'] = false;

            if (caseDetails.Tenant_obligations__c == 'Yes' || caseDetails.Tenant_obligations__c == 'No') {
                this.ClaimsDetails['isTenantObligationsValue'] = true;
                if (caseDetails.Tenant_obligations__c == 'Yes') {
                    this.ClaimsDetails['TenantObligations'] = true;
                    this.ClaimsDetails['TenantObligationsNoWarning'] = false;
                } else if (caseDetails.Tenant_obligations__c == 'No') {
                    this.ClaimsDetails['TenantObligations'] = false;
                    this.ClaimsDetails['TenantObligationsNoWarning'] = true;
                }
            }
            if (caseDetails.inventorycheck_in_report_AGLL__c == 'Yes' || caseDetails.inventorycheck_in_report_AGLL__c == 'No') {
                this.ClaimsDetails['isInventorycheckValue'] = true;
                if (caseDetails.inventorycheck_in_report_AGLL__c == 'Yes') {
                    this.ClaimsDetails['inventorycheck'] = true;
                    this.ClaimsDetails['inventorycheckNoWarning'] = false;
                } else if (caseDetails.inventorycheck_in_report_AGLL__c == 'No') {
                    this.ClaimsDetails['inventorycheck'] = false;
                    this.ClaimsDetails['inventorycheckNoWarning'] = true;
                }
            }
            if (caseDetails.check_out_report_AGLL__c == 'Yes' || caseDetails.check_out_report_AGLL__c == 'No') {
                this.ClaimsDetails['isCheckoutReportValue'] = true;
                if (caseDetails.check_out_report_AGLL__c == 'Yes') {
                    this.ClaimsDetails['checkoutReport'] = true;
                    this.ClaimsDetails['checkoutReportNoWarning'] = false;
                } else if (caseDetails.check_out_report_AGLL__c == 'No') {
                    this.ClaimsDetails['checkoutReport'] = false;
                    this.ClaimsDetails['checkoutReportNoWarning'] = true;
                }
            }
            if (caseDetails.Rent_statement_AGLL__c == 'Yes' || caseDetails.Rent_statement_AGLL__c == 'No') {
                this.ClaimsDetails['isRentStatementValue'] = true;
                if (caseDetails.Rent_statement_AGLL__c == 'Yes') {
                    this.ClaimsDetails['rentStatement'] = true;
                    this.ClaimsDetails['rentStatementNoWarning'] = false;
                } else if (caseDetails.Rent_statement_AGLL__c == 'No') {
                    this.ClaimsDetails['rentStatement'] = false;
                    this.ClaimsDetails['rentStatementNoWarning'] = true;
                }
            }

            if (caseDetails.Respond_Date__c != undefined) {
                var respondDate = new Date(caseDetails.Respond_Date__c);
                if (respondDate != null || respondDate != undefined || respondDate != '') {
                    var checkdate = respondDate.getDate().toString().padStart(2, "0");;
                    var checkmonth = (respondDate.getMonth() + 1).toString().padStart(2, "0");
                    var checkyear = respondDate.getFullYear();
                    var newDate = checkdate + '/' + checkmonth + '/' + checkyear;
                    this.ClaimsDetails['respondDate'] = newDate;
                }
            }
            let disputeItems = [];
            disputeItems.push({ key: 'Cleaning' });
            disputeItems.push({ key: 'Damage' });
            disputeItems.push({ key: 'Redecoration' });
            disputeItems.push({ key: 'Gardening' });
            disputeItems.push({ key: 'Rent arrears' });
            disputeItems.push({ key: 'Other' });

            for (let i = 0; i < disputeItems.length; i++) {
                let flag = false;
                for (let j = 0; j < claimItems.length; j++) {
                    if (disputeItems[i].key.includes(claimItems[j].Type__c)) {
                        flag = true;
                        console.log('claimItems[j].Agreed_by_AGLL__c => ' + claimItems[j].Agreed_by_AGLL__c);
                        disputeItems[i]['isOther'] = claimItems[j].Type__c == 'Other' ? claimItems[j].Agreed_by_AGLL__c.toFixed(2) + '\n' + claimItems[j].Other_Reason__c : '';
                        disputeItems[i]['requestedByAGLL'] = claimItems[j].Agreed_by_AGLL__c.toFixed(2);
                        disputeItems[i]['agreedbyTenant'] = claimItems[j].Agreed_by_Tenant__c;
                        disputeItems[i]['amountInDispute'] = claimItems[j].Agreed_by_AGLL__c - claimItems[j].Agreed_by_Tenant__c;
                        disputeItems[i][claimItems[j].Type__c] = true;
                        disputeItems[i]['isShow'] = j == 0 ? true : false;

                        disputeItems[i]['Id'] = claimItems[j].Id;

                        disputeItems[i]['Claim_description_for_cleaning_agll__c'] = claimItems[j].Claim_description_for_cleaning_agll__c;
                        disputeItems[i]['Supporting_clause_cleaning_agll__c'] = claimItems[j].Supporting_clause_cleaning_agll__c;
                        disputeItems[i]['Evidence_at_tenancystart_cleaning_agll__c'] = claimItems[j].Evidence_at_tenancystart_cleaning_agll__c;
                        disputeItems[i]['Evidence_at_tenancy_end_for_cleaning_agl__c'] = claimItems[j].Evidence_at_tenancy_end_for_cleaning_agl__c;
                        disputeItems[i]['Supporting_evidence_for_cleaning_agll__c'] = claimItems[j].Supporting_evidence_for_cleaning_agll__c;

                        disputeItems[i]['Claim_description_for_cleaning_agll__c_length'] = false;
                        disputeItems[i]['Supporting_clause_cleaning_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancystart_cleaning_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancy_end_for_cleaning_agl__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_cleaning_agll__c_length'] = false;

                        disputeItems[i]['Claim_description_for_damage_agll__c'] = claimItems[j].Claim_description_for_damage_agll__c;
                        disputeItems[i]['Supporting_clause_damage_agll__c'] = claimItems[j].Supporting_clause_damage_agll__c;
                        disputeItems[i]['Evidence_at_tenancystart_damage_agll__c'] = claimItems[j].Evidence_at_tenancystart_damage_agll__c;
                        disputeItems[i]['Evidence_at_tenancy_end_for_damage_agll__c'] = claimItems[j].Evidence_at_tenancy_end_for_damage_agll__c;
                        disputeItems[i]['Supporting_evidence_for_damage_agll__c'] = claimItems[j].Supporting_evidence_for_damage_agll__c;

                        disputeItems[i]['Claim_description_for_damage_agll__c_length'] = false;
                        disputeItems[i]['Supporting_clause_damage_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancystart_damage_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancy_end_for_damage_agll__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_damage_agll__c_length'] = false;

                        disputeItems[i]['Claim_description_for_redecoration_agll__c'] = claimItems[j].Claim_description_for_redecoration_agll__c;
                        disputeItems[i]['Supporting_clause_redecoration_agll__c'] = claimItems[j].Supporting_clause_redecoration_agll__c;
                        disputeItems[i]['Evidence_at_tenancystart_redecoration_ag__c'] = claimItems[j].Evidence_at_tenancystart_redecoration_ag__c;
                        disputeItems[i]['Evidence_at_tenancyend_redecoration_agll__c'] = claimItems[j].Evidence_at_tenancyend_redecoration_agll__c;
                        disputeItems[i]['Supporting_evidence_for_redecoration_agl__c'] = claimItems[j].Supporting_evidence_for_redecoration_agl__c;

                        disputeItems[i]['Claim_description_for_redecoration_agll__c_length'] = false;
                        disputeItems[i]['Supporting_clause_redecoration_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancystart_redecoration_ag__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancyend_redecoration_agll__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_redecoration_agl__c_length'] = false;

                        disputeItems[i]['Claim_description_for_gardening_agll__c'] = claimItems[j].Claim_description_for_gardening_agll__c;
                        disputeItems[i]['Supporting_clause_gardening_agll__c'] = claimItems[j].Supporting_clause_gardening_agll__c;
                        disputeItems[i]['Evidence_at_tenancystart_gardening_agll__c'] = claimItems[j].Evidence_at_tenancystart_gardening_agll__c;
                        disputeItems[i]['Evidence_at_tenancyend_gardening_agll__c'] = claimItems[j].Evidence_at_tenancyend_gardening_agll__c;
                        disputeItems[i]['Supporting_evidence_for_gardening__c'] = claimItems[j].Supporting_evidence_for_gardening__c;

                        disputeItems[i]['Claim_description_for_gardening_agll__c_length'] = false;
                        disputeItems[i]['Supporting_clause_gardening_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancystart_gardening_agll__c_length'] = false;
                        disputeItems[i]['Evidence_at_tenancyend_gardening_agll__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_gardening__c_length'] = false;

                        disputeItems[i]['Rent_arrears_description_agll__c'] = claimItems[j].Rent_arrears_description_agll__c;
                        disputeItems[i]['Was_the_property_re_let_rent_agll__c'] = claimItems[j].Was_the_property_re_let_rent_agll__c;
                        disputeItems[i]['Supporting_clause_rent_agll__c'] = claimItems[j].Supporting_clause_rent_agll__c;
                        disputeItems[i]['Supporting_evidence_for_rent_agll__c'] = claimItems[j].Supporting_evidence_for_rent_agll__c;

                        disputeItems[i]['Rent_arrears_description_agll__c_length'] = false;
                        disputeItems[i]['Was_the_property_re_let_rent_agll__c_length'] = false;
                        disputeItems[i]['Supporting_clause_rent_agll__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_rent_agll__c_length'] = false;

                        disputeItems[i]['Claim_breakdown_other_AGLL__c'] = claimItems[j].Claim_breakdown_other_AGLL__c;
                        disputeItems[i]['Supporting_clause_other_agll__c'] = claimItems[j].Supporting_clause_other_agll__c;
                        disputeItems[i]['Supporting_evidence_for_other_agll__c'] = claimItems[j].Supporting_evidence_for_other_agll__c;

                        disputeItems[i]['Claim_breakdown_other_AGLL__c_length'] = false;
                        disputeItems[i]['Supporting_clause_other_agll__c_length'] = false;
                        disputeItems[i]['Supporting_evidence_for_other_agll__c_length'] = false;
                    }
                }
                if (flag == false) {
                    disputeItems.splice(i, 1);
                    i--;
                }
            }
            this.disputeItems = disputeItems;
            if (this.accountDetails != undefined && this.accountDetails.length > 0) {	
                this.showBankDetails = true;	
            }

            fetchErrorLabel().then(result => {
                let userErr = '';
                console.log('fetchErrorLabel result => ' + result);
                for (var i = 0; i < result.length; i++) {
                    console.log("line-->9  " +result[i].MasterLabel );
                    console.log("line-->9  " +result[i].Error_Message__c );
                    if (result[i].MasterLabel === 'Evidence Gathering AG/LL NI') {
                        userErr = result[i].Error_Message__c; // All fields are mandatory
                        this.allFieldsRequiredErrorMsg = userErr;
                        console.log('line 329'+this.allFieldsRequiredErrorMsg)
                    }
                }
            }).catch(error => {
                console.log('fetchErrorLabel error => ' + error);
            })
        }).catch(error => {
            console.log('getclaimdetailsforevidence error => ' + JSON.stringify(error), error);
        })
        console.log("disputeItems => " + JSON.stringify(this.disputeItems));
    }

    renderedCallback() {
        console.log('renderedCallback this.ClaimsDetails.Consent_box_AGLL__c => ' + this.ClaimsDetails.Consent_box_AGLL__c)
        console.log('renderedCallback isBankDetailsEmpty => ' + this.isBankDetailsEmpty)
        if (this.ClaimsDetails.Consent_box_AGLL__c && !this.isBankDetailsEmpty) {
            this.template.querySelector('.consentbox').style.backgroundColor = '';
            this.template.querySelector('.consentbox').classList.add('blue_theme');
            this.template.querySelector('.consentbox').classList.remove('disable_ew_btn');
        } else {
            this.template.querySelector('.consentbox').style.backgroundColor = '#808080';
            this.template.querySelector('.consentbox').classList.remove('blue_theme');
            this.template.querySelector('.consentbox').classList.add('disable_ew_btn');
        }
    }

    clickYes(event) {
        this.showKeyDocumentsError = false;
        let selectRecordId = event.target.title;
        if (selectRecordId.includes('Exceedclaim')) {
            this.ClaimsDetails['isClaimExceedValue'] = true;
            this.ClaimsDetails['claimExceed'] = true;
            this.template.querySelector('.exceedclaimyes').classList.add('active');
            this.template.querySelector('.exceedclaimno').classList.remove('active');
        }
        else if (selectRecordId == 'TenantObligations') {
            this.ClaimsDetails['isTenantObligationsValue'] = true;
            this.ClaimsDetails['TenantObligations'] = true;
            this.ClaimsDetails['TenantObligationsNoWarning'] = false;
            this.template.querySelector('.tenantobligationsyes').classList.add('active');
            this.template.querySelector('.tenantobligationsno').classList.remove('active');
        }
        else if (selectRecordId == 'inventorycheck') {
            this.ClaimsDetails['isInventorycheckValue'] = true;
            this.ClaimsDetails['inventorycheck'] = true;
            this.ClaimsDetails['inventorycheckNoWarning'] = false;
            this.template.querySelector('.inventorycheckyes').classList.add('active');
            this.template.querySelector('.inventorycheckno').classList.remove('active');
        }
        else if (selectRecordId == 'checkoutReport') {
            this.ClaimsDetails['isCheckoutReportValue'] = true;
            this.ClaimsDetails['checkoutReport'] = true;
            this.ClaimsDetails['checkoutReportNoWarning'] = false;
            this.template.querySelector('.checkoutreportyes').classList.add('active');
            this.template.querySelector('.checkoutreportno').classList.remove('active');
        }
        else if (selectRecordId == 'rentStatement') {
            this.ClaimsDetails['isRentStatementValue'] = true;
            this.ClaimsDetails['rentStatement'] = true;
            this.ClaimsDetails['rentStatementNoWarning'] = false;
            this.template.querySelector('.rentstatementyes').classList.add('active');
            this.template.querySelector('.rentstatementno').classList.remove('active');
        }
    }

    clickNo(event) {
        this.showKeyDocumentsError = false;
        let selectRecordId = event.target.title;
        if (selectRecordId == 'Exceedclaim') {
            this.ClaimsDetails['isClaimExceedValue'] = true;
            this.ClaimsDetails['claimExceed'] = false;
            this.template.querySelector('.exceedclaimyes').classList.remove('active');
            this.template.querySelector('.exceedclaimno').classList.add('active');
            setTimeout(() => {
                if (this.ClaimsDetails['claimExceed']) {
                    console.log('exceedclaimyes => ' + this.template.querySelector('.exceedclaimyes'));
                    this.template.querySelector('.exceedclaimyes').classList.add('active');
                } else if (!this.ClaimsDetails['claimExceed']) {
                    console.log('exceedclaimno => ' + this.template.querySelector('.exceedclaimno'));
                    this.template.querySelector('.exceedclaimno').classList.add('active');
                }

                if (this.ClaimsDetails['TenantObligations']) {
                    console.log('tenantobligationsyes => ' + this.template.querySelector('.tenantobligationsyes'));
                    this.template.querySelector('.tenantobligationsyes').classList.add('active');
                } else if (this.ClaimsDetails['TenantObligations'] == false) {
                    console.log('tenantobligationsno => ' + this.template.querySelector('.tenantobligationsno'));
                    this.template.querySelector('.tenantobligationsno').classList.add('active');
                }

                if (this.ClaimsDetails['inventorycheck']) {
                    console.log('inventorycheckyes => ' + this.template.querySelector('.inventorycheckyes'));
                    this.template.querySelector('.inventorycheckyes').classList.add('active');
                } else if (this.ClaimsDetails['inventorycheck'] == false) {
                    console.log('inventorycheckno => ' + this.template.querySelector('.inventorycheckno'));
                    this.template.querySelector('.inventorycheckno').classList.add('active');
                }

                if (this.ClaimsDetails['checkoutReport']) {
                    console.log('checkoutreportyes => ' + this.template.querySelector('.checkoutreportyes'));
                    this.template.querySelector('.checkoutreportyes').classList.add('active');
                } else if (this.ClaimsDetails['checkoutReport'] == false) {
                    console.log('checkoutreportno => ' + this.template.querySelector('.checkoutreportno'));
                    this.template.querySelector('.checkoutreportno').classList.add('active');
                }

                if (this.ClaimsDetails['rentStatement']) {
                    console.log('rentstatementyes => ' + this.template.querySelector('.rentstatementyes'));
                    this.template.querySelector('.rentstatementyes').classList.add('active');
                } else if (this.ClaimsDetails['rentStatement'] == false) {
                    console.log('rentstatementno => ' + this.template.querySelector('.rentstatementno'));
                    this.template.querySelector('.rentstatementno').classList.add('active');
                }
            }, 100);
        } else if (selectRecordId == 'TenantObligations') {
            this.ClaimsDetails['isTenantObligationsValue'] = true;
            this.ClaimsDetails['TenantObligations'] = false;
            this.ClaimsDetails['TenantObligationsNoWarning'] = true;
            this.template.querySelector('.tenantobligationsyes').classList.remove('active');
            this.template.querySelector('.tenantobligationsno').classList.add('active');

            this.ClaimsDetails.isTenantObligationsEviAttachment = false;
        } else if (selectRecordId == 'inventorycheck') {
            this.ClaimsDetails['isInventorycheckValue'] = true;
            this.ClaimsDetails['inventorycheck'] = false;
            this.ClaimsDetails['inventorycheckNoWarning'] = true;
            this.template.querySelector('.inventorycheckyes').classList.remove('active');
            this.template.querySelector('.inventorycheckno').classList.add('active');

            this.ClaimsDetails.isInventorycheckEviAttachmentFound = false;
        } else if (selectRecordId == 'checkoutReport') {
            this.ClaimsDetails['isCheckoutReportValue'] = true;
            this.ClaimsDetails['checkoutReport'] = false;
            this.ClaimsDetails['checkoutReportNoWarning'] = true;
            this.template.querySelector('.checkoutreportyes').classList.remove('active');
            this.template.querySelector('.checkoutreportno').classList.add('active');

            this.ClaimsDetails.isCheckoutReportEviAttachmentFound = false;
        } else if (selectRecordId == 'rentStatement') {
            this.ClaimsDetails['isRentStatementValue'] = true;
            this.ClaimsDetails['rentStatement'] = false;
            this.ClaimsDetails['rentStatementNoWarning'] = true;
            this.template.querySelector('.rentstatementyes').classList.remove('active');
            this.template.querySelector('.rentstatementno').classList.add('active');

            this.ClaimsDetails.isRentStatementEviAttachmentFound = false;
        }
    }

    getfromchild(event) {
        if (event.detail.isValid) { 
            this.isBankDetailsEmpty = false;
        } else {
            this.isBankDetailsEmpty = true;
        }
        console.log('renderedCallback this.ClaimsDetails.Consent_box_AGLL__c => ' + this.ClaimsDetails.Consent_box_AGLL__c)
        console.log('renderedCallback isBankDetailsEmpty => ' + this.isBankDetailsEmpty)
        if (this.ClaimsDetails.Consent_box_AGLL__c && !this.isBankDetailsEmpty) {
            this.template.querySelector('.consentbox').classList.add('blue_theme');
            this.template.querySelector('.consentbox').classList.remove('disable_ew_btn');
        } else {
            this.template.querySelector('.consentbox').classList.remove('blue_theme');
            this.template.querySelector('.consentbox').classList.add('disable_ew_btn');
        }
    }

    handlegotoDepositSummary(event) {
        let currentURL = window.location.href;
        console.log('currentURL => ' + currentURL);
        let homeURL = currentURL.split('/ni/s');
        console.log('homeURL => ' + homeURL);
        let redirectToURL = '';
        if (this.branchId != null) {
            redirectToURL = homeURL[0] + '/ni/s/depositSummary?depositId=' + btoa(this.depositRecId) + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false'); 
        } else {
            redirectToURL = homeURL[0] + '/ni/s/depositSummary?depositId=' + btoa(this.depositRecId);
        }
        console.log('redirectToURL => ' + redirectToURL);
        window.location.href = redirectToURL;
    }

    handleGoBackStep(event) {
        let title = event.target.title;
        if (title == 'viewContinue') {
            this.ViewContinue = true;
            this.keyDocuments = false;
        } else if (title == 'keyDocument') {
            this.ViewContinue = false;
            this.keyDocuments = true;
            this.showClaimBreakdown = false;
        } else if (title == 'claimBreakdown') {
            this.keyDocuments = false;
            this.showClaimBreakdown = true;
            this.showAdditionalComments = false;
        } else if (title == 'additionalComments') {
            this.showClaimBreakdown = false;
            this.showAdditionalComments = true;
            this.showReviewsubmission = false;
        }
        const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
        topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }

    handleCheckConsent() {
        this.ClaimsDetails.Consent_box_AGLL__c = !this.ClaimsDetails.Consent_box_AGLL__c;
        console.log("ClaimsDetails.Consent_box_AGLL__c => " + this.ClaimsDetails.Consent_box_AGLL__c);
        console.log("this.template.querySelector('.consentbox') => " + this.template.querySelector('.consentbox'));

        if (this.ClaimsDetails.Consent_box_AGLL__c && !this.isBankDetailsEmpty) {
            console.log('if');
            this.template.querySelector('.consentbox').classList.add('blue_theme');
            this.template.querySelector('.consentbox').classList.remove('disable_ew_btn');
        } else {
            console.log('else');
            this.template.querySelector('.consentbox').classList.remove('blue_theme');
            this.template.querySelector('.consentbox').classList.add('disable_ew_btn');
        }
    }

    handlegotokeyDocuments() {
        console.log('this.ClaimsDetails.Status => ' + this.ClaimsDetails.Status);
        console.log('this.cp.Type__c => ' + this.cp.Type__c);
       // console.log('this.cp.AGLL_Raised_Respond => ' + this.cp.AGLL_Raised_Respond__c);
        console.log("ClaimsDetails.Consent_box_AGLL__c => " + this.ClaimsDetails.Consent_box_AGLL__c);

        if (this.ClaimsDetails.Consent_box_AGLL__c && !this.isBankDetailsEmpty) {
            updateClaimAGLL({ claimId: this.ClaimsDetails.Id, consentBox: true })
                .then(result => {
                    console.log('updateClaimAGLL result => ' + result);
                    this.ViewContinue = false;
                    this.keyDocuments = true;
                    this.showClaimBreakdown = false;
                    setTimeout(() => {
                        if (this.Isclaimamountexceed == true) {
                            if (this.ClaimsDetails['claimExceed']) {
                                this.template.querySelector('.exceedclaimyes').classList.add('active');
                            } else if (this.ClaimsDetails['claimExceed'] == false) {
                                this.template.querySelector('.exceedclaimno').classList.add('active');
                            }
                        }
                        if (this.ClaimsDetails['TenantObligations']) {
                            this.template.querySelector('.tenantobligationsyes').classList.add('active');
                        } else if (this.ClaimsDetails['TenantObligations'] == false) {
                            this.template.querySelector('.tenantobligationsno').classList.add('active');
                        }

                        if (this.ClaimsDetails['inventorycheck']) {
                            this.template.querySelector('.inventorycheckyes').classList.add('active');
                        } else if (this.ClaimsDetails['inventorycheck'] == false) {
                            this.template.querySelector('.inventorycheckno').classList.add('active');
                        }

                        if (this.ClaimsDetails['checkoutReport']) {
                            this.template.querySelector('.checkoutreportyes').classList.add('active');
                        } else if (this.ClaimsDetails['checkoutReport'] == false) {
                            this.template.querySelector('.checkoutreportno').classList.add('active');
                        }

                        if (this.isShowPaymentOfRentKey == true) {
                            if (this.ClaimsDetails['rentStatement']) {
                                this.template.querySelector('.rentstatementyes').classList.add('active');
                            } else if (this.ClaimsDetails['rentStatement'] == false) {
                                this.template.querySelector('.rentstatementno').classList.add('active');
                            }
                        }
                        const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
                        topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
                    }, 100);
                }).catch(error => {
                    console.log('updateClaimAGLL error => ' + JSON.stringify(error));
                });
        }
    }

    handlegotoshowClaimBreakdown() {
        var isContinue = true;
        var isLengthIssue = false;

        if (this.Isclaimamountexceed && !this.ClaimsDetails.isClaimExceedValue) {
            isContinue = false;
        } else if (this.ClaimsDetails.claimExceed && (this.ClaimsDetails.claimExceedsComment == null || this.ClaimsDetails.claimExceedsComment.trim() == '' || this.ClaimsDetails.claimExceedsComment == 'undefind')) {
            isContinue = false;
        } else if (this.ClaimsDetails.claimExceedsComment_length) {
            isLengthIssue = true;
        }

        if (this.ClaimsDetails.isTenantObligationsValue && this.ClaimsDetails.isInventorycheckValue
            && this.ClaimsDetails.isCheckoutReportValue) {
            if (this.ClaimsDetails.TenantObligations) {
                const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Tenant obligations');
                if (eviAttachment) {
                    this.ClaimsDetails['isTenantObligationsEviAttachment'] = false;
                } else {
                    this.ClaimsDetails['isTenantObligationsEviAttachment'] = true;
                    isContinue = false;
                }
            }
            if (this.ClaimsDetails.inventorycheck) {
                const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Inventorycheck in report');
                if (eviAttachment) {
                    this.ClaimsDetails['isInventorycheckEviAttachmentFound'] = false;
                } else {
                    this.ClaimsDetails['isInventorycheckEviAttachmentFound'] = true;
                    isContinue = false;
                }
            }
            if (this.ClaimsDetails.checkoutReport) {
                const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Check out report');
                if (eviAttachment) {
                    this.ClaimsDetails['isCheckoutReportEviAttachmentFound'] = false;
                } else {
                    this.ClaimsDetails['isCheckoutReportEviAttachmentFound'] = true;
                    isContinue = false;
                }
            }

            if (this.isShowPaymentOfRentKey) {
                if (this.ClaimsDetails.isRentStatementValue) {
                    if (this.ClaimsDetails.rentStatement) {
                        const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Rent statement');
                        if (eviAttachment) {
                            this.ClaimsDetails['isRentStatementEviAttachmentFound'] = false;
                        } else {
                            this.ClaimsDetails['isRentStatementEviAttachmentFound'] = true;
                            isContinue = false;
                        }
                    }
                }
            }
        } else {
            isContinue = false;
        }

        if (isContinue == true && isLengthIssue == false) {
            this.showKeyDocumentsError = false;
            updatekeyDocuments({
                caseRecID: this.ClaimsDetails.Id,
                tenantObligation: this.ClaimsDetails.TenantObligations ? 'Yes' : 'No',
                exceedclaim: this.ClaimsDetails.claimExceed ? 'Yes' : 'No',
                inventryChekReport: this.ClaimsDetails.inventorycheck ? 'Yes' : 'No',
                checkOutReport: this.ClaimsDetails.checkoutReport ? 'Yes' : 'No',
                rentStatement: this.ClaimsDetails.rentStatement ? 'Yes' : 'No',
                claimExceedsComment: this.ClaimsDetails.claimExceedsComment
            }).then(result => {
                console.log('updatekeyDocuments result => ' + result);
            }).catch(error => {
                console.log('updatekeyDocuments error => ' + error);
            });
            this.keyDocuments = false;
            this.showClaimBreakdown = true;
            this.showAdditionalComments = false;

            const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
            topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
        } else if (!isContinue) {
            this.showKeyDocumentsError = true;
        }
    }
    handleDisputeItemValueChange(event) {
        console.log(event.target.value);
        console.log("this.disputeItems[this.currentItem][event.target.name]['_length'] => " + this.disputeItems[this.currentItem][event.target.name + '_length'])
        var descText = event.target.value;
        if (descText.length > NI_Evidence_Gathering_Comment_Box_Char_Limit) {
            event.target.value = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.disputeItems[this.currentItem][event.target.name] = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.disputeItems[this.currentItem][event.target.name + '_length'] = true;
        } else {
            this.disputeItems[this.currentItem][event.target.name] = descText;
            this.disputeItems[this.currentItem][event.target.name + '_length'] = false;
        }
        console.log('this.disputeItems[this.currentItem][event.target.name] => ' + this.disputeItems[this.currentItem][event.target.name])
    }

    goToPreviousItem(event) {
        console.log('goToPreviousItem currentItem => ' + this.currentItem);
        if (this.currentItem == 0) {
            this.showClaimBreakdown = false;
            this.keyDocuments = true;
            setTimeout(() => {
                if (this.Isclaimamountexceed == true) {
                    if (this.ClaimsDetails['claimExceed']) {
                        console.log('exceedclaimyes => ' + this.template.querySelector('.exceedclaimyes'));
                        this.template.querySelector('.exceedclaimyes').classList.add('active');
                    } else if (this.ClaimsDetails['claimExceed'] == false) {
                        console.log('exceedclaimno => ' + this.template.querySelector('.exceedclaimno'));
                        this.template.querySelector('.exceedclaimno').classList.add('active');
                    }
                }

                if (this.ClaimsDetails['TenantObligations']) {
                    this.template.querySelector('.tenantobligationsyes').classList.add('active');
                } else if (this.ClaimsDetails['TenantObligations'] == false) {
                    this.template.querySelector('.tenantobligationsno').classList.add('active');
                }

                if (this.ClaimsDetails['inventorycheck']) {
                    this.template.querySelector('.inventorycheckyes').classList.add('active');
                } else if (this.ClaimsDetails['inventorycheck'] == false) {
                    this.template.querySelector('.inventorycheckno').classList.add('active');
                }

                if (this.ClaimsDetails['checkoutReport']) {
                    this.template.querySelector('.checkoutreportyes').classList.add('active');
                } else if (this.ClaimsDetails['checkoutReport'] == false) {
                    this.template.querySelector('.checkoutreportno').classList.add('active');
                }

                if (this.isShowPaymentOfRentKey == true) {
                    if (this.ClaimsDetails['rentStatement']) {
                        this.template.querySelector('.rentstatementyes').classList.add('active');
                    } else if (this.ClaimsDetails['rentStatement'] == false) {
                        this.template.querySelector('.rentstatementno').classList.add('active');
                    }
                }
            }, 200);
        } else {
            this.currentItem--;
            this.disputeItems[this.currentItem].isShow = true;
            this.disputeItems[this.currentItem + 1].isShow = false;
        }
        const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
        topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }

    goToNextItem(event) {
        var isValid = true;
        var isLengthIssue = false;
        let calimItems = [];
        if (this.disputeItems[this.currentItem].key == 'Cleaning') {
            if (!this.disputeItems[this.currentItem].Claim_description_for_cleaning_agll__c || this.disputeItems[this.currentItem].Claim_description_for_cleaning_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Claim_description_for_cleaning_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_cleaning_agll__c || this.disputeItems[this.currentItem].Supporting_clause_cleaning_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_cleaning_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancystart_cleaning_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancystart_cleaning_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancystart_cleaning_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_cleaning_agl__c || this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_cleaning_agl__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_cleaning_agl__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_cleaning_agll__c || this.disputeItems[this.currentItem].Supporting_evidence_for_cleaning_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_cleaning_agll__c_length) {
                isLengthIssue = true;
            }
        } else if (this.disputeItems[this.currentItem].key == 'Damage') {
            if (!this.disputeItems[this.currentItem].Claim_description_for_damage_agll__c || this.disputeItems[this.currentItem].Claim_description_for_damage_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Claim_description_for_damage_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_damage_agll__c || this.disputeItems[this.currentItem].Supporting_clause_damage_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_damage_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancystart_damage_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancystart_damage_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancystart_damage_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_damage_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_damage_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_damage_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_damage_agll__c || this.disputeItems[this.currentItem].Supporting_evidence_for_damage_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_damage_agll__c_length) {
                isLengthIssue = true;
            }
        } else if (this.disputeItems[this.currentItem].key == 'Redecoration') {
            if (!this.disputeItems[this.currentItem].Claim_description_for_redecoration_agll__c || this.disputeItems[this.currentItem].Claim_description_for_redecoration_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Claim_description_for_redecoration_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_redecoration_agll__c || this.disputeItems[this.currentItem].Supporting_clause_redecoration_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_redecoration_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancystart_redecoration_ag__c || this.disputeItems[this.currentItem].Evidence_at_tenancystart_redecoration_ag__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancystart_redecoration_ag__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancyend_redecoration_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancyend_redecoration_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancyend_redecoration_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_redecoration_agl__c || this.disputeItems[this.currentItem].Supporting_evidence_for_redecoration_agl__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_redecoration_agl__c_length) {
                isLengthIssue = true;
            }
        } else if (this.disputeItems[this.currentItem].key == 'Gardening') {
            if (!this.disputeItems[this.currentItem].Claim_description_for_gardening_agll__c || this.disputeItems[this.currentItem].Claim_description_for_gardening_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Claim_description_for_gardening_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_gardening_agll__c || this.disputeItems[this.currentItem].Supporting_clause_gardening_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_gardening_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancystart_gardening_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancystart_gardening_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancystart_gardening_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Evidence_at_tenancyend_gardening_agll__c || this.disputeItems[this.currentItem].Evidence_at_tenancyend_gardening_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Evidence_at_tenancyend_gardening_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_gardening__c || this.disputeItems[this.currentItem].Supporting_evidence_for_gardening__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_gardening__c_length) {
                isLengthIssue = true;
            }
        } else if (this.disputeItems[this.currentItem].key == 'Rent arrears') {
            if (!this.disputeItems[this.currentItem].Rent_arrears_description_agll__c || this.disputeItems[this.currentItem].Rent_arrears_description_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Rent_arrears_description_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Was_the_property_re_let_rent_agll__c || this.disputeItems[this.currentItem].Was_the_property_re_let_rent_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Was_the_property_re_let_rent_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_rent_agll__c || this.disputeItems[this.currentItem].Supporting_clause_rent_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_rent_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_rent_agll__c || this.disputeItems[this.currentItem].Supporting_evidence_for_rent_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_rent_agll__c_length) {
                isLengthIssue = true;
            }
        } else if (this.disputeItems[this.currentItem].key == 'Other') {
            console.log('Inside Others');
            if (!this.disputeItems[this.currentItem].Claim_breakdown_other_AGLL__c || this.disputeItems[this.currentItem].Claim_breakdown_other_AGLL__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Claim_breakdown_other_AGLL__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_clause_other_agll__c || this.disputeItems[this.currentItem].Supporting_clause_other_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_clause_other_agll__c_length) {
                isLengthIssue = true;
            }
            if (!this.disputeItems[this.currentItem].Supporting_evidence_for_other_agll__c || this.disputeItems[this.currentItem].Supporting_evidence_for_other_agll__c.trim() == '') {
                isValid = false;
            } else if (this.disputeItems[this.currentItem].Supporting_evidence_for_other_agll__c_length) {
                isLengthIssue = true;
            }
        }

        if (isValid == true && isLengthIssue == false) {
            this.showDisputeItemError = false;
            for (let i in this.disputeItems) {
                let claim = {
                    'Id': this.disputeItems[i].Id,
                    'Claim_description_for_cleaning_agll__c': this.disputeItems[i].Claim_description_for_cleaning_agll__c,
                    'Supporting_clause_cleaning_agll__c': this.disputeItems[i].Supporting_clause_cleaning_agll__c,
                    'Evidence_at_tenancystart_cleaning_agll__c': this.disputeItems[i].Evidence_at_tenancystart_cleaning_agll__c,
                    'Evidence_at_tenancy_end_for_cleaning_agl__c': this.disputeItems[i].Evidence_at_tenancy_end_for_cleaning_agl__c,
                    'Supporting_evidence_for_cleaning_agll__c': this.disputeItems[i].Supporting_evidence_for_cleaning_agll__c,

                    'Claim_description_for_damage_agll__c': this.disputeItems[i].Claim_description_for_damage_agll__c,
                    'Supporting_clause_damage_agll__c': this.disputeItems[i].Supporting_clause_damage_agll__c,
                    'Evidence_at_tenancystart_damage_agll__c': this.disputeItems[i].Evidence_at_tenancystart_damage_agll__c,
                    'Evidence_at_tenancy_end_for_damage_agll__c': this.disputeItems[i].Evidence_at_tenancy_end_for_damage_agll__c,
                    'Supporting_evidence_for_damage_agll__c': this.disputeItems[i].Supporting_evidence_for_damage_agll__c,

                    'Claim_description_for_redecoration_agll__c': this.disputeItems[i].Claim_description_for_redecoration_agll__c,
                    'Supporting_clause_redecoration_agll__c': this.disputeItems[i].Supporting_clause_redecoration_agll__c,
                    'Evidence_at_tenancystart_redecoration_ag__c': this.disputeItems[i].Evidence_at_tenancystart_redecoration_ag__c,
                    'Evidence_at_tenancyend_redecoration_agll__c': this.disputeItems[i].Evidence_at_tenancyend_redecoration_agll__c,
                    'Supporting_evidence_for_redecoration_agl__c': this.disputeItems[i].Supporting_evidence_for_redecoration_agl__c,

                    'Claim_description_for_gardening_agll__c': this.disputeItems[i].Claim_description_for_gardening_agll__c,
                    'Supporting_clause_gardening_agll__c': this.disputeItems[i].Supporting_clause_gardening_agll__c,
                    'Evidence_at_tenancystart_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancystart_gardening_agll__c,
                    'Evidence_at_tenancyend_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancyend_gardening_agll__c,
                    'Supporting_evidence_for_gardening__c': this.disputeItems[i].Supporting_evidence_for_gardening__c,

                    'Rent_arrears_description_agll__c': this.disputeItems[i].Rent_arrears_description_agll__c,
                    'Was_the_property_re_let_rent_agll__c': this.disputeItems[i].Was_the_property_re_let_rent_agll__c,
                    'Supporting_clause_rent_agll__c': this.disputeItems[i].Supporting_clause_rent_agll__c,
                    'Supporting_evidence_for_rent_agll__c': this.disputeItems[i].Supporting_evidence_for_rent_agll__c,

                    'Claim_breakdown_other_AGLL__c': this.disputeItems[i].Claim_breakdown_other_AGLL__c,
                    'Supporting_clause_other_agll__c': this.disputeItems[i].Supporting_clause_other_agll__c,
                    'Supporting_evidence_for_other_agll__c': this.disputeItems[i].Supporting_evidence_for_other_agll__c
                };
                calimItems.push(claim);
            }

            updateClaimBreakdown({ disputeItemRec: JSON.stringify(calimItems) })
                .then(result => {
                }).catch(error => {
                });
            var totalItem = this.disputeItems.length;
            if (this.currentItem == totalItem - 1) {
                this.showClaimBreakdown = false;
                this.showAdditionalComments = true;
            } else {
                this.disputeItems[this.currentItem].isShow = false;
                this.disputeItems[this.currentItem + 1].isShow = true;
                this.currentItem++;
            }
            const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
            topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
        } else if (!isValid) {

            this.showDisputeItemError = true;
        }
    }

    handleClaimExceedCommentValuesChange(event) {
        this.showKeyDocumentsError = false;
        console.log(event.target.value);
        //this.ClaimsDetails[event.target.name] = event.target.value;
        var descText = event.target.value;
        if (descText.length > NI_Evidence_Gathering_Comment_Box_Char_Limit) {
            event.target.value = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name] = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name + '_length'] = true;
        } else {
            this.ClaimsDetails[event.target.name] = descText;
            this.ClaimsDetails[event.target.name + '_length'] = false;
        }
    }

    handleAdditionalCommentValuesChange(event) {
        console.log(event.target.value);
        //this.ClaimsDetails[event.target.name] = event.target.value;
        var descText = event.target.value;
        if (descText.length > NI_Evidence_Gathering_Comment_Box_Char_Limit) {
            event.target.value = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name] = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name + '_length'] = true;
        } else {
            this.ClaimsDetails[event.target.name] = descText;
            this.ClaimsDetails[event.target.name + '_length'] = false;
        }
    }

    handleClaimsDetailsValuesChange(event) {
        console.log(event.target.value);
        //this.ClaimsDetails[event.target.name] = event.target.value;
        var descText = event.target.value;
        if (descText.length > NI_Evidence_Gathering_Comment_Box_Char_Limit) {
            event.target.value = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name] = descText.substring(0, NI_Evidence_Gathering_Comment_Box_Char_Limit);
            this.ClaimsDetails[event.target.name + '_length'] = true;
        } else {
            this.ClaimsDetails[event.target.name] = descText;
            this.ClaimsDetails[event.target.name + '_length'] = false;
        }
    }

    handlegotoshowReviewsubmission() {
        if (!this.ClaimsDetails.Additional_comments_AGLL__c_length) {
            updateAdditionalComments({
                caseId: this.ClaimsDetails.Id,
                additionalComment: this.ClaimsDetails.Additional_comments_AGLL__c
            }).then(result => {
                console.log('result => ' + result);
            }).catch(error => {
                console.log('error => ' + error);
            });
            if (!this.ClaimsDetails.AGLL_Respond_Evidance_Gathering__c) {
                this.showAdditionalComments = false;
                this.showReviewsubmission = true;
            } else {
                this.handlegotoDepositSummary();
            }

            const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
            topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
        }
    }

    handleChangeEviAttachmentList(event) {
        var attachmensts = [];
        if (event.detail.type == 'upload') {
            let aviAttachment = event.detail.evidanceAttachment;
            attachmensts = [...this.evidenceAttachments, aviAttachment];
            this.evidenceAttachments = attachmensts;
        } else if (event.detail.type == 'delete') {
            for (let index in this.evidenceAttachments) {
                if (this.evidenceAttachments[index].Id != event.detail.deletedAttachment.Id) {
                    attachmensts.push(this.evidenceAttachments[index]);
                }
            }
            this.evidenceAttachments = attachmensts;
        }
    }

    handlegotoshowCancelDispute() {
        if (this.ViewContinue) {
            this.cancelFromPage = 'ViewContinue';
            this.ViewContinue = false;
        } else if (this.keyDocuments) {
            this.cancelFromPage = 'keyDocuments';
            this.keyDocuments = false;
        } else if (this.showClaimBreakdown) {
            this.cancelFromPage = 'showClaimBreakdown';
            this.showClaimBreakdown = false;
        } else if (this.showAdditionalComments) {
            this.cancelFromPage = 'showAdditionalComments';
            this.showAdditionalComments = false;
        } else if (this.showReviewsubmission) {
            this.cancelFromPage = 'showReviewsubmission';
            this.showReviewsubmission = false;
        }
        this.showCancelDispute = true;
        const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
        topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }

    handleBackFromCancelDispute() {
        this.showCancelDispute = false;
        this.isConfirmCancelDisputClicked = false;
        if (this.cancelFromPage == 'ViewContinue') {
            this.ViewContinue = true;
        } else if (this.cancelFromPage == 'keyDocuments') {
            this.keyDocuments = true;
        } else if (this.cancelFromPage == 'showClaimBreakdown') {
            this.showClaimBreakdown = true;
        } else if (this.cancelFromPage == 'showAdditionalComments') {
            this.showAdditionalComments = true;
        } else if (this.cancelFromPage == 'showReviewsubmission') {
            this.showReviewsubmission = true;
        }
        const topDiv = this.template.querySelector('[data-id="scroll-to-top"]');
        topDiv.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }

    handleConfirmCancelDispute() {
        this.isConfirmCancelDisputClicked = true;
        this.showSpinner = true;
        cancelclaimHoldingDisputedAmount({
            caseid: this.ClaimsDetails.Id,
            disptAmount: this.ClaimsDetails.remainDisputeAmount,
            depositId: this.depositRecId,
            scheme: 'NI Custodial',
            branchId: this.branchId != null ? this.branchId : null
        }).then(result => {
            this.showSpinner = false;
            this.showConfirmCancelDispute = true;
            console.log('cancle dispute' + showConfirmCancelDispute);
        }).catch(error => {
            this.showSpinner = false;
            console.log('cancelclaim error => ' + JSON.stringify(error));
        });
    }

    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "TenantObligationsNo":
                //  this.ClaimsDetails.isTenantObligationsValue = false;
                this.ClaimsDetails.TenantObligationsNoWarning = false;
                break;
            case "inventorycheckNo":
                //  this.ClaimsDetails.isInventorycheckValue = false;
                this.ClaimsDetails.inventorycheckNoWarning = false;
                break;
            case "checkoutReportNo":
                //  this.ClaimsDetails.isCheckoutReportValue = false;
                this.ClaimsDetails['checkoutReportNoWarning'] = false;
                break;
            case "rentStatementNo":
                //  this.ClaimsDetails.isRentStatementValue = false;
                this.ClaimsDetails['rentStatementNoWarning'] = false;
                break;

            case "isTenantObligationsEviAttachment":
                this.ClaimsDetails.isTenantObligationsEviAttachment = false;
                break;
            case "isInventorycheckEviAttachmentFound":
                this.ClaimsDetails.isInventorycheckEviAttachmentFound = false;
                break;
            case "isCheckoutReportEviAttachmentFound":
                this.ClaimsDetails.isCheckoutReportEviAttachmentFound = false;
                break;
            case "isRentStatementEviAttachmentFound":
                this.ClaimsDetails.isRentStatementEviAttachmentFound = false;
                break;
            case "bankSuccessMessage":
                this.bankSuccessMessage = false;
                break;
            case "nameOnAccountBlankError":
                this.nameOnAccountBlankError = false;
                break;
            case "nameOnAccountSpecialCharError":
                this.nameOnAccountSpecialCharError = false;
                break;
            case "accountNumberLengthError":
                this.accountNumberLengthError = false;
                break;
            case "accountNumberBlankError":
                this.accountNumberBlankError = false;
                break;
            case "invalidAccountNumberError":
                this.invalidAccountNumberError = false;
                break;
            case "sortCodeBlankError":
                this.sortCodeBlankError = false;
                break;
            case "bankOfAmericaSortCode":
                this.bankOfAmericaSortCode = false;
                break;
            case "Sortcodelengtherror":
                this.Sortcodelengtherror = false;
                break;
            case "invalidSortCodeError":
                this.invalidSortCodeError = false;
                break;
            case "bankErrorMessage":
                this.bankErrorMessage = false;
                break;
        }
    }

    getHelpArticleDocument() {
        window.open(this.eveGathUrl,
            '_blank');
            // window.open('https://ewinsureddev.blob.core.windows.net/ewinsureddev/5003G000008RH95QAG-1670487092870-TDS%20Help%20Article_v2.pdf?sp=rw&st=2022-04-05T08:51:01Z&se=2032-04-05T16:51:01Z&spr=https&sv=2020-08-04&sr=c&sig=vbBtrfu%2BbFNQQp1SY8AZ3kTf2z9MKp%2F3Hnia3FLKKCg%3D',
            // '_blank');
            
    }
}