import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

import pageUrl from '@salesforce/resourceUrl/recaptchaV2';
import postTenantFormData from '@salesforce/apex/TRS_TenantComplaint.postTenantFormData';
import areasOfComplaintDetails from '@salesforce/apex/TRS_TenantComplaint.areasOfComplaintDetails';
import findAddress from '@salesforce/apex/TRS_LoqateServiceForSite.findAddress';
import retrieveAddress from '@salesforce/apex/TRS_LoqateServiceForSite.retrieveAddress';

import addressloqate from '@salesforce/label/c.NHOS_AddressLoqateKey';
import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";
import trsSiteHomePageLink from "@salesforce/label/c.TRS_SiteHomePage";

const apikeyId = addressloqate;
const MAX_CHARACTER_LIMIT = 2000;

export default class TrsQuestionpage1 extends NavigationMixin(LightningElement) {

    label = {
        trsPortalHomePageLink
    };

    termsAndConditionsPage = trsSiteHomePageLink+'terms-and-conditions';
    privacyPolicyPage = trsSiteHomePageLink+'privacy-policy';

    @track currentpage = 1;
    activeSectionMessage = '';
    activeSections = ['A'];
    @track navigateTo;
    @track expression1 = true; // true
    @track expression2 = false;
    @track expression3 = false;
    @track expression4 = false;
    @track expression5 = false;
    @track expression6 = false; // false
    @track expression7 = false;
    @track tillQuestion6 = true;
    @track tillQuestion7 = false;
    @track pageSubmitted = false;

    agreedCheckbox = false;

    @track errorMessage = '';
    @track isNextButtonDisabled = true;
    @track showAccordion = false;
    @track showErrorMsg = false;
    @track showErrorMsg2 = false;
    @track showErrorMsg3 = false;
    @track showQ4Field = false;
    @track save2Valid = false;
    @track save3Valid = false;
    @track save4Valid = false;
    @track save5Valid = false;
    @track save6Valid = false;
    @track samePermanentAddress = false;
    @track otherIsSelected = false;
    @track isSubmitdisabled = true;

    @track isErrorMessageVisible = true;
    @track maxCharacterLimit = 2000;
    @track remainingCharacters = this.maxCharacterLimit;

    trsCaseReferenceNumber = '';
    showSpinner = false;

    captchaResult = false;

    showAreasOfComplaintSummaryDetailsInputSection = false;

    tip2 = 'In order to resolve your issue in the best possible way, you must raise your complaint first with your landlord. If after a reasonable time you do not receive a resolution to your issue then please come back to this platform and we will support you.';
    tip3 = 'In order to support your dispute we need the name and contact details of your landlord.<br/><br/> Without these we will be unable to contact the landlord on your behalf.<br/><br/> You should be able to locate the landlord' + 's details on your tenancy agreement document which you would have signed when first moving into the property.';
    tip4 = 'Please provide the contact information for the person who will be corresponding with us throughout this process.<br/><br/> Please provide more details in the complaint question later on.';
    tip5 = 'We need to know the address of the tenanted property so we can help to resolve the issue with your landlord.';
    tip6 = 'It is important you list all of the issues you are complaining about so that we can help you resolve all of the issues.';

    @track commitTenantDetails = {
        'Q1': { 'value': null, 'position': false, 'previewediting': false },
        'Q2': { 'value': null, 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q4': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q5': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q6': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false, 'buttonediting': false }
    };

    @track tenantDetails = {
        'Q1': { 'value': null, 'position': false, 'previewediting': false },
        'Q2': { 'value': null, 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q4': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q5': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q6': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false, 'buttonediting': false }
    };

    constructor() {
        super();
        this.navigateTo = pageUrl;
        // window.addEventListener("message", this.listenForMessage);//add event listener for message that we post in our recaptchaV2 static resource html file.

        window.addEventListener("message", this.listenForMessage.bind(this));
    }

    captchaLoaded(event) {
        if (event.target.getAttribute('src') == pageUrl) {
            // console.log('Google reCAPTCHA is loaded.');
        }
    }

    listenForMessage(message) {

        if (message.data == 'captcha success') {

            this.captchaResult = true;
            this.captchaValidation();
        }
        else if (message.data == 'captcha expired') {
            this.captchaResult = false;
            this.captchaValidation();
        }
    }

    get complaintTypeOptions() {
        return [
            { label: 'Marketing of the tenancy', value: 'Marketing of the tenancy' },
            { label: 'Tenancy terms', value: 'Tenancy terms' },
            { label: 'Property standards', value: 'Property standards' },
            { label: 'Repairs', value: 'Repairs' },
            { label: 'Entry rights', value: 'Entry rights' },
            { label: 'Rent arrears', value: 'Rent arrears' },
            { label: 'Threatened evictions', value: 'Threatened evictions' },
            { label: 'Breach of tenancy terms', value: 'Breach of tenancy terms' },
            { label: 'GDPR', value: 'GDPR' },
            { label: 'Communications', value: 'Communications' },
            { label: 'Noise/Anti-Social behaviour', value: 'Noise/Anti-Social behaviour' },
            { label: 'Other', value: 'Other' }
        ];
    }

    get options1() {
        return [
            { label: 'Yes, I live in England', value: 'Yes' },
            { label: 'No', value: 'No' },
        ];
    }

    get options2() {
        return [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' },
        ];
    }

    apiId = apikeyId;
    @track searchTerm = '';
    @track foundAddresses;
    @track selectedAddress;
    @track encodedKey = '';

    handleSearch(event) {
        this.searchTerm = event.target.value.trim();
        this.findAddress();
    }

    findAddress(secondCall) {
        let encodedSearchTerm = '';
        console.log('second call : ' + secondCall);
        if (secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        }

        console.log('encoded : ' + encodedSearchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = [];
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('error : ' + error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));
        console.log('cleanedid : ' + cleanedId);

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);
            this.findAddress(true);
        } else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
                .then(result => {
                    this.foundAddresses = false;
                    this.selectedAddress = JSON.parse(result);

                    this.tenantDetails.Q5.CurrStreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                    this.tenantDetails.Q5.CurrAddTownCity = this.selectedAddress.Items[0].City;
                    this.tenantDetails.Q5.CurrCounty = this.selectedAddress.Items[0].Province;
                    this.tenantDetails.Q5.CurrAddPostCode = this.selectedAddress.Items[0].PostalCode;
                    this.tenantDetails.Q5.CurrBaseCountry = 'England';
                    this.tenantDetails.Q5.CurrAddCountry = this.selectedAddress.Items[0].CountryName;

                    this.searchTerm = this.selectedAddress.Items[0].PostalCode;
                    //this.addressValidation();
                    this.fifthPageValidation();
                    this.tenantDetails.Q5.position = true;
                })
                .catch(error => {
                    console.log('error : ' + error);
                });
        }

    }

    /*handleSearch(event) {
        this.searchTerm = event.target.value.trim();
        this.findAddress();
    }

    findAddress() {

        const encodedSearchTerm = encodeURIComponent(this.searchTerm);

        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                const addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('Error: find ', error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));

        if (cleanedId.includes('-')) {
            this.searchTerm = cleanedId;

            this.encodedKey = encodeURIComponent(this.searchTerm);

            this.findAddress();
            return;
        }
        else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
                .then(result => {
                    this.selectedAddress = JSON.parse(result);
                    console.log('address - '+JSON.stringify(this.selectedAddress));
                    this.tenantDetails.Q5.CurrStreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                    this.tenantDetails.Q5.CurrAddTownCity = this.selectedAddress.Items[0].City;
                    this.tenantDetails.Q5.CurrCounty = this.selectedAddress.Items[0].Province;
                    this.tenantDetails.Q5.CurrAddPostCode = this.selectedAddress.Items[0].PostalCode;
                    this.tenantDetails.Q5.CurrBaseCountry = 'England'; //this.selectedAddress.Items[0].
                    this.tenantDetails.Q5.CurrAddCountry = this.selectedAddress.Items[0].CountryName;

                    // Close the list of found addresses
                    this.foundAddresses = null;
                    this.searchTerm = this.selectedAddress.Items[0].PostalCode;

                    this.fifthPageValidation();
                    this.tenantDetails.Q5.position = true;
                })
                .catch(error => {
                    console.log('inside eror ', error);
                });
        }
    }*/

    @track searchTermElse = '';
    @track foundAddressesElse;
    @track selectedAddressElse;
    @track encodedKeyElse = '';

    handleSearchElse(event) {
        this.searchTermElse = event.target.value.trim();
        this.findAddressElse();
    }

    findAddressElse(secondCall) {
        let encodedSearchTerm = '';
        console.log('second call : ' + secondCall);
        if (secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTermElse);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTermElse);
        }

        console.log('encoded : ' + encodedSearchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddressesElse = [];
                    this.foundAddressesElse = addresses.Items;
                } else {
                    this.foundAddressesElse = [];
                }
            })
            .catch(error => {
                console.error('error : ' + error);
            });
    }

    retrieveAddressElse(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));
        console.log('cleanedid : ' + cleanedId);

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);
            this.findAddressElse(true);
        } else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
                .then(result => {
                    this.foundAddressesElse = false;
                    this.selectedAddressElse = JSON.parse(result);

                    this.tenantDetails.Q5.PropStreetName = this.selectedAddressElse.Items[0].Line1 + this.selectedAddressElse.Items[0].Line2;
                    this.tenantDetails.Q5.PropAddTownCity = this.selectedAddressElse.Items[0].City;
                    this.tenantDetails.Q5.PropCounty = this.selectedAddressElse.Items[0].Province;
                    this.tenantDetails.Q5.PropAddPostCode = this.selectedAddressElse.Items[0].PostalCode;
                    this.tenantDetails.Q5.PropBaseCountry = 'England';
                    this.tenantDetails.Q5.PropAddCountry = this.selectedAddressElse.Items[0].CountryName;

                    this.searchTermElse = this.selectedAddressElse.Items[0].PostalCode;
                    //this.addressValidation();
                    this.fifthPageValidation();
                    this.tenantDetails.Q5.position = true;
                })
                .catch(error => {
                    console.log('error : ' + error);
                });
        }

    }

    /*handleSearchElse(event) {
        this.searchTermElse = event.target.value.trim();
        this.findAddressElse();
    }

    findAddressElse() {

        const encodedSearchTermElse = encodeURIComponent(this.searchTermElse);
        findAddress({ apiKey: this.apiId, search: encodedSearchTermElse, containerId: this.encodedKeyElse })
            .then(result => {
                const addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddressesElse = addresses.Items;
                } else {
                    this.foundAddressesElse = [];
                }
            })
            .catch(error => {
                console.error('Error: find ', error);
            });
    }

    retrieveAddressElse(event) {
        const idelse = event.target.id;
        const cleanedIdElse = idelse.substring(0, idelse.lastIndexOf('-'));

        if (cleanedIdElse.includes('-')) {
            this.searchTermElse = cleanedIdElse;
            this.encodedKeyElse = encodeURIComponent(this.searchTermElse);

            this.findAddressElse();
            return;
        }
        else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedIdElse })
                .then(result => {
                    this.selectedAddressElse = JSON.parse(result);

                    this.tenantDetails.Q5.PropStreetName = this.selectedAddressElse.Items[0].Line1 + this.selectedAddressElse.Items[0].Line2;
                    this.tenantDetails.Q5.PropAddTownCity = this.selectedAddressElse.Items[0].City;
                    this.tenantDetails.Q5.PropCounty = this.selectedAddressElse.Items[0].Province;
                    this.tenantDetails.Q5.PropAddPostCode = this.selectedAddressElse.Items[0].PostalCode;
                    this.tenantDetails.Q5.PropBaseCountry = 'England';
                    this.tenantDetails.Q5.PropAddCountry = this.selectedAddressElse.Items[0].CountryName;

                    // Close the list of found addresses
                    this.foundAddressesElse = null;
                    this.searchTermElse = this.selectedAddressElse.Items[0].PostalCode;

                    this.fifthPageValidation();
                    this.tenantDetails.Q5.position = true;
                })
                .catch(error => {
                    console.log('inside eror ', error);
                });
        }
    }*/

    handleQ7Checkbox(event) {
        this.agreedCheckbox = event.target.checked;
        this.captchaValidation();
    }

    captchaValidation() {
        if (this.agreedCheckbox && this.captchaResult && this.validateAreasOfComplaintDetailsSubmission2()) {
            this.commitTenantDetails = JSON.parse(JSON.stringify(this.tenantDetails));
            this.isSubmitdisabled = false;
        } else {
            this.isSubmitdisabled = true;
        }
    }

    handleAllChanges(event) {
        if (event.target.dataset.name == 'q1radio') {
            this.tenantDetails.Q1.value = event.target.value;
            this.validateInputFirst();
        } else if (event.target.dataset.name == 'q2radio') {
            this.tenantDetails.Q2.value = event.target.value;
            this.validateInputTwo();
        } else if (event.target.name == 'q3firstname') {
            this.tenantDetails.Q3.FirstName = event.target.value;
            this.tenantDetails.Q3.FirstName = this.tenantDetails.Q3.FirstName.trim();
            this.thirdPageValidation();

            this.tenantDetails.Q3.position = true;
        } else if (event.target.name == 'q3lastname') {
            this.tenantDetails.Q3.LastName = event.target.value;
            this.tenantDetails.Q3.LastName = this.tenantDetails.Q3.LastName.trim();
            this.thirdPageValidation();

            this.tenantDetails.Q3.position = true;
        } else if (event.target.name == 'q3email') {
            this.tenantDetails.Q3.Email = event.target.value;
            this.thirdPageValidation();

            this.tenantDetails.Q3.position = true;
        } else if (event.target.name == 'q3phone') {
            this.tenantDetails.Q3.Phone = event.target.value;
            this.thirdPageValidation();

            this.tenantDetails.Q3.position = true;
        } else if (event.target.name == 'q4firstname') {
            this.tenantDetails.Q4.ConFirstName = event.target.value;
            this.tenantDetails.Q4.ConFirstName = this.tenantDetails.Q4.ConFirstName.trim();
            this.fourthPageValidation();

            this.tenantDetails.Q4.position = true;
        } else if (event.target.name == 'q4lastname') {
            this.tenantDetails.Q4.ConLastName = event.target.value;
            this.tenantDetails.Q4.ConLastName = this.tenantDetails.Q4.ConLastName.trim();
            this.fourthPageValidation();

            this.tenantDetails.Q4.position = true;
        } else if (event.target.name == 'q4email') {
            this.tenantDetails.Q4.ConEmail = event.target.value;
            this.fourthPageValidation();

            this.tenantDetails.Q4.position = true;

        } else if (event.target.name == 'q4phone') {
            this.tenantDetails.Q4.ConPhone = event.target.value;
            this.fourthPageValidation();

            this.tenantDetails.Q4.position = true;
        } else if (event.target.name == 'q5streetname') {
            this.tenantDetails.Q5.CurrStreetName = event.target.value;
            this.fifthPageValidation();

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5towncity') {
            this.tenantDetails.Q5.CurrAddTownCity = event.target.value;
            this.fifthPageValidation();
            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5county') {
            this.tenantDetails.Q5.CurrCounty = event.target.value;
            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5postcode') {
            this.tenantDetails.Q5.CurrAddPostCode = event.target.value;
            this.fifthPageValidation();

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5basecountry') {
            this.tenantDetails.Q5.CurrBaseCountry = event.target.value;
            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5country') {
            this.tenantDetails.Q5.CurrAddCountry = event.target.value;

            this.tenantDetails.Q5.position = true;
        } else if (event.target.dataset.name == 'q5checkbox') {
            this.tenantDetails.Q5.SamePermanentAdd = event.target.checked;

            if (this.tenantDetails.Q5.SamePermanentAdd == true) {
                this.samePermanentAddress = true;
            } else {
                this.samePermanentAddress = false;
            }
            this.fifthPageValidation();
            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5propstreetname') {
            this.tenantDetails.Q5.PropStreetName = event.target.value;
            this.fifthPageValidation();

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5proptowncity') {
            this.tenantDetails.Q5.PropAddTownCity = event.target.value;
            this.fifthPageValidation();

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5propcounty') {
            this.tenantDetails.Q5.PropCounty = event.target.value;

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5proppostcode') {
            this.tenantDetails.Q5.PropAddPostCode = event.target.value;
            this.fifthPageValidation();

            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5propbasecountry') {
            this.tenantDetails.Q5.PropBaseCountry = event.target.value;
            this.tenantDetails.Q5.position = true;
        } else if (event.target.name == 'q5propcountry') {
            this.tenantDetails.Q5.PropAddCountry = event.target.value;

            this.tenantDetails.Q5.position = true;
        } else if (event.target.dataset.name == 'q6checkbox') {
            try {
                this.setAreasOfComplaintsSummaryDynamically(event.detail.value);
                this.selectedComplaintTypes = event.detail.value;
                
                this.tenantDetails.Q6.SelectedCheckboxes = event.detail.value;
                this.tenantDetails.Q6.position = true;

                //this.setAreasOfComplaintsSummaryDynamically(event.detail.value);

                if (this.tenantDetails.Q6.SelectedCheckboxes.includes('Other')) {
                    this.otherIsSelected = true;
                    this.sixthValidation();
                } else {
                    this.otherIsSelected = false;
                    this.sixthValidation();
                }

                if(this.validateAreasOfComplaintDetailsSubmission()) {
                    this.isNextButtonDisabled = false;
                } else {
                    this.isNextButtonDisabled = true;
                }
            } catch (error) {
                console.log('error : ' + error);
            }
        } else if (event.target.dataset.name == 'q6checkbox2') {
            try {
                this.setAreasOfComplaintsSummaryDynamically2(event.detail.value);
                this.commitSelectedComplaintTypes = event.detail.value;

                this.tenantDetails.Q6.SelectedCheckboxes = event.detail.value;
                this.tenantDetails.Q6.position = true;

                //this.setAreasOfComplaintsSummaryDynamically(event.detail.value);

                if (this.tenantDetails.Q6.SelectedCheckboxes.includes('Other')) {
                    this.otherIsSelected = true;
                    this.sixthValidation();
                } else {
                    this.otherIsSelected = false;
                    this.sixthValidation();
                }

                if(this.validateAreasOfComplaintDetailsSubmission()) {
                    this.isNextButtonDisabled = false;
                } else {
                    this.isNextButtonDisabled = true;
                }
            } catch (error) {
                console.log('error : ' + error);
            }
        } else if (event.target.name == 'q6otherselected') {
            this.tenantDetails.Q6.OtherSelectedValue = event.detail.value;
            this.sixthValidation();

            this.tenantDetails.Q6.position = true;
        } else if (event.target.name == 'q6text') {
            this.tenantDetails.Q6.ComplaintDetail = event.detail.value;

            this.remainingCharacters = this.maxCharacterLimit - this.tenantDetails.Q6.ComplaintDetail.length;
            if (this.remainingCharacters <= 0) {
                this.isErrorMessageVisible = false;
            } else {
                this.isErrorMessageVisible = true;
            }

            this.sixthValidation();
            this.tenantDetails.Q6.position = true;
        }
    }

    selectedComplaintTypes = [];
    commitSelectedComplaintTypes = [];

    @track complaintSummaryDetails = [];
    @track commitComplaintSummaryDetails = [];

    @track tempComplaintSummaryDetails = [];

    setAreasOfComplaintsSummaryDynamically(selectedCheckBoxes) {
        try {
            console.log('complaintSummaryDetails size : '+this.complaintSummaryDetails.length);
            this.complaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));
            
            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.complaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.complaintSummaryDetails[i].complaintType));
                        if(this.complaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.complaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.complaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.complaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.complaintSummaryDetails;
            console.log('complaint : '+JSON.stringify(this.tempComplaintSummaryDetails));
        } catch (error) {
            console.log('error in setAreasOfComplaintsSummaryDynamically : ' + error);
        }
    }

    setAreasOfComplaintsSummaryDynamically2(selectedCheckBoxes) {
        try {
            this.commitComplaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));

            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.commitComplaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.commitComplaintSummaryDetails[i].complaintType));
                        if(this.commitComplaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.commitComplaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.commitComplaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.commitComplaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.commitComplaintSummaryDetails;
            console.log('complaint : '+JSON.stringify(this.commitComplaintSummaryDetails));
        } catch (error) {
            console.log('error in setAreasOfComplaintsSummaryDynamically2 : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;
            console.log('complaint type : ' + COMPLAINT_TYPE + ', field value : ' + VALUE+', index : '+INDEX);
            this.complaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.complaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;
            console.log('summary details : ' + JSON.stringify(this.complaintSummaryDetails));
            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
            }
        } catch (error) {
            console.log('error in handleAreasOfComplaintSummaryDetailsChange : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange2(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;
            console.log('complaint type : ' + COMPLAINT_TYPE + ', field value : ' + VALUE+', index : '+INDEX);
            this.commitComplaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.commitComplaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;
            console.log('summary details : ' + JSON.stringify(this.commitComplaintSummaryDetails));
            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.isSubmitdisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
                //this.isSubmitdisabled = true;
            }
            this.captchaValidation();
            JSON.stringify(this.commitComplaintSummaryDetails)
        } catch (error) {
            console.log('error in handleAreasOfComplaintSummaryDetailsChange2 : ' + error);
        }
    }

    validateAreasOfComplaintDetailsSubmission() {
        let isValid = true;

        if(this.selectedComplaintTypes == []) {
            isValid = false;
        }

        this.complaintSummaryDetails.forEach((element) => {
            console.log('element : '+JSON.stringify(element));
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateAreasOfComplaintDetailsSubmission2() {
        let isValid = true;

        if(this.commitSelectedComplaintTypes == []) {
            isValid = false;
        }

        this.commitComplaintSummaryDetails.forEach((element) => {
            console.log('element : '+JSON.stringify(element));
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    handleAOCApexClass() {
        areasOfComplaintDetails({ areasOfComplaintDetails: JSON.stringify(this.complaintSummaryDetails) })
            .then(result => {
                console.log('result : ' + result);
            })
            .catch(error => {
                console.log('error : '+error);
            });
        
        postTenantFormData({ tenantDet: JSON.stringify(this.commitTenantDetails), areasOfComplaintDetails: JSON.stringify(this.complaintSummaryDetails) })
            .then(result => {
                console.log('result : ' + result);
            })
            .catch(error => {
                console.log('error : ' + error);
            });
    }

    remainingCharacterCount(event) {
        console.log('event : '+JSON.stringify(event));
        return String.valueOf(MAX_CHARACTER_LIMIT);
    }

    validateInputFirst() {
        /*if (this.tenantDetails.Q1.value == null && this.currentpage == 1) {
            this.showToast('Error', 'Please select an option', 'Error', 'Dismissable');
            this.isNextButtonDisabled = true;
            return;
        } else {
            this.isNextButtonDisabled = false;
        }*/
        if (this.tenantDetails.Q1.value == null && this.currentpage == 1) {
            this.showToast('Error', 'Please select an option', 'Error', 'Dismissable');

            this.isNextButtonDisabled = true;
            return;
        }
        else if (this.tenantDetails.Q1.value == 'No') {
            this.showErrorMsg = true;
            this.isNextButtonDisabled = true;
            return;
        }
        else {
            this.showErrorMsg = false;
            this.isNextButtonDisabled = false;
        }
    }

    validateInputTwo() {
        if (this.tenantDetails.Q2.value == 'No') {
            this.showErrorMsg2 = true;
            this.isNextButtonDisabled = true;
            this.save2Valid = false;
            return;
        }
        else if (this.tenantDetails.Q2.value == '' || this.tenantDetails.Q2.value == undefined || this.tenantDetails.Q2.value == null) {
            this.isNextButtonDisabled = true;
            this.save2Valid = false;
        }
        else {
            this.showErrorMsg2 = false;
            this.isNextButtonDisabled = false;
            this.save2Valid = true;
        }
    }

    thirdPageValidation() {
        // var fullNameCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailPhonecorrect = false;


        if (this.tenantDetails.Q3.FirstName != '' && this.tenantDetails.Q3.FirstName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.tenantDetails.Q3.FirstName)) {
                let searchCmp = this.template.querySelector(".firstnameCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid first name without space");
                }
                firstNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".firstnameCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                firstNameCorrect = true;
            }
        }
        else if (this.tenantDetails.Q3.FirstName == '') {
            this.template.querySelector(".firstnameCmp3").setCustomValidity("");
        }

        if (this.tenantDetails.Q3.LastName != '' && this.tenantDetails.Q3.LastName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.tenantDetails.Q3.LastName)) {
                let searchCmp = this.template.querySelector(".lastnameCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid last name without space");
                }
                lastNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".lastnameCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                lastNameCorrect = true;
            }
        }
        else if (this.tenantDetails.Q3.LastName == '') {
            this.template.querySelector(".lastnameCmp3").setCustomValidity("");
        }

        const emailRegex = /^(\s*)?[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(\s*)?$/;
        const phoneRegex = /^0\d{10}$/; // Regular expression for a 10-digit phone number

        if ((this.tenantDetails.Q3.Email != '' && this.tenantDetails.Q3.Email != undefined && emailRegex.test(this.tenantDetails.Q3.Email) && (this.tenantDetails.Q3.Phone == '' || this.tenantDetails.Q3.Phone == undefined))
            || (this.tenantDetails.Q3.Phone != '' && this.tenantDetails.Q3.Phone != undefined && this.tenantDetails.Q3.Phone.length == 11 && phoneRegex.test(this.tenantDetails.Q3.Phone) && (this.tenantDetails.Q3.Email == '' || this.tenantDetails.Q3.Email == undefined))
            || (this.tenantDetails.Q3.Email != '' && this.tenantDetails.Q3.Email != undefined && emailRegex.test(this.tenantDetails.Q3.Email) && this.tenantDetails.Q3.Phone != '' && this.tenantDetails.Q3.Phone != undefined && this.tenantDetails.Q3.Phone.length == 11 && phoneRegex.test(this.tenantDetails.Q3.Phone))

        ) {
            emailPhonecorrect = true;

        }
        else if (this.tenantDetails.Q3.Email == '' && this.tenantDetails.Q3.Phone == '') {
            this.showErrorMsg3 = true;
            emailPhonecorrect = false;
        }
        else {
            this.showErrorMsg3 = false;
            emailPhonecorrect = false;

        }

        if (this.tenantDetails.Q3.Phone != null && this.tenantDetails.Q3.Phone != undefined && this.tenantDetails.Q3.Phone != '') {
            if (!phoneRegex.test(this.tenantDetails.Q3.Phone)) {

                let searchCmp = this.template.querySelector(".phoneCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
            }
            else {
                let searchCmp = this.template.querySelector(".phoneCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else if (this.tenantDetails.Q3.Phone == '') {
            this.template.querySelector(".phoneCmp3").setCustomValidity("");
        }


        if (this.tenantDetails.Q3.Email != null && this.tenantDetails.Q3.Email != undefined && this.tenantDetails.Q3.Email != '') {
            if (!emailRegex.test(this.tenantDetails.Q3.Email)) {
                let searchCmp = this.template.querySelector(".emailCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                let searchCmp = this.template.querySelector(".emailCmp3");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else if (this.tenantDetails.Q3.Email == '') {
            this.template.querySelector(".emailCmp3").setCustomValidity("");
        }

        if (emailPhonecorrect && firstNameCorrect && lastNameCorrect) {
            this.isNextButtonDisabled = false;
            this.save3Valid = true;
        } else {
            this.isNextButtonDisabled = true;
            this.save3Valid = false;
        }
    }

    fourthPageValidation() {
        // var fullNameCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailcorrect = false;
        var phonecorrect = true;

        if (this.tenantDetails.Q4.ConFirstName != '' && this.tenantDetails.Q4.ConFirstName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.tenantDetails.Q4.ConFirstName)) {
                let searchCmp2 = this.template.querySelector(".firstnameCmp4");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid first name without space");
                }
                firstNameCorrect = false;
            }
            else {
                let searchCmp2 = this.template.querySelector(".firstnameCmp4");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }
                firstNameCorrect = true;
            }
        }
        else if (this.tenantDetails.Q4.ConFirstName == '') {
            this.template.querySelector(".firstnameCmp4").setCustomValidity("");
        }

        if (this.tenantDetails.Q4.ConLastName != '' && this.tenantDetails.Q4.ConLastName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.tenantDetails.Q4.ConLastName)) {
                let searchCmp = this.template.querySelector(".lastnameCmp4");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid last name without space");
                }
                lastNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".lastnameCmp4");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                lastNameCorrect = true;
            }
        }
        else if (this.tenantDetails.Q4.ConLastName == '') {
            this.template.querySelector(".lastnameCmp4").setCustomValidity("");
        }

        const emailRegex = /^(\s*)?[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(\s*)?$/;
        const phoneRegex = /^0\d{10}$/; // Regular expression for a 10-digit phone number

        if (this.tenantDetails.Q4.ConEmail != '' && this.tenantDetails.Q4.ConEmail != undefined && emailRegex.test(this.tenantDetails.Q4.ConEmail)) {
            emailcorrect = true;
        }

        if (this.tenantDetails.Q4.ConPhone != null && this.tenantDetails.Q4.ConPhone != undefined && this.tenantDetails.Q4.ConPhone != '') {
            if (!phoneRegex.test(this.tenantDetails.Q4.ConPhone)) {
                let searchCmp4 = this.template.querySelector(".phoneCmp4");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
                phonecorrect = false;
            }
            else {
                let searchCmp4 = this.template.querySelector(".phoneCmp4");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("");
                }
                phonecorrect = true;
            }
        } else if (this.tenantDetails.Q4.ConPhone == '') {
            this.template.querySelector(".phoneCmp4").setCustomValidity("");
            phonecorrect = true;
        }

        if (this.tenantDetails.Q4.ConEmail != null && this.tenantDetails.Q4.ConEmail != undefined && this.tenantDetails.Q4.ConEmail != '') {
            if (!emailRegex.test(this.tenantDetails.Q4.ConEmail)) {
                let searchCmp5 = this.template.querySelector(".emailCmp4");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                let searchCmp5 = this.template.querySelector(".emailCmp4");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("");
                }
            }
        } else if (this.tenantDetails.Q4.ConEmail == '') {
            this.template.querySelector(".emailCmp4").setCustomValidity("");
        }

        if ((emailcorrect && firstNameCorrect && lastNameCorrect && phonecorrect)) {
            this.isNextButtonDisabled = false;
            this.save4Valid = true;
        } else {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        }
    }

    fifthPageValidation() {
        if ((this.tenantDetails.Q5.CurrStreetName != undefined && this.tenantDetails.Q5.CurrStreetName != null && this.tenantDetails.Q5.CurrStreetName != '')
            && (this.tenantDetails.Q5.CurrAddTownCity != null && this.tenantDetails.Q5.CurrAddTownCity != undefined && this.tenantDetails.Q5.CurrAddTownCity != '')
            && (this.tenantDetails.Q5.CurrAddPostCode != null && this.tenantDetails.Q5.CurrAddPostCode != '' && this.tenantDetails.Q5.CurrAddPostCode != undefined)
            && (this.tenantDetails.Q5.PropStreetName != undefined && this.tenantDetails.Q5.PropStreetName != null && this.tenantDetails.Q5.PropStreetName != '')
            && (this.tenantDetails.Q5.PropAddTownCity != null && this.tenantDetails.Q5.PropAddTownCity != undefined && this.tenantDetails.Q5.PropAddTownCity != '')
            && (this.tenantDetails.Q5.PropAddPostCode != null && this.tenantDetails.Q5.PropAddPostCode != '' && this.tenantDetails.Q5.PropAddPostCode != undefined)
            && this.samePermanentAddress == false) {
            this.isNextButtonDisabled = false;
            this.save5Valid = true;

        }
        else if ((this.tenantDetails.Q5.CurrStreetName != undefined && this.tenantDetails.Q5.CurrStreetName != null && this.tenantDetails.Q5.CurrStreetName != '')
            && (this.tenantDetails.Q5.CurrAddTownCity != null && this.tenantDetails.Q5.CurrAddTownCity != undefined && this.tenantDetails.Q5.CurrAddTownCity != '')
            && (this.tenantDetails.Q5.CurrAddPostCode != null && this.tenantDetails.Q5.CurrAddPostCode != '' && this.tenantDetails.Q5.CurrAddPostCode != undefined)
            && this.samePermanentAddress == true) {
            this.isNextButtonDisabled = false;
            this.save5Valid = true;
        }
        else if ((this.tenantDetails.Q5.CurrStreetName != undefined && this.tenantDetails.Q5.CurrStreetName != null && this.tenantDetails.Q5.CurrStreetName != '')
            && (this.tenantDetails.Q5.CurrAddTownCity != null && this.tenantDetails.Q5.CurrAddTownCity != undefined && this.tenantDetails.Q5.CurrAddTownCity != '')
            && (this.tenantDetails.Q5.CurrAddPostCode != null && this.tenantDetails.Q5.CurrAddPostCode != '' && this.tenantDetails.Q5.CurrAddPostCode != undefined)
            && this.samePermanentAddress == false) {
            this.isNextButtonDisabled = true;
            this.save5Valid = false;
        }
        else {
            this.isNextButtonDisabled = true;
            this.save5Valid = false;
        }

    }

    sixthValidation() {
        if (this.tenantDetails.Q6.SelectedCheckboxes != [] && this.tenantDetails.Q6.SelectedCheckboxes != '' && this.tenantDetails.Q6.ComplaintDetail != undefined && this.tenantDetails.Q6.ComplaintDetail != '') {
            if (this.tenantDetails.Q6.SelectedCheckboxes.length >= 1 && this.tenantDetails.Q6.ComplaintDetail != '' && this.otherIsSelected == false) {
                this.isNextButtonDisabled = false;
                this.save6Valid = true;
            } else if (this.otherIsSelected == true && this.tenantDetails.Q6.SelectedCheckboxes.length >= 1 && (this.tenantDetails.Q6.OtherSelectedValue != '' && this.tenantDetails.Q6.OtherSelectedValue != undefined && this.tenantDetails.Q6.OtherSelectedValue != null)) {
                this.isNextButtonDisabled = false;
                this.save6Valid = true;
            } else {
                this.isNextButtonDisabled = true;
                this.save6Valid = false;
            }
        } else if ((this.tenantDetails.Q6.SelectedCheckboxes != [] || this.tenantDetails.Q6.SelectedCheckboxes != '') && (this.tenantDetails.Q6.ComplaintDetail == undefined || this.tenantDetails.Q6.ComplaintDetail == '')) {
            this.isNextButtonDisabled = true;
            this.save6Valid = false;
        } else if ((this.tenantDetails.Q6.SelectedCheckboxes == [] || this.tenantDetails.Q6.SelectedCheckboxes == '') && (this.tenantDetails.Q6.ComplaintDetail != undefined || this.tenantDetails.Q6.ComplaintDetail != '')) {
            this.isNextButtonDisabled = true;
            this.save6Valid = false;
        }

        if ((this.tenantDetails.Q6.SelectedCheckboxes == [] && (this.tenantDetails.Q6.ComplaintDetail == undefined || this.tenantDetails.Q6.ComplaintDetail == '')) && this.currentpage == 6) {
            this.isNextButtonDisabled = true;
            this.save6Valid = false;
        }
    }

    handleNext() {
        window.scrollTo(0, 0);

        this.isNextButtonDisabled = true;

        this.hideAll();

        if (this.tenantDetails.Q1.value == null && this.currentpage == 1) {
            this.showToast('Error', 'Please select an option', 'Error', 'Dismissable');

            this.isNextButtonDisabled = true;
            return;
        }

        if (this.tenantDetails.Q2.value == null && this.currentpage == 2) {
            this.showToast('Error', 'Please select an option', 'Error', 'Dismissable');

            this.isNextButtonDisabled = true;
            return;
        } else if (this.tenantDetails.Q3.FirstName == null && this.tenantDetails.Q3.LastName == null && this.currentpage == 4) {
            this.showToast('Error', 'Please Fill Name Field', 'Error', 'Dismissable');
            //this.isNextButtonDisabled = true;
            return;
        } else if (((this.tenantDetails.Q3.Email == '' || this.tenantDetails.Q3.Email == undefined) && (this.tenantDetails.Q3.Phone == '' || this.tenantDetails.Q3.Phone == undefined)) && this.currentpage == 4) {
            this.showToast('Error', 'Either Email Or Phone must be filled', 'Error', 'Dismissable');

            this.isNextButtonDisabled = true;
            return;
        } else if (this.tenantDetails.Q4.ConFirstName == null && this.tenantDetails.Q4.ConLastName == null && this.currentpage == 3) {
            this.showToast('Error', 'Please Fill Name Field', 'Error', 'Dismissable');
            //this.isNextButtonDisabled = true;
            return;
        } else if (((this.tenantDetails.Q4.ConEmail == '' || this.tenantDetails.Q4.ConEmail == undefined) && (this.tenantDetails.Q4.ConPhone == '' || this.tenantDetails.Q4.ConPhone == undefined)) && this.currentpage == 3) {
            this.showToast('Error', 'Either Email Or Phone must be filled', 'Error', 'Dismissable');

            this.isNextButtonDisabled = true;
            return;
        } else {

        }

        this.currentpage++;

        if (this.currentpage == 2) {
            this.validateInputTwo();
        }

        if (this.currentpage == 3) {
            //this.thirdPageValidation();
            this.fourthPageValidation();
        }

        if (this.currentpage == 4) {
            //this.fourthPageValidation();
            this.thirdPageValidation();
        }

        if (this.currentpage == 5) {
            this.fifthPageValidation();
        }

        if (this.currentpage == 6) {
            this.sixthValidation();
        }

        if (this.currentpage >= 7) {
            this.currentpage = 7;
            this.tillQuestion6 = false;
            this.tillQuestion7 = true;
            //update commit details
            this.commitSelectedComplaintTypes = [];
            this.commitComplaintSummaryDetails = [];

            this.commitSelectedComplaintTypes = this.selectedComplaintTypes;
            this.commitComplaintSummaryDetails = this.complaintSummaryDetails;
        }

        this.getexpression();

        this.commitTenantDetails = JSON.parse(JSON.stringify(this.tenantDetails));
    }

    handlePrevious() {
        this.isNextButtonDisabled = false;
        this.hideAll();
        this.currentpage--;
        if (this.currentpage < 1) {
            this.currentpage = 0;
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    name: 'TenantPage1__c'
                }
            });
        }
        if (this.currentpage == 6) {
            this.tillQuestion6 = true;
            this.tillQuestion7 = false;

            this.agreedCheckbox = false;
            this.captchaResult = false;
            this.captchaValidation();

            //update commit details
            this.selectedComplaintTypes = [];
            this.complaintSummaryDetails = [];

            this.selectedComplaintTypes = this.commitSelectedComplaintTypes;
            this.complaintSummaryDetails = this.commitComplaintSummaryDetails;
            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.isSubmitdisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
                //this.isSubmitdisabled = true;
            }
        }
        this.getexpression();
    }

    hideAll() {
        this.question1 = false;
        this.question2 = false;
        this.question3 = false;
        this.question4 = false;
        this.question5 = false;
        this.question6 = false;
        this.question7 = false;
    }

    getexpression() {
        this.expression1 = this.currentpage == 1 ? true : false;
        this.expression2 = this.currentpage == 2 ? true : false;
        this.expression3 = this.currentpage == 3 ? true : false;
        this.expression4 = this.currentpage == 4 ? true : false;
        this.expression5 = this.currentpage == 5 ? true : false;
        this.expression6 = this.currentpage == 6 ? true : false;
        this.expression7 = this.currentpage == 7 ? true : false;
    }

    handleSubmit() {
        if (this.isSubmitdisabled == false && this.currentpage == 7) {
            this.showSpinner = true;
            /*this.hideAll();
            this.expression7 = false;
            this.tillQuestion7 = false;
            this.pageSubmitted = true;*/

            postTenantFormData({ tenantDet: JSON.stringify(this.commitTenantDetails), areasOfComplaintDetails: JSON.stringify(this.commitComplaintSummaryDetails) })
                .then(result => {
                    // this.contacts = result;
                    // console.log('this.contacts -> ' + this.contacts);
                    console.log('result : ' + result);
                    this.trsCaseReferenceNumber = result;
                    this.error = undefined;

                    this.hideAll();
                    this.expression7 = false;
                    this.tillQuestion7 = false;
                    this.pageSubmitted = true;

                    this.showSpinner = false;
                })
                .catch(error => {
                    this.error = error;
                    // console.log('this.error  ' + this.error);
                    // this.contacts = undefined;
                    this.showSpinner = false;
                });
        }
        else {
            this.showToast('error', 'please agree to terms and conditions', 'error', 'dismissable');
        }
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TenantPage1__c'
            }
        });
    }

    // Function to send the email
    sendEmail() {
        // sendEmail({ toAddress: this.toEmail, subject: this.subject, body: this.message })
        //     .then(() => {
        //         // Show success toast notification
        //         this.showToast('Success', 'Email sent successfully', 'success');
        //         // Clear input fields
        //         this.clearFields();
        //     })
        //     .catch(error => {
        //         // Show error toast notification
        //         this.showToast('Error', 'Failed to send email', 'error');
        //         console.error(error);
        //     });
    }

    handleHome() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    handleChange(event) {
        if (event.target.dataset.name == 'q1') {
            this.tenantDetails.Q1.previewediting = true;
        }
        else if (event.target.dataset.name == 'q2') {
            this.tenantDetails.Q2.previewediting = true;
        }
        else if (event.target.dataset.name == 'q3') {
            this.tenantDetails.Q3.previewediting = true;
        }
        else if (event.target.dataset.name == 'q4') {
            this.tenantDetails.Q4.previewediting = true;
        }
        else if (event.target.dataset.name == 'q5') {
            this.tenantDetails.Q5.previewediting = true;
        }
        else if (event.target.dataset.name == 'q6') {
            this.tenantDetails.Q6.previewediting = true;
        }
    }

    handleSave(event) {
        if (event.target.dataset.name == 'q1Save') {
            this.validateInputFirst();

            this.commitTenantDetails.Q1 = this.tenantDetails.Q1;
            this.tenantDetails.Q1.previewediting = false;
        }
        else if (event.target.dataset.name == 'q2Save') {
            this.validateInputTwo();

            if (this.save2Valid == true) {
                this.commitTenantDetails.Q2 = this.tenantDetails.Q2;
                this.tenantDetails.Q2.previewediting = false;
            } else {
                this.showToast('Error', 'Please select correct values', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q3Save') {
            this.thirdPageValidation();

            if (this.save3Valid == true) {
                this.commitTenantDetails.Q3 = this.tenantDetails.Q3;
                this.tenantDetails.Q3.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct values', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q4Save') {
            this.fourthPageValidation();

            if (this.save4Valid == true) {
                this.commitTenantDetails.Q4 = this.tenantDetails.Q4;
                this.tenantDetails.Q4.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct values', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q5Save') {
            this.fifthPageValidation();

            if (this.save5Valid == true) {
                this.commitTenantDetails.Q5 = this.tenantDetails.Q5;
                this.tenantDetails.Q5.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct values', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q6Save') {
            //this.validateAreasOfComplaintDetailsSubmission();
            //this.sixthValidation();

            if (this.validateAreasOfComplaintDetailsSubmission2()) {
                this.commitTenantDetails.Q6 = this.tenantDetails.Q6;
                this.tenantDetails.Q6.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct values', 'Error', 'Dismissable');
            }
        }
    }

    handleDownArrowClick() {
        this.showAccordion = true;
    }

    handleUpArrowClick() {
        this.showAccordion = false;
    }

    showToast(title, message, variant, mode) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }
}