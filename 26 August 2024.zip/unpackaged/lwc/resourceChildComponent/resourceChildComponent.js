import { LightningElement, api, wire, track } from 'lwc';
import getPdfLink from '@salesforce/apex/KnowledgeArticleController.getPdfLink';
export default class ResourceChildComponent extends LightningElement {

    @api showArticleInfo;
  //  @api callBackend=false;
    articleID;
    showPdfDetail=[];
    @track showTableData = false;
     connectedCallback() {
      console.log('this.showArticleInfo'+ this.showArticleInfo);
      if(this.showArticleInfo!== undefined){
        console.log('inside undefined if');
        this.articleID=this.showArticleInfo[0].Id;
        console.log('this.articleID'+ this.showArticleInfo[0].Id);
 console.log('this.articleID'+ this.articleID);
console.log('this.showArticleInfo'+ JSON.stringify(this.showArticleInfo));
//console.log('# this.callBackend'+this.callBackend);
//if(this.callBackend===true){
getPdfLink({
    articleID: this.articleID
  }).then((data) => {
    console.log('## data '+JSON.stringify(data));
   this.showPdfDetail = Object.keys(data).map(item=>({"label":data[item],
             "value": item,
             "url":item
            }))   
            if(this.showPdfDetail!== undefined && this.showPdfDetail.length>0){
            this.showTableData=true;
            }
  }).catch((error) => {
    console.error(error);
  });
     }
     }
    // }
}