import { LightningElement ,api } from 'lwc';

export default class TdsPlus_ThreeWays extends LightningElement {
    // digit 1
    @api digit1 = '';
    @api subheading1 = '';
    @api description1 = '';
      // digit 2
    @api digit2 = '';
    @api subheading2 = '';
    @api description2 = '';
     // digit 3
    @api digit3 = '';
    @api subheading3 = '';
    @api description3 = '';
     // digit 4
    @api digit4 = '';
    @api subheading4 = '';
    @api description4 = '';
      // digit 5
    @api digit5 = '';
    @api subheading5 = '';
    @api description5 = '';

}