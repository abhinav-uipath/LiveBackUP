import { LightningElement, wire, api, track } from 'lwc';

import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";
import trsSiteHomePageLink from "@salesforce/label/c.TRS_SiteHomePage";

import getArticlesByCategory from '@salesforce/apex/KnowledgeArticleController.getArticlesByCategory';

export default class TRS_ResourceSitePage extends LightningElement {

    label = {
        trsPortalHomePageLink
    };

    trsSiteHomePageBaseUrl = trsSiteHomePageLink;

    @track categories = []; // it shows all data in the list
    @track childData = []; // article data for showing in child component
    @track displayList = []; //list for showing only 2 list data
    @track categoryAllData = []
    @track isTenantSelected = false;
    @track isLandlordSelected = false;
    @track selectedCustomerType = 'Tenant';
    @track activeCategory = '';
    @track searchKey = '';
    @track tenantData = '';
    @track landlordData = '';

    @track activeTabValue = 'tenant';
    @track showChild = false;
    @track articleUrl = '';
    @track showViewAllData = false;

    //Dynamic screen size for mobile
    @api tabs;
    // @track selectedTab;
    tabSetVariant = '';

    connectedCallback() {
        this.setTabSetVariant();
    }

    setTabSetVariant() {
        if (window.innerWidth <= 767) {
            console.log('inside scope variant');
            this.tabSetVariant = 'scope';
        } else {
            console.log('inside vertical variant');
            this.tabSetVariant = 'vertical';
        }
    }

    handleResize() {
        this.setTabSetVariant();
    }

    connectedCallback() {
        this.setTabSetVariant();
        window.addEventListener('resize', this.handleResize.bind(this));
    }

    disconnectedCallback() {
        window.removeEventListener('resize', this.handleResize.bind(this));
    }

    handleSearch(event) {
        this.searchKey = event.target.value.toLowerCase();
        console.log('search --> ' + this.searchKey);
        this.filterArticles();
    }

    filterArticles() {
        this.showViewAllData = true;
        if (this.selectedCustomerType == 'Tenant') {
            this.categories = JSON.parse(JSON.stringify(this.tenantData));
        } else if (this.selectedCustomerType == 'Landlord') {
            this.categories = JSON.parse(JSON.stringify(this.landlordData));
        }

        let catList = this.categories[this.activeCategory].subCategoryList;
        catList = catList.filter(cat => cat.Title.toLowerCase().includes(this.searchKey));

        this.categories[this.activeCategory].subCategoryList = catList;
        // this.categoryAllData = catList;
        // console.log('search list --> ', JSON.stringify(this.categoryAllData));

        if (this.searchKey.length == 0) {
            if (this.selectedCustomerType == 'Tenant') {
                this.categories = JSON.parse(JSON.stringify(this.tenantData));
                this.showViewAllData = false;
            } else if (this.selectedCustomerType == 'Landlord') {
                this.categories = JSON.parse(JSON.stringify(this.landlordData));
                this.showViewAllData = false;
            }
        }
    }

    openArticle(event) {
        const articleId = event.target.dataset.articleId;
        //this.articleUrl = 'https://thedisputeservice--trs.sandbox.my.site.com/TRSSite/s/article/' + articleId;
        this.articleUrl = this.trsSiteHomePageBaseUrl+'article/' + articleId;
        // window.open(articleUrl, '_blank');

        let childList = this.categories[this.activeCategory].subCategoryList;
        this.childData = childList.filter(cat => cat.Id == articleId);

        //console.log('category -> ', JSON.stringify(this.categories));
        this.showChild = true;
    }

    handleCategoryChange(event) {
        // console.log('event ');
        // console.log('this.selectedCustomerType -- ' + this.selectedCustomerType);
        // console.log('cat ', this.categories);
        this.showViewAllData = false;
        this.activeCategory = event.target.value;

        if (this.selectedCustomerType == 'Tenant') {
            this.categories = JSON.parse(JSON.stringify(this.tenantData));

            let displayList = this.categories[this.activeCategory].subCategoryList;
            // console.log('@@ displayList ', displayList);
            this.categoryAllData = displayList.slice(0, 2);
            // console.log('@@ this.categoryAllData tenantttttt -- ', JSON.stringify(this.categoryAllData));
        } else if (this.selectedCustomerType == 'Landlord') {
            this.categories = JSON.parse(JSON.stringify(this.landlordData));

            let displayList = this.categories[this.activeCategory].subCategoryList;
            console.log('## displayList ', displayList);
            this.categoryAllData = displayList.slice(0, 2);
            // console.log('## this.categoryAllData landlorddddd --', JSON.stringify(this.categoryAllData));
        }
    }

    handleTenantClick() {
        // console.log('tenant ');
        this.showViewAllData = false;
        this.isTenantSelected = true;
        this.isLandlordSelected = false;
        this.selectedCustomerType = 'Tenant';
        this.activeTabValue = 'Tenant';
        // this.filterCategories();
        this.categories = JSON.parse(JSON.stringify(this.tenantData));

        let displayList = this.categories[this.activeCategory].subCategoryList;
        console.log('## displayList ', displayList);
        this.categoryAllData = displayList.slice(0, 2);
        // console.log('## this.categoryAllData tenant', JSON.stringify(this.categoryAllData));
        // console.log('## this.categories tenant ', this.categories);
    }

    handleLandlordClick() {
        // console.log('Landlord ');
        this.showViewAllData = false;
        this.isTenantSelected = false;
        this.isLandlordSelected = true;
        this.selectedCustomerType = 'Landlord';
        this.activeTabValue = 'Landlord';
        // this.filterCategories();
        this.categories = JSON.parse(JSON.stringify(this.landlordData));

        let displayList = this.categories[this.activeCategory].subCategoryList;
        // console.log('## displayList ', displayList);
        this.categoryAllData = displayList.slice(0, 2);
        // console.log('## this.categoryAllData landlord', JSON.stringify(this.categoryAllData));
        // console.log('## this.categories land ', this.categories);
    }

    handleViewAll() {
        this.showViewAllData = true;
        if (this.selectedCustomerType == 'Tenant') {
            this.categories = JSON.parse(JSON.stringify(this.tenantData));
        } else if (this.selectedCustomerType == 'Landlord') {
            this.categories = JSON.parse(JSON.stringify(this.landlordData));
        }
    }

    handleBack() {
        this.showChild = false;
    }

    @wire(getArticlesByCategory, { customerType: 'Tenant' })
    wiredCategories({ error, data }) {
        if (data) {
            console.log('inside tenant ', data);
            this.tenantData = JSON.parse(JSON.stringify(data));
            this.categories = JSON.parse(JSON.stringify(data));

            let displayList = this.categories[0].subCategoryList;
            console.log('## displayList ', displayList);
            this.categoryAllData = displayList.slice(0, 2);
            // console.log('## this.categoryAllData ', JSON.stringify(this.categoryAllData));
        } else {
            //console.log('inside ten error ', error);
        }
    }

    @wire(getArticlesByCategory, { customerType: 'Landlord' })
    wiredCategorieslandlord({ error, data }) {
        if (data) {
            console.log('inside landlord ', data);
            this.landlordData = JSON.parse(JSON.stringify(data));
        } else {
            //console.log('inside land error ', error);
        }
    }

}