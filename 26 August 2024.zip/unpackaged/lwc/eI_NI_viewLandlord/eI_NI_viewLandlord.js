import { LightningElement, wire, track, api } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import getLandlordDetails from '@salesforce/apex/EI_NI_ManageProperties.getLandlordDetails';
import myLandlordList from '@salesforce/apex/EI_NI_ManageProperties.myLandlordList';
import saveLandlord from '@salesforce/apex/EI_NI_ManageProperties.saveLandlord';
import archieveLandlord from '@salesforce/apex/EI_NI_ManageProperties.archieveLandlord';
import fetchPropertylist from '@salesforce/apex/EI_NI_ManageProperties.fetchPropertylist';
import searchpropertylist from '@salesforce/apex/EI_NI_ManageProperties.searchpropertylist';
import getPropertyDetails from '@salesforce/apex/EI_NI_ManageProperties.getPropertyDetails';
import updatePropDetails from '@salesforce/apex/EI_NI_ManageProperties.updatePropDetails';
import getPhoneCodePiclistValues from '@salesforce/apex/EI_NI_ManageProperties.getPhoneCodePiclistValues';
import allocationRegistrationStatusList from '@salesforce/apex/EI_NI_ManageProperties.allocationRegistrationStatusList';
import updatePropertyAllocation from '@salesforce/apex/EI_NI_ManageProperties.updatePropertyAllocation';
import createAllocationForLandlord from '@salesforce/apex/EI_NI_ManageProperties.createAllocationForLandlord';
import removeLand from '@salesforce/apex/EI_NI_ManageProperties.removeLand';
import searchLandlord from '@salesforce/apex/EI_NI_ManageProperties.serachlandlord';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import SystemModstamp from '@salesforce/schema/Account.SystemModstamp';
import saveData from '@salesforce/apex/EI_NI_ManageProperties.saveproperty';
import getNIPostCodes from '@salesforce/apex/EI_NI_ManageProperties.getNIPostCodes';
import getManagePropertiesWrapper from '@salesforce/apex/EI_NI_ManageProperties.getManagePropertiesWrapper';
export default class EI_NI_viewLandlord extends LightningElement {

    // attributes
    @track PageSpinner = false;
    @track textareaval = '';
    @track landlordStatus = '';
    @track LandlordListView = [];
    @track totalPagesCountLandlord = 1;
    @track totalRecordsCountLandlord;
    @api PaginationLandlordList = [];
    @track editPage = false;
    @track showViewPage = false;
    @track blankFields = false;
    @track phonelengthError = false;
    @track duplicateRecord = {};// type contact
    @track duplicateEmailError = false;
    @track duplicateNameError = false;
    @track fromParentComp = false;
    @track archivedLandlord = false;
    @track landlord = {}; //type contact
    @track phoneCodePicklist = [];
    @track phoneCodelist = [];
    @track Number_of_Deposits__c = 0;
    @track Total_Deposits__c = 0;
    @track Account_Status__c;
    @track searchTextValue = ''; // to search lanlord
    @track branchId = '';
    @track selPickListValue = 'Active';
    @track landlordRecId = '';
    @track currentPage = 1;
    @track startPage = 0;
    @track endPage = '';
    @track pageSize = 4; // number of records to be displayed per page default 4
    @track totalPagesCount = 1;
    @track saved = false;
    @track isShowModal = false;
    @track statusActive = false;
    @track statusInactive = false;
    @track showPropView = true;
    @track showLandlorddetails = false;
    @track selPropPickListValue = 'Active';
    @track showPropList = true;
    @track propertyList = []; //type property
    @track totalRecordsCountPropList;
    @api PaginationPropList = [];
    @api PaginationPropAllList = [];
    @track propertyAllocationList =[];
    @track LandRegStatuses = [];
    @track propertyStatus = '';
    @track editPropPage = false;
    @track statusPropActive = false;
    @track statusPropInactive = false;
    @track isNewLandLordClick = false;
    @track isNewPropertyClick = true;
    @track goToPropertyPages = false;
    @track showAddProperty = true;
    @track defaultLandlordPhoneCode = '';
    @track replaceLandlord = false;
    @track showEditLandLord = false;
    @api showNextPrimaryLandlordQues = false;
    @api nextPrimaryLandlordName = '';
    @api nextPrimaryLandlordId = '';
    @api property = {};
    @track disableRemove = false;
    editProperty = true;
    isErrorEL = false;
    errorEL = '';
    isSuccessEL = false;
    successEL = '';
    isAddressNotOfNiError
    isShowLandlordDepandAccStatus = false;
    isLandlordReActivateStatus = false;
    isLandlordArchiveStatus = false;
    @track isEndPageNav = false;
    @track isStartPageNav = false;
    @track isStartPage = true;
    @track isEndPage = true;
    isShowDeposits = true;
    //isShowProperties= true;
    isShowProperties = true;
    @track isPropStatusActive = false;
    @track isPropStatusArchive = false;
    showPropertydetails = false;
    isPropShowModal = false;
    isPostcodeErrorAlert = false;
    isemailformatError = false;
    showDataForm = false;
    isShowPropertyLandLordDetails = false;
    isRegStatus = false;
    @track addressDetails;
    @track city;
    @track country;
    @track postalCode;
    @track house;
    @track street;
    @track primary;
    @track reference;
    @track phoneCode;
    @track propertyContactIds = [];
    editedLandlord = {};
    editedAllocation = {};
    isShowcorrespondenceAddress = false;
    primaryL = false;
    primaryLandlordName = '';
    @track isShowListedLandlord = false;
    selectedjointlandlordID = [];
    selectedPrimaryLandlord = [];
    isPrimaryLandlordError = false;
    isFirstNameError = false;
    isSurNameError = false;
    isEmailEmptyError = false;
    isPhoneEmptyError = false;
    isEmailForError = false;
    isPhoneLnthError = false;
    isSuccessupdatedetails = false;
    changePrimaryLLMessage = '';
    searchLandlordString = '';
    presentPrimaryLL = '';
    ischangePrimaryLLMessage = false;
    showCorrespondenceError = false;
    permissionList = [];
    loggedInUser ;
    isAgent= false; // to check if the user is agent or landlord
    isViewProperties = false;
    isManageProperties = false;
    @track profileName;
    niPostCodesList = [];

    // agent not approved
    isStartProtectingAgentInsuredShow= false;
    insuredCheck = false;
    insuredStatus = '';

    openPropetyForm() {
        this.showDataForm = true;

    }
    handlePropertyData(event) {
        console.log('Handle change data:', event.target.value);
        var targetName = event.target.name;
        switch (targetName) {
            case "AddressField":
                this.addressDetails = event.target.value;
                break;
            case "Primary":
                this.primary = event.target.value;
                break;

            case "house":
                this.house = event.target.value;
                break;

            case "street":
                this.street = event.target.value;
                break;

            case "town":
                this.town = event.target.value;
                break;
            case "Country":
                this.country = event.target.value;
                break;

            case "City":
                this.city = event.target.value;
                break;

            case "postalCode":
                this.postalCode = event.target.value;
                break;

        }
    }


    // images
    newspaper_icon = NI_Theme + '/assets/img/newspaper_icon.svg';
    Organisation_icon = NI_Theme + '/assets/img/Organisation_icon.svg';
    edit_icon = NI_Theme + '/assets/img/input-edit_icon.png';
    delete_icon = NI_Theme + '/assets/img/Trash.png';
    warning_icon = NI_Theme + '/assets/img/warning-icon.png';
    view_icon = NI_Theme + '/assets/img/view_icon.png';
    featherEditImg = NI_Theme + '/assets/img/feather-edit_nhos.svg';
    right_Check = NI_Theme + '/assets/img/RIght_Check.png';
    //add_new = NI_Theme +'/assets/img/add-new-property_blue.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    // transfer_icon = TDSTheme + '/assets/img/transfer.svg';
    // cancel_icon = TDSTheme + '/assets/img/Cancel-icon.png';
    cancel_icon = NI_Theme + '/assets/img/Cancel-icon.png';
    constructor() {
        super();

        console.log('My account constructor loaded');
    }

    showPrimary() {
        this.primaryL = true;

    }
    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "landlordYesNoError":
                this.isLandlordYesNo = false;
                break;
            case "successmsg":
                this.isSucceessmessage = false;
                break;
            case "companyName":
                this.isCompanyNameError = false;
                break;
            case "companyPhone":
                this.isCompanyPhoneError = false;
                break;
            case "companyPhonelength":
                this.isCompanyPhonelengthError = false;
                break;
            case "title":
                this.isTitleError = false;
                break;
            case "firstName":
                this.isFirstNameError = false;
                break;
            case "surName":
                this.isSurNameError = false;
                break;
            //    case "emailOfUser":
            //             this.isEmailError=false;
            //    break; 
            //    case "emailFormatErrorMsg":
            //             this.isEmailFormatError=false;
            //    break;
            //    case "mobileEmailError":
            //             this.isMobileEmailError=false;
            //    break;
            case "telephoneNumber":
                this.isTelephoneNumError = false;
                break;

            case "validAddress":
                this.isAddressValidError = false;
                break;
            case "addressNotOfNiErrorMsg":
                this.isAddressNotOfNiError = false;
                break;
            case "duplicateEmail":
                this.isDuplicateEmailError = false;
                break;
            case "phonelength":
                this.phonelengthError = false;
                break;
            case "blankFieldsBtn":
                this.blankFields = false;
                break;
            case "postlcodeErrorAlert":
                this.isPostcodeErrorAlert = false;
                break;
            case "emailformat":
                this.isemailformatError = false;
                break;
            case "firstName":
                this.isFirstNameError = false;
                break;
            case "surName":
                this.isSurNameError = false;
                break;
            case "emailOfUser":
                this.isEmailEmptyError = false;
                break;
            case "telephoneOfUser":
                this.isPhoneEmptyError = false;
                break;
            case "lengthtelephoneOfUser":
                this.isPhoneLnthError = false;
                break;
            case "EmailFormatOfUser":
                this.isEmailForError = false;
                break;
            case "updatesuccmsg":
                this.isSuccessupdatedetails = false;
                break;
            case "showCorrespondenceErrorMsg":
                this.showCorrespondenceError = false;
                break;

        }
    }

    saveData() {
        var propertyData = {
            'Street': this.street,
            'City': this.city,
            'Postcode': this.postalCode,
            'Country': this.country,
            'houseNo': this.house,
            'Town': this.town

        }

        var data = JSON.stringify(propertyData);
        saveData({ receivedParams: data })
            .then(result => {
                console.log('result', result);
            })
            .catch(error => {
                console.log('error', error);
            });

    }

    showPropertyPage(event) {
        this.goToPropertyPages = true;

    }
    /*    handleCancel(){
          
            this.goToPropertyPage = false;
         }*/
    connectedCallback(event) {
        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js'),
            loadScript(this, NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_Theme + '/assets/js/datepicker.js')

        ])
            .then(() => {
                console.log('Theme File loaded');
                //var selPickListValue = 'Active';
                this.getMyProperties();
                this.getMyLandlords(event, selPickListValue);
                console.log('Theme File loaded after getMyLandlords');
            })
            .catch(error => {
                console.log('Error line 47 => ' + JSON.stringify(error));
                console.log('Error line 47 => ' + error);
            });


        // Get Country codes Picklist Values
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const LandlordRecId = urlParams.get('id');

        var branchRecId = urlParams.get('branchRecId');
        if (branchRecId != null && branchRecId != '' && branchRecId != undefined) {
            this.branchId = atob(branchRecId);
        }
        if (LandlordRecId == null || LandlordRecId == undefined || LandlordRecId == "") {
            //  setTimeout(function(){ 
            var selPickListValue = 'Active';
            
        }
        else {
            // this.showViewPage = false;
            getLandlord({ landlordRecId: this.landlordRecId })
            this.showViewPage = false
                .then(result => {
                    if (result != null)
                        
                        this.landlord = result;
                        this.showViewPage = true;
                    
                    this.PageSpinner = false;
                //   console.log('Line==>393--'+JSON.stringify(this.landlord));     

                })
                .catch(error => {

                    console.log('Line 672 Error -> ', error);
                    this.PageSpinner = false;  
                });
                this.PageSpinner = false;
        }

        //Getting roles and permission for current user;
        getManagePropertiesWrapper({branchId : this.branchId})
        .then(result => {
            this.PageSpinner = true;
            this.isViewProperties = true;
            this.isManageProperties = true;
            if(result!= null){
                this.loggedInUser = result[0].userData;
                //alert('2');
                console.log('line 407-->'+JSON.stringify(this.loggedInUser));
                if(this.loggedInUser.User_Type__c=='Agent'){
                    this.isAgent= true;
                    }
                if (this.loggedInUser.Contact.Account.Insured_User__c) {
                    this.insuredCheck = true;
                }
                var custodialCheck= false;
                if (this.loggedInUser.Contact.Account.Custodial_User__c) {
                    custodialCheck = true;
                }
                this.insuredStatus = this.loggedInUser.Contact.Account.Insured_status__c;
                if (this.insuredCheck && !custodialCheck) {

                    if ((this.insuredStatus == 'Pending approval')) {
                        this.isStartProtectingAgentInsuredShow = true;
                    }else{
                        this.isStartProtectingAgentInsuredShow = false;
                    }
                }
                this.permissionList = result[0].permissionList;
                this.profileName = this.loggedInUser.Profile.Name;
                console.log('Line 376 loggedInUser in viewlandlord: '+JSON.stringify(this.loggedInUser));
                console.log('Line 376 permissions in viewlandlord: '+this.permissionList);
                console.log('ProfileName==>'+this.profileName);
                console.log('this.permissionList.length==>'+this.permissionList.length)
                if(this.permissionList.length>0 && this.profileName!='NI_Head_Office_User') {
                   
                    this.setButtonMatrixForBranch(this.permissionList);
                }
                this.PageSpinner = false;
            }               
        })
        .catch(error => {
            console.log('Line 380 Error -> '+error);
            this.PageSpinner = false;
        });

            
            this.PageSpinner = false;
        getNIPostCodes()
        .then(result=>{
            if(result!=null){
                this.niPostCodesList = result;
                console.log('NI Postal Codes list==>'+JSON.stringify(result));
            }
        })
        .catch(error=>{
            console.log('error while fetching NI postal codes==>'+error);
        });

    }
      //Validating Permissions
      setButtonMatrixForBranch(permissionList) {
        this.PageSpinner = true;
        
        console.log('Line 469 - '+permissionList);

        if(permissionList.includes('View properties')){
            this.isViewProperties = true;
        } else {
            this.isViewProperties = false;
        }

        if(permissionList.includes('Manage properties')){
            console.log('Line 446 - ');
            this.isManageProperties = true;
            this.isViewProperties = true;
        } else {
            this.isManageProperties = false;
            if(permissionList.includes('View properties')){
                this.isViewProperties = true;
            } else {
                this.isViewProperties = false;
            }
        }
        
    }
    handleArch(event) {
        this.landlordStatus = event.target.id;
        console.log('ActiveStatus == ' + this.landlordStatus);
        this.updateLanlordStatus();
        this.showHandle = true;
        this.isLandlordArchiveStatus = false;
    }
    handleReactivate(event) {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.landlordStatus = event.target.id;
        this.updateLanlordStatus();
        this.isLandlordReActivateStatus = false;
    }
    archiveStatus() {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.isShowModal = true;
    }
    closeArchived() {
        this.isShowModal = false;
    }
    backHandler() {
        this.goToPropertyPages = false;
    }
    goToPropertyPage(event) {
        //this.PaginationPropList=[];

    }
    PropertyCreationHandler(event) {
        console.log('inside handleLandlordCreated 1');
        var createdContact = event.detail;
       // console.log(JSON.stringify(createdContact));
       
    }

    updateLanlordStatus() {
        this.PageSpinner = true;
        archieveLandlord({ landlordRec: this.landlord, status: this.landlordStatus })
            .then(result => {
                this.PageSpinner = false;
                if (result != null) {
                   // console.log('update Account Status  == ' + JSON.stringify(result));
                    
                    if (result.Account_Status__c == 'Active') {
                        this.statusActive = true;
                    }
                    if (result.Account_Status__c == 'Inactive') {
                        this.statusInactive = true;
                    }
                    this.isShowModal = false;
                }
            })
    }
   
    handleCancle(event) {
        this.editPage = false;

        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;
        this.blankFields = false;
        this.phonelengthError = false;
        this.showCorrespondenceError = false;
        this.isemailformatError = false;
        this.duplicateEmailError = false;
        this.isPostcodeErrorAlert = false;
    }
    statusCheckPick(event) {
       // console.log('line108');
        this.selPickListValue = event.target.value;  
        this.getMyLandlords(event, this.selPickListValue);

    }
    statusPropPick(event) {
        this.selPropPickListValue = event.target.value;

        this.getMyProperties();

    }


    navigateLandlord(event) {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;
        this.blankFields = false;
        this.phonelengthError = false;
        this.showCorrespondenceError = false;
        this.isemailformatError = false;
        this.duplicateEmailError = false;
        this.isPostcodeErrorAlert = false;


       // console.log(' navigateLandlord ');
        this.searchTextValue = '';
        try {
            setTimeout(() => {
                var selPickListValue = 'Active';
                this.getMyLandlords(event, selPickListValue);
            }, 500);

        } catch (error) {
            console.log('getMyLandlords error in navigateLandlord  == ' + JSON.stringify(error));
        }
        console.log(' navigateLandlord 1');
        this.showViewPage = true;
        this.showPropView = false;
        this.showLandlorddetails = false;
        this.editPage = false;
        this.showPropertydetails = false;
        this.showPropList = false;
        this.template.querySelector('[data-id="myLandlord"]').classList.add('active');
       // console.log(' After add active in myLandlord ' + this.template.querySelector('[data-id="myLandlord"]').className);
        this.template.querySelector('[data-id="myProp"]').classList.remove('active');
      //  console.log(' After remove active in myProp ' + this.template.querySelector('[data-id="myProp"]').className);
        this.template.querySelector('[data-id="SelectLandPick"]').selectedIndex = 0;
    }
    navigateMyProp() {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

         this.isStartPage= true;
         this.isStartPageNav = false;
        

        this.getMyProperties();
        this.searchTextValue = '';
        console.log(' navigateMyProp ');
        this.template.querySelector('[data-id="myProp"]').classList.add('active'); 
        this.template.querySelector('[data-id="myLandlord"]').classList.remove('active');
        this.showPropView = true;
        this.showViewPage = false;
        this.editPage = false;
        this.showPropertydetails = false;
        this.showLandlorddetails = false;
        this.showPropList = true;
        this.template.querySelector('[data-id="SelectPropPick"]').selectedIndex = 0;
    }
    handleAddLanlord() {
        this.isNewLandLordClick = true;
    }
    ViewLandlord(event) {
       // console.log('Clicked view/Edit button');
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

       
        var targetId = event.target.dataset.targetId;
       
        this.PageSpinner = true;
        getLandlordDetails({ landlordId: targetId,timestamp: new Date().getTime()})
            .then(result => {
                
                this.showViewPage = false;
                this.showLandlorddetails = true;
                if (result != null)
                    
                    var valz = result.MailingStreet + "\n" + result.MailingCity + "\n" + result.MailingState + "\n" + result.MailingPostalCode + "\n" +
                        result.Correspondence_Street__c + "\n" + result.Correspondence_City__c + "\n" + result.Correspondence_State__c + "\n" + result.Correspondence_Postal_Code__c;
               // console.log('corr Address-->' + result.Correspondence_Street__c + "\n" + result.Correspondence_City__c + "\n" + result.Correspondence_State__c + "\n" + result.Correspondence_Postal_Code__c);

                
              //  console.log('result.Correspondence_Street__c==>'+result.Correspondence_Street__c);
                if (result.Correspondence_Street__c != null || result.Correspondence_City__c != undefined ||
                    result.Correspondence_Postal_Code__c != undefined || result.Correspondence_State__c != undefined) {
                    this.isShowcorrespondenceAddress = true;
                    // console.log('corrAddressShow-------->');
                } else {
                    this.isShowcorrespondenceAddress = false;
                    // console.log('corrAddressHide-------->');

                }

                this.textareaval = valz;
                console.log('line720000:::' + this.textareaval);
                this.landlord = result;
                console.log('Line==602>>'+JSON.stringify(this.landlord));
                if (this.landlord.Number_of_Deposits__c == 0 && this.landlord.Account_Status__c == 'Active') {
                    console.log('archive button show');
                    // this.isShowLandlordDepandAccStatus = true;
                    this.isLandlordArchiveStatus = true;
                    this.isLandlordReActivateStatus = false;
                }
                else {
                    console.log('archive button hide')
                    this.isLandlordArchiveStatus = false;
                    this.isLandlordReActivateStatus = false;

                }
                if (this.landlord.Account_Status__c == 'Inactive') {
                    this.isLandlordArchiveStatus = false;
                    this.isLandlordReActivateStatus = true;
                }
                this.landlordStatus = this.landlord.Account_Status__c;
                // this.fetchPhoneCodePicklist();
                this.PageSpinner = false;
            })
    }
    navigationHandle(event) {
        event.preventDefault();
        
        var sObjectList = this.propertyList;
        var sObjectList = this.LandlordListView;
        var sObjectList = this.propertyAllocationList;
        var pageSize = Number(this.pageSize);
        var start = this.startPage;
        var end = this.endPage;
        console.log('navigationHandle ===' + event.target.dataset.id);
        var navigate = event.target.dataset.id;
        if (navigate == 'propNextId') {
            var sObjectList = this.propertyList;
            var listName = 'prop';
            console.log('navigationHandle in  propNextId');
            console.log('navigationHandle in  propNextId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage + 1;
            this.next(listName, sObjectList, end, start, pageSize);
        }
        else if (navigate == 'propPreviousId') {
            var sObjectList = this.propertyList;
            var listName = 'prop';
            console.log('navigationHandle in  propPreviousId');
            this.currentPage = this.currentPage - 1;
            this.previous(listName, sObjectList, end, start, pageSize);
        }
        else if (navigate == 'landNextId') {
            var sObjectList = this.LandlordListView;
            var listName = 'land';
            console.log('navigationHandle in  landNextId');
            console.log('navigationHandle in  landNextId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage + 1;
            this.next(listName, sObjectList, end, start, pageSize);
        }
        else if (navigate == 'landPreviousId') {
            var sObjectList = this.LandlordListView;
            var listName = 'land';
            console.log('navigationHandle in  landPreviousId');
            console.log('navigationHandle in  landPreviousId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage - 1;
            this.previous(listName, sObjectList, end, start, pageSize);
        }
       else if (navigate == 'landNextId1') {
            var sObjectList = this.property.Property_Allocations__r;
            var listName = 'landAloc';
            console.log('navigationHandle in  landNextId');
            console.log('navigationHandle in  landNextId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage + 1;
            this.next(listName, sObjectList, end, start, pageSize);
        }
        else if (navigate == 'landPreviousId1') {
            var sObjectList = this.property.Property_Allocations__r;
            var listName = 'landAloc';
            console.log('navigationHandle in  landPreviousId1');
            console.log('navigationHandle in  landPreviousId sObjectList' + JSON.stringify(sObjectList));
            this.currentPage = this.currentPage - 1;
            this.previous(listName, sObjectList, end, start, pageSize);
        }
    }
    next(listName, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for (var i = end + 1; i < end + pageSize + 1; i++) {
            if (sObjectList.length > i) {
                Paginationlist.push(sObjectList[i]);

            }
            counter++;
        }
        this.PageSpinner = false;
        start = start + counter;
        end = end + counter;
        this.startPage = start;
        this.endPage = end;
        if (listName == 'prop') {
            this.PaginationPropList = Paginationlist;
        }
        else if (listName == 'land') {
            this.PaginationLandlordList = Paginationlist;
        }
        else if (listName == 'landAloc') {
            this.PaginationPropAllList = Paginationlist;
        }

        if (this.currentPage == 1) {
            this.isStartPage = true;
            this.isStartPageNav = false;
        } else {
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if (this.currentPage == this.totalPagesCount) {
            this.isEndPage = true;
            this.isEndPageNav = false;
        } else {
            this.isEndPage = false;
            this.isEndPageNav = true;
        }
        
    }
    // navigate to previous pagination record set   
    previous(listName, sObjectList, end, start, pageSize) {
        var Paginationlist = [];
        var counter = 0;
        this.PageSpinner = true;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {

                Paginationlist.push(sObjectList[i]);
                counter++;
            } else {
                start++;
            }
        }
        this.PageSpinner = false;
        start = start - counter;
        end = end - counter;
        this.startPage = start;
        this.endPage = end;
        if (listName == 'prop') {
            this.PaginationPropList = Paginationlist;
        }
        else if (listName == 'land') {
            this.PaginationLandlordList = Paginationlist;
        }
        else if (listName == 'landAloc') {
            this.PaginationPropAllList = Paginationlist;
        }

        if (this.currentPage == 1) {
            this.isStartPage = true;
            this.isStartPageNav = false;
        } else {
            this.isStartPage = false;
            this.isStartPageNav = true;
        }

        if (this.currentPage == this.totalPagesCount) {
            this.isEndPage = true;
            this.isEndPageNav = false;
        } else {
            this.isEndPage = false;
            this.isEndPageNav = true;
        }
        // component.set("v.startPage",start);
        // component.set("v.endPage",end);
        // component.set('v.PaginationList', Paginationlist);
    }
    handleLandlordCreated(event) {
        console.log('inside handleLandlordCreated 1');
        var createdContact = event.detail.landLordCreated;
        var calledfrom = event.detail.calledfrom;
        this.PaginationLandlordList = [];
        this.PaginationLandlordList.push(createdContact);
        console.log(this.PaginationLandlordList);
        this.propertyContactIds=[];
        this.propertyAllocationList = [];
        this.PaginationPropAllList = [];
        if (calledfrom == 'viewLandlordForProperty') {

            createAllocationForLandlord({ proprtyId: this.property.Id, landlordId: createdContact.Id })
                .then(result => {
                    console.log('response==' + JSON.stringify(result));
                    console.log('responseLength==' + result.length);
                    this.property.Property_Allocations__r = result;
                    var landlordList = []
                    landlordList = result;
                    if (this.property.Property_Allocations__r.length > 1) {
                        this.disableRemove = false;
                    } else{
                        this.disableRemove = true;
                    }
                    this.nextPrimaryLandlordName = '';
                    this.presentPrimaryLL = '';
                    for (const obj of this.property.Property_Allocations__r) {
                        console.log("msgFrom", obj);
                        console.log("msgBody", obj.Relation_to_Property__c);
                        
                        if (obj.Relation_to_Property__c == 'Joint Landlord' && this.nextPrimaryLandlordName == '') {
                            this.nextPrimaryLandlordId = obj.Contact__c;
                            this.nextPrimaryLandlordName = obj.Contact__r.Name;
                        }
                        if (obj.Relation_to_Property__c == 'Primary Landlord' && this.presentPrimaryLL == '') {
                            this.presentPrimaryLL = obj.Id;

                        }
                        if (this.presentPrimaryLL != '' && this.nextPrimaryLandlordName != '') {
                            break;
                        }
                        

                    }
                    for(const proAll of landlordList){
                        if(proAll.Contact__c){
                            this.propertyContactIds.push(proAll.Contact__c);
                        }
                        this.propertyAllocationList.push(proAll);

                    }
                   
                    console.log('inside updateLandlordData 21');
                    this.isMainPageError = false;
                    this.isMainPageSuccess = false;
                    this.MainPageErrorMsg = '';
                    this.MainPageSuccessMsg = '';
                    console.log('afterAddingJointLandlords=List=>'+this.propertyContactIds);

                    console.log('afterAddAlandlordUpdatedList==>'+JSON.stringify(this.propertyAllocationList));
                     this.PaginationPropAllList = this.propertyAllocationList;
                })
                .catch(error => {
                    this.isMainPageError = true;
                    this.isMainPageSuccess = false;
                    this.MainPageErrorMsg = 'unknow error occured contact system administrator';
                    this.MainPageSuccessMsg = '';
                    console.log('Error -> ', error);
                })
        }
    }
    getMyLandlords(event, selPickListValue) {
        this.PageSpinner = true;

        this.isStartPage= true;
        this.isStartPageNav = false;

        this.searchTextValue = this.template.querySelector("[data-id='searchValue']").value;
        if (this.searchTextValue == null || this.searchTextValue == undefined) {
            this.searchTextValue = '';
        }
        console.log('line157');

        console.log('this.searchTextValue==' + this.searchTextValue);
        console.log('this.selPickListValue==' + this.selPickListValue);
        console.log('this.branchId==' + this.branchId);

        myLandlordList({ searchVar: this.searchTextValue, status: selPickListValue, branchId: this.branchId })
            .then(result => {
                this.PageSpinner = false;
               // this.searchTextValue = '';
                console.log('Success====' + JSON.stringify(result));
                if (result != null) {
                    if (result == '') {
                        this.currentPage = 1;
                    }
                    else {
                        this.currentPage = 1;
                    }
                    this.LandlordListView = result;
                    var pageSize = this.pageSize;
                    var totalRecordsList = result;
                    var totalLength = totalRecordsList.length;
                    console.log('totalLength ' + totalLength);
                    console.log('totalDeposites' + this.landlord.Total_Deposits__c);
                    this.totalRecordsCountLandlord = totalLength;
                    this.startPage = 0;
                    this.endPage = pageSize - 1;
                    var PaginationLandlordList = [];
                    for (var i = 0; i < pageSize; i++) {
                        if ((this.LandlordListView).length > i) {
                            PaginationLandlordList.push(this.LandlordListView[i]);
                        }
                    }
                    this.PaginationLandlordList = PaginationLandlordList;
                    console.log('PaginationLandlordList====' + JSON.stringify(this.PaginationLandlordList));
                    // this.selectedCount = 0;
                    this.totalPagesCount = Math.ceil(totalLength / pageSize);
                    console.log('totalPagesCount === ' + Math.ceil(totalLength / pageSize));
                    console.log('this.isEndPageNav before====' + this.isEndPageNav);
                    if (this.totalPagesCount > 1) {
                        this.isEndPageNav = true;
                        this.isEndPage = false;
                    }
                    else {
                        this.isEndPage = true;
                        this.isEndPageNav = false;
                    }
                    console.log('this.isEndPageNav after ====' + this.isEndPageNav)
                   
                }

                
             
            })
            .catch(error => {
                this.PageSpinner = false;
                console.log('Line 169 Error -> ', error);

            })
        console.log('Line172');
    }

    replacePrimaryLandlord() {
        console.log('replaceLandlord');
        this.replaceLandlord = true;
    }
    handleSuccess() {
        this.replaceLandlord = false;
    }
    handleSubmit() {
        //this.replaceLandlord=false;
    }
    hideReplaceLandlord() {
        this.replaceLandlord = false;
    }

    editAllocation(event) {

        this.isSuccessupdatedetails = false;
        this.isFirstNameError = false;
        this.isSurNameError = false;
        this.isEmailEmptyError = false;
        this.isPhoneEmptyError = false;
        this.isPhoneLnthError = false;
        this.isEmailForError = false;

        console.log('Clicked editLandLord button');
        this.showEditLandLord = true;
        var targetId = event.target.dataset.targetId;
        console.log('propertyRecId == ' + targetId);
        var PropAllocations = this.property.Property_Allocations__r;
        this.selectedallocation = PropAllocations.find((obj) => {
            return (obj.Id === targetId);
        });

        // eslint-disable-next-line no-console
        console.log(JSON.stringify(this.selectedallocation));

        this.fetchPhoneCodePicklist();
        this.StatusPicklist();
        this.showEditLandLord = true;
    }

    ClickedNo(event) {
        this.replaceLandlord = true;
        this.showNextPrimaryLandlordQues = false;
    }


    removeLandlord(event) {
        console.log('Clicked removeLandLord button');
        var targetId = event.target.dataset.targetId;
        console.log('propertyRecId == ' + targetId);
       // var PropAllocations = this.property.Property_Allocations__r;
       var PropAllocations = this.PaginationPropAllList;
        if (this.showNextPrimaryLandlordQues == false) {
            this.selectedallocation = PropAllocations.find((obj) => {
                return (obj.Id === targetId);
            });
        }

        // eslint-disable-next-line no-console
        console.log(JSON.stringify(this.selectedallocation));




        var relation = this.selectedallocation.Relation_to_Property__c;
        var jointLandlordId;
        var landlordRec;
        console.log(relation);
        var executeApexPrimary = false;
        if (relation == 'Primary Landlord' && this.showNextPrimaryLandlordQues == false) {
            this.showNextPrimaryLandlordQues = true;
            for (const obj of PropAllocations) {
                //this.property.Property_Allocations__r.forEach((obj, i) => {

                console.log("msgFrom", obj);
                console.log("msgBody", obj.Relation_to_Property__c);
                if (obj.Relation_to_Property__c == 'Joint Landlord') {
                    this.nextPrimaryLandlordId = obj.Contact__c;
                    this.nextPrimaryLandlordName = obj.Contact__r.Name;
                    break;
                }

                //});
            }

        }
        else if (relation == 'Primary Landlord' && this.showNextPrimaryLandlordQues == true) {
            console.log('inside showNextPrimaryLandlordQues true');
            executeApexPrimary = true;
            jointLandlordId = targetId;
            landlordRec = this.selectedallocation.Id;
            //removeAllocation();
        }
        else if (relation == 'Joint Landlord') {
            jointLandlordId = null;
            landlordRec = targetId;
            //removeAllocation();
        }
        console.log(jointLandlordId);
        console.log(landlordRec);
        console.log(this.showNextPrimaryLandlordQues);
        console.log(this.nextPrimaryLandlordId);
        if (relation == 'Joint Landlord' || (relation == 'Primary Landlord' && this.showNextPrimaryLandlordQues == true && executeApexPrimary == true)) {
            console.log('inside apex callout');
            removeLand({
                propAllocationid: landlordRec,
                relation: relation,
                jointLandlordId: jointLandlordId
            }).then(result => {
                console.log('fetchPropertylist====' + JSON.stringify(result));
                if (result == null || result == undefined) {
                    console.log('undefined');
                    this.showNextPrimaryLandlordQues = false;
                    this.nextPrimaryLandlordId = '';
                    this.nextPrimaryLandlordName = '';
                    this.isMainPageError = true;
                    this.MainPageErrorMsg = 'error occured in apex callout';
                }
                else {
                    console.log('fetchPropertylist====' + JSON.stringify(result));
                   // this.property.Property_Allocations__r = result;
                        this.PaginationPropAllList = result;
                    if (this.PaginationPropAllList.length > 1) {
                        this.disableRemove = false;
                    } else
                        this.disableRemove = true;
                    this.nextPrimaryLandlordName = '';
                    this.presentPrimaryLL = '';
                    for (const obj of this.PaginationPropAllList) {
                        console.log("msgFrom", obj);
                        console.log("msgBody", obj.Relation_to_Property__c);
                        if (obj.Relation_to_Property__c == 'Joint Landlord' && this.nextPrimaryLandlordName == '') {
                            this.nextPrimaryLandlordId = obj.Contact__c;
                            this.nextPrimaryLandlordName = obj.Contact__r.Name;
                        }
                        if (obj.Relation_to_Property__c == 'Primary Landlord' && this.presentPrimaryLL == '') {
                            this.presentPrimaryLL = obj.Id;

                        }
                        if (this.presentPrimaryLL != '' && this.nextPrimaryLandlordName != '') {
                            break;
                        }

                    }
                    this.showNextPrimaryLandlordQues = false;
                    this.nextPrimaryLandlordId = '';
                    this.nextPrimaryLandlordName = '';
                    this.replaceLandlord = false;
                    this.isMainPageError = false;
                    this.MainPageErrorMsg = '';
                }


            })

                .catch(error => {
                    console.log('fetchPropertylist error ' + JSON.stringify(error));
                    this.showNextPrimaryLandlordQues = false;
                    this.nextPrimaryLandlord = '';
                    this.isMainPageError = true;
                    this.MainPageErrorMsg = 'error occured in apex callout';
                })
        }


    }


    getMyProperties() {
        this.PageSpinner = true;
        fetchPropertylist({ status: this.selPropPickListValue, branchId: this.branchId })
            .then(result => {
                this.PageSpinner = false;
                console.log('fetchPropertylist====' + JSON.stringify(result));
                console.log('fetchPropertylistSize====' + result.length);
                if (result != null) {
                    if (result == '') {
                        this.currentPage = 1;
                    }
                    else {
                        this.currentPage = 1;
                    }
                    this.propertyList = result;
                    console.log('propertyList111====' + JSON.stringify(this.propertyList));
                    var pageSize = this.pageSize;
                    var totalRecordsList = result;
                    var totalLength = totalRecordsList.length;
                    this.totalRecordsCountPropList = totalLength;
                    this.startPage = 0;
                    this.endPage = pageSize - 1;
                    var PaginationPropList = [];
                    for (var i = 0; i < pageSize; i++) {
                        if ((this.propertyList).length > i) {
                            PaginationPropList.push(this.propertyList[i]);
                        }
                    }
                    this.PaginationPropList = PaginationPropList;
                    console.log('fetchPropertylist====' + JSON.stringify(this.PaginationPropList));
                    this.totalPagesCount = Math.ceil(totalLength / pageSize);
                    if (this.totalPagesCount > 1) {
                        this.isEndPageNav = true;
                        this.isEndPage = false;
                    }
                    else {
                        this.isEndPage = true;
                        this.isEndPageNav = false;
                    }
                    console.log('line 1228');
                }
                this.selPropPickListValue = 'Active';
                console.log('line 1230');
            })

            .catch(error => {
                console.log('fetchPropertylist error ' + JSON.stringify(error));

            })
    }
    getMySearchProperties() {
        console.log('getMySearchProperties');
        this.searchTextValue = this.template.querySelector("[data-id='searchPropValue']").value.trim();
        //var searchTextValue = this.template.querySelector("[data-id='searchPropValue']").value;
        console.log('searchPropValue == ' + this.searchTextValue);
        console.log('selPropPickListValue == ' + this.selPropPickListValue);
        this.PageSpinner = true;
        this.editPropPage = false;
        searchpropertylist({ searchtext: this.searchTextValue, status: this.selPropPickListValue })
            .then(result => {
                this.PageSpinner = false;
               // this.searchTextValue = '';
                console.log('property Search List====' + JSON.stringify(result));
                if (result != null) {
                    if (result == '') {
                        this.currentPage = 1;
                    }
                    else {
                        this.currentPage = 1;
                    }
                    this.propertyList = result;
                    var pageSize = this.pageSize;
                    var totalRecordsList = result;
                    var totalLength = totalRecordsList.length;
                    this.totalRecordsCountPropList = totalLength;
                    this.startPage = 0;
                    this.endPage = pageSize - 1;
                    var PaginationPropList = [];
                    for (var i = 0; i < pageSize; i++) {
                        if ((this.propertyList).length > i) {
                            PaginationPropList.push(this.propertyList[i]);
                        }
                    }
                    this.PaginationPropList = PaginationPropList;
                    this.totalPagesCount = Math.ceil(totalLength / pageSize);
                    if (this.totalPagesCount > 1) {
                        this.isEndPageNav = true;
                        this.isEndPage = false;
                    }
                    else {
                        this.isEndPage = true;
                        this.isEndPageNav = false;
                    }
                }
            })
            .catch(error => {
                console.log('Line 169 Error -> ', error);

            })

    }
    ViewProperty(event) {
        console.log('Clicked view/Edit button');

        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.isStartPage = true;
        this.isStartPageNav = false;

        var targetId = event.target.dataset.targetId;
        console.log('propertyRecId == ' + targetId);
        this.editPropPage = false;
        this.PageSpinner = true;
        this.replaceLandlord= false;
        getPropertyDetails({ propertyId: targetId })
            .then(result => {
                this.showPropView = false;
                this.PageSpinner = false;
                console.log('view/Edit button Result getPropDetails == ' + JSON.stringify(result));
                this.showViewPage = false;
                this.showPropertydetails = true;
                if (result != null)
                    this.property = result;
                console.log('this.property.Property_status__c = ' + this.property.Property_status__c);
                if (this.property.NoOfDeposit__c == 0 && this.property.Property_status__c == 'Active') {
                    //if(this.property.Property_status__c == 'Active'){
                    this.isPropStatusActive = true;
                    this.isPropStatusArchive = false;
                    console.log('In side isPropStatusActive');

                  
                }
                else {
                    this.isPropStatusActive = false;
                    this.isPropStatusArchive = false;
                }
                if (this.property.Property_status__c == 'Inactive') {
                    this.isPropStatusArchive = true;
                    this.isPropStatusActive = false;
                    console.log('In side isPropStatusArchive');
                }
                this.propertyStatus = this.property.Property_status__c;
                if (this.property != undefined && this.property.Property_Allocations__r != undefined && this.property.Property_Allocations__r.length > 0) {

                    this.isShowPropertyLandLordDetails = true;
                    if (this.property.Property_Allocations__r.length > 1) {
                        this.disableRemove = false;
                    } else
                        this.disableRemove = true;
                    this.nextPrimaryLandlordName = '';
                    this.presentPrimaryLL = '';
                    for (const obj of this.property.Property_Allocations__r) {
                        console.log("msgFrom", obj);
                        console.log("msgBody", obj.Relation_to_Property__c);
                        if (obj.Relation_to_Property__c == 'Joint Landlord' && this.nextPrimaryLandlordName == '') {
                            this.nextPrimaryLandlordId = obj.Contact__c;
                            this.nextPrimaryLandlordName = obj.Contact__r.Name;
                        }
                        if (obj.Relation_to_Property__c == 'Primary Landlord' && this.presentPrimaryLL == '') {
                            this.presentPrimaryLL = obj.Id;

                        }
                        if (this.presentPrimaryLL != '' && this.nextPrimaryLandlordName != '') {
                            break;
                        }

                    }
                    
                    this.currentPage = 1;
                    var pageSize = this.pageSize;
                    var totalRecordsList = this.property.Property_Allocations__r;
                    var totalLength = totalRecordsList.length;
                    console.log('total alloc length' + totalLength);
                    this.totalRecordsCountPropList = totalLength;
                    this.startPage = 0;
                    this.endPage = pageSize - 1;
                    var PaginationPropAllList = [];
                    var propertyAllocationList = [];
                    for (var i = 0; i < pageSize; i++) {
                        if ((this.property.Property_Allocations__r).length > i) {
                            propertyAllocationList.push(this.property.Property_Allocations__r[i]);
                        }
                    }
                    this.propertyAllocationList = propertyAllocationList;
                    this.PaginationPropAllList = propertyAllocationList;
                    this.totalPagesCount = Math.ceil(totalLength / pageSize);
                    if (this.totalPagesCount > 1) {
                        this.isEndPageNav = true;
                        this.isEndPage = false;
                    }
                    else {
                        this.isEndPage = true;
                        this.isEndPageNav = false;
                    }
                    //  }


                }
                this.propertyContactIds = [];

                // Extract and store Contact__c IDs associated with each property
                if (this.property.Property_Allocations__r && this.property.Property_Allocations__r.length > 0) {
                    this.propertyContactIds = this.property.Property_Allocations__r.map(item => item.Contact__c);
                }
                console.log('PropAllocationsContctIds==>'+JSON.stringify(this.propertyContactIds));
            })
    }



    handleLandlordClick(event) {
        this.getMyLandlords(event, this.selPickListValue);
    }
    handleLandlordSearch(event) {
        if (event.keyCode === 13) {
            this.getMyLandlords(event, this.selPickListValue);
        }
    }
    handlePropClick() {
        console.log('handlePropClick');
        //this.editPropPage = false;
        this.getMySearchProperties();
    }
    enterclickhandler(event) {
        if (event.keyCode === 13) {
            console.log('enter pressed');
            this.getMySearchProperties();
        }
    }
    handleEditLandlord() {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.fetchPhoneCodePicklist();
        this.editPage = true;
        console.log('editPage2===' + this.editPage);

    }
    handleLandlordPhoneChange() {
        console.log('handleLandlordPhoneChange');
        console.log('handleLandlordPhoneChange == ' + this.template.querySelector('[data-id="phoneLandlordCode"]').value);
        console.log('Sele == ' + this.template.querySelector('[data-id="phoneLandlordCode"]').value);
    }
    handleEditProperty() {
        console.log('In side handleEditProperty');
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.editPropPage = true;
        this.editProperty = false;
    }
    archivePropStatus() {
        //update Property Status as Inactive
    }
    fetchPhoneCodePicklist() {
        getPhoneCodePiclistValues()
            .then(result => {
                if (result) {
                    //this.result = result;
                    this.phoneCodePicklist = result;
                    for (var eachCode in result) {
                        if (this.landlord.Phone_Code__c != undefined && result[eachCode] == this.landlord.Phone_Code__c) {
                            this.phoneCodelist.push({ key: result[eachCode], value: true });
                        }
                        else {
                            this.phoneCodelist.push({ key: result[eachCode], value: false });
                        }
                    }
                }
                console.log('Success');

            })
            .catch(error => {
                console.log('Error -> ', error);
            })
    }

    handlePostCode(event) {
        console.log('Postcode:::', event.target.value.toLowerCase());
        this.template.querySelector('[data-id="postlCode"]').value = event.target.value.toUpperCase();
        let postCode = event.target.value.toUpperCase();
        let postcodeParts = postCode.split(' ');
        if (postCode != null && postCode != '' && postCode != undefined) {
            const postCodeExists = this.niPostCodesList.some(item => {
                return postCode.startsWith(item.Label.toUpperCase());
            });
            if (postCodeExists) {
                this.isShowcorrespondenceAddress = false;
                this.showCorrespondenceError = false;
            } else {
                this.isShowcorrespondenceAddress = true;
                this.showCorrespondenceError = true;
            }
        }
    }

    handleCorrPostcode(event) {
        var corrPostcode = event.target.value.toUpperCase();
        let postcodeParts = corrPostcode.split(' ');
        this.template.querySelector('[data-id="corrpostlCode"]').value = event.target.value.toUpperCase();
        if (this.isShowcorrespondenceAddress) {
            // if (!corrPostcode.includes('bt')) {
            //     this.showCorrespondenceError = true;
            // } else if (corrPostcode.includes('bt')) {
            //     this.showCorrespondenceError = false;
            // }
            //const postCodeExists = this.niPostCodesList.some(item => item.Label.toUpperCase() === postcodeParts[0]);

            const postCodeExists = this.niPostCodesList.some(item => {
                return corrPostcode.startsWith(item.Label.toUpperCase());
            });
            if (postCodeExists) {
               // this.isShowcorrespondenceAddress = false;
                this.showCorrespondenceError = false;
            } else {
                //this.isShowcorrespondenceAddress = true;
                this.showCorrespondenceError = true;
            }
        }
    }

    handleSave(event) {
        try {
            //this.PageSpinner = true;
            this.saved = false;
            this.statusPropActive = false;
            this.statusPropInactive = false;
            this.statusActive = false;
            this.statusInactive = false;
            
            console.log(' handleSave Clicked');
            this.blankFields = false;
            this.phonelengthError = false;
            this.duplicateEmailError = false;
            var street = this.template.querySelector('[data-id="street"]').value;
            console.log('street -> ', street);
            var city = this.template.querySelector('[data-id="city"]').value;
            console.log('city -> ', city);
            var postlCode = this.template.querySelector('[data-id="postlCode"]').value;
            console.log('postlCode -> ', postlCode);
            var email = this.template.querySelector('[data-id=email]').value;
            console.log('email -> ', email);


            console.log('testttttt---->');
            if (this.isShowcorrespondenceAddress == true) {
                var corrStreet = this.template.querySelector('[data-id="corrstreet"]').value;
                var corrCity = this.template.querySelector('[data-id="corrcity"]').value;
                var corrPostalcode = this.template.querySelector('[data-id="corrpostlCode"]').value.toUpperCase();
            } else {
                corrStreet = '';
                corrCity = '';
                corrPostalcode = '';
            }


            console.log('corrStreet -> ', corrStreet);



            console.log('corrcity -> ', corrCity);

            var phoneCode = this.template.querySelector('[data-id="phoneLandlordCode"]').value;
            var phone = this.template.querySelector('[data-id="phone"]').value;
            console.log('phone -> ', phone);
            var reference = this.template.querySelector('[data-id="reference"]').value;
            console.log('reference->', reference);
            var conRec = this.landlord;
            console.log('Before Update Landlord -> ', JSON.stringify(conRec));
            const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            let postcodeParts = corrPostalcode.split(' ');
            //const postCodeExists = this.niPostCodesList.some(item => item.Label.toUpperCase() === postcodeParts[0]);
            const postCodeExists = this.niPostCodesList.some(item => {
                return corrPostalcode.startsWith(item.Label.toUpperCase());
            });
            if (street == '' || city == '' || postlCode == '' || email == '' || phone == '') {

                console.log('Invalid ');
                this.blankFields = true;

                // console.log('Invalid '+ component.get("v.blankFields"));phoneCode == "+44" && (
            } else if (phoneCode == '+44' && phone.length != 11) {
                this.phonelengthError = true;
                console.log('Invalid phonelengthError ' + this.phonelengthError);
            } else if (!email.match(EMAIL_REGEX)) {
                this.isemailformatError = true;
            } else if (this.isShowcorrespondenceAddress && (corrStreet == '' || corrCity == '' || corrPostalcode == '')) {
                this.blankFields = true;
            } else if (this.isShowcorrespondenceAddress && !postCodeExists) {
                this.showCorrespondenceError = true;
            } else {
                console.log('valid');
                console.log('corrStreet' + corrStreet);

                saveLandlord({
                    landlordRec: conRec, street: street, city: city, postalCode: postlCode, email: email, phoneCode: phoneCode, phone: phone, reference: reference,
                    corrStreet: corrStreet, corrCity: corrCity, corrPostalcode: corrPostalcode
                })
                    .then(response => {
                        this.PageSpinner = false;
                        console.log('response==' + JSON.stringify(response));
                        this.editPage = false;
                        var result = response;
                        console.log('result for save ' + JSON.stringify(result));
                        var duplicateValue = [];
                        for (var key in result) {
                            duplicateValue.push({ val: result[key], key: key });
                        }
                        var key = duplicateValue[0].key;
                        var recValue = duplicateValue[0].val;

                        if (key == "Duplicate Email") {
                            this.duplicateEmailError = true;
                        }
                        else if (key == "Duplicate Name") {
                            this.duplicateNameError = true;
                            this.duplicateRecord = recValue;
                        }
                        else {
                            this.saved = true;
                            this.landlord = recValue;
                            this.editPage = false;

                        }
                    });
            }
        } catch (error) {
            console.log('Error', error);

        }
    }
    // ******************************

    handlePropUpdate() {
        this.PageSpinner = false;

       
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        console.log(' handleSave Clicked');
        this.blankFields = false;
        this.phonelengthError = false;
        this.duplicateEmailError = false;
        var street = this.template.querySelector('[data-id="propStreet"]').value;
        console.log('street -> ', street);
        var town = this.template.querySelector('[data-id="propTown"]').value;
        console.log('town -> ', town);
        var county = this.template.querySelector('[data-id="propCounty"]').value;
        console.log('county -> ', county);
        // var noOfDeposits = this.template.querySelector('[data-id="propDeposits"]').value;
        // console.log('noOfDeposits -> ',noOfDeposits);"NoOfDeposit__c":noOfDeposits,
        var postlCode = this.template.querySelector('[data-id="propPostlCode"]').value.toUpperCase();
        console.log('postlCode -> ', postlCode);
        var houseNo = this.template.querySelector('[data-id="propHno"]').value;
        var prop = this.property;
        var updateProp = { "Id": prop.Id, "County__c": county, "Street__c": street, "Postal_Code__c": postlCode, "Town__c": town, "House_No__c": houseNo };
        let postcodeParts = postlCode.split(' ');
      //  const postCodeExists = this.niPostCodesList.some(item => item.Label.toUpperCase() === postcodeParts[0]);
            const postCodeExists = this.niPostCodesList.some(item => {
                return postlCode.startsWith(item.Label.toUpperCase());
            });
        console.log('Before Update updateProp -> ', JSON.stringify(updateProp));

        if (street == '' || houseNo == '' || town == '' || postlCode == '' || county == '' || postlCode == '') {
            console.log('Invalid ');
            this.blankFields = true;
            // console.log('Invalid '+ component.get("v.blankFields"));
        }
        else if (!postCodeExists) {
            this.isPostcodeErrorAlert = true

        }

        else {
            console.log('valid');
            updatePropDetails({ updtProperty: updateProp })
                .then(response => {
                    console.log('response==' + JSON.stringify(response));
                    this.PageSpinner = false;
                    this.editPropPage = false;
                    this.saved = true;
                    this.editProperty = true;
                    this.property = response;
                    if (this.property.Property_Allocations__r.length > 1) {
                        this.disableRemove = false;
                    } else
                        this.disableRemove = true;

                })
                .catch(error => {
                    console.log('Error -> ', error);
                })
        }

    }
    handlePropCancle() {
        this.editPropPage = false;
        this.editProperty = true;
    }
    handlePropStatusUpdate(event) {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.isPropStatusArchive = false;
        var targetStatus = event.target.dataset.targetStatus;
        console.log('Property Status change to ', targetStatus);
        var prop = this.property;
        var updateProp = { "Id": prop.Id, "Property_status__c": targetStatus };
        updatePropDetails({ updtProperty: updateProp })
            .then(response => {
                console.log('response==' + JSON.stringify(response));
                this.PageSpinner = false;
                this.property = response;
                /*if(this.property.Property_Allocations__r.length>1){
                    this.disableRemove= false;
                }else */
                this.disableRemove = true;
                this.isPropShowModal = false;
                this.isPropStatusActive = false;
                if (this.property.Property_status__c == 'Active') {
                    this.statusPropActive = true;
                }
                else if (this.property.Property_status__c == 'Inactive') {
                    this.statusPropInactive = true;
                }

            })
            .catch(error => {
                console.log('Error -> ', error);
            })
    }
    handlePropArchive() {
        this.saved = false;
        this.statusPropActive = false;
        this.statusPropInactive = false;
        this.statusActive = false;
        this.statusInactive = false;

        this.isPropShowModal = true;
    }
    closePropArchived() {
        this.isPropShowModal = false;
    }
    /////////////////////////
    refreshLandlordList2(event) {
        console.log('refresh');
        var selPickListValue = 'Active';
        this.getMyLandlords(event, selPickListValue);
    }
    hidesavePopup() {
        this.saved = false;
    }
    hidestatusActive() {
        this.statusActive = false;
    }
    hidestatusInactive() {
        this.statusInactive = false;
    }
    hideAlert() {
        this.statusPropActive = false;
        this.statusPropInactive = false;
    }

    StatusPicklist() {
        allocationRegistrationStatusList()
            .then(result => {
                console.log('response==' + JSON.stringify(result));

                var lanRegStatuses = [];
                for (var key in result) {
                    lanRegStatuses.push({ key: key, value: result[key] });
                }
                this.LandRegStatuses = lanRegStatuses;
                console.log('lanRegStatuses --->>> ' + this.LandRegStatuses);

            })
            .catch(error => {
                console.log('Error -> ', error);
            })

    }
    cancelRefresh() {
        this.showEditLandLord = false;
    }
    updateLandlordData() {
        console.log('inside updateLandlordData');
        this.editLandLordDetails();
        console.log(this.editedAllocation);
        console.log('inside updateLandlordData 11');
        console.log(JSON.stringify(this.editedAllocation));
        console.log('inside updateLandlordData 12');
        console.log(this.editedLandlord);
        console.log('inside updateLandlordData 13');
        console.log(JSON.stringify(this.editedLandlord));
        console.log('inside updateLandlordData 1');

        updatePropertyAllocation({ editedAllocation: JSON.stringify(this.editedAllocation), editedLandlord: JSON.stringify(this.editedLandlord) })
            .then(result => {
                console.log('response==' + JSON.stringify(result));

                console.log(this.editLandLordDetails.lastName);
                console.log(this.editLandLordDetails.email);
                console.log(this.editLandLordDetails.telephoneNumber);
                this.showEditLandLord = false;
                this.isErrorEL = false;
                this.errorEL = '';
                this.isSuccessEL = true;
                this.isSuccessupdatedetails = true;
                this.successEL = 'updated details';
                console.log('inside updateLandlordData 20');
                var foundIndex = this.property.Property_Allocations__r.findIndex(x => x.Id == this.selectedallocation.Id);
                console.log('inside updateLandlordData 21');
                this.property.Property_Allocations__r[foundIndex] = this.selectedallocation;
                console.log('inside updateLandlordData 22');
                console.log(JSON.stringify(this.selectedallocation));
                console.log(JSON.stringify(this.property.Property_Allocations__r[foundIndex]));
                console.log('inside updateLandlordData 22');


            })
            .catch(error => {
                //     this.isErrorEL=true;
                this.errorEL = 'unknow error occured contact system administrator';
                //     this.isSuccessEL=false;
                //     this.successEL='';
                console.log('Error -> ', error);
            })
        console.log('inside updateLandlordData 2');

    }
    addLandlordDataHandle() {
        console.log('inside addLandlordDataHandle');
        var regsts = this.template.querySelector('[data-id="selectregStatusELL"]').value;
        console.log('line 270 Company phonecode: ' + regsts);
        if (regsts == 'Landlord is appealing a decision to remove their entry from the local authority register' || regsts == 'Landlord is entered on the local authority register for the area where this property is located')
            this.isRegStatus = true;
        else
            this.isRegStatus = false;

    }
    editLandLordDetails() {
        console.log('inside editLandLordDetails');
        var landLord = {};
        var allocation = {};
        landLord.Id = this.selectedallocation.Contact__c;
        allocation.Id = this.selectedallocation.Id;
        console.log('firstName:' + this.template.querySelector('[data-id="firstNameELL"]').value);
        landLord.firstName = this.template.querySelector('[data-id="firstNameELL"]').value;
        landLord.lastName = this.template.querySelector('[data-id="lastNameELL"]').value;
        landLord.email = this.template.querySelector('[data-id="emailELL"]').value;
        landLord.companyPhoneCode = this.template.querySelector('[data-id="selectCompanyCodeELL"]').value;
        landLord.telephoneNumber = this.template.querySelector('[data-id="telephoneNumberELL"]').value;
        const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        console.log('firstName--?' + landLord.firstName);
        console.log('email-->' + landLord.email);

        this.selectedallocation.Contact__r.FirstName = landLord.firstName;
        this.selectedallocation.Contact__r.LastName = landLord.lastName;
        this.selectedallocation.Contact__r.Email = landLord.email;
        this.selectedallocation.Contact__r.Phone = landLord.telephoneNumber;
        this.selectedallocation.Contact__r.Phone_Code__c = landLord.companyPhoneCode;
        // this.selectedallocation.Landlord_Registrataion_Status__c= allocation.regStatus;
        // this.selectedallocation.Landlord_Registration_Number__c= allocation.regNumber;

        if (this.selectedallocation.Contact__r.FirstName == "" || this.selectedallocation.Contact__r.FirstName == undefined) {

            this.isFirstNameError = true;
        }
        if (this.selectedallocation.Contact__r.LastName == "" || this.selectedallocation.Contact__r.LastName == undefined) {

            this.isSurNameError = true;
            this.isEmailForError = false;
        }

        if (this.selectedallocation.Contact__r.Phone == "" || this.selectedallocation.Contact__r.Phone == undefined) {
            this.isPhoneEmptyError = true;
        }
        // if(this.selectedallocation.Contact__r.Phone_Code__c=='+44' && this.selectedallocation.Contact__r.Phone.length!='11'){
        //        this.isPhoneLnthError=true;       
        // }
        if (!this.selectedallocation.Contact__r.Email.match(EMAIL_REGEX)) {
            this.isEmailForError = true;
        }
        if (this.selectedallocation.Contact__r.Email == "" || this.selectedallocation.Contact__r.Email == undefined) {
            this.isEmailEmptyError = true;

        }
        else {

            console.log('allocation' + JSON.stringify(allocation));
            console.log('landLord' + JSON.stringify(landLord));
            this.editedLandlord = landLord;
            this.editedAllocation = allocation;

        }  //this.phoneCode=this.template.querySelector("[name='selectPhoneCodeAddLL']").value;


    }

    searchPrimaryLLHandle(event) {
        this.isShowListedLandlord = false;
        this.ischangePrimaryLLMessage = false;
        this.changePrimaryLLMessage = '';
        this.isPrimaryLandlordError = false;
        this.searchLandlordString = this.template.querySelector('[name="landlord_replace_search"]').value;
        let searchLandlordStr = this.searchLandlordString;
        this.primaryLandLordList = [];
        // this.primaryLandlordName='';
        console.log('Line 482 Primary LL search key -> ', searchLandlordStr);
        console.log('Line 483 length -> ', searchLandlordStr.length);
        console.log('this.branchId' + this.branchId);
        console.log('existingNonMemLLlist@@=>'+this.propertyContactIds);
        if (searchLandlordStr.length > 2) {
            searchLandlord({ searchField: this.searchLandlordString, branchId: this.branchId })
                .then(result => {
                    console.log('result length : ' + result.length);
                    
                    if (result.length == 0) {
                        console.log('result lengtth 0');
                        this.primaryLandLordList = [];
                        this.isShowListedLandlord = false;
                    } else {
                        console.log('result lengtth > 0');
                        
                        const filteredResult = result.filter(item => !this.propertyContactIds.includes(item.Id));
                        if(filteredResult.length>0){
                            this.primaryLandLordList = filteredResult;
                            this.isShowListedLandlord = true;
                        }
                        
                        //  this.primaryLandlordName='';

                    }
                    console.log('Landlord data : ' + JSON.stringify(this.primaryLandLordList));

                })
                .catch(error => {

                    console.log('Line 288 Error -> ', error);
                });

        }

    }

    handlePrimaryLandLord(event) {
        this.ischangePrimaryLLMessage = false;
        this.changePrimaryLLMessage = '';
        this.isShowListedLandlord = false;
        this.isPrimaryLandlordError = false;
        let currentSelectedAddressId = event.target.getAttribute('data-id');
        let recordID = currentSelectedAddressId.slice(0, 18);
        console.log('landlord selectRecord ## ' + recordID);
        let primarylandlord = this.primaryLandLordList;
        //  console.log('landlord primarylandlord ## '+ primarylandlord);
        let selectedrecId = this.selectedjointlandlordID;
        console.log('line 561--->' + selectedrecId);

        let selectedPrimarylandlord = this.selectedPrimaryLandlord;
        console.log("line 28" + JSON.stringify(selectedPrimarylandlord));
        if (selectedPrimarylandlord.length > 0) {
            console.log("line 29");
            if (selectedrecId.includes(selectedPrimarylandlord[0].Id)) {
                console.log("line 30");
                let index = selectedrecId.indexOf(selectedPrimarylandlord[0].Id);
                console.log("line 568-->" + index);
                selectedrecId.splice(index, 1);
                console.log("line 27");
            }
        }
        console.log('line 562--->' + selectedrecId);
        let selectedrec = [];
        for (let i = 0; i < primarylandlord.length; i++) {
            if (primarylandlord[i].Id == recordID) {
                if (!selectedrecId.includes(recordID)) {
                    console.log("line 93 primaryLL " + primarylandlord[i].Id, primarylandlord[i].FirstName);
                    selectedrec.push(primarylandlord[i]);
                    selectedrecId.push(recordID);
                } else {
                    this.isPrimaryLandlordError = true;
                    // this.primaryLandlordName='';
                }
            }
        }
        console.log('Line 584 landlord selectedrec ## ' + JSON.stringify(selectedrec));
        var fullName;
        if (selectedrec[0].FirstName != undefined || selectedrec[0].FirstName != null) {
            fullName = selectedrec[0].FirstName + " " + selectedrec[0].LastName;
        } else {
            fullName = selectedrec[0].LastName;
        }
        console.log("fullName-->", fullName);
        this.primaryLandLordList = [];
        this.primaryLandlordName = fullName;
        this.selectedPrimaryLandlord = selectedrec;
        this.selectedjointlandlordID = selectedrecId;
        console.log('Line 813 additionalLandlord--->' + JSON.stringify(this.selectedPrimaryLandlord));
        console.log('Line 814 additionalLandlord--->' + this.selectedPrimaryLandlord[0].Id);

    }

    cancelReplacement() {
        this.changePrimaryLLMessage = '';
        this.ischangePrimaryLLMessage = false;
        this.replaceLandlord = false;
        this.primaryLandlordName = '';
        this.primaryLandLordList = [];
        this.isShowListedLandlord = false;
        this.isPrimaryLandlordError = false;
        this.ischangePrimaryLLMessage = false;
    }
    confirmReplacement() {
        console.log('Line 813 additionalLandlord--->' + JSON.stringify(this.selectedPrimaryLandlord));
        console.log('Line 814 additionalLandlord--->' + this.selectedPrimaryLandlord[0].Id);
        console.log('this.property.Id ' + this.property.Id);
        console.log('this.property.Id ' + this.presentPrimaryLL);

        removeLand({
            propAllocationid: this.presentPrimaryLL,
            relation: 'Primary Landlord',
            jointLandlordId: this.selectedPrimaryLandlord[0].Id
        })
            .then(result => {
                console.log('response==' + JSON.stringify(result));

               // this.property.Property_Allocations__r = result;
               this.PaginationPropAllList = result;
                if (this.PaginationPropAllList.length > 1) {
                    this.disableRemove = false;
                } else
                    this.disableRemove = true;
                this.nextPrimaryLandlordName = '';
                this.presentPrimaryLL = '';
                for (const obj of this.PaginationPropAllList) {
                    console.log("msgFrom", obj);
                    console.log("msgBody", obj.Relation_to_Property__c);
                    if (obj.Relation_to_Property__c == 'Joint Landlord' && this.nextPrimaryLandlordName == '') {
                        this.nextPrimaryLandlordId = obj.Contact__c;
                        this.nextPrimaryLandlordName = obj.Contact__r.Name;
                    }
                    if (obj.Relation_to_Property__c == 'Primary Landlord' && this.presentPrimaryLL == '') {
                        this.presentPrimaryLL = obj.Id;

                    }
                    if (this.presentPrimaryLL != '' && this.nextPrimaryLandlordName != '') {
                        break;
                    }

                }
                console.log('inside updateLandlordData 21');
                this.changePrimaryLLMessage = '';
                this.ischangePrimaryLLMessage = false;
                this.replaceLandlord = false;
                this.primaryLandlordName = '';
                this.primaryLandLordList = [];
                this.isShowListedLandlord = false;
                this.isPrimaryLandlordError = false;
                this.ischangePrimaryLLMessage = false;

            })
            .catch(error => {
                this.changePrimaryLLMessage = 'Error occured while property creation';
                this.ischangePrimaryLLMessage = true;
                this.primaryLandLordList = [];

                console.log('Line 915 Error -> ', error);
            })
    }

}