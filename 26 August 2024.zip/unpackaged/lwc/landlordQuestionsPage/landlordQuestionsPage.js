import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import pageUrl from '@salesforce/resourceUrl/recaptchaV2';

import postLandlordFormData from '@salesforce/apex/TRS_LandlordComplaint.postLandlordFormData';
import findAddress from '@salesforce/apex/TRS_LoqateServiceForSite.findAddress';
import retrieveAddress from '@salesforce/apex/TRS_LoqateServiceForSite.retrieveAddress';

import addressloqate from '@salesforce/label/c.NHOS_AddressLoqateKey';
import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";
import trsSiteHomePageLink from "@salesforce/label/c.TRS_SiteHomePage";

const apikeyId = addressloqate;
const MAX_CHARACTER_LIMIT = 2000;

export default class LandlordQuestionsPage extends NavigationMixin(LightningElement) {

    label = {
        trsPortalHomePageLink
    };

    termsAndConditionsPage = trsSiteHomePageLink+'terms-and-conditions';
    privacyPolicyPage = trsSiteHomePageLink+'privacy-policy';

    @track navigateTo;
    @track currentpage = 0;
    @track page0 = true; //true
    @track page1 = true; //true
    @track page2 = false;
    @track page3 = false;
    @track page4 = false; //false
    @track page5preview = false;
    @track pagefinal = false;
    @track tillQuestion4 = true;
    @track tillQuestion5 = false;
    @track checkedOrNot = false;
    agreedCheckbox1 = false;
    agreedCheckbox2 = false;
    @track showErrorMsg1 = false;
    @track sameCurrentAddress = false;
    @track showHelpandAnswers = false;
    activeSectionMessage = '';
    activeSections = ['A'];
    @track isNextButtonDisabled = true;
    @track isSubmitdisabled = true;
    tippage2 = 'In order to support your dispute we need the name and contact details of your tenant.<br/><br/> Without these we will be unable to contact the tenant on your behalf.<br/><br/> You should be able to locate the tenants details on you tenancy agreement.';
    tippage3 = 'We need to know that we have the correct property address when talking to the tenant.';
    @track save1Valid = false;
    @track save2Valid = false;
    @track save3Valid = false;
    @track save4Valid = false;
    @track showAccordion = false;
    @track otherIsSelected = false;

    @track isErrorMessageVisible = true;
    @track maxCharacterLimit = 2000;
    @track remainingCharacters = this.maxCharacterLimit;

    trsCaseReferenceNumber = '';
    showSpinner = false;

    captchaResult = false;


    @track commitLandlordDetails = {
        'Q0': { 'value': null, 'position': false, 'previewediting': false },
        'Q1': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q2': { 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false },
        'Q4': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false }
    };

    @track landlordDetails = {
        'Q0': { 'value': null, 'position': false, 'previewediting': false },
        'Q1': { 'position': false, 'previewediting': false, 'buttonediting': false },
        'Q2': { 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false },
        'Q4': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false }

    };


    constructor() {
        super();
        this.navigateTo = pageUrl;
        window.addEventListener("message", this.listenForMessage.bind(this));
    }

    captchaLoaded(event) {
        if (event.target.getAttribute('src') == pageUrl) {
        }
    }

    listenForMessage(message) {
        if (message.data == 'captcha success') {
            this.captchaResult = true;
            this.sixthValidation();
        }
        else if (message.data == 'captcha expired') {
            this.captchaResult = false;
            this.sixthValidation();
        }
    }

    get options1() {
        return [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' },
        ];
    }

    get complaintOptions() {
        return [
            { label: 'Marketing of the tenancy', value: 'Marketing of the tenancy' },
            { label: 'Tenancy terms', value: 'Tenancy terms' },
            { label: 'Property standards', value: 'Property standards' },
            { label: 'Repairs', value: 'Repairs' },
            { label: 'Entry rights', value: 'Entry rights' },
            { label: 'Rent arrears', value: 'Rent arrears' },
            { label: 'Threatened evictions', value: 'Threatened evictions' },
            { label: 'Breach of tenancy terms', value: 'Breach of tenancy terms' },
            { label: 'GDPR', value: 'GDPR' },
            { label: 'Communications', value: 'Communications' },
            { label: 'Noise/Anti-Social behaviour', value: 'Noise/Anti-Social behaviour' },
            { label: 'Other', value: 'Other' }
        ];
    }

    apiId = apikeyId;

    @track searchTerm = '';
    @track foundAddresses;
    @track selectedAddress;
    @track encodedKey = '';

    handleSearch(event) {
        this.searchTerm = event.target.value.trim();
        this.findAddress();
    }

    findAddress(secondCall) {
        let encodedSearchTerm = '';

        if(secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        }
        
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = [];
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                //console.error('error : ' + error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);   
            this.findAddress(true);
        } else{
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
            .then(result => {
                this.foundAddresses = false;
                this.selectedAddress = JSON.parse(result);

                this.landlordDetails.Q1.CurrStreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                this.landlordDetails.Q1.CurrAddTownCity = this.selectedAddress.Items[0].City;
                this.landlordDetails.Q1.CurrCounty = this.selectedAddress.Items[0].Province;
                this.landlordDetails.Q1.CurrAddPostCode = this.selectedAddress.Items[0].PostalCode;
                this.landlordDetails.Q1.CurrBaseCountry = 'England';
                this.landlordDetails.Q1.CurrAddCountry = this.selectedAddress.Items[0].CountryName;

                this.searchTerm = this.selectedAddress.Items[0].PostalCode;
                this.addressValidation();
            })
            .catch(error => {
                //console.log('error : ' + error);
            });
        }
        
    }

    /*findAddress() {
        const encodedSearchTerm = encodeURIComponent(this.searchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                // Handle response from Loqate API
                const addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('Error: find ', error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));

        if (cleanedId.includes('-')) {
            this.searchTerm = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTerm);
            this.findAddress();
            return;
        } else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
                .then(result => {
                    this.selectedAddress = JSON.parse(result);

                    this.landlordDetails.Q1.CurrStreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                    this.landlordDetails.Q1.CurrAddTownCity = this.selectedAddress.Items[0].City;
                    this.landlordDetails.Q1.CurrCounty = this.selectedAddress.Items[0].Province;
                    this.landlordDetails.Q1.CurrAddPostCode = this.selectedAddress.Items[0].PostalCode;
                    this.landlordDetails.Q1.CurrBaseCountry = 'England'; //this.selectedAddress.Items[0].
                    this.landlordDetails.Q1.CurrAddCountry = this.selectedAddress.Items[0].CountryName;

                    this.foundAddresses = null;
                    this.searchTerm = this.selectedAddress.Items[0].PostalCode;

                    this.landlordDetails.Q1.position = true;
                    this.landlordNameEmailValidationQ1();
                })
                .catch(error => {
                    console.log('inside eror ', error);
                });
        }
    }*/

    @track searchTermProp = '';
    @track foundAddressesProp;
    @track selectedAddressProp;
    @track encodedKeyProp = '';

    handleSearchProp(event) {
        this.searchTermProp = event.target.value.trim();
        this.findAddressProp();
    }

    findAddressProp(secondCall) {
        let encodedSearchTerm = '';

        if(secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTermProp);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTermProp);
        }
        
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddressesProp = [];
                    this.foundAddressesProp = addresses.Items;
                } else {
                    this.foundAddressesProp = [];
                }
            })
            .catch(error => {
                //console.error('error : ' + error);
            });
    }

    retrieveAddressProp(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);   
            this.findAddressProp(true);
        } else{
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
            .then(result => {
                this.foundAddressesProp = false;
                this.selectedAddressProp = JSON.parse(result);

                this.landlordDetails.Q3.PropStreetName = this.selectedAddressProp.Items[0].Line1 + this.selectedAddressProp.Items[0].Line2;
                this.landlordDetails.Q3.PropAddTownCity = this.selectedAddressProp.Items[0].City;
                this.landlordDetails.Q3.PropCounty = this.selectedAddressProp.Items[0].Province;
                this.landlordDetails.Q3.PropAddPostCode = this.selectedAddressProp.Items[0].PostalCode;
                this.landlordDetails.Q3.PropBaseCountry = 'England';
                this.landlordDetails.Q3.PropAddCountry = this.selectedAddressProp.Items[0].CountryName;

                this.searchTermProp = this.selectedAddressProp.Items[0].PostalCode;
                this.addressValidation();
            })
            .catch(error => {
                //console.log('error : ' + error);
            });
        }
        
    }

    /*handleSearchProp(event) {
        this.searchTermProp = event.target.value.trim();
        this.findAddressProp();
    }

    findAddressProp() {
        const encodedSearchTermProp = encodeURIComponent(this.searchTermProp);

        findAddress({ apiKey: this.apiId, search: encodedSearchTermProp, containerId: this.encodedKeyProp })
            .then(result => {
                // Handle response from Loqate API
                const addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddressesProp = addresses.Items;
                } else {
                    this.foundAddressesProp = [];
                }
            })
            .catch(error => {
                console.error('Error: find ', error);
            });
    }

    retrieveAddressProp(event) {
        const idprop = event.target.id;
        const cleanedIdProp = idprop.substring(0, idprop.lastIndexOf('-'));

        if (cleanedIdProp.includes('-')) {
            this.searchTermProp = cleanedIdProp;

            this.encodedKeyProp = encodeURIComponent(this.searchTermProp);

            this.findAddressProp();
            return;
        }
        else {
            retrieveAddress({ apiKey: this.apiId, idx: cleanedIdProp })
                .then(result => {
                    this.selectedAddressProp = JSON.parse(result);

                    this.landlordDetails.Q3.PropStreetName = this.selectedAddressProp.Items[0].Line1 + this.selectedAddressProp.Items[0].Line2;
                    this.landlordDetails.Q3.PropAddTownCity = this.selectedAddressProp.Items[0].City;
                    this.landlordDetails.Q3.PropCounty = this.selectedAddressProp.Items[0].Province;
                    this.landlordDetails.Q3.PropAddPostCode = this.selectedAddressProp.Items[0].PostalCode;
                    this.landlordDetails.Q3.PropBaseCountry = 'England'; //this.selectedAddressProp.Items[0].
                    this.landlordDetails.Q3.PropAddCountry = this.selectedAddressProp.Items[0].CountryName;

                    // Close the list of found addresses
                    this.foundAddressesProp = null;
                    this.searchTermProp = this.selectedAddressProp.Items[0].PostalCode;

                    this.landlordDetails.Q3.position = true;
                    this.addressValidation();
                })
                .catch(error => {
                    console.log('inside eror ', error);
                });
        }
    }*/

    handlepage5Checkbox(event) {
        if (event.target.dataset.name == 'q5checkbox1') {
            this.agreedCheckbox1 = event.target.checked;
        }
        else if (event.target.dataset.name == 'q5checkbox2') {
            this.agreedCheckbox2 = event.target.checked;
        }
        this.sixthValidation();
    }

    sixthValidation() {
        if (this.agreedCheckbox1 && this.agreedCheckbox2 && this.captchaResult && this.validateAreasOfComplaintDetailsSubmission2()) {
            this.commitLandlordDetails = JSON.parse(JSON.stringify(this.landlordDetails));
            this.isSubmitdisabled = false;
        } else {
            this.isSubmitdisabled = true;
        }
    }

    handleAllChanges(event) {
        if (event.target.dataset.name == 'q0radio') {
            this.landlordDetails.Q0.value = event.target.value;
            this.validateInputFirst();
        }

        else if (event.target.name == 'q1firstname') {
            this.landlordDetails.Q1.LandlordFirstName = event.target.value;
            this.landlordDetails.Q1.LandlordFirstName = this.landlordDetails.Q1.LandlordFirstName.trim();
            this.landlordNameEmailValidationQ1();

            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1lastname') {
            this.landlordDetails.Q1.LandlordLastName = event.target.value;
            this.landlordDetails.Q1.LandlordLastName = this.landlordDetails.Q1.LandlordLastName.trim();
            this.landlordNameEmailValidationQ1();

            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1email') {
            this.landlordDetails.Q1.LandlordEmail = event.target.value;
            this.landlordNameEmailValidationQ1();

            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1phone') {
            this.landlordDetails.Q1.LandlordPhone = event.target.value;
            this.landlordNameEmailValidationQ1();

            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currstreetname') {
            this.landlordDetails.Q1.CurrStreetName = event.target.value;
            this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currtowncity') {
            this.landlordDetails.Q1.CurrAddTownCity = event.target.value;
            this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currcounty') {
            this.landlordDetails.Q1.CurrCounty = event.target.value;
            //this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currpostcode') {
            this.landlordDetails.Q1.CurrAddPostCode = event.target.value;
            this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currbasecountry') {
            this.landlordDetails.Q1.CurrBaseCountry = event.target.value;
            //this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }
        else if (event.target.name == 'q1currcountry') {
            this.landlordDetails.Q1.CurrAddCountry = event.target.value;
            //this.addressValidation();
            this.landlordDetails.Q1.position = true;
        }

        else if (event.target.name == 'q2firstname') {
            this.landlordDetails.Q2.FirstName = event.target.value;
            this.landlordDetails.Q2.FirstName = this.landlordDetails.Q2.FirstName.trim();
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        }
        else if (event.target.name == 'q2lastname') {
            this.landlordDetails.Q2.LastName = event.target.value;
            this.landlordDetails.Q2.LastName = this.landlordDetails.Q2.LastName.trim();
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        }
        else if (event.target.name == 'q2email') {
            this.landlordDetails.Q2.Email = event.target.value;
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        }
        else if (event.target.name == 'q2phone') {
            this.landlordDetails.Q2.Phone = event.target.value;
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        }
        else if (event.target.name == 'q3propstreetname') {
            this.landlordDetails.Q3.PropStreetName = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        }
        else if (event.target.name == 'q3proptowncity') {
            this.landlordDetails.Q3.PropAddTownCity = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        }
        else if (event.target.name == 'q3propcounty') {
            this.landlordDetails.Q3.PropCounty = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        }
        else if (event.target.name == 'q3proppostcode') {
            this.landlordDetails.Q3.PropAddPostCode = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        }
        else if (event.target.name == 'q3propbasecountry') {
            this.landlordDetails.Q3.PropBaseCountry = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        }
        else if (event.target.name == 'q3propcountry') {
            this.landlordDetails.Q3.PropAddCountry = event.target.value;

            this.landlordDetails.Q3.position = true;
        } else if (event.target.dataset.name == 'multicheckbox') {
            this.setAreasOfComplaintsSummaryDynamically(event.detail.value);
            this.selectedComplaintTypes = event.detail.value;

            this.landlordDetails.Q4.SelectedCheckboxes = event.detail.value;
            this.landlordDetails.Q4.position = true;
            if (this.landlordDetails.Q4.SelectedCheckboxes.includes('Other')) {
                this.otherIsSelected = true;
            } else {
                this.otherIsSelected = false;
            }
            this.fourthValidation();

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }
        } else if (event.target.dataset.name == 'multicheckbox2') {
            this.setAreasOfComplaintsSummaryDynamically2(event.detail.value);
            this.commitSelectedComplaintTypes = event.detail.value;

            this.landlordDetails.Q4.SelectedCheckboxes = event.detail.value;
            this.landlordDetails.Q4.position = true;
            if (this.landlordDetails.Q4.SelectedCheckboxes.includes('Other')) {
                this.otherIsSelected = true;
            } else {
                this.otherIsSelected = false;
            }
            this.fourthValidation();

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }
        } else if (event.target.name == 'q4otherselected') {
            this.landlordDetails.Q4.OtherSelectedValue = event.detail.value;
            this.fourthValidation();
            this.landlordDetails.Q4.position = true;

        } else if (event.target.name == 'q4text') {
            this.landlordDetails.Q4.ComplaintDetail = event.detail.value;

            this.remainingCharacters = this.maxCharacterLimit - this.landlordDetails.Q4.ComplaintDetail.length;
            if (this.remainingCharacters <= 0) {
                this.isErrorMessageVisible = false;
            } else {
                this.isErrorMessageVisible = true;
            }

            this.fourthValidation();
            this.landlordDetails.Q4.position = true;
        }
    }

    selectedComplaintTypes = [];
    commitSelectedComplaintTypes = [];

    @track complaintSummaryDetails = [];
    @track commitComplaintSummaryDetails = [];
    @track tempComplaintSummaryDetails = [];

    setAreasOfComplaintsSummaryDynamically(selectedCheckBoxes) {
        try {
            this.complaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));

            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.complaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.complaintSummaryDetails[i].complaintType));
                        if(this.complaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.complaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.complaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.complaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.complaintSummaryDetails;
            console.log('complaint summry : '+JSON.stringify(this.complaintSummaryDetails));
        } catch (error) {
            //console.log('error in setAreasOfComplaintsSummaryDynamically2 : ' + error);
        }
    }

    setAreasOfComplaintsSummaryDynamically2(selectedCheckBoxes) {
        try {
            this.commitComplaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));

            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.commitComplaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.commitComplaintSummaryDetails[i].complaintType));
                        if(this.commitComplaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.commitComplaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.commitComplaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.commitComplaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.commitComplaintSummaryDetails;
            console.log('complaint summary commit : '+JSON.stringify(this.commitComplaintSummaryDetails));
        } catch (error) {
            //console.log('error in setAreasOfComplaintsSummaryDynamically2 : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;

            this.complaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.complaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
            }
        } catch (error) {
            //console.log('error in handleAreasOfComplaintSummaryDetailsChange : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange2(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;

            this.commitComplaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.commitComplaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }

            this.sixthValidation();
            JSON.stringify(this.commitComplaintSummaryDetails)
        } catch (error) {
            //console.log('error in handleAreasOfComplaintSummaryDetailsChange2 : ' + error);
        }
    }

    validateAreasOfComplaintDetailsSubmission() {
        let isValid = true;

        if(this.selectedComplaintTypes == []) {
            isValid = false;
        }

        this.complaintSummaryDetails.forEach((element) => {
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateAreasOfComplaintDetailsSubmission2() {
        let isValid = true;

        if(this.commitSelectedComplaintTypes == []) {
            isValid = false;
        }

        this.commitComplaintSummaryDetails.forEach((element) => {
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateInputFirst() {
        if (this.landlordDetails.Q0.value == 'No') {
            this.showErrorMsg1 = true;
            this.tillQuestion4 = false;
            return;
        }
        else if (this.landlordDetails.Q0.value == '' || this.landlordDetails.Q0.value == undefined || this.landlordDetails.Q0.value == null) {
            this.isNextButtonDisabled = true;
            this.tillQuestion4 = true;
        }
        else {
            this.showErrorMsg1 = false;
            this.isNextButtonDisabled = false;
            this.tillQuestion4 = true;
        }

    }

    landlordNameEmailValidationQ1() {
        var addressCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailPhonecorrect = false;
        var phonecorrect = true;

        if (this.landlordDetails.Q1.LandlordFirstName != '' && this.landlordDetails.Q1.LandlordFirstName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q1.LandlordFirstName)) {

                let searchCmp2 = this.template.querySelector(".firstnameCmp5");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid first name without space");
                }
                firstNameCorrect = false;
            }
            else {
                let searchCmp2 = this.template.querySelector(".firstnameCmp5");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }
                firstNameCorrect = true;
            }
        }
        else if (this.landlordDetails.Q1.LandlordFirstName == '') {
            this.template.querySelector(".firstnameCmp5").setCustomValidity("");
        }

        if (this.landlordDetails.Q1.LandlordLastName != '' && this.landlordDetails.Q1.LandlordLastName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q1.LandlordLastName)) {
                let searchCmp = this.template.querySelector(".lastnameCmp5");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid last name without space");
                }
                lastNameCorrect = false;
            } else {
                let searchCmp = this.template.querySelector(".lastnameCmp5");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                lastNameCorrect = true;
            }
        } else if (this.landlordDetails.Q1.LandlordLastName == '') {
            this.template.querySelector(".lastnameCmp5").setCustomValidity("");
        }

        const emailRegex = /^(\s*)?[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(\s*)?$/;
        const phoneRegex = /^0\d{10}$/; // Regular expression for a 10-digit phone number

        if (this.landlordDetails.Q1.LandlordEmail != '' && this.landlordDetails.Q1.LandlordEmail != undefined && emailRegex.test(this.landlordDetails.Q1.LandlordEmail)) {
            emailPhonecorrect = true;
        }

        if (this.landlordDetails.Q1.LandlordPhone != null && this.landlordDetails.Q1.LandlordPhone != undefined && this.landlordDetails.Q1.LandlordPhone != '') {
            if (!phoneRegex.test(this.landlordDetails.Q1.LandlordPhone)) {
                let searchCmp4 = this.template.querySelector(".phoneCmp5");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
                phonecorrect = false;
            }
            else {
                let searchCmp4 = this.template.querySelector(".phoneCmp5");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("");
                }
                phonecorrect = true;
            }
        } else if (this.landlordDetails.Q1.LandlordPhone == '') {
            this.template.querySelector(".phoneCmp5").setCustomValidity("");
            phonecorrect = true;
        }

        if (this.landlordDetails.Q1.LandlordEmail != null && this.landlordDetails.Q1.LandlordEmail != undefined && this.landlordDetails.Q1.LandlordEmail != '') {
            if (!emailRegex.test(this.landlordDetails.Q1.LandlordEmail)) {
                let searchCmp5 = this.template.querySelector(".emailCmp5");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                let searchCmp5 = this.template.querySelector(".emailCmp5");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("");
                }
            }
        } else if (this.landlordDetails.Q1.LandlordEmail == '') {
            this.template.querySelector(".emailCmp5").setCustomValidity("");
        }


        if ((this.landlordDetails.Q1.CurrStreetName != undefined && this.landlordDetails.Q1.CurrStreetName != null && this.landlordDetails.Q1.CurrStreetName != '')
            && (this.landlordDetails.Q1.CurrAddTownCity != null && this.landlordDetails.Q1.CurrAddTownCity != undefined && this.landlordDetails.Q1.CurrAddTownCity != '')
            && (this.landlordDetails.Q1.CurrAddPostCode != null && this.landlordDetails.Q1.CurrAddPostCode != '' && this.landlordDetails.Q1.CurrAddPostCode != undefined)) {

            addressCorrect = true;
        }

        if ((emailPhonecorrect && firstNameCorrect && lastNameCorrect && addressCorrect && phonecorrect)) {
            this.isNextButtonDisabled = false;
            this.save1Valid = true;
        } else {
            this.isNextButtonDisabled = true;
            this.save1Valid = false;
        }
    }

    detailsValidation() {
        // var fullNameCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailPhonecorrect = false;

        if (this.landlordDetails.Q2.FirstName != '' && this.landlordDetails.Q2.FirstName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q2.FirstName)) {
                let searchCmp2 = this.template.querySelector(".firstnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid first name without space");
                }
                firstNameCorrect = false;
            }
            else {
                let searchCmp2 = this.template.querySelector(".firstnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }
                firstNameCorrect = true;
            }
        } else if (this.landlordDetails.Q2.FirstName == '') {
            this.template.querySelector(".firstnameCmp2").setCustomValidity("");
        }

        if (this.landlordDetails.Q2.LastName != '' && this.landlordDetails.Q2.LastName != undefined) {
            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q2.LastName)) {
                let searchCmp2 = this.template.querySelector(".lastnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid last name without space");
                }
                lastNameCorrect = false;
            }
            else {
                let searchCmp2 = this.template.querySelector(".lastnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }
                lastNameCorrect = true;
            }
        } else if (this.landlordDetails.Q2.LastName == '') {
            this.template.querySelector(".lastnameCmp2").setCustomValidity("");
        }

        const emailRegex = /^(\s*)?[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(\s*)?$/;
        const phoneRegex = /^0\d{10}$/;
        if ((this.landlordDetails.Q2.Email != '' && this.landlordDetails.Q2.Email != undefined && emailRegex.test(this.landlordDetails.Q2.Email) && (this.landlordDetails.Q2.Phone == '' || this.landlordDetails.Q2.Phone == undefined))
            || (this.landlordDetails.Q2.Phone != '' && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone.length == 11 && phoneRegex.test(this.landlordDetails.Q2.Phone) && (this.landlordDetails.Q2.Email == '' || this.landlordDetails.Q2.Email == undefined))
            || (this.landlordDetails.Q2.Email != '' && this.landlordDetails.Q2.Email != undefined && emailRegex.test(this.landlordDetails.Q2.Email) && this.landlordDetails.Q2.Phone != '' && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone.length == 11 && phoneRegex.test(this.landlordDetails.Q2.Phone))
        ) {
            emailPhonecorrect = true;
        }
        else {
            emailPhonecorrect = false;
        }


        if (this.landlordDetails.Q2.Phone != null && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone != '') {
            if (!phoneRegex.test(this.landlordDetails.Q2.Phone)) {
                let searchCmp = this.template.querySelector(".phoneCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
            }
            else {
                let searchCmp = this.template.querySelector(".phoneCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else if (this.landlordDetails.Q2.Phone == '') {
            this.template.querySelector(".phoneCmp2").setCustomValidity("");
        }

        if (this.landlordDetails.Q2.Email != null && this.landlordDetails.Q2.Email != undefined && this.landlordDetails.Q2.Email != '') {
            if (!emailRegex.test(this.landlordDetails.Q2.Email)) {
                let searchCmp = this.template.querySelector(".emailCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                let searchCmp = this.template.querySelector(".emailCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else if (this.landlordDetails.Q2.Email == '') {
            this.template.querySelector(".emailCmp2").setCustomValidity("");
        }

        if (emailPhonecorrect && firstNameCorrect && lastNameCorrect) {
            this.isNextButtonDisabled = false;
            this.save2Valid = true;
        } else {
            this.isNextButtonDisabled = true;
            this.save2Valid = false;
        }
    }

    addressValidation() {
        if (this.currentpage == 1) {
            
            if ((this.landlordDetails.Q1.CurrStreetName != undefined && this.landlordDetails.Q1.CurrStreetName != null && this.landlordDetails.Q1.CurrStreetName != '') &&
                (this.landlordDetails.Q1.CurrAddTownCity != null && this.landlordDetails.Q1.CurrAddTownCity != undefined && this.landlordDetails.Q1.CurrAddTownCity != '') && 
                (this.landlordDetails.Q1.CurrAddPostCode != null && this.landlordDetails.Q1.CurrAddPostCode != '' && this.landlordDetails.Q1.CurrAddPostCode != undefined)) {
                this.isNextButtonDisabled = false;
                this.save3Valid = true;
            } else {
                this.isNextButtonDisabled = true;
                this.save3Valid = false;
            }
        }

        if (this.currentpage == 3) {
            if ((this.landlordDetails.Q3.PropStreetName != undefined && this.landlordDetails.Q3.PropStreetName != null && this.landlordDetails.Q3.PropStreetName != '')
                && (this.landlordDetails.Q3.PropAddTownCity != null && this.landlordDetails.Q3.PropAddTownCity != undefined && this.landlordDetails.Q3.PropAddTownCity != '')
                && (this.landlordDetails.Q3.PropAddPostCode != null && this.landlordDetails.Q3.PropAddPostCode != '' && this.landlordDetails.Q3.PropAddPostCode != undefined)) {
                this.isNextButtonDisabled = false;
                this.save3Valid = true;
            } else {
                this.isNextButtonDisabled = true;
                this.save3Valid = false;
            }
        }

        



    }

    fourthValidation() {
        if (this.landlordDetails.Q4.SelectedCheckboxes != [] && this.landlordDetails.Q4.SelectedCheckboxes != '' && this.landlordDetails.Q4.ComplaintDetail != undefined && this.landlordDetails.Q4.ComplaintDetail != '') {
            if (this.landlordDetails.Q4.SelectedCheckboxes.length >= 1 && this.landlordDetails.Q4.ComplaintDetail != '' && this.otherIsSelected == false) {
                this.isNextButtonDisabled = false;
                this.save4Valid = true;
            }
            else if (this.otherIsSelected == true && this.landlordDetails.Q4.SelectedCheckboxes.length >= 1 && (this.landlordDetails.Q4.OtherSelectedValue != '' && this.landlordDetails.Q4.OtherSelectedValue != undefined && this.landlordDetails.Q4.OtherSelectedValue != null)) {
                this.isNextButtonDisabled = false;
                this.save4Valid = true;
            }
            else {
                this.isNextButtonDisabled = true;
                this.save4Valid = false;
            }
        } else if ((this.landlordDetails.Q4.SelectedCheckboxes != [] || this.landlordDetails.Q4.SelectedCheckboxes != '') && (this.landlordDetails.Q4.ComplaintDetail == undefined || this.landlordDetails.Q4.ComplaintDetail == '')) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        } else if ((this.landlordDetails.Q4.SelectedCheckboxes == [] || this.landlordDetails.Q4.SelectedCheckboxes == '') && (this.landlordDetails.Q4.ComplaintDetail != undefined || this.landlordDetails.Q4.ComplaintDetail != '')) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        }

        if ((this.landlordDetails.Q4.SelectedCheckboxes == [] && (this.landlordDetails.Q4.ComplaintDetail == undefined || this.landlordDetails.Q4.ComplaintDetail == '')) && this.currentpage == 4) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        }
    }

    handleNext() {
        console.log('current page : '+this.currentpage);
        window.scrollTo(0, 0);

        this.currentpage++;
        this.isNextButtonDisabled = true;

        if (this.currentpage == 1 || this.currentpage == 2 || this.currentpage == 3 || this.currentpage == 4) {
            this.showHelpandAnswers = true;
        }
        else {
            this.showHelpandAnswers = false;
        }

        if (this.currentpage == 5) {
            this.tillQuestion4 = false;
            this.tillQuestion5 = true;
            //update commit details
            this.commitSelectedComplaintTypes = [];
            this.commitComplaintSummaryDetails = [];

            this.commitSelectedComplaintTypes = this.selectedComplaintTypes;
            this.commitComplaintSummaryDetails = this.complaintSummaryDetails;
        }

        if (this.currentpage == 0) {
            this.validateInputFirst();
        }
        if (this.currentpage == 1) {
            this.landlordNameEmailValidationQ1();
        }
        if (this.currentpage == 2) {
            this.detailsValidation();

        }
        if (this.currentpage == 3) {
            this.addressValidation();
        }
        if (this.currentpage == 4) {
            //this.fourthValidation();
            
        }

        this.getexpression();
        this.commitLandlordDetails = JSON.parse(JSON.stringify(this.landlordDetails));
    }

    handlePrevious() {
        console.log('current page : '+this.currentpage);
        window.scrollTo(0, 0);

        this.isNextButtonDisabled = false;
        this.currentpage--;
        this.captchaResult = false;

        if (this.currentpage < 0) {
            this.currentpage = 0;
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    name: 'TRS_LandlordLandingPage__c'
                }
            });
        }
        if (this.currentpage == 4) {
            this.tillQuestion4 = true;
            this.tillQuestion5 = false;
            this.showHelpandAnswers = true;

            this.agreedCheckbox1 = false;
            this.agreedCheckbox2 = false;
            this.sixthValidation();
            //update commit details
            this.selectedComplaintTypes = [];
            this.complaintSummaryDetails = [];

            this.selectedComplaintTypes = this.commitSelectedComplaintTypes;
            this.complaintSummaryDetails = this.commitComplaintSummaryDetails;

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }
        }
        else if (this.currentpage == 0) {
            this.showHelpandAnswers = false;
        }
        this.getexpression();
    }

    handleSubmit() {
        if (this.isSubmitdisabled == false && this.currentpage == 5) {
            this.showSpinner = true;
            /*this.currentpage++;
            this.currentpage = 6;
            this.tillQuestion5 = false;
            this.page5preview = false;
            this.pagefinal = true;*/

            postLandlordFormData({ landlordDet: JSON.stringify(this.commitLandlordDetails),  areasOfComplaintDetails: JSON.stringify(this.commitComplaintSummaryDetails) })
                .then(result => {
                    this.trsCaseReferenceNumber = result;
                    this.contacts = result;
                    this.error = undefined;

                    this.currentpage++;
                    this.currentpage = 6;
                    this.tillQuestion5 = false;
                    this.page5preview = false;
                    this.pagefinal = true;

                    this.showSpinner = false;

                })
                .catch(error => {
                    this.error = error;
                    this.contacts = undefined;
                    this.showSpinner = false;
                });
        }
    }

    handleChange(event) {
        if (event.target.dataset.name == 'q1') {
            this.landlordDetails.Q1.previewediting = true;
        }
        else if (event.target.dataset.name == 'q2') {
            this.landlordDetails.Q2.previewediting = true;
        }
        else if (event.target.dataset.name == 'q3') {
            this.landlordDetails.Q3.previewediting = true;
        }
        else if (event.target.dataset.name == 'q4') {
            this.landlordDetails.Q4.previewediting = true;
        }

    }

    handleSave(event) {
        if (event.target.dataset.name == 'q1Save') {
            this.landlordNameEmailValidationQ1();

            if (this.save1Valid == true) {
                this.commitLandlordDetails.Q1 = this.landlordDetails.Q1;
                this.landlordDetails.Q1.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct landlord details', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q2Save') {
            this.detailsValidation();

            if (this.save2Valid == true) {
                this.commitLandlordDetails.Q2 = this.landlordDetails.Q2;
                this.landlordDetails.Q2.previewediting = false;
            } else {
                this.showToast('Error', 'Please select correct tenant details', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q3Save') {
            this.addressValidation();

            if (this.save3Valid == true) {
                this.commitLandlordDetails.Q3 = this.landlordDetails.Q3;
                this.landlordDetails.Q3.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct address', 'Error', 'Dismissable');
            }
        }
        else if (event.target.dataset.name == 'q4Save') {
            //this.fourthValidation();

            if (this.validateAreasOfComplaintDetailsSubmission2()) {
                this.commitLandlordDetails.Q4 = this.landlordDetails.Q4;
                this.landlordDetails.Q4.previewediting = false;
            } else {
                this.showToast('Error', 'Please fill correct checbox and details', 'Error', 'Dismissable');
            }
        }
    }

    handleDownArrowClick() {
        this.showAccordion = true;
    }

    handleUpArrowClick() {
        this.showAccordion = false;
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TRS_LandlordLandingPage__c'
            }
        });
    }

    handleBackToLandlordLandingPage() {
        
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TRS_LandlordLandingPage__c'
            }
        });
    }

    handleBackToHome() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    sendEmail() {
    }

    getexpression() {
        this.page0 = this.currentpage == 0 ? true : false;
        this.page1 = this.currentpage == 1 ? true : false;
        this.page2 = this.currentpage == 2 ? true : false;
        this.page3 = this.currentpage == 3 ? true : false;
        this.page4 = this.currentpage == 4 ? true : false;
        this.page5preview = this.currentpage == 5 ? true : false;
        this.pagefinal = this.currentpage == 6 ? true : false;
    }

    showToast(title, message, variant, mode) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

}