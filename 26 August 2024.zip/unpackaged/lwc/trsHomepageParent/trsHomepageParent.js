import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import trsPortalHomePageLink from "@salesforce/label/c.TRS_PortalHomePage";

export default class TrsHomepageParent extends NavigationMixin(LightningElement) {

    label = {
        trsPortalHomePageLink
    };

    handleTenant() {
        // console.log('inside tenant ');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TenantPage1__c'
            }
        });

    }

    handleLandlord() {
        // console.log('inside landlord ');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TRS_LandlordLandingPage__c'
            }
        });
    }

    handleForTenantClick() {
        // console.log('inside landlord ');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TenantPage1__c'
            }
        });
    }

    handleForLandlordClick() {
        // console.log('inside landlord ');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'TRS_LandlordLandingPage__c'
            }
        });
    }
}