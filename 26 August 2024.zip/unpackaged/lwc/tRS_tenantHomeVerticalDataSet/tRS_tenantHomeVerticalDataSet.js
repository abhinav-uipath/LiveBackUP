import { LightningElement, api, track } from 'lwc';

import trsSiteHomePageLink from "@salesforce/label/c.TRS_SiteHomePage";
import trsCodeOfPracticeLink from "@salesforce/resourceUrl/TRS_Code_Of_Practice";

export default class TRS_tenantHomeVerticalDataSet extends LightningElement {
    @api tabs;
   // @track selectedTab;
    tabSetVariant = '';

    questionspage = trsSiteHomePageLink+'tenant-question';
    trsCodeOfPractice = trsCodeOfPracticeLink;

    connectedCallback() {
        this.setTabSetVariant();
    }

    setTabSetVariant() {
        if (window.innerWidth <= 767) { 
            console.log('inside scope variant');
            this.tabSetVariant = 'scope';
        } else {
            console.log('inside vertical variant');
            this.tabSetVariant = 'vertical';
        }
    }

  /*  handleTabClick(event) {
        const tab = event.currentTarget.dataset.tab;
        this.selectedTab = tab;
        const tabChangeEvent = new CustomEvent('tabchange', { detail: tab });
        this.dispatchEvent(tabChangeEvent);
    }*/

    handleResize() {
        this.setTabSetVariant();
    }

    connectedCallback() {
        this.setTabSetVariant();
        window.addEventListener('resize', this.handleResize.bind(this));
    }

    disconnectedCallback() {
        window.removeEventListener('resize', this.handleResize.bind(this));
    }

    goToTRSCodeOfPractice() {
        window.open(this.trsCodeOfPractice, '_self');
    }
}