import { LightningElement,track,wire,api } from 'lwc';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getDepositInformation from '@salesforce/apex/EI_NI_TransferDeposit.getDepositInformation';
import getAgentLandlordTransferDetails from '@salesforce/apex/EI_NI_TransferDeposit.getAgentLandlordTransferDetails';
import getAgentLandlordEmailDetails from '@salesforce/apex/EI_NI_TransferDeposit.getAgentLandlordEmailDetails'; //TGK-634 :: Validation
import NI_CustodialDepositSummryUrl from '@salesforce/label/c.NI_CustodialDepositSummryUrl';


export default class EI_NI_TransferDepositToLandlord extends NavigationMixin (LightningElement) {
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    successImage = NI_Theme + '/assets/img/thank-you.png';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    @track showThankYouPage = false;
    @track isEmailvalidSection = false;
    depositId = '';
    depositList = [];
    @track depositInfo = [];
    loggedInUser = '';
    emailNotValid = false;
    isConfirmationPopUp = false;
    isEmailBlankError=false;
    isEmailFormatError = false;
    isSameAccountError = false;
    @track isSubmitDisabled = false;
    @track showSpinner = false;
    @wire(CurrentPageReference)
    currentPageReference;
    @track emailFieldValue ='';
    @track goToDepositUrl = NI_CustodialDepositSummryUrl;
    branchId=null;

    //TGK-634 : START
    @track isTransfertoAgent =false;
    @track isNewLandLordClick = false;
    @track typeOfAGLL = '';
    @track isEmailExistError = false;
    //TGK-634 : END

    connectedCallback() {

        var depositRecId = `${this.currentPageReference.state.depositId}`;
        console.log('DepositId::', depositRecId);
        this.depositId = atob(depositRecId);
        console.log('Decrypt DepositId:::', this.depositId);
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null) {
                this.branchId = window.atob(branchRecId);
            } else {
                this.branchId = null;
            }
                console.log('Transferred');
                
            }
    
        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            
        ]).then(() => {
            console.log('Files loaded');

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });      
        // const param = 'depositId';
        // this.depositId =atob(this.getUrlParamValue(window.location.href, param));
        // console.log('Decrypt DepositId:::', this.depositId);
        //getDepositInformation()
        getDepositInformation().then(result => {
            console.log('Deposit Wrapper Response:::', JSON.stringify(result));
            this.depositList = result.depositList;
            this.loggedInUser = result.loggedInUser;
            console.log('Deposit List: '+JSON.stringify(this.depositList));
            console.log('Logged In User: '+this.loggedInUser);
            console.log('User Profile: '+this.loggedInUser.Profile.Name);
            const selectedDeposit  = this.depositList.find(deposit => deposit.Id === this.depositId);
            if (selectedDeposit) {
                this.depositInfo = selectedDeposit;
                console.log('this.depositInfo:', JSON.stringify(this.depositInfo));
            } else {
                console.log('Deposit not found');
            }
        }).catch(error => {
            console.log('Error fetching post codes:::', JSON.stringify(error));
        })
    }



    goBackHandle(event) {
        event.preventDefault();
        var depId = `${this.currentPageReference.state.depositId}`;
        console.log('depId: '+depId);
        this.depositId = window.atob(depId);

        if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
            window.location = window.location.origin + this.goToDepositUrl + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
            //window.location = window.location.origin + '/ni/s/depositSummary?depositId=' + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
        }
        else{
            window.location = window.location.origin + this.goToDepositUrl + window.btoa(this.depositId);
            //window.location = window.location.origin + '/ni/s/depositSummary?depositId=' + window.btoa(this.depositId);

        }
            
    }
    handleEmailChange(event){
      
        this.emailFieldValue = event.target.value;
        console.log('email :'+this.emailFieldValue);
        console.log('email :'+emailFieldValue);
       
    }

    transferSingleDeposit(event){
        console.log('Submit clicked');
        event.preventDefault();
        console.log('email==>'+this.emailFieldValue);
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
        var isValid = true;
        if(this.emailFieldValue ==null || this.emailFieldValue == undefined || this.emailFieldValue == ''){
            this.isEmailBlankError=true;
            isValid = false;
        }        
        else{
            this.isEmailBlankError=false;
            this.isEmailFormatError = false;
        }
        if((this.emailFieldValue!='') && !this.emailFieldValue.match(regExpEmailformat)){
            this.isEmailFormatError = true;
            isValid= false;
        }
        else{
            this.isEmailFormatError = false;
        }

         
        if(isValid){
        var isValid2 = true;
        //this.showThankYouPage = true;
        //TGK-634 :: Check the entered email is Agent or Landlord :: START        
        var profilesNameForEnteredEmail = ['NI_Agent','NI_ Branch Users','NI_Head_Office_User','NI_Landlord'];
        //var landlordProfiles = ['NI_Landlord'];
        getAgentLandlordEmailDetails({emailValue:this.emailFieldValue,profilesNameForEnteredEmail:profilesNameForEnteredEmail})
        .then(result=>{
            console.log('result email transfer == ',result);
            this.typeOfAGLL = result;

            if(this.typeOfAGLL == 'No user found'){
                isValid2 = false;
                this.isEmailExistError = true;
            }
            else if(this.typeOfAGLL == 'Agent'){
                isValid2 = true;
                this.isEmailExistError = false;
                this.isTransfertoAgent =  true;
            }
            else if(this.typeOfAGLL == 'Landlord'){
                isValid2 = true;
                this.isEmailExistError = false;
                this.isTransfertoAgent = false;
            }
            if(isValid2){
                this.showThankYouPage = true;
            }
        })
        .catch(error=>{
            console.log('error while submitting transfer=>'+JSON.stringify(error));
        });
        //TGK-634 :: Check the entered email is Agent or Landlord :: END
           
        }
    }
    submitTransfers(event){
        event.preventDefault();
        this.showSpinner = true;

         //TGK-634 :: capture the details of new non member landlord :: START
         var newLandlordDetails = '';
         if(this.typeOfAGLL == 'Agent' && event.detail.landLordCreated != undefined && event.detail.landLordCreated != ''){
             newLandlordDetails = event.detail.landLordCreated; 
             var calledfrom = event.detail.calledfrom; 
             console.log('submit typeOfAGLLthis == ',this.typeOfAGLL);
     
             console.log('newLandlordDetails==> ',newLandlordDetails);
             console.log('calledfrom ==> ',calledfrom);
         }
         //TGK-634 :: capture the details of landlord :: END

        console.log('transfer confirm clicked');
        var listDepositId =[];
        listDepositId.push(this.depositId);
        console.log('transfer confirm clicked==>'+listDepositId);
        this.isSubmitDisabled = true;
        var listProfiles = ['NI_Agent','NI_Landlord','NI_ Branch Users','NI_Head_Office_User'];
        console.log('Profile Names: '+listProfiles);
        getAgentLandlordTransferDetails({emailValue:this.emailFieldValue,listDepositId:listDepositId, profileNamesList:listProfiles,scheme:'NI Custodial',
        typeOfAGLL:this.typeOfAGLL,newLandlordDetails:newLandlordDetails
        })
        .then(result=>{
            console.log('Result: '+result);
            console.log('Result: '+result);
            if(result=='same account'){
                this.isSameAccountError=true;
                // isValid = false;
                this.isSubmitDisabled = false;
                this.showSpinner = false;
                console.log('Transferred within same Account error');
                this.showThankYouPage = false;
            } if(result=='non member landlord') {
                this.isSameAccountError=true;
                // isValid = false;
                this.isSubmitDisabled = false;
                this.showSpinner = false;
                console.log('Transferred to non member landlord error');
                this.showThankYouPage = false;
            } else if(result=='transferred'){
                this.showSpinner = false;
                //this.showThankYouPage = true;
                event.preventDefault();
                var depId = `${this.currentPageReference.state.depositId}`;
                console.log('depId: '+depId);
                this.depositId = window.atob(depId);
                
                if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                    window.location = window.location.origin + this.goToDepositUrl + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                    //window.location = window.location.origin + '/ni/s/depositSummary?depositId=' + window.btoa(this.depositId)  + '&branchRecId=' + window.btoa(this.branchId) + '&showBranch=' + window.btoa('false');
                }
                else{
                    window.location = window.location.origin + this.goToDepositUrl + window.btoa(this.depositId);
                    //window.location = window.location.origin + '/ni/s/depositSummary?depositId=' + window.btoa(this.depositId);
                }
                this.isConfirmationPopUp = false;
                
                console.log('Transferred');
                
            }
            
        })
        .catch(error=>{
            console.log('error while submitting transfer=>'+JSON.stringify(error));
        });
    }
    handleConfirmDialogNo(event){
        this.showThankYouPage = false;
        this.emailFieldValue = '';

    }
    hideBootstrapErrors(event){ 
        var button_Name = event.target.name;
        switch (button_Name) { 
            case "emailBlank":
                this.isEmailBlankError=false;
            break;
            case "emailFormat":
                this.isEmailFormatError=false;
            break;
            case "sameAccount":
                this.isSameAccountError=false;
            break;
            case "emailNotExist":
                this.isEmailExistError=false;
            break;
        }
    }

}