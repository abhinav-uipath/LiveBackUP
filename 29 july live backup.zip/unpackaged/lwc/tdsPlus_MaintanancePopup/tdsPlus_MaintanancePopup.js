import { LightningElement ,wire,api} from 'lwc';
import { getContent } from "experience/cmsDeliveryApi";
import Maintainance_popup_window from '@salesforce/label/c.Maintenance_popup_window_tdsPlus';
import siteId from "@salesforce/site/Id";

export default class TdsPlus_MaintanancePopup extends LightningElement {

     //Add salesforce cms containt
     @api contentKey;
     data;
     popupcontain;
  
     @wire(getContent, { channelOrSiteId: siteId, contentKeyOrId: "$contentKey" })
     onGetContent(result) {
       if (result.data) {
         this.data = result.data;
         // console.log('line no:15'+result.data.title);
         console.log('line no:17'+result.data.contentBody.Subtitle);
         this.popupcontain=result.data.contentBody.Subtitle;  
   
       }
     }
 
      
   // Import the custom label
     label = {
         
         Maintainance_popup_window: Maintainance_popup_window,
         
        };
     // Getter to interpret the custom label as a boolean
     get isMaintainancePopupVisible() {
         return this.label.Maintainance_popup_window === 'true';
        
 
     }
 
 
 }