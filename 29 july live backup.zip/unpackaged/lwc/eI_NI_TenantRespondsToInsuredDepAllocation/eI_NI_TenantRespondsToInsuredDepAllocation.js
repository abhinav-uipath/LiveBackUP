import { LightningElement,track,wire } from 'lwc';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin,CurrentPageReference } from 'lightning/navigation';
import {loadStyle,loadScript} from 'lightning/platformResourceLoader';
import getCaseandDispiteItemsDetails from '@salesforce/apex/EI_NI_TenantRespondsInsuredDepProposal.getCaseandDispiteItemsDetails';
import updateCaseAgreetoAGLLbyTenant from '@salesforce/apex/EI_NI_TenantRespondsInsuredDepProposal.updateCaseAgreetoAGLLbyTenant';
import updateCaseNotAgreeAGLLButWishToSchemebyTenant from '@salesforce/apex/EI_NI_TenantRespondsInsuredDepProposal.updateCaseNotAgreeAGLLButWishToSchemebyTenant';
import updateCaseNotAgreeAGLLAndSchemeBothbyTenant from '@salesforce/apex/EI_NI_TenantRespondsInsuredDepProposal.updateCaseNotAgreeAGLLAndSchemeBothbyTenant';

export default class EI_NI_TenantRespondsToInsuredDepAllocation  extends NavigationMixin(LightningElement){
    homeImg= NI_Theme + '/assets/img/home_icon.png';
    pound_icon = NI_Theme +'/assets/img/pound_icon.png';
    successImage = NI_Theme +'/assets/img/circle_checked_icon.png';
    backBtnImg = NI_Theme + '/assets/img/md-arrow-dropleft.png';

    isAgreeToAGLLRequest = false;
    isNotAgreeButWishToScheme = false;
    isNotAgreeAndSchemeBoth = false;

    formattedEndDate ='';
    // Code started EID-137
    @track claimexceedamount;
    @track showclaimexceedamount = false;
    @track showclaimexceeddetails = false;
    // Code ended EID-137
    @track depositAmount = 0.00;
    @track amountToTenantByAGLL = 0.00;
    @track amountToTenantByTT = 0.00;
    @track depositAmountClaimedByAGLL = 0.00;
    @track depositAmountClaimedByTT = 0.00;
    @track agllName ='';
    @track disputeItems =[];

    @track isAgreedButtonDisabled = false;
    @track isSelfresButtonDisabled = false;
    @track isCourtCaseButtonDisabled = false;

    @track AmtToAgll=0.00;
    @track AmtToTenant = 0.00;
    
    @track tenancyEndDate;
    @track respondDate;
    @track tenantOtherReason ='';

    @track otherReason ='';
    @track isOtherReasonPresent = false;
    isShowMainRespondSection = true;
    isResponseToproposalSection = false;
    isShowAgreAndSchemeSection = false;

    @track otherAmtValidationError = false;
    @track otherAmtexplaError = false;

    isThankyouSection = false;
    isAgreeThankYou = false;
    isDoNotAgreeButSchmeThankYou = false;
    isDonotAgreeBothThankyou = false;
    PageSpinner = false;

    @track showIfClaimedMoreThenDepositAmount = false;

    @track depositRecId;
    @wire(CurrentPageReference)
    currentPageReference;
    connectedCallback(){
        var depositRecId = `${this.currentPageReference.state.depositId}`;
        this.depositRecId = atob(depositRecId);
      //  this.depositRecId = 'a0L25000005mdkd';
      console.log('depositId==>'+this.depositRecId);
        Promise.all([
            loadStyle(this, `${NI_Theme }/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme +'/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme +'/assets/js/custom.js')
        ])
        .then(() => {
            console.log('Files loaded.');
        })
        .catch(error => {
            console.log(error.body.message);
        });  
        getCaseandDispiteItemsDetails({depositId:this.depositRecId})
        .then(result=>{
            console.log('result=>'+JSON.stringify(result));
            if(result!= null){
                
                this.depositAmount = (result[0].Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2);
                this.depositAmountClaimedByAGLL = (result[0].Total_Claimed_by_Landlord__c).toFixed(2);
                this.amountToTenantByAGLL = (parseFloat(this.depositAmount)-parseFloat(this.depositAmountClaimedByAGLL)).toFixed(2);
                this.agllName = result[0].Deposit_Account_Number__r.Customer__r.Name;
                this.respondDate = formatDate(result[0].Respond_Date__c, "ddmmyy"); 
                this.tenancyEndDate = formatDate(result[0].Deposit_Account_Number__r.End_Date__c, "ddS mmmm yyyy");
                this.caseId = result[0].Id;
                console.log('CaseId==>'+this.caseId);
                // Code started EID-137
                this.claimexceedamount = result[0].Claim_exceed_amount__c;
                if( this.claimexceedamount > 0){
                    this.showclaimexceeddetails = true;
                    this.showclaimexceedamount = true;
                } else {
                    this.showclaimexceeddetails = false;
                    this.showclaimexceedamount = false;
                }
                // Code ended EID-137
            }   
                console.log('BranchIdLine(91)==>'+result[0].Agent_Branch__c);

            let aglldisputeItems = JSON.parse(JSON.stringify(result[0].Dispute_Items__r));
            for(let ind in aglldisputeItems ){
                // console.log('aglldisputeItems['+ind+'].Claimed_by_Landlord__c => ' + aglldisputeItems[ind].Claimed_by_Landlord__c.toFixed(2));
                aglldisputeItems[ind].Claimed_by_Landlord__c = (parseFloat(aglldisputeItems[ind].Claimed_by_Landlord__c)).toFixed(2);
                let itemType;
                if(aglldisputeItems[ind].Type__c.includes('Rent')){
                    itemType = 'Rent arrears'
                }
                else{
                    itemType = aglldisputeItems[ind].Type__c;
                }
                this.disputeItems.push({
                    key: itemType, 
                    value:{itemAmountbyAGLL: aglldisputeItems[ind].Claimed_by_Landlord__c, itemAmountbyTT: 0.00, isTTAmountMoreThenAgllAmount: false, claimItemId: aglldisputeItems[ind].Id}
                });
                if(aglldisputeItems[ind].Other_Reason__c != null && aglldisputeItems[ind].Other_Reason__c != undefined){
                    this.isOtherReasonPresent = true;
                    this.otherReason = aglldisputeItems[ind].Other_Reason__c;
                }
                else{
                    this.isOtherReasonPresent = false;
                }
            }

            function formatDate(dateString, format) {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) {
                  return "Invalid Date";
                }
                const day = date.getDate();
                const month = date.toLocaleString('default', { month: 'long' });
                const year = date.getFullYear();
                const suffix = getDaySuffix(day); // get the day suffix (st, nd, rd, th)
                if (format === "ddmmyy") {
                  const dayStr = String(day).padStart(2, '0');
                  const monthStr = String(date.getMonth() + 1).padStart(2, '0');
                  return `${dayStr}/${monthStr}/${year.toString()}`;
                } else if (format === "ddS mmmm yyyy") {
                  return `${day}${suffix} ${month} ${year}`;
                } else {
                  return "Invalid Format";
                }
              }
              
              function getDaySuffix(day) {
                if (day >= 11 && day <= 13) {
                  return "th";
                }
                switch (day % 10) {
                  case 1:
                    return "st";
                  case 2:
                    return "nd";
                  case 3:
                    return "rd";
                  default:
                    return "th";
                }
              }
        })
        .catch(error=>{
            console.log('error=>'+JSON.stringify(error));
            console.log('error@@=>'+error);
        })
    }
    restrictDecimal(event) {  
        let amtVal = event.target.value;
        return (amtVal.indexOf(".") >= 0) ? (amtVal.substr(0, amtVal.indexOf(".")) + amtVal.substr(amtVal.indexOf("."), 3)) : amtVal;
    }
    removeZero(event) {
        console.log('removeZero');
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
                s = s.substring(1,9999); 
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;
        
        if(trimeVal.includes('.')){
            var number = trimeVal.split('.');
            console.log('numbs '+number[1]);
            if(number[1].length>2)
            event.target.value = parseFloat(trimeVal).toFixed(2);
        }else{
            event.target.value = trimeVal;
        }
    }

    handleOtherReason(event){
        this.otherAmtValidationError = false;
        this.otherAmtexplaError = false;
        const OtherReasonTenant = event.target.value.trim();; 
        this.tenantOtherReason = OtherReasonTenant;
        console.log('otherreason=>'+this.tenantOtherReason);
        console.log('otherTextLength==>'+this.tenantOtherReason.length);
    }
    handleContinueProposal(event){
        this.isShowMainRespondSection = false;
        this.isResponseToproposalSection = true;
    }
    handleAgreeToAGLLRequest(event){
        event.preventDefault();
        this.isAgreeToAGLLRequest = true;
        this.isNotAgreeButWishToScheme = false;
        this.isNotAgreeAndSchemeBoth = false;
        
        this.template.querySelector('.agreebutton').classList.remove('disablebutton'); 
        this.template.querySelector('.selfresbutton').classList.add('disablebutton');
        this.template.querySelector('.courtcasebutton').classList.add('disablebutton');
    }
    handleSubmitAgreetoAGLLRequest(event){
        this.isSelfresButtonDisabled = true;
        this.isCourtCaseButtonDisabled = true;
        this.template.querySelector('.submit-btn-agree').classList.remove('bg-color-blue');
        this.template.querySelector('.submit-btn-agree').classList.add('disable_ew_btn');
        this.isSubmitBtnDisable = true;
        
        var claimedItemsDetailsObj = {};
        for(let ind in this.disputeItems){
            let detailsObj = {};
            detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
            detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;
            claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
            console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
        }
        console.log('otherAmt==>'+this.otherReason);
        var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
        // need to add an apex call for update case status > ‘Case closed - resolved without adjudication’
        updateCaseAgreetoAGLLbyTenant({caseId: this.caseId, 
            agreedAmount: this.depositAmountClaimedByAGLL,
            depositAmount: this.depositAmount,
            depositId: this.depositRecId,
            claimedItems:claimedItemsDetailsObjStr,
            otherReason: this.otherReason
        }).then(result => {
            console.log("updateCaseAgreetoAGLLbyTenant result => " + result);
            if(result=='Success'){
                this.isResponseToproposalSection = false;
                this.isThankyouSection = true;
                this.isAgreeThankYou = true;

            }
            
        }).catch(error => {
            console.log("updateCaseAgreetoAGLLbyTenant error => ", error);
        });
    }


    handleNotAgreeButWishToScheme(event){
        event.preventDefault();
        this.isAgreeToAGLLRequest = false;
        this.isNotAgreeButWishToScheme = true;
        this.isNotAgreeAndSchemeBoth = false;

        this.template.querySelector('.agreebutton').classList.add('disablebutton'); 
        this.template.querySelector('.selfresbutton').classList.remove('disablebutton');
        this.template.querySelector('.courtcasebutton').classList.add('disablebutton');
    }

    handleAmountToTenantByTTChange(event){
        this.otherAmtValidationError = false;
        this.otherAmtexplaError = false;
        this.showIfClaimedMoreThenDepositAmount = false;
        let val = this.restrictDecimal(event);
        event.target.value = val;
        this.amountToTenantByTT = event.target.value;
        console.log('amtToTTbyTT==>'+this.amountToTenantByTT);
    }
    handleCalculateClaimAmountByTT(event){
        this.otherAmtValidationError = false;
        this.otherAmtexplaError = false;
        this.showIfClaimedMoreThenDepositAmount = false;
        let val = this.restrictDecimal(event);
        console.log("handleCalculateClaimAmountByTT" + val);
        event.target.value = val;

        console.log("handleCalculateClaimAmountByTT" + event.target.value);
        let index = event.target.title;
        let claimItemValue = event.target.value;
        
        this.disputeItems[index].value.itemAmountbyTT = claimItemValue;

        if(claimItemValue > 0){
            if(parseFloat(this.disputeItems[index].value.itemAmountbyTT) > parseFloat(this.disputeItems[index].value.itemAmountbyAGLL)){
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = true;
            }else{
                this.disputeItems[index].value.isTTAmountMoreThenAgllAmount = false;
            }
        }

        // console.log(" on change disputeItems=> " + JSON.stringify(this.disputeItems));
        this.depositAmountClaimedByTT = 0;
        
        for(let ind in this.disputeItems ){
            console.log(" on change claimedItem => " + this.disputeItems[ind].value.itemAmountbyTT);
            if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT) + parseFloat(this.disputeItems[ind].value.itemAmountbyTT)).toFixed(2);
            }
        }
        console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
    }
    handleContinueNotAgreeButWishToScheme(event){
        this.isAgreedButtonDisabled = true;
        this.isCourtCaseButtonDisabled = true;

        this.isShowMainRespondSection = false;
        this.isResponseToproposalSection = false;
        this.isShowAgreAndSchemeSection = true;

    }
    handleClaimSubmit(event){
        if(this.amountToTenantByTT > 0){
            this.amountToTenantByTT = (parseFloat(this.amountToTenantByTT)).toFixed(2);
        }else{
            this.amountToTenantByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.amountToTenantByTT => " + this.amountToTenantByTT);

        if(this.depositAmountClaimedByTT > 0){
            this.depositAmountClaimedByTT = (parseFloat(this.depositAmountClaimedByTT)).toFixed(2);
        }else{
            this.depositAmountClaimedByTT = (parseFloat(0.00)).toFixed(2);
        }
        console.log("this.depositAmountClaimedByTT => " + this.depositAmountClaimedByTT);
        console.log("this.amountToTenantByTT + this.depositAmountClaimedByTT => " + (( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)));
        let isValid = true;
        if((( parseFloat(this.amountToTenantByTT) + parseFloat(this.depositAmountClaimedByTT) ).toFixed(2)) != (parseFloat(this.depositAmount).toFixed(2))){
            this.showIfClaimedMoreThenDepositAmount = true;
            isValid = false;
        }else{
            this.showIfClaimedMoreThenDepositAmount = false;
        }
            //let isValid = true;
            // need to do a server call for update case status to 'Self-resolution' and update claimed amount of tenant on dispute Items
            var claimedItemsDetailsObj = {};
            for(let ind in this.disputeItems){
                if(parseFloat(this.disputeItems[ind].value.itemAmountbyTT) > parseFloat(this.disputeItems[ind].value.itemAmountbyAGLL)){
                    isValid = false;
                    this.disputeItems[ind].value.isTTAmountMoreThenAgllAmount = true;
                    this.template.querySelector(".moreamounterror").scrollIntoView();
                }
                
                console.log("key => " + this.disputeItems[ind].key);
                console.log("value => " + JSON.stringify(this.disputeItems[ind].value));
                let detailsObj = {};
                detailsObj['itemAmountbyAGLL'] = this.disputeItems[ind].value.itemAmountbyAGLL;
                if(this.disputeItems[ind].value.itemAmountbyTT > 0){
                    detailsObj['itemAmountbyTT'] = this.disputeItems[ind].value.itemAmountbyTT;
                }else{
                    detailsObj['itemAmountbyTT'] = 0.00;
                }
                detailsObj['claimItemId'] = this.disputeItems[ind].value.claimItemId;

                claimedItemsDetailsObj[this.disputeItems[ind].key] = detailsObj;
                console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
            }
            var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
            if(claimedItemsDetailsObj['Other']!= null){

                let otherValue =claimedItemsDetailsObj['Other']['itemAmountbyTT'];
                if (otherValue && otherValue.trim) {
                    otherValue = otherValue.trim();
                }
                console.log('748');
                console.log(typeof otherValue); 
                console.log('750');
                let othervalueByTenant = parseFloat(otherValue);
                console.log('amtToAgLL by tenant000==>'+otherValue+'floatvalue==>'+othervalueByTenant);
                
                if(othervalueByTenant > 0 && (this.tenantOtherReason ==""|| this.tenantOtherReason == undefined || this.tenantOtherReason == null)){
                    // alert('other reason ');
                     this.otherAmtValidationError = true;
                     isValid = false;
                     
                 }
                 else{
                     this.otherAmtValidationError = false;
                     
                 }
                 if(othervalueByTenant > 0 &&this.tenantOtherReason.length >300){
                    this.otherAmtexplaError = true;
                    isValid = false;

                }
                else{
                    this.otherAmtexplaError = false;
                    
                }
            }
            if(isValid){
                this.isDisableSubmitBtn = true;
                this.showIfClaimedMoreThenDepositAmount = false;
                this.PageSpinner = true;
                // this.template.querySelector('.submit-btn').classList.remove('blue_theme');
                // this.template.querySelector('.submit-btn').classList.add('disable_ew_btn');
                console.log('Line==>319');
                //alert('isValid!!!')
                updateCaseNotAgreeAGLLButWishToSchemebyTenant({caseId: this.caseId, amountToTTbyTT: this.amountToTenantByTT, 
                    depositId: this.depositRecId, claimedItems: claimedItemsDetailsObjStr,otherReason: this.tenantOtherReason}) 
                .then(result=>{
                    console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant result => ' + result);
                    if(result == 'Successfully updated'){
                        this.PageSpinner = false;
                        this.isShowAgreAndSchemeSection = false;
                        this.isThankyouSection = true;
                        this.isDoNotAgreeButSchmeThankYou = true;
                    }
                }).catch(error=>{
                    console.log('updateCaseNotAgreeAGLLButWishToSchemebyTenant error => ' + JSON.stringify(error));
                })
            }
       // }
    }
    handleNotAgreeAndSchemeBoth(event){
        event.preventDefault();
        this.isAgreeToAGLLRequest = false;
        this.isNotAgreeButWishToScheme = false;
        this.isNotAgreeAndSchemeBoth = true;

        this.template.querySelector('.agreebutton').classList.add('disablebutton'); 
        this.template.querySelector('.selfresbutton').classList.add('disablebutton');
        this.template.querySelector('.courtcasebutton').classList.remove('disablebutton');
    }
    handleSubmitNotAgreeAndSchemeBoth(event){
        this.isAgreedButtonDisabled = true;
        this.isSelfresButtonDisabled = true;
        this.template.querySelector('.submit-btn-notagree').classList.remove('bg-color-blue');
        this.template.querySelector('.submit-btn-notagree').classList.add('disable_ew_btn');
        this.isSubmitBtnDisable = true;
        // need to add an apex call for update case status > ’Consent to resolution not given'. 
        updateCaseNotAgreeAGLLAndSchemeBothbyTenant({caseId: this.caseId, 
            agreedAmount: this.depositAmountClaimedByAGLL,
            depositAmount: this.depositAmount,
            depositId: this.depositRecId
        }).then(result => {
            console.log("updateCaseNotAgreeAGLLAndSchemeBothbyTenant result => " + result);
            if(result=='Success'){
                this.isResponseToproposalSection = false;
                this.isThankyouSection = true;
                this.isDonotAgreeBothThankyou = true;
            }
           
        }).catch(error => {
            console.log("updateCaseNotAgreeAGLLAndSchemeBothbyTenant error => ", error);
        });
    }
    handleGoBack(event){
        event.preventDefault();
        this.isShowAgreAndSchemeSection = false;
        this.isShowMainRespondSection = false;
        this.isResponseToproposalSection = true;
        this.isAgreedButtonDisabled = false;
        this.isCourtCaseButtonDisabled = false;
        this.isSelfresButtonDisabled = false;
        this.isNotAgreeButWishToScheme = false;
        
    }
    goBackToSummaryPageHandle(event){
        event.preventDefault();
        window.history.back();

    }
}