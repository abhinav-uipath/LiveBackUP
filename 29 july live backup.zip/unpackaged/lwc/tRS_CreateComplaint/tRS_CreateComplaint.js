import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import registerComplaint from '@salesforce/apex/TRS_ComplaintRegistrationHelper.registerComplaintFromLandlordPortal';
import findAddress from '@salesforce/apex/TRS_LoqateServiceForSite.findAddress';
import retrieveAddress from '@salesforce/apex/TRS_LoqateServiceForSite.retrieveAddress';

import addressloqate from '@salesforce/label/c.NHOS_AddressLoqateKey';

const APIKEY = addressloqate;
const MAX_CHARACTER_LIMIT = 2000;

export default class TRS_CreateComplaint extends NavigationMixin(LightningElement) {

    trsCaseReferenceNumber = '';
    navigateTo;

    currentpage = 0;
    maxCharacterLimit = 2000;
    remainingCharacters = this.maxCharacterLimit;

    showSpinner = false;
    showCancelComplaintButton = true;

    searchTerm = '';
    searchTermDup = '';

    foundAddresses;
    selectedAddress;
    encodedKey;

    apiId = APIKEY;

    otherIsSelected = false;

    page0 = true;
    page1 = true;
    page2 = false;
    page3 = false;
    page4 = false;
    page5preview = false;
    pagefinal = false;
    tillQuestion4 = true;
    tillQuestion5 = false;
    checkedOrNot = false;
    agreedCheckbox1 = false;
    agreedCheckbox2 = false;
    showErrorMsg1 = false;
    sameCurrentAddress = false;
    showHelpandAnswers = false;

    isErrorMessageVisible = true;

    activeSectionMessage = '';
    activeSections = ['A'];

    isNextButtonDisabled = true;
    isSubmitdisabled = true;

    tippage2 = 'In order to support your dispute we need the name and contact details of your tenant.<br/><br/> Without these we will be unable to contact the tenant on your behalf.<br/><br/> You should be able to locate the tenants details on you tenancy agreement.';
    tippage3 = 'We need to know that we have the correct property address when talking to the tenant.';

    save2Valid = false;
    save3Valid = false;
    save4Valid = false;
    save5Valid = false;
    showAccordion = false;

    commitLandlordDetails = {
        'Q1': { 'value': null, 'position': false, 'previewediting': false },
        'Q2': { 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false },
        'Q4': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false },
        'Q5': { 'position': false, 'previewediting': false, 'buttonediting': false },
    };

    @track landlordDetails = {
        'Q1': { 'value': null, 'position': false, 'previewediting': false },
        'Q2': { 'position': false, 'previewediting': false },
        'Q3': { 'position': false, 'previewediting': false },
        'Q4': { 'SelectedCheckboxes': [], 'position': false, 'previewediting': false },
        'Q5': { 'position': false, 'previewediting': false, 'buttonediting': false },
    };

    constructor() {
        super();
    }

    listenForMessage(message) {
        // console.log('message data : ' + message.data);//message.data - The object passed from the other window.
        // console.log('message origin : ' + message.origin);//message.origin - The origin of the window that sent the message at the time postMessage was called.
    }

    get options1() {
        return [
            { label: 'Yes', value: 'Yes' },
            { label: 'No', value: 'No' },
        ];
    }

    get complaintTypeOptions() {
        return [
            { label: 'Marketing of the tenancy', value: 'Marketing of the tenancy' },
            { label: 'Tenancy terms', value: 'Tenancy terms' },
            { label: 'Property standards', value: 'Property standards' },
            { label: 'Repairs', value: 'Repairs' },
            { label: 'Entry rights', value: 'Entry rights' },
            { label: 'Rent arrears', value: 'Rent arrears' },
            { label: 'Threatened evictions', value: 'Threatened evictions' },
            { label: 'Breach of tenancy terms', value: 'Breach of tenancy terms' },
            { label: 'GDPR', value: 'GDPR' },
            { label: 'Communications', value: 'Communications' },
            { label: 'Noise/Anti-Social behaviour', value: 'Noise/Anti-Social behaviour' },
            { label: 'Other', value: 'Other' }

            // { label: 'Rent arrears', value: 'Rent arrears' },
            // { label: 'Access issues', value: 'Access issues' },
            // { label: 'Cleaning issues', value: 'Cleaning issues' },
            // { label: 'Gardening issues', value: 'Gardening issues' },
            // { label: 'Repair / damage issues', value: 'Repair / damage issues' },
            // { label: 'Other', value: 'Other' }
        ];
    }

    handlepage5Checkbox(event) {
        if (event.target.dataset.name == 'q5checkbox1') {
            this.agreedCheckbox1 = event.target.checked;
        } else if (event.target.dataset.name == 'q5checkbox2') {
            this.agreedCheckbox2 = event.target.checked;
        }

        if (this.agreedCheckbox1 && this.agreedCheckbox2) {
            this.isSubmitdisabled = false;
        } else {
            console.log('inside 2 false ');
            this.isSubmitdisabled = true;
        }
    }

    handleSubmitValidation() {
        if (this.agreedCheckbox1 && this.agreedCheckbox2 && this.validateAreasOfComplaintDetailsSubmission2()) {
            this.isSubmitdisabled = false;
        } else {
            console.log('inside 2 false ');
            this.isSubmitdisabled = true;
        }
    }

    handleAllChanges(event) {
        if (event.target.dataset.name == 'q1radio') {
            this.landlordDetails.Q1.value = event.target.value;
            this.validateInputFirst();
        } else if (event.target.name == 'q5firstname') {
            this.landlordDetails.Q5.LandlordFirstName = event.target.value;
            this.landlordDetails.Q5.LandlordFirstName = this.landlordDetails.Q5.LandlordFirstName.trim();
            this.landlordNameEmailValidationQ5();

            this.landlordDetails.Q5.position = true;
        } else if (event.target.name == 'q5lastname') {
            this.landlordDetails.Q5.LandlordLastName = event.target.value;
            this.landlordDetails.Q5.LandlordLastName = this.landlordDetails.Q5.LandlordLastName.trim();
            this.landlordNameEmailValidationQ5();

            this.landlordDetails.Q5.position = true;
        } else if (event.target.name == 'q5email') {
            this.landlordDetails.Q5.LandlordEmail = event.target.value;
            this.landlordNameEmailValidationQ5();

            this.landlordDetails.Q5.position = true;
        } else if (event.target.name == 'q5phone') {
            this.landlordDetails.Q5.LandlordPhone = event.target.value;
            this.landlordNameEmailValidationQ5();

            this.landlordDetails.Q5.position = true;
        } else if (event.target.name == 'q2firstname') {
            this.landlordDetails.Q2.FirstName = event.target.value;
            this.landlordDetails.Q2.FirstName = this.landlordDetails.Q2.FirstName.trim();
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        } else if (event.target.name == 'q2lastname') {
            this.landlordDetails.Q2.LastName = event.target.value;
            this.landlordDetails.Q2.LastName = this.landlordDetails.Q2.LastName.trim();
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        } else if (event.target.name == 'q2email') {
            this.landlordDetails.Q2.Email = event.target.value;
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        } else if (event.target.name == 'q2phone') {
            this.landlordDetails.Q2.Phone = event.target.value;
            this.detailsValidation();

            this.landlordDetails.Q2.position = true;
        } else if (event.target.name == 'q3propstreetname') {
            console.log('property 1 - ' + event.target.value);
            this.landlordDetails.Q3.PropStreetName = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3proptowncity') {
            console.log('property 2 - ' + event.target.value);
            this.landlordDetails.Q3.PropAddTownCity = event.target.value;

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3propcounty') {
            console.log('property 3 - ' + event.target.value);
            this.landlordDetails.Q3.PropCounty = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3proppostcode') {
            console.log('property 4 - ' + event.target.value);
            this.landlordDetails.Q3.PropAddPostCode = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3propbasecountry') {
            console.log('property 3 - ' + event.target.value);
            this.landlordDetails.Q3.PropBaseCountry = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3propcountry') {
            console.log('property 6 - ' + event.target.value);
            this.landlordDetails.Q3.PropAddCountry = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.dataset.name == 'q3checkbox') {
            console.log(' 7  - ', event.target.checked);
            this.landlordDetails.Q3.SameCurrentAdd = event.target.checked;

            if (this.landlordDetails.Q3.SameCurrentAdd == true) {
                this.sameCurrentAddress = true;
            } else {
                this.sameCurrentAddress = false;
            }
            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currstreetname') {
            console.log(' 1 - ' + event.target.value);
            this.landlordDetails.Q3.CurrStreetName = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currtowncity') {
            console.log(' 2 - ' + event.target.value);
            this.landlordDetails.Q3.CurrAddTownCity = event.target.value;

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currcounty') {
            console.log(' 3 - ' + event.target.value);
            this.landlordDetails.Q3.CurrCounty = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currpostcode') {
            console.log(' 4 - ' + event.target.value);
            this.landlordDetails.Q3.CurrAddPostCode = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currbasecountry') {
            console.log(' 3 - ' + event.target.value);
            this.landlordDetails.Q3.CurrBaseCountry = event.target.value;
            this.addressValidation();

            this.landlordDetails.Q3.position = true;
        } else if (event.target.name == 'q3currcountry') {
            console.log(' 6 - ' + event.target.value);
            this.landlordDetails.Q3.CurrAddCountry = event.target.value;

            this.landlordDetails.Q3.position = true;
        } else if (event.target.dataset.name == 'multicheckbox') {
            this.setAreasOfComplaintsSummaryDynamically(event.detail.value);
            this.selectedComplaintTypes = event.detail.value;

            this.landlordDetails.Q4.SelectedCheckboxes = event.detail.value;
            if(this.landlordDetails.Q4.SelectedCheckboxes.includes('Other')) {
                this.otherIsSelected = true;
            } else {
                this.otherIsSelected = false;
            }
            this.landlordDetails.Q4.position = true;
            this.fourthValidation();

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
            }
        } else if (event.target.dataset.name == 'multicheckbox2') {
            this.setAreasOfComplaintsSummaryDynamically2(event.detail.value);
            this.commitSelectedComplaintTypes = event.detail.value;

            this.landlordDetails.Q4.SelectedCheckboxes = event.detail.value;
            if(this.landlordDetails.Q4.SelectedCheckboxes.includes('Other')) {
                this.otherIsSelected = true;
            } else {
                this.otherIsSelected = false;
            }
            this.landlordDetails.Q4.position = true;
            this.fourthValidation();

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }
        } else if (event.target.name == 'q4text') {
            this.landlordDetails.Q4.ComplaintDetail = event.detail.value;
            this.landlordDetails.Q4.position = true;

            this.remainingCharacters = this.maxCharacterLimit - this.landlordDetails.Q4.ComplaintDetail.length;
            if (this.remainingCharacters <= 0) {
                this.isErrorMessageVisible = false;
            } else {
                this.isErrorMessageVisible = true;
            }

            this.fourthValidation();
        } else if (event.target.name == 'q4otherselected') {
            this.landlordDetails.Q4.OtherSelectedValue = event.detail.value;
            this.landlordDetails.Q4.position = true;
            this.fourthValidation();
        }
    }

    selectedComplaintTypes = [];
    commitSelectedComplaintTypes = [];

    @track complaintSummaryDetails = [];
    @track commitComplaintSummaryDetails = [];
    @track tempComplaintSummaryDetails = [];

    setAreasOfComplaintsSummaryDynamically(selectedCheckBoxes) {
        try {
            this.complaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));

            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.complaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.complaintSummaryDetails[i].complaintType));
                        if(this.complaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.complaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.complaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.complaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.complaintSummaryDetails;
            console.log('complaint : '+JSON.stringify(this.complaintSummaryDetails));
        } catch (error) {
            console.log('error in setAreasOfComplaintsSummaryDynamically2 : ' + error);
        }
    }

    setAreasOfComplaintsSummaryDynamically2(selectedCheckBoxes) {
        try {
            this.commitComplaintSummaryDetails = selectedCheckBoxes.map(element => ({
                complaintType: element,
                complaintSummary: '',
                remainingCharacterCount: MAX_CHARACTER_LIMIT
            }));

            if(this.tempComplaintSummaryDetails.length > 0) {
                for(var i=0; i<this.commitComplaintSummaryDetails.length; i++) {
                    for(var k=0; k<this.tempComplaintSummaryDetails.length; k++) {
                        console.log('data : '+JSON.stringify(this.tempComplaintSummaryDetails[k]));
                        console.log('k : '+JSON.stringify(this.tempComplaintSummaryDetails[k].complaintType));
                        console.log('i : '+JSON.stringify(this.commitComplaintSummaryDetails[i].complaintType));
                        if(this.commitComplaintSummaryDetails[i].complaintType != undefined && this.tempComplaintSummaryDetails[k].complaintType != undefined) {
                            if(this.commitComplaintSummaryDetails[i].complaintType == this.tempComplaintSummaryDetails[k].complaintType) {
                                this.commitComplaintSummaryDetails[i].complaintSummary = this.tempComplaintSummaryDetails[k].complaintSummary;
                                this.commitComplaintSummaryDetails[i].remainingCharacterCount = MAX_CHARACTER_LIMIT - this.tempComplaintSummaryDetails[k].complaintSummary.length;
                            }
                        }
                    }
                }
            }
            
            this.tempComplaintSummaryDetails = this.commitComplaintSummaryDetails;
            console.log('complaint : '+JSON.stringify(this.commitComplaintSummaryDetails));
        } catch (error) {
            console.log('error in setAreasOfComplaintsSummaryDynamically2 : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;
            console.log('complaint type : ' + COMPLAINT_TYPE + ', field value : ' + VALUE+', index : '+INDEX);
            this.complaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.complaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;
            console.log('summary details : ' + JSON.stringify(this.complaintSummaryDetails));
            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
            }
            JSON.stringify(this.complaintSummaryDetails)
        } catch (error) {
            console.log('error in handleAreasOfComplaintSummaryDetailsChange : ' + error);
        }
    }

    handleAreasOfComplaintSummaryDetailsChange2(event) {
        try {
            const COMPLAINT_TYPE = event.target.dataset.item;
            const VALUE = event.target.value;
            const INDEX = event.target.dataset.index;
            console.log('complaint type : ' + COMPLAINT_TYPE + ', field value : ' + VALUE+', index : '+INDEX);
            this.commitComplaintSummaryDetails[INDEX].complaintSummary = VALUE;
            this.commitComplaintSummaryDetails[INDEX].remainingCharacterCount = MAX_CHARACTER_LIMIT - VALUE.length;
            console.log('summary details : ' + JSON.stringify(this.commitComplaintSummaryDetails));
            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
                //this.handleAOCApexClass();
            } else {
                this.isNextButtonDisabled = true;
            }
            this.handleSubmitValidation();
            JSON.stringify(this.commitComplaintSummaryDetails)
        } catch (error) {
            console.log('error in handleAreasOfComplaintSummaryDetailsChange2 : ' + error);
        }
    }

    validateAreasOfComplaintDetailsSubmission() {
        let isValid = true;

        if(this.selectedComplaintTypes == []) {
            isValid = false;
        }

        this.complaintSummaryDetails.forEach((element) => {
            console.log('element : '+JSON.stringify(element));
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateAreasOfComplaintDetailsSubmission2() {
        let isValid = true;

        if(this.commitSelectedComplaintTypes == []) {
            isValid = false;
        }

        this.commitComplaintSummaryDetails.forEach((element) => {
            console.log('element : '+JSON.stringify(element));
            if(element.complaintSummary == '' || element.complaintSummary == null) {
                isValid = false;
            }
        });
        return isValid;
    }

    /*handleAOCApexClass() {
        areasOfComplaintDetails({ areasOfComplaintDetails: JSON.stringify(this.complaintSummaryDetails) })
            .then(result => {
                console.log('result : ' + result);
            })
            .catch(error => {
                console.log('error : '+error);
            });
        
        postTenantFormData({ tenantDet: JSON.stringify(this.commitTenantDetails), areasOfComplaintDetails: JSON.stringify(this.complaintSummaryDetails) })
            .then(result => {
                console.log('result : ' + result);
            })
            .catch(error => {
                console.log('error : ' + error);
            });
    }*/

    validateInputFirst() {
        if (this.landlordDetails.Q1.value == 'No') {
            this.showErrorMsg1 = true;
            this.tillQuestion4 = false;
        } else if (this.landlordDetails.Q1.value == '' || this.landlordDetails.Q1.value == undefined || this.landlordDetails.Q1.value == null) {
            this.isNextButtonDisabled = true;
            this.tillQuestion4 = true;
        } else {
            this.showErrorMsg1 = false;
            this.isNextButtonDisabled = false;
            this.tillQuestion4 = true;
        }
    }

    landlordNameEmailValidationQ5() {

        var fullNameCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailPhonecorrect = false;
        var phonecorrect = false;

        if (this.landlordDetails.Q5.LandlordFirstName != '' && this.landlordDetails.Q5.LandlordFirstName != undefined) {


            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q5.LandlordFirstName)) {

                let searchCmp2 = this.template.querySelector(".firstnameCmp5");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid first name");
                }
                //this.errorMessage = 'Please enter a valid name';
                firstNameCorrect = false;
                // console.log('incorrect con name');
            }
            else {
                let searchCmp2 = this.template.querySelector(".firstnameCmp5");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }
                firstNameCorrect = true;
            }

        }

        if (this.landlordDetails.Q5.LandlordLastName != '' && this.landlordDetails.Q5.LandlordLastName != undefined) {

            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;

            if (!pattern.test(this.landlordDetails.Q5.LandlordLastName)) {

                let searchCmp = this.template.querySelector(".lastnameCmp5");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid last name");
                }

                lastNameCorrect = false;
            } else {

                let searchCmp = this.template.querySelector(".lastnameCmp5");

                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
                lastNameCorrect = true;
            }

            // if(firstNameCorrect && lastNameCorrect){
            //     fullNameCorrect = true;
            // }else{
            //     fullNameCorrect = false;

            // }

        }
        // console.log('email 1- ')
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        // console.log('email 2- ')
        const phoneRegex = /^[0-9]{10}$/; // Regular expression for a 10-digit phone number

        if (this.landlordDetails.Q5.LandlordEmail != '' && this.landlordDetails.Q5.LandlordEmail != undefined && emailRegex.test(this.landlordDetails.Q5.LandlordEmail)) {
            emailPhonecorrect = true;
            // console.log('emailPhonecorrect -- ' + emailPhonecorrect);
        }

        if (this.landlordDetails.Q5.LandlordPhone != null && this.landlordDetails.Q5.LandlordPhone != undefined) {
            if (!phoneRegex.test(this.landlordDetails.Q5.LandlordPhone) && this.landlordDetails.Q5.LandlordPhone.length < 10) {
                let searchCmp4 = this.template.querySelector(".phoneCmp5");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("Please enter a valid phone number");
                }
                phonecorrect = false;

            }
            else {
                let searchCmp4 = this.template.querySelector(".phoneCmp5");
                if (searchCmp4) {
                    searchCmp4.setCustomValidity("");
                }
                phonecorrect = true;

            }
        }

        if (this.landlordDetails.Q5.LandlordEmail != null && this.landlordDetails.Q5.LandlordEmail != undefined) {
            if (!emailRegex.test(this.landlordDetails.Q5.LandlordEmail)) {
                let searchCmp5 = this.template.querySelector(".emailCmp5");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                let searchCmp5 = this.template.querySelector(".emailCmp5");
                if (searchCmp5) {
                    searchCmp5.setCustomValidity("");
                }
            }
        }

        //if ((emailPhonecorrect && fullNameCorrect && phonecorrect)) {
        if ((emailPhonecorrect && firstNameCorrect && lastNameCorrect)) {
            // console.log('inside 223');
            this.isNextButtonDisabled = false;
            this.save5Valid = true;
        } else {
            // console.log('inside 226');
            this.isNextButtonDisabled = true;
            this.save5Valid = false;
        }
    }

    detailsValidation() {

        var fullNameCorrect = false;
        var firstNameCorrect = false;
        var lastNameCorrect = false;
        var emailPhonecorrect = false;

        if (this.landlordDetails.Q2.FirstName != '' && this.landlordDetails.Q2.FirstName != undefined) {

            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q2.FirstName)) {

                let searchCmp2 = this.template.querySelector(".firstnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid first name");
                }

                firstNameCorrect = false;
            } else {
                let searchCmp2 = this.template.querySelector(".firstnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }

                firstNameCorrect = true;
            }
        }

        if (this.landlordDetails.Q2.LastName != '' && this.landlordDetails.Q2.LastName != undefined) {

            const pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            if (!pattern.test(this.landlordDetails.Q2.LastName)) {

                let searchCmp2 = this.template.querySelector(".lastnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("Please enter a valid last name");
                }
                lastNameCorrect = false;
            } else {
                let searchCmp2 = this.template.querySelector(".lastnameCmp2");
                if (searchCmp2) {
                    searchCmp2.setCustomValidity("");
                }

                lastNameCorrect = true;
            }

            // if(firstNameCorrect && lastNameCorrect){
            //     fullNameCorrect = true;
            // }else{
            //     fullNameCorrect = false;
            // }
        }

        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        const phoneRegex = /^0\d{10}$/;
        // const phoneRegex = /^[0-9]{10}$/; // Regular expression for a 10-digit phone number

        if ((this.landlordDetails.Q2.Email != '' && this.landlordDetails.Q2.Email != undefined && emailRegex.test(this.landlordDetails.Q2.Email) && (this.landlordDetails.Q2.Phone == '' || this.landlordDetails.Q2.Phone == undefined))
            || (this.landlordDetails.Q2.Phone != '' && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone.length == 11 && phoneRegex.test(this.landlordDetails.Q2.Phone) && (this.landlordDetails.Q2.Email == '' || this.landlordDetails.Q2.Email == undefined))
            || (this.landlordDetails.Q2.Email != '' && this.landlordDetails.Q2.Email != undefined && emailRegex.test(this.landlordDetails.Q2.Email) && this.landlordDetails.Q2.Phone != '' && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone.length == 11 && phoneRegex.test(this.landlordDetails.Q2.Phone))
        ) {
            emailPhonecorrect = true;
        } else {
            emailPhonecorrect = false;
        }

        if (this.landlordDetails.Q2.Phone != null && this.landlordDetails.Q2.Phone != undefined && this.landlordDetails.Q2.Phone != '') {
            if (!phoneRegex.test(this.landlordDetails.Q2.Phone)) {
                let searchCmp = this.template.querySelector(".phoneCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid 11 digit phone number starting with 0 and without spaces");
                }
            } else {
                let searchCmp = this.template.querySelector(".phoneCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        } else if (this.landlordDetails.Q2.Phone == '') {
            this.template.querySelector(".phoneCmp2").setCustomValidity("");
        }

        if (this.landlordDetails.Q2.Email != null && this.landlordDetails.Q2.Email != undefined) {
            if (!emailRegex.test(this.landlordDetails.Q2.Email)) {
                // console.log('In ewww for q3')
                let searchCmp = this.template.querySelector(".emailCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("Please enter a valid email");
                }
            }
            else {
                // console.log('In wwqwqwqwqw for q3')
                let searchCmp = this.template.querySelector(".emailCmp2");
                if (searchCmp) {
                    searchCmp.setCustomValidity("");
                }
            }
        }

        // console.log('emailPhonecorrect -- '+emailPhonecorrect+', fullNameCorrect -- '+fullNameCorrect );
        if (emailPhonecorrect && firstNameCorrect && lastNameCorrect) {
            // console.log('inside 223');
            this.isNextButtonDisabled = false;
            this.save2Valid = true;
        } else {
            // console.log('inside 226');
            this.isNextButtonDisabled = true;
            this.save2Valid = false;
        }
    }

    addressValidation() {
        this.isNextButtonDisabled = true;
        this.save3Valid = true;

        if (this.landlordDetails.Q3.PropStreetName == '' || this.landlordDetails.Q3.PropStreetName == null ||
            this.landlordDetails.Q3.PropAddTownCity == '' || this.landlordDetails.Q3.PropAddTownCity == null ||
            this.landlordDetails.Q3.PropAddPostCode == '' || this.landlordDetails.Q3.PropAddPostCode == null ||
            this.landlordDetails.Q3.PropBaseCountry == '' || this.landlordDetails.Q3.PropBaseCountry == null ||
            this.landlordDetails.Q3.PropAddCountry == '' || this.landlordDetails.Q3.PropAddCountry == null) {
            this.isNextButtonDisabled = true;
            this.landlordDetails.Q3.position = false;
        } else {
            this.isNextButtonDisabled = false;
            this.landlordDetails.Q3.position = true;
        }
    }

    fourthValidation() {

        if (this.landlordDetails.Q4.SelectedCheckboxes != [] && this.landlordDetails.Q4.SelectedCheckboxes != '' && this.landlordDetails.Q4.ComplaintDetail != undefined && this.landlordDetails.Q4.ComplaintDetail != '') {
            if (this.landlordDetails.Q4.SelectedCheckboxes.length >= 1 && this.landlordDetails.Q4.ComplaintDetail != '') {
                this.isNextButtonDisabled = false;
                this.save4Valid = true;
            } else {
                this.isNextButtonDisabled = true;
                this.save4Valid = false;
            }
        } else if ((this.landlordDetails.Q4.SelectedCheckboxes != [] || this.landlordDetails.Q4.SelectedCheckboxes != '') && (this.landlordDetails.Q4.ComplaintDetail == undefined || this.landlordDetails.Q4.ComplaintDetail == '')) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        } else if ((this.landlordDetails.Q4.SelectedCheckboxes == [] || this.landlordDetails.Q4.SelectedCheckboxes == '') && (this.landlordDetails.Q4.ComplaintDetail != undefined || this.landlordDetails.Q4.ComplaintDetail != '')) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        }

        if ((this.landlordDetails.Q4.SelectedCheckboxes == [] && (this.landlordDetails.Q4.ComplaintDetail == undefined || this.landlordDetails.Q4.ComplaintDetail == '')) && this.currentpage == 4) {
            this.isNextButtonDisabled = true;
            this.save4Valid = false;
        }

        if(this.otherIsSelected == true) {
            if(this.otherIsSelected == true && this.landlordDetails.Q4.SelectedCheckboxes.length >= 1 && (this.landlordDetails.Q4.OtherSelectedValue == '' || this.landlordDetails.Q4.OtherSelectedValue == undefined || this.landlordDetails.Q4.OtherSelectedValue == null)) {
                this.isNextButtonDisabled = true;
                this.save4Valid = false;
            }
        }
    }

    handleNext() {
        window.scrollTo(0, 0);
        
        this.currentpage++;
        this.isNextButtonDisabled = true;

        if (this.currentpage == 1) {
            this.currentpage++;
        }

        if (this.currentpage == 1 || this.currentpage == 2 || this.currentpage == 3 || this.currentpage == 4) {
            this.showHelpandAnswers = true;
        } else {
            this.showHelpandAnswers = false;
        }

        if (this.currentpage == 5) {
            this.tillQuestion4 = false;
            this.tillQuestion5 = true;

            //update commit details
            this.commitSelectedComplaintTypes = [];
            this.commitComplaintSummaryDetails = [];

            this.commitSelectedComplaintTypes = this.selectedComplaintTypes;
            this.commitComplaintSummaryDetails = this.complaintSummaryDetails;
        }

        if (this.currentpage == 0) {
            this.validateInputFirst();
        }

        if (this.currentpage == 1) {
            this.landlordNameEmailValidationQ5();
        }

        if (this.currentpage == 2) {
            this.detailsValidation();
        }

        if (this.currentpage == 3) {
            this.addressValidation();
        }

        if (this.currentpage == 4) {
            console.log('4 page validate ');
            this.fourthValidation();
        }

        this.getexpression();
        console.log('page next ' + this.currentpage);
        console.log('landlord details : '+JSON.stringify(this.landlordDetails));
        this.commitLandlordDetails = JSON.parse(JSON.stringify(this.landlordDetails));
        console.log('commit : '+JSON.stringify(this.commitLandlordDetails));
    }

    handlePrevious() {
        window.scrollTo(0, 0);

        this.isNextButtonDisabled = false;

        this.currentpage--;

        if (this.currentpage == 1) {
            this.currentpage--;
        }

        if (this.currentpage < 0) {
            this.currentpage = 0;
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    name: 'Home'
                }
            });
        }

        if (this.currentpage == 4) {
            this.tillQuestion4 = true;
            this.tillQuestion5 = false;
            this.showHelpandAnswers = true;

            //update commit details
            this.selectedComplaintTypes = [];
            this.complaintSummaryDetails = [];

            this.selectedComplaintTypes = this.commitSelectedComplaintTypes;
            this.complaintSummaryDetails = this.commitComplaintSummaryDetails;

            if(this.validateAreasOfComplaintDetailsSubmission()) {
                this.isNextButtonDisabled = false;
            } else {
                this.isNextButtonDisabled = true;
            }
        } else if (this.currentpage == 0) {
            this.showHelpandAnswers = false;
        }

        this.getexpression()
    }

    handleSubmit() {
        if (this.isSubmitdisabled == false && this.currentpage == 5) {
            this.currentpage++;

            this.currentpage = 6;
            this.tillQuestion5 = false;
            this.page5preview = false;
            this.pagefinal = true;
            this.showCancelComplaintButton = false;

            console.log('areas of complaint : '+this.landlordDetails.Q4.ComplaintDetail);

            console.log('email : '+this.landlordDetails.Q2.Email);
            if(this.landlordDetails.Q2.Email == undefined) {
                this.landlordDetails.Q2.Email = '';
                console.log('email : '+this.landlordDetails.Q2.Email);
            }

            const jsonString = '{' +
                '"tenantFirstName": "'+this.landlordDetails.Q2.FirstName+'",' +
                '"tenantLastName": "'+this.landlordDetails.Q2.LastName+'",' +
                '"tenantPhoneNumber": "'+this.landlordDetails.Q2.Phone+'",' +
                '"tenantEmailAddress": "'+this.landlordDetails.Q2.Email+'",' +
                '"areasOfComplaint": "'+this.landlordDetails.Q4.SelectedCheckboxes+'",' +
                '"tenantProvidedResponse": "No",' +
                '"hasTenancyEnded": "No",' +
                '"tenancyEndDate": "",' +
                '"complaintSummary": "'+this.landlordDetails.Q4.ComplaintDetail+'",' +
                '"desiredOutcome": "",' +
                '"firstName": "",' +
                '"surname": "",' +
                '"phoneNumber": "",' +
                '"emailAddress": "",' +
                '"currentAddress": {' +
                '"houseNumber": "",' +
                '"streetName": "",' +
                '"city": "",' +
                '"county": "",' +
                '"postalCode": "",' +
                '"baseCountry": "",' +
                '"country": ""' +
                '},' +
                '"areasOfComplaints": '+JSON.stringify(this.commitComplaintSummaryDetails)+',' +
                '"propertyAddress": {' +
                '"houseNumber": "'+this.landlordDetails.Q3.PropStreetName+'",' +
                '"streetName": "'+this.landlordDetails.Q3.PropStreetName+'",' +
                '"city": "'+this.landlordDetails.Q3.PropAddTownCity+'",' +
                '"county": "'+this.landlordDetails.Q3.PropCounty+'",' +
                '"postalCode": "'+this.landlordDetails.Q3.PropAddPostCode+'",' +
                '"baseCountry": "England",' +
                '"country": "United Kingdom"' +
                '}' +
            '}';

            console.log('json : '+jsonString);
            this.showSpinner = true;
            this.registerComplaint(jsonString);
        }
    }

    handleChange(event) {
        console.log('question : '+event.target.dataset.name);
        if (event.target.dataset.name == 'q2') {
            console.log('q2');
            this.landlordDetails.Q2.previewediting = true;
        } else if (event.target.dataset.name == 'q3') {
            console.log('q3');
            this.landlordDetails.Q3.previewediting = true;
        } else if (event.target.dataset.name == 'q4') {
            console.log('q4');
            this.landlordDetails.Q4.previewediting = true;
        } else if (event.target.dataset.name == 'q5') {
            console.log('q5');
            this.landlordDetails.Q5.previewediting = true;
        }
    }

    handleSave(event) {
        console.log('save : '+event.target.dataset.name);
        if (event.target.dataset.name == 'q2Save') {
            this.detailsValidation();

            if (this.save2Valid == true) {
                this.commitLandlordDetails.Q2 = this.landlordDetails.Q2;
                this.landlordDetails.Q2.previewediting = false;
            } else {
                this.showToast('Error', 'Please select correct tenant details', 'Error', 'Dismissable');
            }
            // console.log('q2 - ' + JSON.stringify(this.commitTenantDetails));
        } else if (event.target.dataset.name == 'q3Save') {
            this.addressValidation();

            if (this.save3Valid == true) {
                this.commitLandlordDetails.Q3 = this.landlordDetails.Q3;
                this.landlordDetails.Q3.previewediting = false;
                // console.log('q3 - ' + JSON.stringify(this.commitTenantDetails));
            } else {
                this.showToast('Error', 'Please fill correct address', 'Error', 'Dismissable');
            }
        } else if (event.target.dataset.name == 'q4Save') {
            /*this.fourthValidation();

            if (this.save4Valid == true) {
                this.commitLandlordDetails.Q4 = this.landlordDetails.Q4;
                this.landlordDetails.Q4.previewediting = false;
                // console.log('q4 - ' + JSON.stringify(this.commitTenantDetails));
            } else {
                this.showToast('Error', 'Please fill correct checbox and details', 'Error', 'Dismissable');
            }*/
            try {
                console.log('valid : ' + this.validateAreasOfComplaintDetailsSubmission2());
                if (this.validateAreasOfComplaintDetailsSubmission2()) {
                    //this.commitTenantDetails.Q6 = this.tenantDetails.Q6;
                    this.landlordDetails.Q4.previewediting = false;
                } else {
                    this.showToast('Error', 'Please fill correct values', 'Error', 'Dismissable');
                    this.landlordDetails.Q4.previewediting = true;
                }
            } catch (error) {
                console.log('error : ' + error);
            }
            
        } else if (event.target.dataset.name == 'q5Save') {
            this.landlordNameEmailValidationQ5();

            if (this.save5Valid == true) {
                this.commitLandlordDetails.Q5 = this.landlordDetails.Q5;
                this.landlordDetails.Q5.previewediting = false;
                // console.log('q5 - ' + JSON.stringify(this.commitTenantDetails));
            } else {
                this.showToast('Error', 'Please fill correct landlord details', 'Error', 'Dismissable');
            }
        }
    }

    handleDownArrowClick() {
        console.log(' down ', this.showAccordion);
        this.showAccordion = true;
    }

    handleUpArrowClick() {
        console.log(' up ', this.showAccordion);
        this.showAccordion = false;
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    handleBackToHome() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    sendEmail() {

    }

    getexpression() {
        this.page0 = this.currentpage == 0 ? true : false;
        this.page1 = this.currentpage == 1 ? true : false;
        this.page2 = this.currentpage == 2 ? true : false;
        this.page3 = this.currentpage == 3 ? true : false;
        this.page4 = this.currentpage == 4 ? true : false;
        this.page5preview = this.currentpage == 5 ? true : false;
        this.pagefinal = this.currentpage == 6 ? true : false;
        this.showCancelComplaintButton = this.currentpage == 6 ? false : true;
    }

    showToast(title, message, variant, mode) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
            mode: mode
        });
        this.dispatchEvent(event);
    }

    registerComplaint(jsonString) {
        console.log('register complaint');
        registerComplaint({ wrapperString: jsonString })
        .then(result => {
            console.log('result : '+result);
            if(!result.includes('TRS-')) {
                this.showToast('Error', 'Something went wrong please try again later', 'Error', 'Dismissable');
            }
            this.trsCaseReferenceNumber = result;
            this.showSpinner = false;
        })
        .catch(error => {
            console.log('error '+error);
            this.showSpinner = false;
            this.showToast('Error', 'Something went wrong, please contact SF admin', 'Error', 'Dismissable');
        });
    }

    handleSearch(event) {
        this.searchTerm = event.target.value;
        this.findAddress();
    }

    findAddress(secondCall) {
        let encodedSearchTerm = '';
        console.log('second call : '+secondCall);
        if(secondCall) {
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        } else {
            this.encodedKey = '';
            this.searchTermDup = '';
            encodedSearchTerm = encodeURIComponent(this.searchTerm);
        }
        
        console.log('encoded : '+encodedSearchTerm);
        findAddress({ apiKey: this.apiId, search: encodedSearchTerm, containerId: this.encodedKey })
            .then(result => {
                let addresses = JSON.parse(result);
                if (addresses && addresses.Items) {
                    this.foundAddresses = [];
                    this.foundAddresses = addresses.Items;
                } else {
                    this.foundAddresses = [];
                }
            })
            .catch(error => {
                console.error('error : ' + error);
            });
    }

    retrieveAddress(event) {
        const id = event.target.id;
        const cleanedId = id.substring(0, id.lastIndexOf('-'));
        console.log('cleanedid : '+cleanedId);

        if (cleanedId.includes('-')) {
            this.searchTermDup = cleanedId;
            this.encodedKey = encodeURIComponent(this.searchTermDup);   
            this.findAddress(true);
        } else{
            retrieveAddress({ apiKey: this.apiId, idx: cleanedId })
            .then(result => {
                this.foundAddresses = false;
                this.selectedAddress = JSON.parse(result);
                //console.log('selected address : '+JSON.stringify(this.selectedAddress));
                console.log('line 1 : '+this.selectedAddress.Items[0].Line1);
                console.log('line 2 : '+this.selectedAddress.Items[0].Line2);
                console.log('city : '+this.selectedAddress.Items[0].City);
                console.log('province : '+this.selectedAddress.Items[0].Province);
                console.log('postal code : '+this.selectedAddress.Items[0].PostalCode);
                console.log('country name : '+this.selectedAddress.Items[0].CountryName);

                this.landlordDetails.Q3.PropStreetName = this.selectedAddress.Items[0].Line1 + this.selectedAddress.Items[0].Line2;
                this.landlordDetails.Q3.PropAddTownCity = this.selectedAddress.Items[0].City;
                this.landlordDetails.Q3.PropCounty = this.selectedAddress.Items[0].Province;
                this.landlordDetails.Q3.PropAddPostCode = this.selectedAddress.Items[0].PostalCode;
                this.landlordDetails.Q3.PropBaseCountry = 'England';
                this.landlordDetails.Q3.PropAddCountry = this.selectedAddress.Items[0].CountryName;
                this.searchTerm = this.selectedAddress.Items[0].PostalCode;
                this.addressValidation();
            })
            .catch(error => {
                console.log('error : ' + error);
            });
        }
        
    }
}