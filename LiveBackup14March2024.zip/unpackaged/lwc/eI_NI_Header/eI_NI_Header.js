import { LightningElement, wire, track, api } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import NI_Header_Footer from '@salesforce/resourceUrl/NI_Header_Footer';
//import logo from '@salesforce/resourceUrl/NI_Logo';
import { loadStyle } from 'lightning/platformResourceLoader';
import { loadScript } from 'lightning/platformResourceLoader';
import { getRecord } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import NAME_FIELD from '@salesforce/schema/User.Name';
//import isGuest from "@salesforce/user/isGuest";

import basePath from "@salesforce/community/basePath";
import returnUser from '@salesforce/apex/EI_NI_HeaderApex.returnUser';
import getScore from '@salesforce/apex/EI_NI_HeaderApex.getScore';
import fetchAccountDetails from '@salesforce/apex/EI_NI_HeaderApex.getCompanyDetails';
import fetchDeposits from '@salesforce/apex/EI_NI_DepositManagement.getLoggedinTenantDeposits';
import ei_NI_PostLoginChannel from '@salesforce/messageChannel/ei_NI_PostLoginChannel__c';
import { subscribe, MessageContext } from 'lightning/messageService';
import landlordCount from '@salesforce/apex/EI_NI_HeaderApex.landlordCount';
import tenantCount from '@salesforce/apex/EI_NI_HeaderApex.tenantCount';
import getPermissionsAndRoles from '@salesforce/apex/EI_NI_HeaderApex.getPermissionsAndRoles';
import fetchBranchDetails from '@salesforce/apex/EI_NI_HeaderApex.getBranchDetails';
import getNavigationMenuItems from '@salesforce/apex/NavigationMenuItemsController.getNavigationMenuItems';

export default class EI_NI_Header extends NavigationMixin(LightningElement) {

    @track error;
    @track username;
    @track totalPer;
    @track loggedInUser;
    @track branchName='';

    @track tabselectedhomepage;
    @track tabselectedmyacoountagll;
    @track tabselectedbranchaccount;
    @track tabselectedmyacoounttenant;
    @track tabselectedbranchuseraccount;
    @track tabselectedmyportfolio;
    @track tabselectedBulkactions;
    @track tabselectedbranchhomepage;
    @track tabselectedbranchreporting;
    @track tabselectedbranchselection;

    isUserProfileAgll = false;
    isHeadOffice = false;
    showBranchUser = false;
    showBillingTab = false;

    profileName;
    myAccountPageName;
    isTenant = false;
    showAccountTab = false;

    // percentage bar
    personalDetails = false;
    marketingPref = false;
    piClaus = false;
    bankDetails = false;
    


    //LogoFiles = logo + '/NI_logo.png';
    //LogoFiles = TDSTheme + '/assets/img/Logo_FIles.png';
    management_green = NI_Theme + '/assets/img/management_green.png';
    portfolio_green = NI_Theme + '/assets/img/portfolio_green.png';
    reporting_green = NI_Theme + '/assets/img/reporting_green.png';
    bulk_action_green = NI_Theme + '/assets/img/bulk-action_green.png';
    setting_green = NI_Theme + '/assets/img/setting_green.png';
    //LogoFiles = NI_Theme + '/assets/img/NI_logo.PNG';
    LogoFiles = NI_Header_Footer + '/images/tds-ni-logo.svg';
    UserIcon = NI_Theme + '/assets/img/User_Icon.png';
    proposalimage = NI_Theme + '/assets/img/management_green.png';
    myaccountimg = NI_Theme + '/assets/img/setting_green.png';
    billingimg = NI_Theme + '/assets/img/invoice.png';
    notifyIcon = NI_Theme + '/assets/img/notify-icon.png';
    notiyfActive = NI_Theme + '/assets/img/notify-Latest.png';
    hamburger=NI_Theme + '/assets/img/Icon-menu.png';
    defaultPage = '';
    viewPageUrl = '';
    goToClickedTabPage = '';

    // for bell notification

    @track countOfTenant;
    @track countOfLandlord;

    branchId = null;
    isHeadOfficeUser = false;
    isBranchUser = false;
    isBranchURLParamsNOTNull = false;
    showHeadOfficeLoginNav = false;
    showBranchUserNav = false;
    isExportReports = true;
    isBulkPermission = true;
    showSpinner = false;
    showBilling = false;
    // customCss = NI_Theme  + '/assets/css/custom-ni.css';

    subscription = null;
    @wire(MessageContext)
    messageContext;
    showButton = false;
    isBranchOnHeader = false;
    //InsuredUserForButton = false;

    // Navigation variables start
    @api linkSetMasterLabel = 'NI TDS Navigation';
    @api publishStatus = 'Live';
    @api addHomeMenuItem = false;
    @api includeImageUrls = false;
    @track menuItems = [];
    @track isLoaded = false;  
    // Navigation variables end  

    @wire(CurrentPageReference) Cpageref;
    @wire(CurrentPageReference)
    getpageRef(pageRef) {
        this.showSpinner = true;
        // const queryurl = window.location.href.split('/').pop();
        // const queryurl =  window.location.href.split('/').pop().split('?')[0];
        //const queryurl = window.location.href;
        let queryurl =  window.location.href;
        let urlParams1 = new URLSearchParams(queryurl); 
      
        this.isBranchURLParamsNOTNull = false;
        if(urlParams1 != null && urlParams1 != undefined && urlParams1 != '' && queryurl.includes('branchRecId')){
         this.isBranchURLParamsNOTNull = true;
        }



        if (queryurl.includes('myaccount') && this.isBranchURLParamsNOTNull == false && this.isHeadOfficeUser == false && this.isBranchUser == false) {
            this.showHeadOfficeLoginNav = false;
            this.tabselectedhomepage = "nav-link";
            this.tabselectedmyportfolio = "nav-link";
            this.tabselectedBulkactions = "nav-link";
            this.tabselectedmyacoountagll = "nav-link active";
            this.tabselectedbranchaccount = "nav-link active";
            this.tabselectedbranchuseraccount = "nav-link active";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedbranchreporting = "nav-link";
            
        } else if(queryurl.includes('myaccount') && this.isBranchURLParamsNOTNull == false && (this.isHeadOfficeUser == true || this.isBranchUser == true)){
            this.showHeadOfficeLoginNav = false;
            this.tabselectedhomepage = "nav-link";
            this.tabselectedmyportfolio = "nav-link";     
            this.tabselectedBulkactions = "nav-link"; 
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedbranchreporting = "nav-link";
            
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedbranchaccount = "nav-link active";
            this.tabselectedbranchuseraccount = "nav-link active";
            
       
        } else if(queryurl.includes('myaccount') && this.isBranchURLParamsNOTNull == true ){

            this.tabselectedmyacoountagll = "nav-link active";
            this.tabselectedhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link";        
            this.tabselectedBulkactions = "nav-link";  
            this.tabselectedbranchreporting="nav-link";        
            //alert('inside 213');  
        }
        else if (queryurl.includes('myportfolio')) {
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link active";
            this.tabselectedBulkactions = "nav-link";
            this.tabselectedbranchreporting="nav-link";   
        }
        else if (queryurl.includes('tenantaccount')) {
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link active";
            this.tabselectedmyportfolio = "nav-link ";
            this.tabselectedBulkactions = "nav-link";
        }
        else if (queryurl.includes('communityReporting')) {
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link ";
            this.tabselectedBulkactions = "nav-link";
            this.tabselectedbranchreporting="nav-link active";
            this.tabselectedbranchaccount="nav-link";
        }
        else if (queryurl.includes('registermultipledepositsni') || queryurl.includes('downloadbulkcertificatesni') || queryurl.includes('downloadpiformsni') || queryurl.includes('bulkactionsni')) {
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link ";
            this.tabselectedBulkactions = "nav-link active";
            this.tabselectedbranchreporting = "nav-link";
           
        } else if(queryurl.includes('viewbranchuser')){
            this.showHeadOfficeLoginNav = false;
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link active";
            this.tabselectedbranchhomepage = "nav-link";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link"; 
            this.tabselectedBulkactions = "nav-link";
            this.tabselectedbranchreporting = "nav-link";
           
        } else {
            this.tabselectedmyacoountagll = "nav-link";
            this.tabselectedhomepage = "nav-link active";
            this.tabselectedbranchhomepage = "nav-link active";
            this.tabselectedmyacoounttenant = "nav-link";
            this.tabselectedmyportfolio = "nav-link";
            this.tabselectedBulkactions = "nav-link";
            this.tabselectedbranchaccount = "nav-link";
            this.tabselectedbranchreporting = "nav-link";
            this.tabselectedbranchselection = "nav-link active";
            this.tabselectedbranchuseraccount = "nav-link";
        
        }
        this.showSpinner = false;
    }

    // To get the navigation menu items
    @wire(getNavigationMenuItems, {
        navigationLinkSetMasterLabel: '$linkSetMasterLabel',
        publishStatus: '$publishStatus',
        addHomeMenuItem: '$addHomeMenuItem',
        includeImageUrl: '$includeImageUrls'
    })
    wiredMenuItems({error, data}) {
        if (data && !this.isLoaded) {
            console.log('Line 245 data -> '+JSON.stringify(data));
            this.menuItems = data.map((item, index) => {
                return {
                    target: item.actionValue,
                    id: index,
                    label: item.label,
                    type: item.actionType,
                    subMenu: item.subMenu.map((subItem, index) => {
                        return {
                            target: subItem.actionValue,
                            id: index,
                            label: subItem.label,
                            type: subItem.actionType,
                            subMenu: subItem.subMenu,
                            imageUrl: subItem.imageUrl,
                            windowName: subItem.target, 
                            parentId: index
                        }
                    }),
                    subMenuDisplay: item.subMenu.length == 0 ? false:true,
                    imageUrl: item.imageUrl,
                    windowName: item.target
                }
            });
            console.log('Line 108 navigation -> '+JSON.stringify(this.menuItems));
            // this.error = undefined;
            this.isLoaded = true;
        }
        else if (error) {
            // this.error = error;
            this.menuItems = [];
            this.isLoaded = true;
            console.error(`Navigation menu error: ${JSON.stringify(this.error)}`);
        }
    }

    connectedCallback() {
        this.showSpinner = true;
        Promise.all([
            loadStyle(this, `${NI_Theme}/assets/css/custom-ni.css`),
            loadStyle(this, NI_Theme + '/assets/css/niheaderfont.css'),
            // loadStyle(this, `${NI_Header_Footer}/css/style.css`),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js')
        ]).then(() => {
            console.log('Header Files loaded');
        }).catch(error => {
            console.log('Error in loading script -> ', error.body.message);
        });

        console.log('Line 44 -> ');

        //Get page parameters
        var queryString = window.location.href;
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null) {
                this.branchId = window.atob(branchRecId);
            } 
        }
        
        console.log('URL String>>>' + JSON.stringify(queryString));
        console.log('BranchId>>>' + this.branchId);

        if(this.branchId != null && this.branchId != '' && this.branchId != undefined){
            fetchBranchDetails({branchId : this.branchId})
            .then(result => {
                console.log('line 105'+ JSON.stringify(result));
                let branchDetails  = result;
                if(branchDetails != null){
                    this.isBranchOnHeader = true;
                    this.branchName = branchDetails.Branch_Name__c;
                } else {
                    this.isBranchOnHeader = false;
                }
                console.log('line 108'+branchDetails.Branch_Name__c);
            });
        }

        returnUser()
            .then(result => {
                this.loggedInUser = result;
                if (this.loggedInUser.Profile.Name == 'NI_ Branch Users') {
                    this.showBranchUser = true;
                }
                if (this.loggedInUser.Profile.Name == 'NI_Tenant') {
                    this.isTenant = true;
                    this.getDepositCount();
                }
                if(this.loggedInUser.Account.Pay_for_Tenancies__c =='Monthly Invoicing' && this.loggedInUser.Account.Insured_User__c==true)
                {
                    this.showButton = true;
                }
                else{
                    this.showButton = false;
                }
                console.log('line 143-->'+this.loggedInUser.Account.Pay_for_Tenancies__c);
                console.log('line 145-->'+this.loggedInUser.Account.Insured_User__c);
                // if(urlParams != null && urlParams != undefined && urlParams != '' && queryString.includes('branchRecId')){
                //     this.isBranchURLParamsNOTNull = true;
                // }

                this.profileName = this.loggedInUser.Profile.Name;
                console.log('NI_Branch User:::', this.showBranchUser);
                console.log('Line 47 -> ' + result.Profile.Name);
                if (this.loggedInUser.Profile.Name == 'NI_Agent' || this.loggedInUser.Profile.Name == 'NI_Landlord' ||
                    this.loggedInUser.Profile.Name == 'NI_Head_Office_User' || this.loggedInUser.Profile.Name == 'NI_ Branch Users') {
                    this.isUserProfileAgll = true;
                }

                fetchAccountDetails({ usrId: this.loggedInUser.Id }).then(result => {
                    //this.isBranchURLParamsNOTNull = false;

                    const queryString = window.location.href;
                        console.log('80 queryString => ' + queryString);
                        console.log('urlParams = 81 ' + queryString);
                        console.log('fetchAccountDetails result:::'+ JSON.stringify(result));
                        console.log(' queryString.includes ewc'+ queryString.includes('/EWC/s/'));
                        console.log('line 114 viewbranchuser: '+queryString.includes('viewbranchuser'));
                        console.log('myportfolio: '+queryString.includes('myportfolio'));
                        console.log('result.Is_Head_Office_User__c '+result.Is_Head_Office_User__c);
                        const urlParams = new URLSearchParams(queryString);

                        this.isBranchURLParamsNOTNull = false;
                        if(this.loggedInUser.Profile.Name == 'NI_ Branch Users'){
                            this.isBranchUser = true;
                        } else if(this.loggedInUser.Profile.Name == 'NI_Head_Office_User'){
                            this.isHeadOfficeUser = true;
                        }

                        if(urlParams != null && urlParams != undefined && urlParams != '' && queryString.includes('branchRecId')){
                            this.isBranchURLParamsNOTNull = true;
                        }

                    console.log('fetchAccountDetails result:::', JSON.stringify(result));


        if(!result.Is_Head_Office_User__c && (this.loggedInUser.Profile.Name == 'NI_Agent' || this.loggedInUser.Profile.Name == 'NI_Landlord' || this.loggedInUser.Profile.Name == 'NI_Tenant')){
                    // this.isHeadOffice = true;
                    // this.showBranchUser = false;

                    this.showHeadOfficeLoginNav = true;
                    this.showBranchUserNav = false;
        } else if (result.Is_Head_Office_User__c && this.isBranchURLParamsNOTNull == true && this.loggedInUser.Profile.Name == 'NI_Head_Office_User' &&  (queryString.includes('viewbranchuser') || queryString.includes('addInsuredDeposit') || queryString.includes('myaccount') || queryString.includes('adddeposit') || queryString.includes('viewbranchuser') || queryString.includes('myportfolio') || queryString.includes('registermultipledepositsni') ||
                    queryString.includes('depositinsuredsummary') || queryString.includes('depositSummary') || queryString.includes('agentllrepaymentrequest') ||  queryString.includes('payInsuredDeposit') || queryString.includes('deposithistory') || queryString.includes('payDeposit') || queryString.includes('transferproperty') || queryString.includes('niselfresagll') || queryString.includes('agentdepprotection') || queryString.includes('transferinsureddeposittobranch') ||
                    queryString.includes('tenancyoutcome') || queryString.includes('insureddeposittransferredtoagll') || queryString.includes('insurededittenancy') || queryString.includes('agllrespondstoinsureddepositallocation') || queryString.includes('agllinsuredevidencegatheringni') || queryString.includes('niAgllEvidenceGathering') ||  queryString.includes('InsuredViewEvidence') || queryString.includes('CustodialViewEvidence') || queryString.includes('deposit-summary') || 
                    queryString.includes('niinsuredagllselfresolution') || queryString.includes('agllinitiateschangeover') || queryString.includes('repaymentrequestsummaryagll') || queryString.includes('transferdeposittoagll') || queryString.includes('downloadpiformsni') || queryString.includes('bulkactionsni') || queryString.includes('downloadbulkcertificatesni') || queryString.includes('downloadbulkcertificatesni') || queryString.includes('paymentconfirmation') || 
                    queryString.includes('monthlyinvoicing') || queryString.includes('canceltenantchangeover') || queryString.includes('transferdepositstobranch') || queryString.includes('branchRecId') || !queryString.includes('/ni/s/'))) {
                
                    // this.isHeadOffice = false;
                    // this.showBranchUser = false;
                    // this.isUserProfileAgll = true;

                    this.showHeadOfficeLoginNav = true;
                    this.showBranchUserNav = false;
                    console.log('Line 118 Head Office User: '+result.Is_Head_Office_User__c);
                    console.log('Inside Else if 1');

        } else if (result.Is_Head_Office_User__c && this.isBranchURLParamsNOTNull == false && this.loggedInUser.Profile.Name == 'NI_Head_Office_User' && queryString.includes('branchRecId')){
                    this.showHeadOfficeLoginNav = false;
                    this.showBranchUserNav = false;
                    console.log('Line 118 Head Office User: '+result.Is_Head_Office_User__c);
                    console.log('Inside Else if 2');

        } else if (this.loggedInUser.Profile.Name == 'NI_ Branch Users' && this.isBranchURLParamsNOTNull == true  &&  (queryString.includes('viewbranchuser') || queryString.includes('addInsuredDeposit') || queryString.includes('myaccount') || queryString.includes('adddeposit') || queryString.includes('viewbranchuser') || queryString.includes('myportfolio') || queryString.includes('registermultipledepositsni') || queryString.includes('depositinsuredsummary') || queryString.includes('depositSummary') || queryString.includes('agentllrepaymentrequest') || queryString.includes('transferinsureddeposittobranch') ||
                    queryString.includes('payInsuredDeposit') || queryString.includes('deposithistory') || queryString.includes('payDeposit') || queryString.includes('transferproperty') || queryString.includes('niselfresagll') || queryString.includes('agentdepprotection') || queryString.includes('tenancyoutcome') || queryString.includes('insureddeposittransferredtoagll') || queryString.includes('insurededittenancy') || queryString.includes('agllrespondstoinsureddepositallocation') || queryString.includes('agllinsuredevidencegatheringni') || queryString.includes('niAgllEvidenceGathering') || 
                    queryString.includes('InsuredViewEvidence') || queryString.includes('CustodialViewEvidence') || queryString.includes('deposit-summary') || queryString.includes('niinsuredagllselfresolution') || queryString.includes('agllinitiateschangeover') || queryString.includes('repaymentrequestsummaryagll') || queryString.includes('transferdeposittoagll') || queryString.includes('downloadpiformsni') || queryString.includes('bulkactionsni') || queryString.includes('downloadbulkcertificatesni') || queryString.includes('downloadbulkcertificatesni') || queryString.includes('paymentconfirmation') || 
                    queryString.includes('monthlyinvoicing') || queryString.includes('canceltenantchangeover') || queryString.includes('transferdepositstobranch') || !queryString.includes('/ni/s/'))) {
            
                    // this.isHeadOffice = false;
                    // this.showBranchUser = false;
                    // this.isUserProfileAgll = true;

                    this.showHeadOfficeLoginNav = true;
                    this.showBranchUserNav = false;
                    console.log('Line 118 Head Office User: '+result.Is_Head_Office_User__c);
                    console.log('Inside Else if 3');

        } else if(this.loggedInUser.Profile.Name == 'NI_ Branch Users' && queryString.includes('/ni/s/')) {
                    this.showBranchUserNav = true;
                    this.showHeadOfficeLoginNav = false;
                    console.log('Line 126 branch User: '+this.loggedInUser.Profile.Name);
                    console.log('Inside Else if 4');

        } else if (result.Is_Head_Office_User__c && (!this.loggedInUser.Profile.Name == 'NI_ Branch Users' || !this.loggedInUser.Profile.Name == 'NI_Head_Office_User')  &&  (!queryString.includes('viewbranchuser') || !queryString.includes('addInsuredDeposit') || !queryString.includes('myaccount') || !queryString.includes('adddeposit') || !queryString.includes('viewbranchuser') || !queryString.includes('myportfolio') || !queryString.includes('registermultipledepositsni') || !queryString.includes('depositinsuredsummary') || !queryString.includes('depositSummary') || !queryString.includes('agentllrepaymentrequest') || !queryString.includes('transferinsureddeposittobranch') ||
                  !queryString.includes('payInsuredDeposit') || !queryString.includes('deposithistory') || !queryString.includes('payDeposit') || !queryString.includes('transferproperty') || !queryString.includes('niselfresagll') || !queryString.includes('agentdepprotection') || !queryString.includes('tenancyoutcome') || !queryString.includes('insureddeposittransferredtoagll') || !queryString.includes('insurededittenancy') || !queryString.includes('agllrespondstoinsureddepositallocation') || !queryString.includes('agllinsuredevidencegatheringni') || !queryString.includes('niAgllEvidenceGathering') || !queryString.includes('InsuredViewEvidence') || !queryString.includes('CustodialViewEvidence') || !queryString.includes('deposit-summary') ||
                  !queryString.includes('niinsuredagllselfresolution') || !queryString.includes('agllinitiateschangeover') || !queryString.includes('repaymentrequestsummaryagll') || !queryString.includes('transferdeposittoagll') || !queryString.includes('downloadpiformsni') || !queryString.includes('bulkactionsni') || !queryString.includes('downloadbulkcertificatesni') || !queryString.includes('downloadbulkcertificatesni') || !queryString.includes('paymentconfirmation') || !queryString.includes('monthlyinvoicing') || !queryString.includes('canceltenantchangeover') || !queryString.includes('transferdepositstobranch') || queryString.includes('/ni/s/'))) {
    
                    // this.isHeadOffice = false;
                    // this.showBranchUser = false;
                    // this.isUserProfileAgll = true;

                    this.showHeadOfficeLoginNav = false;
                    console.log('Line 233 Inside else ');
                    console.log('Inside Else if 5');
        }




                    /*if (result.Is_Head_Office_User__c && this.branchId == null && (this.profileName == 'NI_Agent' || this.profileName == 'NI_Head_Office_User')) {
                        console.log('Inside If');
                        this.isHeadOffice = true;
                    } else if ((result.Is_Head_Office_User__c || this.branchId != null) && (this.profileName == 'NI_Head_Office_User' || this.profileName == 'NI_ Branch Users') &&
                        (queryString.includes('addInsuredDeposit') || queryString.includes('myaccount') || queryString.includes('adddeposit') ||
                            queryString.includes('viewbranchuser') || queryString.includes('myportfolio') || queryString.includes('registermultipledepositsni') ||
                            queryString.includes('depositinsuredsummary') || queryString.includes('depositSummary') || queryString.includes('agentllrepaymentrequest') ||
                            queryString.includes('payInsuredDeposit') || queryString.includes('deposithistory') || queryString.includes('payDeposit') ||
                            queryString.includes('transferproperty') || queryString.includes('niselfresagll') || queryString.includes('agentdepprotection') ||
                            queryString.includes('tenancyoutcome') || queryString.includes('insureddeposittransferredtoagll') || queryString.includes('insurededittenancy') ||
                            queryString.includes('agllrespondstoinsureddepositallocation') || queryString.includes('agllinsuredevidencegatheringni') || queryString.includes('niAgllEvidenceGathering')
                            || queryString.includes('InsuredViewEvidence') || queryString.includes('CustodialViewEvidence') || queryString.includes('deposit-summary') ||
                            queryString.includes('niinsuredagllselfresolution') || queryString.includes('agllinitiateschangeover') || queryString.includes('repaymentrequestsummaryagll') ||
                            queryString.includes('transferdeposittoagll') || queryString.includes('downloadpiformsni') || queryString.includes('bulkactionsni') || queryString.includes('downloadbulkcertificatesni')
                            || queryString.includes('downloadbulkcertificatesni'))) {
                        console.log('Inside Else if 1');
                        this.isHeadOffice = false;
                        this.showBranchUser = false;
                        this.isUserProfileAgll = true;
                    } else if (result.Is_Head_Office_User__c && (this.profileName == 'NI_Head_Office_User' || this.profileName == 'NI_Agent')) {
                        console.log('Inside Else If 2');
                        this.isHeadOffice = true;
                    }*/
                    // this.fetchScore();
            console.log('120 Nav URL: '+queryString.includes('viewbranchuser'));
            console.log('showHeadOfficeLoginNav '+this.showHeadOfficeLoginNav);
        }).catch(error => {
            console.log('fetchAccountDetails Error::', JSON.stringify(error));
            this.showSpinner = false;
        })

                if (this.isTenant) {

                    tenantCount({})
                        .then(result => {
                            console.log('tenant 179--->' + JSON.stringify(result));
                            console.log('tenant Count result--->' + result.length);
                            let count = result.length;
                            this.countOfTenant = count;
                            // if(this.countOfTenant>0){
                            //     this.isTenantNotify=true;
                            // }else{
                            //     this.isTenantNotify=false;
                            // }
                            // alert('count notify-->'+this.countOfTenant);
                            console.log('tenant Count result--->' + result.length);

                        })
                        .catch(error => {
                            console.log('tenant Count error--->' + JSON.stringify(error));
                            this.showSpinner = false;
                        });

                } else {
                    console.log('landlord-->')
                    landlordCount({})
                        .then(result => {
                            console.log('landlord Count result--->' + result);
                            let count = result;
                            this.countOfLandlord = count;
                            //   if(this.countOfLandlord>0){
                            //     this.isLandlordNotify=true;
                            //   }else{
                            //     this.isLandlordNotify=false;
                            //   }

                        })
                        .catch(error => {
                            console.log('landlord Count error--->' + JSON.stringify(error));
                            this.showSpinner = false;
                        });

                }
            })
            .catch(error => {
                console.log('Line 672 Error -> ', error);
                this.showSpinner = false;
            })

            getPermissionsAndRoles({ branchId: this.branchId }).then(result => {
                if(result != null ){
                    this.permissionList = result;
                    console.log('Line 245 Header Permission List: '+this.permissionList);
                    if(this.permissionList.length>0 && this.userType !='EWC Head Office User') {
                        console.log('Line 248 Header Permission List: '+this.permissionList);
                        this.setButtonMatrixForBranch(this.permissionList);
                    }
                }
            }).catch(error => {
                console.log('Line 251 Header getPermissionsAndRoles Error::'+ error);
                this.showSpinner = false;
            })

            this.defaultPage = window.location.origin + '/ni/s/';
            setTimeout(() => {
                this.showSpinner = false;
                    }, 2000);
        //   registerListener("BillingTab",this.showBillingTabMethod,this);


        // const queryString = window.location.search;
        // console.log('Line 63 -> '+queryString);
        // let pageName = queryString.substring(str.indexOf('/s/') + 1);  

        // var stateList = this.template.querySelector("[name='deposit_management']");
        // if(pageName == 'myaccount') {
        //     this.template.querySelector("[name='deposit_management']").classList.remove("active");
        //     this.template.querySelector("[name='my_portfolio']").classList.remove("active");
        //     this.template.querySelector("[name='reporting']").classList.remove("active");
        //     this.template.querySelector("[name='bulk_actions']").classList.remove("active");
        //     this.template.querySelector("[name='deposit_management']").classList.add("active");
        // }

        // var hlinkp= this.template.querySelector("[name='left_nav-sf-presonal-tab']");
        // var hlink= this.template.querySelector("[name='left_nav-sf-organisation-tab']");
        // this.isPersonalDetail=true;
        // this.isOrgDetailShow=false;
        // if(!hlinkp.classList.contains("active")){
        //     hlinkp.classList.add("active");
        //     hlink.classList.remove("active"); 
        // }
        this.handleSubscribe();

    }

    // Nav Click Function
    nav_click() {
        var checktoggle = this.template.querySelector('.navbarSupportedContent').style.display;
        if(checktoggle=="block"){
            this.template.querySelector('.navbarSupportedContent').style.display = 'none';
        }else{
            this.template.querySelector('.navbarSupportedContent').style.display = 'block';
        }
    }
    
    handleSubscribe() {
        console.log('In handleSubscribe');
        console.log('In handleSubscribe subscription', this.subscription);
        /*if (this.subscription) {
            return;
        }*/
        this.subscription = subscribe(this.messageContext, ei_NI_PostLoginChannel, (message) => {
            console.log('message', message);
            console.log('message.showButton', message.showButton);
            console.log('message.typeOfUser', message.typeOfUser);
            //this.InsuredUserForButton = message.typeOfUser;
            //this.showButton = message.showButton;
            if (message.typeOfUser && message.showButton) {
                // this.showBranchUser=false;
                // this.isHeadOffice=false;
               // this.showButton = true;
            } else {
                //this.showButton = false;
            }
        });
    }

    handleEvent(messageFromEvt) {
        console.log("event handled ********** ", messageFromEvt);
        this.message = messageFromEvt
            ? JSON.stringify(messageFromEvt, null, "\t")
            : "no message payload";
        console.log("event handled After **********", message);
    }

    //  showBillingTabMethod(data){
    //     console.log('child');
    //     // this.showBranchUser=false;
    //     // this.isHeadOffice=false;
    //     this.showBilling = data.showBilling;
    // }

    // fetchScore() {
    //     getScore()
    //         .then(result => {
    //             console.log('Success Line 78-->' + result);
    //             var piClause = 0;
    //             var bankDetails = 0;
    //             this.totalPer = JSON.stringify(result);
    //             var returnResult = result;

    //             var res = returnResult.split("#");
    //             console.log('Result break line 90-->' + res);
    //             var personDetails = parseInt(res[0]);
    //             console.log('personDetails::' + typeof personDetails + ' ::: ' + personDetails);
    //             //   console.log('Line 92 Personal Check-->'+personDetails);
    //             var marketPref = parseInt(res[1]);
    //             console.log('Line 94 marketPref-->' + typeof marketPref + ':::' + marketPref);
    //             if (!this.isHeadOffice) {
    //                 piClause = parseInt(res[2]);
    //                 bankDetails = parseInt(res[3]);
    //             }
    //             if(this.isTenant) {
    //                 bankDetails = parseInt(res[2]);
    //             }
    //             //  console.log('Line 97 bankDetails-->'+bankDetails);

    //             //    alert('account details '+paymentDetails+marketPref+piClause+bankDetails)
    //             if (personDetails != 0) {
    //                 this.personalDetails = true;
    //             }
    //             if (marketPref != 0) {
    //                 this.marketingPref = true;
    //             }
    //             if (piClause != 0) {
    //                 this.piClaus = true;
    //             }
    //             if (bankDetails != 0) {
    //                 this.bankDetails = true;
    //             }

    //             console.log('personDetails::1::' + personDetails);
    //             console.log('marketPref::2::' + marketPref);
    //             console.log('piClause::3::' + piClause);
    //             console.log('bankDetails::4::' + bankDetails);
    //             var total = 0;
    //             if (!this.isHeadOffice && !this.isTenant) {
    //                 console.log('inside if total');
    //                 total = personDetails + marketPref + piClause + bankDetails;
    //                 console.log('inside if total:: ' + total);
    //             } else if(this.isTenant) {
    //                 console.log('Inside isTenant');
    //                 total = personDetails + marketPref + bankDetails;
    //                 console.log('Total:::',total);
    //             } else {
    //                 console.log('inside else total');
    //                 total = personDetails + marketPref;
    //                 console.log('inside else total:: ' + total);
    //             }
    //             // var total = parseInt(personDetails) + parseInt(marketPref) + parseInt(piClause) + parseInt(bankDetails);
    //             console.log('Line 109--->' + total);
    //             this.totalPer = total;

    //         })
    //         .catch(error => {
    //             console.log('line 83 Error -> ', error);
    //         })
    // }

    getDepositCount() {
        fetchDeposits().then(result => {
            let deposits = result.length;
            if (deposits > 0) {
                this.showAccountTab = true;
            } else {
                this.showAccountTab = false;
            }
        }).catch(error => {
            console.log('Error while fetching deposits::', JSON.stringify(error));
        })
    }

    renderedCallback() {
        this.viewPageUrl = window.location.href;
        var branchScreen = this.template.querySelector("[name='branch_management']");
        var accountScreen = this.template.querySelector("[name='branch_account']");

        /* if(this.viewPageUrl.indexOf("myaccount") > -1) {
            accountScreen.classList.add("active");
            branchScreen.classList.remove("active");
        } */
    }

    get isUserProfileTenant() {
        if (this.loggedInUser.Profile.Name == 'NI_Tenant') {
            return true;

        } else {
            return false;
        }

    }

    handleTabChange(event) {
       // let isBranchUser = false;
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        

        this.isBranchURLParamsNOTNull = false;
       /* if (urlParams != null && urlParams != '' && urlParams != undefined && queryString.includes('branchRecId')) {
            //isBranchUser = true;
            this.isBranchURLParamsNOTNull = true;
        } *//*else {
            isBranchUser = false;
        }*/

        if (urlParams != undefined || urlParams != '' || urlParams != null) {
            var branchrecId = urlParams.get('branchRecId');
            if (branchrecId != null && branchrecId != '') {
                this.branchId = atob(branchrecId);
                this.isBranchURLParamsNOTNull = true;
                console.log('line 621'+this.branchId);
            }

        }

        // if (event.target.name == 'deposit_management'  && !queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == false) {
        //     this.goToClickedTabPage = this.defaultPage;
        // } 
        if (event.target.name == 'deposit_management'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined)  && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage;
        }
        else if (event.target.name == 'deposit_management' && queryString.includes('branchRecId')  && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'viewbranchuser?' + urlParams;
        } else if (event.target.name == 'my_portfolio'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined) && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage + 'myportfolio';
            /* if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                this.goToClickedTabPage = this.defaultPage + 'myportfolio?branchRecId=' + btoa(this.branchId);
            } else {
                this.goToClickedTabPage = this.defaultPage + 'myportfolio';
            } */
        } else if (event.target.name == 'my_portfolio'   && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'myportfolio?' + urlParams;
        } else if (event.target.name == 'reporting'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined) && this.isBranchURLParamsNOTNull == false) {
            console.log('line 693');
            this.goToClickedTabPage = this.defaultPage + 'communityReporting' ;


        } else if (event.target.name == 'reporting'  && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            console.log('line 698');
            this.goToClickedTabPage = this.defaultPage + 'communityReporting?' + urlParams; 

        } else if (event.target.name == 'bulk_actions'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined) && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage + 'registermultipledepositsni';
            /* if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                this.goToClickedTabPage = this.defaultPage + 'registermultipledepositsni?branchId=' + btoa(this.branchId);
            } else {
                this.goToClickedTabPage = this.defaultPage + 'registermultipledepositsni';
            } */
        } else if (event.target.name == 'bulk_actions'  && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'registermultipledepositsni?' + urlParams;
        } else if (event.target.name == 'my_account'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined) && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage + 'myaccount';
            /* if (this.branchId != null && this.branchId != '' && this.branchId != undefined) {
                this.goToClickedTabPage = this.defaultPage + 'myaccount?branchRecId=' + btoa(this.branchId);
            } else {
                this.goToClickedTabPage = this.defaultPage + 'myaccount';
            } */
        } else if (event.target.name == 'my_account'  && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'myaccount?' + urlParams;
        } else if (event.target.name == 'branch_management' && !queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == false) {
            console.log('Clicked Id:::', event.target.name);
            this.goToClickedTabPage = this.defaultPage;
        } else if (event.target.name == 'branch_management' && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            console.log('Clicked Id:::', event.target.name);
            this.goToClickedTabPage = this.defaultPage + 'myaccount?'+ urlParams;
        } else if (event.target.name == 'branchuser_account' && !queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == false) {
            console.log('Clicked Id:::', event.target.name);
            this.goToClickedTabPage = this.defaultPage + 'myaccount';
        } else if (event.target.name == 'branchuser_account' && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            console.log('Clicked Id:::', event.target.name);
            this.goToClickedTabPage = this.defaultPage + 'myaccount?'+ urlParams;
        } else if (event.target.name == 'branch_selection') {
            console.log('Clicked Id:::',event.target.name);
            this.goToClickedTabPage = this.defaultPage;
        } else if (event.target.name == 'branch_account' && !queryString.includes('branchRecId')  && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage + 'myaccount';
            /* document.getElementById("branch_management").classList.remove("active");
            document.getElementById(event.target.name).classList.add("active"); */

        } else if (event.target.name == 'branch_account'  && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'myaccount?'+ urlParams;
        } else if (event.target.name == 'branch_reporting') {
            this.goToClickedTabPage = this.defaultPage +'communityReporting';
        } else if (event.target.name == 'tenant-account') {
            this.goToClickedTabPage = this.defaultPage + 'tenantaccount';
        }
        // Redirect to Montly Invoicing
        else if (event.target.name == 'billing_tab'  && (this.branchId == '' || this.branchId == null || this.branchId == undefined) && this.isBranchURLParamsNOTNull == false) {
            this.goToClickedTabPage = this.defaultPage + 'monthlyinvoicing';
            
            event.preventDefault();
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'monthlyinvoicing'
                }

            });
        }  else if (event.target.name == 'billing_tab' && queryString.includes('branchRecId') && this.isBranchURLParamsNOTNull == true) {
            this.goToClickedTabPage = this.defaultPage + 'monthlyinvoicing'+ urlParams;
            
            event.preventDefault();
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'monthlyinvoicing'
                },
                state: {
                    branchRecId: btoa(this.branchId),
                    showBranch: window.btoa('false')
                }

            });
        }
        console.log('Line 97 -> ', this.defaultPage);
        console.log('Line 97 -> ', this.goToClickedTabPage);
    }

    notificationController(event) {
        event.preventDefault();
        //this.goToClickedTabPage = this.defaultPage + 'agllnotification';

        console.log('notification bell');

        if (this.isTenant) {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'tenantnotification'
                }

            });
        }
        else {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'agllnotification'
                }

            });
        }


    }

    @wire(getRecord, {
        recordId: USER_ID,
        fields: [NAME_FIELD]
    }) wireuser({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            this.username = data.fields.Name.value;
        }
    }
    /*
    get isGuest() {
        return isGuest;
    }*/

    get logoutLink() {
        const sitePrefix = basePath.replace(/\/s$/i, ""); // site prefix is the site base path without the trailing "/s"
        return sitePrefix + "/secur/logout.jsp";
    }

        //Validating Permissions
    setButtonMatrixForBranch(permissionList) {
        this.PageSpinner = true;
        
        //console.log('Line 599 - '+permissionList);

        if(permissionList.includes('Export reports')){
            this.isExportReports = true;
        } else {
            this.isExportReports = false;
        }

        if(permissionList.includes('Import updates' && 'Register bulk' && 'Modify bulk' && 'End bulk')){
            this.isBulkPermission = true;
        } else {
            this.isBulkPermission = false;
        }
    }
}