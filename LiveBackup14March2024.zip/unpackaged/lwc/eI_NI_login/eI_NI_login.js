import { LightningElement, track } from 'lwc';
import doLogin from '@salesforce/apex/EI_NI_signUpApx.doLogin';
import getResetUsername from '@salesforce/apex/EI_NI_signUpApx.resetPasswordMethod'

import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import NI_Header_Footer from '@salesforce/resourceUrl/NI_Header_Footer';
import { loadStyle } from 'lightning/platformResourceLoader';
import { loadScript } from 'lightning/platformResourceLoader';
import SystemModstamp from '@salesforce/schema/Account.SystemModstamp';

import { NavigationMixin } from 'lightning/navigation';


export default class EI_NI_login extends NavigationMixin(LightningElement) {

    // logoImg = NI_Theme + '/assets/img/NI_logo.PNG';
    Login_banner = NI_Theme + '/assets/img/login-banner.png';
    cancelImg = NI_Theme + '/assets/img/Cancel-icon.png';
    eyeImg = NI_Theme + '/assets/img/view_icon.png';
    LogoFiles = NI_Header_Footer + '/images/tds-ni-logo.svg';

    @track userName = "";
    @track password = "";
    @track UserNameResetError = false;
    @track txtErrorMessage = '';
    @track isShowResetModal = false;
    @track isConfirmShow = false;
    @track invalidUserName = false;
    @track userLocked = false;

    // Attributes to show Bootstrap error messages START
    errorMessage = false;
    usernameError = false;
    passwordError = false;
    inActiveError = false;
    // Attributes to show Bootstrap error messages START

    connectedCallback() {

        // Get the page parameters
        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);
        var username = '';
        console.log('Line 43 -> '+urlParams);

        if(urlParams != undefined) {
            username = urlParams.get('username');
            console.log('Line 47 ->' + username);
            if (username != null && username != '' && username != undefined) {
                console.log('Line 47 ->' + username);
                // this.template.querySelector("[name='inputUserName']").value = username;
            }
            
        }

        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js')
        ])
            .then(() => {
                console.log('Files loaded');
                if(username!='') {
                    this.template.querySelector("[name='inputUserName']").value = username;
                }

            })
            .catch(error => {
                console.log('Error => ', JSON.stringify(error));
            });
    }

    goToSignUpPage() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: "Register"
            }
        });
    }

    clickSubmit(event) {

        this.usernameError = false;
        this.passwordError = false;
        this.invalidUserName = false;
        this.userLocked = false;

        this.userName = this.template.querySelector("[name='inputUserName']").value;
        this.password = this.template.querySelector("[name='inputPassword']").value;

        if (this.userName == '' || this.userName == undefined || this.password == '' || this.password == undefined) {
            if (this.userName == '' || this.userName == undefined) {
                //this.errorMessage = true;
                this.usernameError = true;
            }
            if (this.password == '' || this.userName == undefined) {
                this.passwordError = true;
            }
        } else {
            //this.errorMessage = false;
            doLogin({
                userName: this.userName,
                password: this.password
            }).then(result => {
                console.log('Line 69-->' + JSON.stringify(result));
                if ((result == 'Your login attempt has failed. Make sure the username and password are correct.') || (result == 'login error')) {
                    this.invalidUserName = true;

                } else if (result == 'User Locked') {
                    this.userLocked = true;
                } /* else if (result == 'User Inactive') {
                    this.inActiveError = true;
                } */ else {
                    window.location.href = result;
                    this.invalidUserName = false;
                }
            }).catch(error => {
            })
        }


    }

    onClickForget(event) {
        this.isShowResetModal = true;
        this.UserNameResetError = false;
        console.log('ABC');
    }

    cancelPopUp() {
        this.isShowResetModal = false;
    }

    closeConfirmModel() {
        this.isConfirmShow = false;
    }

    resetPassword(event) {
        this.userName = this.template.querySelector("[name='resetUsername']").value;
        var isValid = true;
        event.preventDefault();
        if (this.userName == '' || this.userName == null || typeof this.userName == undefined) {
            this.txtErrorMessage = 'Username is mandatory.';
            this.UserNameResetError = true;
            isValid = false;
        }else{
            var mailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(this.userName.match(mailformat))
            {
                isValid = true;
            }
            else
            {   
                
                this.txtErrorMessage = 'Please enter valid username.';
            this.UserNameResetError = true;
            isValid = false;
            }    
        }

        if(isValid) {
            getResetUsername({
                username: this.userName
            }).then(result => {
                if (result === 'Reset') {
                    this.isConfirmShow = true;
                    this.isShowResetModal = false;
                } /*else if (result == 'User Inactive') {
                    this.txtErrorMessage = 'This user is inactive.';
                    this.UserNameResetError = true;
                } else {
                    this.txtErrorMessage = 'Please check your username.';
                    this.UserNameResetError = true;
                }*/
                else{
                    this.isConfirmShow = true;
                    this.isShowResetModal = false;
                }
            }).catch(error => {
                // this.errorMessage=true;
                console.log('Errors: ', error);
            })
        }
    }

    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "usernameErrorMsg":
                this.usernameError = false;
                break;
            case "passwordErrorMsg":
                this.passwordError = false;
                break;
            case "userName1":
                this.UserNameResetError = false;
                break;
            case "invalidUserName":
                this.invalidUserName = false;
                break;
            case "userLocked":
                this.userLocked = false;
                break;
            // case "errorMessageMsg":
            //     this.errorMessage = false;
            //     break; 
            case "inActiveErrorMsg":
                this.inActiveError = false;
                break;

        }
    }
    changeAtt(event) {

        this.pass = this.template.querySelector("[name='inputPassword']");
        if (this.pass.type === 'password') {
            this.pass.type = 'text';
        }
        else {
            this.pass.type = 'password';
        }
    }
}