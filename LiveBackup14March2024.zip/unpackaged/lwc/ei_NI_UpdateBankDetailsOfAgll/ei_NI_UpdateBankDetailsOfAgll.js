import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NIResource from '@salesforce/resourceUrl/NI_Theme';
import TDSResource from '@salesforce/resourceUrl/TDSTheme';
import NoTenantsToShow from '@salesforce/label/c.NoTenantsToShow';
import Redecoration from '@salesforce/label/c.Redecoration';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import fetchBankDetails from '@salesforce/apex/EI_NI_UpdateBankDetailsOfAGLL.fetchBankDetails';
import updateBankDetailsOfAGLL from '@salesforce/apex/EI_NI_UpdateBankDetailsOfAGLL.updateBankDetailsOfAGLL';

export default class Ei_NI_UpdateBankDetailsOfAgll extends LightningElement {

    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    successImage = NI_Theme + '/assets/img/thank-you.png';
    featherImg = NI_Theme + '/assets/img/feather-edit_nhos.svg';

    //Bank payment 
    wiredAccountData;
    @track bankDetails = {};
    @track bankAccountName = '';
    @track bankAccountNumber = '';
    @track sortCode = '';
    @track bankName = '';
    @track branchIds = null;
    @track isbankdetailsNotAvl = false;
    @track leftToAllocateAgentError = false;

    @track agLLName = '';
    isBankSuccessMessage = false;
    isBankErrorMessage = false;
    isBankNoChangeError = false;
    isNameOnAccountBlankError = false;
    isNameOnAccountSizeError = false;
    isNameOnAccountSpecialCharError = false;
    isAccountNumberLengthError = false;
    isAccountNumberBlankError = false;
    isInvalidAccountNumberError = false;
    isSortCodeBlankError = false;
    isSortcodelengtherror = false;
    isInvalidSortCodeError = false;



    isShowbankdetailSection = false;
    isbankdetailsPresent = false;
    isNoBankDetailsfound = false;
    isBranchPresent = false;
    isNoBankParent = false;
    isYesBankParent = true;
    @api saveDetailsForFutureRepayments = false;

    // @api parentSaveDetailsForFutureRepayments = false;
    @api noBankParent = false;
    @api isBankDetails = false;
    @api isCustodial = false;
    @api calledFrom;
    @api isEvidenceGatheringButtons;

    connectedCallback() {
        Promise.all([
            loadStyle(this, `${NIResource}/assets/css/custom-ni.css`),
            loadScript(this, NIResource + '/assets/js/plugin.min.js'),
            loadScript(this, NIResource + '/assets/js/custom.js')
        ]).then(() => {
            console.log('Files loaded.');
        }).catch(error => {
            console.log(error.body.message);
        });
        this.depositRecordId = this.calledFrom;
        console.log('noBankParent==>' + this.noBankParent);
        fetchBankDetails({
            depositsId: this.depositRecordId
        }).then(result => {
            console.log('bank details-->', JSON.stringify(result));
            console.log('bank details-->', result.length);
            // console.log('bank ac name-->'+result[0].Bank_Account_Holder_Name__c);
            //this.saveDetailsForFutureRepayments = event.target.checked;
            this.bankDetails = result;
            this.agLLName = this.bankDetails[0].Customer__r.Name;
            if (this.bankDetails[0].Branch__c != null && this.bankDetails[0].Branch__c != '') {
                this.isBranchPresent = true;
            }
            // this.saveDetailsForFutureRepayments = true;
            this.isBankDetailCheckbox = true;
            console.log('Line 289 - ' + this.isBranchPresent);
            if (this.isBranchPresent) {
                if (this.bankDetails[0].Branch__r.ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.isbankdetailsPresent = true;
                    this.saveDetailsForFutureRepayments = true;
                    this.bankAccountName = this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c;
                    this.bankAccountNumber = this.bankDetails[0].Branch__r.Account_Number__c;
                    this.sortCode = this.bankDetails[0].Branch__r.Sort_Code__c;
                    this.bankName = this.bankDetails[0].Branch__r.Bank_Name__c;

                } else {
                    this.isBankDetails = false;
                    this.isNoBankDetailsfound = true;
                    this.bankAccountName = '';
                    this.bankAccountNumber = '';
                    this.sortCode = '';
                    this.bankName = '';
                }
            } else {
                if (this.bankDetails[0].Customer__r.ValidInternationBankDetails__c == true) {
                    this.isbankdetailsPresent = true;
                    this.isBankDetails = true;
                     this.saveDetailsForFutureRepayments = true;
                    this.bankAccountName = this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c;
                    this.bankAccountNumber = this.bankDetails[0].Customer__r.Account_Number__c;
                    this.sortCode = this.bankDetails[0].Customer__r.Sort_Code__c;
                    this.bankName = this.bankDetails[0].Customer__r.Bank_Name__c;

                } else {
                    this.isBankDetails = false;
                    this.isNoBankDetailsfound = true;
                    this.bankAccountName = '';
                    this.bankAccountNumber = '';
                    this.sortCode = '';
                    this.bankName = '';
                }
            }
            console.log('123 Line bankDetaDep==>' + this.bankDetails[0].ValidInternationBankDetails__c);
            console.log('124 line bankDetaDepcheckox==>' + this.saveDetailsForFutureRepayments);
            if (this.saveDetailsForFutureRepayments == false) {
                console.log('bankDetaDep==>124' + this.bankDetails[0].ValidInternationBankDetails__c);
                if (this.bankDetails[0].ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.saveDetailsForFutureRepayments = false;
                    console.log('bankDetaDep@@' + this.isbankdetailsPresent);
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;


                } else {
                    this.isBankDetails = false;
                    this.isNoBankDetailsfound = true;
                    this.isbankdetailsPresent = false;


                }
            }
            console.log('Line==>143$$$' + this.isBankDetails);
            // Firing event from Child component to Parent component START
            const eventData = { isBankDetails: this.isBankDetails, saveDetailsForFutureRepayments: this.saveDetailsForFutureRepayments };
            const event = new CustomEvent('getbankdetails', { detail: eventData });
            this.dispatchEvent(event);
            // Firing event from Child component to Parent component END

            // this.saveDetailsForFutureRepayments = this.parentSaveDetailsForFutureRepayments;
            this.setBankDetails();
        }).catch(error => {
            console.log('bank details error-->', JSON.stringify(error));

        });
    }

    get saveLabel() {
        return this.isEvidenceGatheringButtons ? 'Save' : 'Submit';
    }

    renderedCallback() {
        // Pass initial data to parent component
        // console.log('bank true'+this.isBankDetails);
        // const eventData = {isBankDetails: this.isBankDetails};
        // const event = new CustomEvent('getbankdetails', { detail: eventData });
        // this.dispatchEvent(event);

        // console.log('noBankParentRender==>'+this.noBankParent);
    }

    @api showWarning(isWarning) {
        this.noBankParent = isWarning;
        console.log('this.noBankParent ==>' + this.noBankParent);
        if (this.noBankParent) {
            this.isNoBankParent = true;
            this.isYesBankParent = false;
        }
    }

    @api
    updateSaveDetailsForFutureRepayments(saveDetailsForFutureRepayments) {
        this.saveDetailsForFutureRepayments = saveDetailsForFutureRepayments;

        this.setBankDetails();
    }

    bankdetailsSaveOnAccont(event) {
        // this.isBankDetailCheckbox = true;
        this.saveDetailsForFutureRepayments = event.target.checked;
        this.isbankdetailsNotAvl = false;
        console.log('bankDetails==>checkboxchange==>' + JSON.stringify(this.bankDetails));

        this.setBankDetails();

        /* if (this.saveDetailsForFutureRepayments) {
            // this.isBankDetailCheckbox = event.target.checked;
            this.isBankDetailCheckbox = true;
            console.log('CheckboxTicked==>' + this.isBankDetailCheckbox);

            if (this.isBranchPresent) {
                if (this.bankDetails[0].Branch__r.ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;
                } else {
                    this.isBankDetails = false;
                    this.isbankdetailsPresent = false;
                    this.isNoBankDetailsfound = true;
                }

                if (this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != undefined && this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != ""
                    && this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != null) {
                    this.bankAccountName = this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c;
                    console.log('bankacchname--->2' + this.bankAccountName);
                } else {
                    this.bankAccountName = '';
                    console.log('bankacchname--->3' + this.bankAccountName);
                }

                if (this.bankDetails[0].Branch__r.Account_Number__c != undefined && this.bankDetails[0].Branch__r.Account_Number__c != ""
                    && this.bankDetails[0].Branch__r.Account_Number__c != null) {
                    this.bankAccountNumber = this.bankDetails[0].Branch__r.Account_Number__c;

                } else {
                    this.bankAccountNumber = '';
                }

                if (this.bankDetails[0].Branch__r.Sort_Code__c != undefined && this.bankDetails[0].Branch__r.Sort_Code__c != ""
                    && this.bankDetails[0].Branch__r.Sort_Code__c != null) {
                    this.sortCode = this.bankDetails[0].Branch__r.Sort_Code__c;
                } else {
                    this.sortCode = '';
                }

                if (this.bankDetails[0].Branch__r.Bank_Name__c != undefined && this.bankDetails[0].Branch__r.Bank_Name__c != ""
                    && this.bankDetails[0].Branch__r.Bank_Name__c != null) {
                    this.bankName = this.bankDetails[0].Branch__r.Bank_Name__c;
                } else {
                    this.bankName = '';
                }
            } 
            else {
                if (this.bankDetails[0].Customer__r.ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;
                } else {
                    this.isBankDetails = false;
                    this.isbankdetailsPresent = false;
                    this.isNoBankDetailsfound = true;
                }
                if (this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != undefined && this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != "" && this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != null) {
                    this.bankAccountName = this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c;
                    console.log('bankacchname--->2' + this.bankAccountName);
                } else {
                    this.bankAccountName = '';
                    console.log('bankacchname--->3' + this.bankAccountName);
                }

                if (this.bankDetails[0].Customer__r.Account_Number__c != undefined && this.bankDetails[0].Customer__r.Account_Number__c != "" && this.bankDetails[0].Customer__r.Account_Number__c != null) {
                    this.bankAccountNumber = this.bankDetails[0].Customer__r.Account_Number__c;

                } else {
                    this.bankAccountNumber = '';

                }
                if (this.bankDetails[0].Customer__r.Sort_Code__c != undefined && this.bankDetails[0].Customer__r.Sort_Code__c != "" && this.bankDetails[0].Customer__r.Sort_Code__c != null) {
                    this.sortCode = this.bankDetails[0].Customer__r.Sort_Code__c;

                } else {
                    this.sortCode = '';

                }
                if (this.bankDetails[0].Customer__r.Bank_Name__c != undefined && this.bankDetails[0].Customer__r.Bank_Name__c != "" && this.bankDetails[0].Customer__r.Bank_Name__c != null) {
                    this.bankName = this.bankDetails[0].Customer__r.Bank_Name__c;

                } else {
                    this.bankName = '';
                }
            }

        } 
        else {
            //this.isBankDetailCheckbox = event.target.checked;
            this.isBankDetailCheckbox = false;

            console.log('CheckboxUnTicked==>' + this.isBankDetailCheckbox);
            if (this.bankDetails[0].ValidInternationBankDetails__c == true) {
                this.isBankDetails = true;
                this.saveDetailsForFutureRepayments = false;
                console.log('bankDetaDep' + this.isbankdetailsPresent);
                this.isbankdetailsPresent = true;
                this.isNoBankDetailsfound = false;

            } else {
                this.isBankDetails = false;
                this.isNoBankDetailsfound = true;
                this.isbankdetailsPresent = false;


            }
            if (this.bankDetails[0].Bank_Account_Holder_Name__c !== undefined && this.bankDetails[0].Bank_Account_Holder_Name__c !== "" && this.bankDetails[0].Bank_Account_Holder_Name__c !== null) {
                this.bankAccountName = this.bankDetails[0].Bank_Account_Holder_Name__c;
                console.log('bankacchname--->415' + this.bankAccountName);
            } else {
                this.bankAccountName = '';
                console.log('bankacchname--->418' + this.bankAccountName);
            }

            if (this.bankDetails[0].Account_Number__c != undefined && this.bankDetails[0].Account_Number__c != "" && this.bankDetails[0].Account_Number__c != null) {
                this.bankAccountNumber = this.bankDetails[0].Account_Number__c;

            } else {
                this.bankAccountNumber = '';

            }
            if (this.bankDetails[0].Sort_Code__c != undefined && this.bankDetails[0].Sort_Code__c != "" && this.bankDetails[0].Sort_Code__c != null) {
                this.sortCode = this.bankDetails[0].Sort_Code__c;

            } else {
                this.sortCode = '';

            }
            if (this.bankDetails[0].Bank_Name__c != undefined && this.bankDetails[0].Bank_Name__c != "" && this.bankDetails[0].Bank_Name__c != null) {
                this.bankName = this.bankDetails[0].Bank_Name__c;

            } else {
                this.bankName = '';

            }
        } */

        //  // Firing event from Child component to Parent component START
        // const eventData = { isBankDetails: this.isBankDetails };
        const eventData = { isBankDetails: this.isBankDetails, saveDetailsForFutureRepayments: this.saveDetailsForFutureRepayments };
        const bankevent = new CustomEvent('getbankdetails', { detail: eventData });
        this.dispatchEvent(bankevent);
        //  // Firing event from Child component to Parent component END
    }

    setBankDetails() {
        if (this.saveDetailsForFutureRepayments) {
            // this.isBankDetailCheckbox = event.target.checked;
            this.isBankDetailCheckbox = true;
            console.log('CheckboxTicked==>' + this.isBankDetailCheckbox);

            if (this.isBranchPresent) {
                if (this.bankDetails[0].Branch__r.ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;
                } else {
                    this.isBankDetails = false;
                    this.isbankdetailsPresent = false;
                    this.isNoBankDetailsfound = true;
                }

                if (this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != undefined && this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != ""
                    && this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c != null) {
                    this.bankAccountName = this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c;
                    console.log('bankacchname--->2' + this.bankAccountName);
                } else {
                    this.bankAccountName = '';
                    console.log('bankacchname--->3' + this.bankAccountName);
                }

                if (this.bankDetails[0].Branch__r.Account_Number__c != undefined && this.bankDetails[0].Branch__r.Account_Number__c != ""
                    && this.bankDetails[0].Branch__r.Account_Number__c != null) {
                    this.bankAccountNumber = this.bankDetails[0].Branch__r.Account_Number__c;

                } else {
                    this.bankAccountNumber = '';
                }

                if (this.bankDetails[0].Branch__r.Sort_Code__c != undefined && this.bankDetails[0].Branch__r.Sort_Code__c != ""
                    && this.bankDetails[0].Branch__r.Sort_Code__c != null) {
                    this.sortCode = this.bankDetails[0].Branch__r.Sort_Code__c;
                } else {
                    this.sortCode = '';
                }

                if (this.bankDetails[0].Branch__r.Bank_Name__c != undefined && this.bankDetails[0].Branch__r.Bank_Name__c != ""
                    && this.bankDetails[0].Branch__r.Bank_Name__c != null) {
                    this.bankName = this.bankDetails[0].Branch__r.Bank_Name__c;
                } else {
                    this.bankName = '';
                }
            } else {
                if (this.bankDetails[0].Customer__r.ValidInternationBankDetails__c == true) {
                    this.isBankDetails = true;
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;
                } else {
                    this.isBankDetails = false;
                    this.isbankdetailsPresent = false;
                    this.isNoBankDetailsfound = true;
                }
                if (this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != undefined && this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != "" && this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c != null) {
                    this.bankAccountName = this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c;
                    console.log('bankacchname--->2' + this.bankAccountName);
                } else {
                    this.bankAccountName = '';
                    console.log('bankacchname--->3' + this.bankAccountName);
                }

                if (this.bankDetails[0].Customer__r.Account_Number__c != undefined && this.bankDetails[0].Customer__r.Account_Number__c != "" && this.bankDetails[0].Customer__r.Account_Number__c != null) {
                    this.bankAccountNumber = this.bankDetails[0].Customer__r.Account_Number__c;

                } else {
                    this.bankAccountNumber = '';

                }
                if (this.bankDetails[0].Customer__r.Sort_Code__c != undefined && this.bankDetails[0].Customer__r.Sort_Code__c != "" && this.bankDetails[0].Customer__r.Sort_Code__c != null) {
                    this.sortCode = this.bankDetails[0].Customer__r.Sort_Code__c;

                } else {
                    this.sortCode = '';

                }
                if (this.bankDetails[0].Customer__r.Bank_Name__c != undefined && this.bankDetails[0].Customer__r.Bank_Name__c != "" && this.bankDetails[0].Customer__r.Bank_Name__c != null) {
                    this.bankName = this.bankDetails[0].Customer__r.Bank_Name__c;

                } else {
                    this.bankName = '';
                }
            }

        }
        else {
            //this.isBankDetailCheckbox = event.target.checked;
            this.isBankDetailCheckbox = false;

            console.log('CheckboxUnTicked==>' + this.isBankDetailCheckbox);
            if (this.bankDetails[0].ValidInternationBankDetails__c == true) {
                this.isBankDetails = true;
                this.saveDetailsForFutureRepayments = false;

                this.isbankdetailsPresent = true;
                this.isNoBankDetailsfound = false;
                console.log('bankDetaDep' + this.isbankdetailsPresent);
                // this.parentSaveDetailsForFutureRepayments = true;

            } else {
                this.isBankDetails = false;
                this.isNoBankDetailsfound = true;
                this.isbankdetailsPresent = false;


            }
            if (this.bankDetails[0].Bank_Account_Holder_Name__c !== undefined && this.bankDetails[0].Bank_Account_Holder_Name__c !== "" && this.bankDetails[0].Bank_Account_Holder_Name__c !== null) {
                this.bankAccountName = this.bankDetails[0].Bank_Account_Holder_Name__c;
                console.log('bankacchname--->415' + this.bankAccountName);
            } else {
                this.bankAccountName = '';
                console.log('bankacchname--->418' + this.bankAccountName);
            }

            if (this.bankDetails[0].Account_Number__c != undefined && this.bankDetails[0].Account_Number__c != "" && this.bankDetails[0].Account_Number__c != null) {
                this.bankAccountNumber = this.bankDetails[0].Account_Number__c;

            } else {
                this.bankAccountNumber = '';

            }
            if (this.bankDetails[0].Sort_Code__c != undefined && this.bankDetails[0].Sort_Code__c != "" && this.bankDetails[0].Sort_Code__c != null) {
                this.sortCode = this.bankDetails[0].Sort_Code__c;

            } else {
                this.sortCode = '';

            }
            if (this.bankDetails[0].Bank_Name__c != undefined && this.bankDetails[0].Bank_Name__c != "" && this.bankDetails[0].Bank_Name__c != null) {
                this.bankName = this.bankDetails[0].Bank_Name__c;

            } else {
                this.bankName = '';

            }
        }
    }

    bankDetailsEditSection(event) {
        event.preventDefault();
        this.isShowbankdetailSection = true;
        this.isbankdetailsNotAvl = false;

        console.log('bank ac name from edit-->' + this.bankAccountName);
        console.log('add bank detail' + this.isNoBankDetailsfound);

    }

    //Handle  payment detail
    handlebankAccountNamechange(event) {
        this.bankAccountName = event.target.value;
        console.log('this.bankAccountName : @@@@@' + this.bankAccountName);
    }

    handlebankAccountNumberChange(event) {
        this.bankAccountNumber = event.target.value.trim();
        console.log('this.bankAccountNumber : @@@@@' + this.bankAccountNumber);
    }

    handlesortcodeChange(event) {
        this.sortCode = event.target.value.trim();
        console.log('this.sortCode : @@@@@' + this.sortCode);
    }

    updateBankDetails() {
        this.isBankSuccessMessage = false;
        this.isBankErrorMessage = false;
        this.isBankNoChangeError = false;
        this.isNameOnAccountBlankError = false;
        this.isNameOnAccountSizeError = false;
        this.isNameOnAccountSpecialCharError = false;
        this.isAccountNumberLengthError = false;
        this.isAccountNumberBlankError = false;
        this.isInvalidAccountNumberError = false;
        this.isSortCodeBlankError = false;
        this.isSortcodelengtherror = false;
        this.isInvalidSortCodeError = false;

        console.log("entered line 441");
        let isValid = true;
        let accountNumber = this.bankAccountNumber;
        let sortCode = this.sortCode;
        let bankAccountNames = this.bankAccountName;

        const regEX = /^[a-zA-Z0-9\s]*$/;
        const nameNumRegEx = /^[a-zA-Z0-9\s]*$/;


        if (bankAccountNames == undefined || bankAccountNames == "" || bankAccountNames == null || bankAccountNames.trim() == "") {
            this.isNameOnAccountBlankError = true;
            isValid = false;
        } else if (!regEX.test(bankAccountNames)) {
            this.isNameOnAccountSpecialCharError = true;
            isValid = false;
        }
        if (bankAccountNames.length > 64) {
            this.isNameOnAccountSizeError = true;
            isValid = false;
        }

        if (sortCode == undefined || sortCode == '' || sortCode == null || sortCode.trim() == '') {
            isValid = false;
            this.isSortCodeBlankError = true;
        } else if (!nameNumRegEx.test(sortCode)) {
            this.isInvalidSortCodeError = true;
            isValid = false;
        } else if (sortCode.length < 6 || sortCode.length > 6) {
            this.isSortcodelengtherror = true;
            isValid = false;
        }


        if (accountNumber == undefined || accountNumber == "" || accountNumber == null || accountNumber.trim() == "") {
            isValid = false;
            this.isAccountNumberBlankError = true;
        } else if (!nameNumRegEx.test(this.accountNumber)) {
            isValid = false;
            this.isInvalidAccountNumberError = true;
        } else if (accountNumber.length < 8 || accountNumber.length > 8) {
            this.isAccountNumberLengthError = true;
            isValid = false;
        }

        if (isValid) {
            this.isSortCodeBlankError = false;
            this.isAccountNumberBlankError = false;
            this.isNameOnAccountBlankError = false;
            if (this.isbankdetailsPresent && this.isBankDetailCheckbox == false &&
                (this.bankAccountName == this.bankDetails[0].Bank_Account_Holder_Name__c &&
                    this.bankAccountNumber == this.bankDetails[0].Account_Number__c && this.sortCode == this.bankDetails[0].Sort_Code__c)) {
                this.isBankNoChangeError = true;
            } 
            else {

                // Validating Bank Account No. for Invalid pattern
                this.findInvalidAccountNumberPattern(accountNumber);
                
                updateBankDetailsOfAGLL({ accountNumber: accountNumber, sortCode: sortCode, bankAccountName: bankAccountNames, bankName: this.bankName, ischecked: this.isBankDetailCheckbox, depositsId: this.depositRecordId })
                    .then(result => {
                        var messageValue;
                        var objectList;
                        for (let [key, value] of Object.entries(result)) {
                            console.log(key); // prints the map key, i.e., the message
                            console.log(value); // prints the list of objects
                            messageValue = key;
                            objectList = value;
                        }
                        if (messageValue == 'UnknownSortCode') {
                            this.isInvalidSortCodeError = true;
                        }

                        if (messageValue == 'InvalidAccountNumber') {
                            this.isInvalidAccountNumberError = true;

                        } else if (messageValue != 'UnknownSortCode' && messageValue != 'InvalidAccountNumber') {
                            this.isBankSuccessMessage = true;
                            this.isNoBankDetailsfound = false;
                            this.isbankdetailsPresent = true;

                            // Firing event from Child component to Parent component START
                            const eventData = { isBankDetails: this.isbankdetailsPresent, saveDetailsForFutureRepayments: this.saveDetailsForFutureRepayments };
                            const event = new CustomEvent('getbankdetails', { detail: eventData });
                            this.dispatchEvent(event);

                            // Firing event from Child component to Parent component END

                            setTimeout(() => {
                                this.isShowbankdetailSection = false;
                                this.isBankSuccessMessage = false;
                              }, 1000);
                              
                            if (this.isBankDetailCheckbox) {
                                if (this.isBranchPresent) {
                                    for (let obj of objectList) {
                                        console.log('GetObjList=609=>'+JSON.stringify(objectList));
                                        this.bankDetails[0].Branch__r.Bank_Account_Holder_Name__c = obj.Branch__r.Bank_Account_Holder_Name__c;
                                        this.bankDetails[0].Branch__r.Account_Number__c = obj.Branch__r.Account_Number__c;
                                        this.bankDetails[0].Branch__r.Sort_Code__c = obj.Branch__r.Sort_Code__c;
                                        this.bankDetails[0].Branch__r.Bank_Name__c = messageValue;
                                        this.bankDetails[0].Branch__r.ValidInternationBankDetails__c = obj.Branch__r.ValidInternationBankDetails__c;
                                        this.bankName = messageValue;
                                    }
                                } else {
                                    for (let obj of objectList) {
                                        this.bankDetails[0].Customer__r.Bank_Account_Holder_Name__c = obj.Bank_Account_Holder_Name__c;
                                        this.bankDetails[0].Customer__r.Account_Number__c = obj.Account_Number__c;
                                        this.bankDetails[0].Customer__r.Sort_Code__c = obj.Sort_Code__c;
                                        this.bankDetails[0].Customer__r.Bank_Name__c = messageValue;
                                        this.bankDetails[0].Customer__r.ValidInternationBankDetails__c = obj.ValidInternationBankDetails__c;
                                        this.bankName = messageValue;
                                    }
                                }
                            } else {
                                for (let obj of objectList) {
                                    this.bankDetails[0].Bank_Account_Holder_Name__c = obj.Bank_Account_Holder_Name__c;
                                    this.bankDetails[0].Account_Number__c = obj.Account_Number__c;
                                    this.bankDetails[0].Sort_Code__c = obj.Sort_Code__c;
                                    this.bankDetails[0].Bank_Name__c = messageValue;
                                    this.bankDetails[0].ValidInternationBankDetails__c = obj.ValidInternationBankDetails__c;
                                    this.bankName = messageValue;
                                    this.isbankdetailsPresent = true;
                                }
                            }


                        }
                    }).catch(error => {
                        this.isBankSuccessMessage = false;
                        this.isBankErrorMessage = true;
                        console.log('Line 210 Error -> ', error);
                    });
            }
        }
    }

    bankdetailcancelhandle(event) {
        this.isShowbankdetailSection = false;
    }

    // Method for finding the Invalid pattern in Account number
    findInvalidAccountNumberPattern(accountNo) {
        //code for pattern regex
        var pattermatch = /(012|123|234|345|456|567|678|789|111|222|333|444|555|666|777|888|999|987|765|654|543|432|321|210)/g;
        console.log('Line 593 pattern -> ', pattermatch);

        //if(pattermatch.test(this.bankAccountNumber)){
        var passBankAccNumber = accountNo;
        if (pattermatch.test(accountNo)) {
            this.isInvalidAccountNumberError = true;
        } 
        else if (/(000)/g.test(accountNo)) {
            passBankAccNumber = '11111111';
            console.log('test000');
            this.isInvalidAccountNumberError = true;
            // isValid = false;
        }
    }

    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "bankSuccessMessage":
                this.isBankSuccessMessage = false;
                break;
            case "bankErrorMessage":
                this.isBankErrorMessage = false;
                break;
            case "bankNoChangeError":
                this.isBankNoChangeError = false;
                break;
            case "nameOnAccountBlankError":
                this.isNameOnAccountBlankError = false;
                break;
            case "nameOnAccountSizeError":
                this.isNameOnAccountSizeError = false;
                break;
            case "nameOnAccountSpecialCharError":
                this.isNameOnAccountSpecialCharError = false;
                break;
            case "accountNumberLengthError":
                this.isAccountNumberLengthError = false;
                break;
            case "accountNumberBlankError":
                this.isAccountNumberBlankError = false;
                break;
            case "invalidAccountNumberError":
                this.isInvalidAccountNumberError = false;
                break;
            case "sortCodeBlankError":
                this.isSortCodeBlankError = false;
                break;
            case "bankOfAmericaSortCode":
                this.isBankOfAmericaSortCode = false;
                break;
            case "Sortcodelengtherror":
                this.isSortcodelengtherror = false;
                break;
            case "invalidSortCodeError":
                this.isInvalidSortCodeError = false;
                break;
            // case "blankAgentAmountError":
            //     this.blankAgentAmountValidation=false;
            // break;
            // case "blanktenantAmountError":
            //     this.blankTenantAmountValidation=false;
            // break;
        }
    }

}