import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import jQuery from '@salesforce/resourceUrl/JQuery';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import { NavigationMixin } from 'lightning/navigation';

import getAllDeposits from '@salesforce/apex/EI_NI_DepositManagement.fetchAllDeposits';
import fetchUnValidatedDeps from '@salesforce/apex/EI_NI_DepositManagement.getUnvalidatedDeposits';
import validateDeposit from '@salesforce/apex/EI_NI_DepositManagement.validateDepositDetails';
import getDepositRecordsBySearch from '@salesforce/apex/EI_NI_DepositManagement.getDepositRecordsBySearchText';
import RecaptchaHandler from '@salesforce/apex/EI_NI_Recaptcha.insertRecord';

export default class Ei_NI_TenantPostLogin extends NavigationMixin(LightningElement) {
    view_icon = NI_THEME + '/assets/img/view_icon.png';
    view_edit = NI_THEME + '/assets/img/view_icon.png'

    @track searchText = '';
    @track allDepositCountByStatus = { 'RNP': 0, 'DPBS': 0, 'RRT': 0, 'RRAL': 0, 'SR': 0, 'DS': 0, 'RP': 0, 'DRLY': 0, 'DPS': 0 };
    @track allDepositAmountByStatus = { 'RNP': 0.00, 'DPBS': 0.00, 'RRT': 0.00, 'RRAL': 0.00, 'SR': 0.00, 'DS': 0.00, 'RP': 0.00, 'DRLY': 0.00, 'DPS': 0.00 };
    @track allDepositListByStatus = { 'RNP': [], 'DPBS': [], 'RRT': [], 'RRAL': [], 'SR': [], 'DS': [], 'RP': [], 'DRLY': [], 'DPS': [] };
    years = [];

    showCollapseOne = false;
    showCollapseTwo = false;
    showCollapseThree = false;
    showCollapseFour = false;
    showCollapseFive = false;
    showCollapseSix = false;
    showCollapseSeven = false;
    showCollapseEight = false;
    showCollapseNine = false
    showSubmit = false;

    displayAttemptWarning = false;
    showCustodialDeposits = true;
    showInsuredDeposits = false;
    hideSectionOne = false;
    displayMessage = false;


    @track showConfirmForm = false;

    postCodeError = false;
    depositAmountError = false;
    tenancyMonthError = false;
    tenancyYearError = false;

    loggedInUser = {};
    allDepositsByStatus = [];
    nonValidatedDeposits = [];
    @track unvalidatedDeposits = [];
    @api rnpstatuslist=[];
    @track isSearchResult=false;
    @track searchList= { 'RNP': [], 'DPBS': [], 'RRT': [], 'RRAL': [], 'SR': [], 'DS': [], 'RP': [], 'DRLY': [], 'DPS': [] };

    depositId = '';
    remainingAttempts = 0;
    validationError = false;

    connectedCallback() {
        this.isSearchResult=false;
        this.postCodeError = false;
        this.depositAmountError = false;
        this.validationError = false;
        this.unvalidatedDeposits = [];
        this.allDepositsByStatus = [];
        this.nonValidatedDeposits = [];

        loadScript(this, jQuery).then(() => {
            console.log('JQuery loaded.');
        }).catch(error => {
            console.log('Failed to load the JQuery : ' + error);
        });
        Promise.all([
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')
        ]).then(() => {
            console.log('Files loaded');

        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });

        // Fetch Deposit Details
        getAllDeposits({ "schemeType": "Insured" }).then(result => {
            console.log('getAllDeposits::', JSON.stringify(result));
            this.loggedInUser = result.loggedInUserDetails;
            this.allDepositsByStatus = result.allDeposits;

            fetchUnValidatedDeps({
                "typeofScheme": "Insured"
            }).then(result => {
                console.log('fetchUnValidatedDeps::', JSON.stringify(result));
                this.nonValidatedDeposits = result;
                if (this.nonValidatedDeposits.length == 0) {
                    this.hideSectionOne = false;
                } else {
                    this.hideSectionOne = true;
                }
                if (this.allDepositsByStatus.length > 0 || this.nonValidatedDeposits.length > 0) {
                    this.displayMessage = false;
                } else {
                    this.displayMessage = true;
                }
                this.getDepositsByStatus(this.allDepositsByStatus, this.nonValidatedDeposits);
            }).catch(error => {
                console.log('Error while fetching unvalidated deposits::', JSON.stringify(error));
            })
        }).catch(error => {
            console.log('::Error while fetching all deposits:::', JSON.stringify(error));
        })
    }

    removeZero(event) {
        var edValue = event.target.value;
        function trimNumber(s) {
            while (s.substring(0, 1) == '0' && s.length >= 1 && !s.includes(".")) {
                s = s.substring(1, 9999);
            }
            return s;
        }
        var trimeVal = trimNumber(edValue);
        event.target.value = trimeVal;

        if (trimeVal.includes('.')) {
            var number = trimeVal.split('.');
            console.log('numbs ' + number[1]);
            if (number[1].length > 2)
                event.target.value = parseFloat(trimeVal).toFixed(2);
        } else {
            event.target.value = trimeVal;
        }
    }

    restrictDecimal(event) {
        const t = event.target.value;
        const charCode = (event.which) ? event.which : event.keyCode;
        const decimalIndex = t.indexOf('.');

        // Allow only one decimal point
        if (charCode === 46 && decimalIndex !== -1) {
            event.preventDefault();
        }

        // Allow only digits and a decimal point
        else if (charCode !== 46 && (charCode < 48 || charCode > 57)) {
            event.preventDefault();
        }

        // Allow only up to two digits after the decimal point
        else if (decimalIndex !== -1 && t.slice(decimalIndex).length >= 3 && event.target.selectionStart > decimalIndex) {
            event.preventDefault();
        }
    }


    getDepositsByStatus(allDeposits, unValidatedDeps) {
        console.log('allDeposits at grouping\t' + JSON.stringify(allDeposits) + '::unValidatedDeps' + JSON.stringify(unValidatedDeps));
        let depositCountByStatus = { 'RNP': 0, 'DPBS': 0, 'RRT': 0, 'RRAL': 0, 'SR': 0, 'DS': 0, 'RP': 0, 'DRLY': 0, 'DPS': 0 };
        let depositAmountByStatus = { 'RNP': 0.00, 'DPBS': 0.00, 'RRT': 0.00, 'RRAL': 0.00, 'SR': 0.00, 'DS': 0.00, 'RP': 0.00, 'DRLY': 0.00, 'DPS': 0.00 };
        let depositListByStatus = { 'RNP': [], 'DPBS': [], 'RRT': [], 'RRAL': [], 'SR': [], 'DS': [], 'RP': [], 'DRLY': [], 'DPS': [] };

        this.allDepositCountByStatus.DPBS = depositCountByStatus.DPBS;
        this.allDepositAmountByStatus.DPBS = depositAmountByStatus.DPBS.toFixed(2);
        this.allDepositCountByStatus.RNP = depositCountByStatus.RNP;
        this.allDepositAmountByStatus.RNP = depositAmountByStatus.RNP.toFixed(2);
        this.allDepositCountByStatus.RRT = depositCountByStatus.RRT;
        this.allDepositAmountByStatus.RRT = depositAmountByStatus.RRT.toFixed(2);
        this.allDepositCountByStatus.RRAL = depositCountByStatus.RRAL;
        this.allDepositAmountByStatus.RRAL = depositAmountByStatus.RRAL.toFixed(2);
        this.allDepositCountByStatus.SR = depositCountByStatus.SR;
        this.allDepositAmountByStatus.SR = depositAmountByStatus.SR.toFixed(2);
        this.allDepositCountByStatus.DS = depositCountByStatus.DS;
        this.allDepositAmountByStatus.DS = depositAmountByStatus.DS.toFixed(2);
        this.allDepositCountByStatus.RP = depositCountByStatus.RP;
        this.allDepositAmountByStatus.RP = depositAmountByStatus.RP.toFixed(2);
        this.allDepositCountByStatus.DRLY = depositCountByStatus.DRLY;
        this.allDepositAmountByStatus.DRLY = depositAmountByStatus.DRLY.toFixed(2);
        this.allDepositCountByStatus.DPS = depositCountByStatus.DPS;
        this.allDepositAmountByStatus.DPS = depositAmountByStatus.DPS.toFixed(2);

        for (var i = 0; i < allDeposits.length; i++) {
            if (allDeposits[i].Deposit__r.Status__c == 'Deposits protected by scheme') {
                depositCountByStatus.DPBS = depositCountByStatus.DPBS + 1;
                depositAmountByStatus.DPBS = depositAmountByStatus.DPBS + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.DPBS.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Proposal submitted - tenant') {
                depositCountByStatus.RRT = depositCountByStatus.RRT + 1;
                depositAmountByStatus.RRT = depositAmountByStatus.RRT + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.RRT.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Proposal submitted – awaiting tenant response') {
                depositCountByStatus.RRAL = depositCountByStatus.RRAL + 1;
                depositAmountByStatus.RRAL = depositAmountByStatus.RRAL + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.RRAL.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Repayment not agreed - In self-resolution') {
                depositCountByStatus.SR = depositCountByStatus.SR + 1;
                depositAmountByStatus.SR = depositAmountByStatus.SR + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.SR.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Repayment not agreed - In dispute resolution') {
                depositCountByStatus.DS = depositCountByStatus.DS + 1;
                depositAmountByStatus.DS = depositAmountByStatus.DS + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.DS.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Repayment process') {
                depositCountByStatus.RP = depositCountByStatus.RP + 1;
                depositAmountByStatus.RP = depositAmountByStatus.RP + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.RP.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Deposit protections concluded in the last year') {
                depositCountByStatus.DRLY = depositCountByStatus.DRLY + 1;
                depositAmountByStatus.DRLY = depositAmountByStatus.DRLY + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.DRLY.push(allDeposits[i].Deposit__r);
            } else if (allDeposits[i].Deposit__r.Status__c == 'Deposit protected by scheme (tenancy ended)') {
                depositCountByStatus.DPS = depositCountByStatus.DPS + 1;
                depositAmountByStatus.DPS = depositAmountByStatus.DPS + allDeposits[i].Deposit__r.Deposit_Amount__c;
                depositListByStatus.DPS.push(allDeposits[i].Deposit__r);
            }
        }
        for (var i = 0; i < unValidatedDeps.length; i++) {
            depositCountByStatus.RNP = depositCountByStatus.RNP + 1;
            depositAmountByStatus.RNP = depositAmountByStatus.RNP + unValidatedDeps[i].Deposit__r.Deposit_Amount__c;
            depositListByStatus.RNP.push(unValidatedDeps[i]);
        }
        if (depositListByStatus.RNP.length > 0) {
            this.allDepositCountByStatus.RNP = depositCountByStatus.RNP;
            this.allDepositAmountByStatus.RNP = depositAmountByStatus.RNP.toFixed(2);
            this.allDepositListByStatus.RNP = depositListByStatus.RNP;
        }
        if (depositListByStatus.DPBS.length > 0) {
            this.allDepositCountByStatus.DPBS = depositCountByStatus.DPBS;
            this.allDepositAmountByStatus.DPBS = depositAmountByStatus.DPBS.toFixed(2);
            this.allDepositListByStatus.DPBS = depositListByStatus.DPBS;
        }
        if (depositListByStatus.RRT.length > 0) {
            this.allDepositCountByStatus.RRT = depositCountByStatus.RRT;
            this.allDepositAmountByStatus.RRT = depositAmountByStatus.RRT.toFixed(2);
            this.allDepositListByStatus.RRT = depositListByStatus.RRT;
        }
        if (depositListByStatus.RRAL.length > 0) {
            this.allDepositCountByStatus.RRAL = depositCountByStatus.RRAL;
            this.allDepositAmountByStatus.RRAL = depositAmountByStatus.RRAL.toFixed(2);
            this.allDepositListByStatus.RRAL = depositListByStatus.RRAL;
        }
        if (depositListByStatus.SR.length > 0) {
            this.allDepositCountByStatus.SR = depositCountByStatus.SR;
            this.allDepositAmountByStatus.SR = depositAmountByStatus.SR.toFixed(2);
            this.allDepositListByStatus.SR = depositListByStatus.SR;
        }
        if (depositListByStatus.DS.length > 0) {
            this.allDepositCountByStatus.DS = depositCountByStatus.DS;
            this.allDepositAmountByStatus.DS = depositAmountByStatus.DS.toFixed(2);
            this.allDepositListByStatus.DS = depositListByStatus.DS;
        }
        if (depositListByStatus.RP.length > 0) {
            this.allDepositCountByStatus.RP = depositCountByStatus.RP;
            this.allDepositAmountByStatus.RP = depositAmountByStatus.RP.toFixed(2);
            this.allDepositListByStatus.RP = depositListByStatus.RP;
        }
        if (depositListByStatus.DRLY.length > 0) {
            this.allDepositCountByStatus.DRLY = depositCountByStatus.DRLY;
            this.allDepositAmountByStatus.DRLY = depositAmountByStatus.DRLY.toFixed(2);
            this.allDepositListByStatus.DRLY = depositListByStatus.DRLY;
        }

        if (depositListByStatus.DPS.length > 0) {
            this.allDepositCountByStatus.DPS = depositCountByStatus.DPS;
            this.allDepositAmountByStatus.DPS = depositAmountByStatus.DPS.toFixed(2);
            this.allDepositListByStatus.DPS = depositListByStatus.DPS;
        }

        if (this.allDepositListByStatus.RNP.length > 0) {
            this.template.querySelector('[data-id="confirmTenant"]').classList.remove("collapsed");
            this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "true");
            this.showCollapseOne = true;

            for (var i in this.allDepositListByStatus.RNP) {
                var depositRec = {};
                var singleDep = this.allDepositListByStatus.RNP[i];
                depositRec.Id = singleDep.Id;
                depositRec.depositId = singleDep.Deposit__c;
                depositRec.address = singleDep.Deposit__r.EI_PropertyAddWithStar__c;
                depositRec.depositNumber = singleDep.Deposit__r.NI_Deposit_Number__c;
                depositRec.totalTenants = singleDep.Deposit__r.No_of_tenant__c;
                depositRec.rowColor = '';
                if (singleDep.Number_Of_Attempts__c == 3) {
                    depositRec.displayWarning = true;
                } else {
                    depositRec.displayWarning = false;
                }
                /* console.log('Single Deposit:::', JSON.stringify(singleDep));
                if (singleDep.Number_Of_Attempts__c == 3) {
                    this.displayAttemptWarning = true;
                } else {
                    this.displayAttemptWarning = false;
                } */
                this.unvalidatedDeposits.push(depositRec);
            }
        }
        console.log('::Deposits by Status::', JSON.stringify(this.allDepositListByStatus));
    }

    addClick(event) {
        var clickedSection = event.currentTarget.dataset.id;
        switch (clickedSection) {
            case "confirmTenant":
                var section = this.template.querySelector("[data-id='confirmTenant']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                this.showCollapseOne = !this.showCollapseOne;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "depositHeld":
                var section = this.template.querySelector("[data-id='depositHeld']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");

                this.rnpstatuslist=this.allDepositListByStatus.DPBS;
                this.showCollapseOne = false;
                this.showCollapseTwo = !this.showCollapseTwo;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "repaymentReqTenant":
                var section = this.template.querySelector("[data-id='repaymentReqTenant']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.RRT;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = !this.showCollapseThree;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "repaymentReqAgnt":
                var section = this.template.querySelector("[data-id='repaymentReqAgnt']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.RRAL;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = !this.showCollapseFour;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "repaymentNotAgrISR":
                var section = this.template.querySelector("[data-id='repaymentNotAgrISR']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.SR;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = !this.showCollapseFive;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "repaymentNotAgrIDR":
                var section = this.template.querySelector("[data-id='repaymentNotAgrIDR']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.DS;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = !this.showCollapseSix;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                break;
            case "repayProcess":
                var section = this.template.querySelector("[data-id='repayProcess']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = !this.showCollapseSeven;
                this.showCollapseEight = false;
                break;
            case "depositRepayments":
                var section = this.template.querySelector("[data-id='depositRepayments']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.DRLY;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = !this.showCollapseEight;
                break;
            case "depositProtected":
                var section = this.template.querySelector("[data-id='depositProtected']");
                if (section.classList.contains('collapsed')) {
                    section.classList.remove('collapsed');
                    section.setAttribute("aria-expanded", "true");
                } else {
                    section.classList.add('collapsed');
                    section.setAttribute("aria-expanded", "false");
                }
                this.template.querySelector('[data-id="confirmTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="confirmTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositHeld"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositHeld"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqTenant"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqTenant"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentReqAgnt"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrISR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repaymentNotAgrIDR"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="repayProcess"]').classList.add("collapsed");
                this.template.querySelector('[data-id="repayProcess"]').setAttribute("aria-expanded", "false");
                this.template.querySelector('[data-id="depositRepayments"]').classList.add("collapsed");
                this.template.querySelector('[data-id="depositRepayments"]').setAttribute("aria-expanded", "false");
                
                this.rnpstatuslist=this.allDepositListByStatus.DPS;
                this.showCollapseOne = false;
                this.showCollapseTwo = false;
                this.showCollapseThree = false;
                this.showCollapseFour = false;
                this.showCollapseFive = false;
                this.showCollapseSix = false;
                this.showCollapseSeven = false;
                this.showCollapseEight = false;
                this.showCollapseNine = !this.showCollapseNine;
                break;

        }
    }

    handleEnterClick(event) {
        // console.log('Called Event',event.keyCode);
        if (event.keyCode === 13) {
            this.handleSearchClick();
        }
    }

    handleSearchClick() {
        this.template.querySelector('[data-id="confirmTenant"]').style = '';
        if (this.hideSectionOne) {
            this.template.querySelector('[data-id="RNPDiv1"]').style.color = '';
            /* this.template.querySelector('[data-id="RNPDiv2"]').style.color = '';
            this.template.querySelector('[data-id="RNPDiv3"]').style.color = ''; */
        }

        this.template.querySelector('[data-id="depositHeld"]').style = '';
        this.template.querySelector('[data-id="DHBSDiv1"]').style.color = '';
        this.template.querySelector('[data-id="DHBSDiv2"]').style.color = '';
        this.template.querySelector('[data-id="DHBSDiv3"]').style.color = '';

        this.template.querySelector('[data-id="repaymentReqTenant"]').style = '';
        this.template.querySelector('[data-id="RRTDiv1"]').style.color = '';
        this.template.querySelector('[data-id="RRTDiv2"]').style.color = '';
        this.template.querySelector('[data-id="RRTDiv3"]').style.color = '';

        this.template.querySelector('[data-id="repaymentReqAgnt"]').style = '';
        this.template.querySelector('[data-id="RRALDiv1"]').style.color = '';
        this.template.querySelector('[data-id="RRALDiv2"]').style.color = '';
        this.template.querySelector('[data-id="RRALDiv3"]').style.color = '';

        this.template.querySelector('[data-id="repaymentNotAgrISR"]').style = '';
        this.template.querySelector('[data-id="SRDiv1"]').style.color = '';
        this.template.querySelector('[data-id="SRDiv2"]').style.color = '';
        this.template.querySelector('[data-id="SRDiv3"]').style.color = '';

        this.template.querySelector('[data-id="repaymentNotAgrIDR"]').style = '';
        this.template.querySelector('[data-id="DSDiv1"]').style.color = '';
        this.template.querySelector('[data-id="DSDiv2"]').style.color = '';
        this.template.querySelector('[data-id="DSDiv3"]').style.color = '';

        this.template.querySelector('[data-id="repayProcess"]').style = '';
        this.template.querySelector('[data-id="RPDiv1"]').style.color = '';
        this.template.querySelector('[data-id="RPDiv2"]').style.color = '';
        this.template.querySelector('[data-id="RPDiv3"]').style.color = '';

        this.template.querySelector('[data-id="depositRepayments"]').style = '';
        this.template.querySelector('[data-id="DRLYDiv1"]').style.color = '';
        this.template.querySelector('[data-id="DRLYDiv2"]').style.color = '';
        this.template.querySelector('[data-id="DRLYDiv3"]').style.color = '';

        this.template.querySelector('[data-id="depositProtected"]').style = '';
        this.template.querySelector('[data-id="DPSDiv1"]').style.color = '';
        this.template.querySelector('[data-id="DPSDiv2"]').style.color = '';
        this.template.querySelector('[data-id="DPSDiv3"]').style.color = '';


        var searchValue = this.template.querySelector('[data-id="searchCustodialValue"]').value;
        this.searchText = searchValue;
        console.log('Search String::', searchValue);
        if (searchValue.length > 0) {
            getDepositRecordsBySearch({
                "searchText": searchValue,
                "scheme": 'Insured'
            }).then(result => {
                this.isSearchResult=true;
                this.searchList= { 'RNP': [], 'DPBS': [], 'RRT': [], 'RRAL': [], 'SR': [], 'DS': [], 'RP': [], 'DRLY': [], 'DPS': [] };
                console.log('Result Length::' + result.length + '\tResult::' + JSON.stringify(result));
                let depositCountByStatus = { 'RNP': 0, 'DPBS': 0, 'RRT': 0, 'RRAL': 0, 'SR': 0, 'DS': 0, 'RP': 0, 'DRLY': 0, 'DPS': 0 };
                let depositAmountByStatus = { 'RNP': 0.00, 'DPBS': 0.00, 'RRT': 0.00, 'RRAL': 0.00, 'SR': 0.00, 'DS': 0.00, 'RP': 0.00, 'DRLY': 0.00, 'DPS': 0.00 };
                let depositListByStatus = { 'RNP': [], 'DPBS': [], 'RRT': [], 'RRAL': [], 'SR': [], 'DS': [], 'RP': [], 'DRLY': [], 'DPS': [] };

                this.allDepositCountByStatus.DPBS = depositCountByStatus.DPBS;
                this.allDepositAmountByStatus.DPBS = depositAmountByStatus.DPBS.toFixed(2);
                this.allDepositCountByStatus.RNP = depositCountByStatus.RNP;
                this.allDepositAmountByStatus.RNP = depositAmountByStatus.RNP.toFixed(2);
                this.allDepositCountByStatus.RRT = depositCountByStatus.RRT;
                this.allDepositAmountByStatus.RRT = depositAmountByStatus.RRT.toFixed(2);
                this.allDepositCountByStatus.RRAL = depositCountByStatus.RRAL;
                this.allDepositAmountByStatus.RRAL = depositAmountByStatus.RRAL.toFixed(2);
                this.allDepositCountByStatus.SR = depositCountByStatus.SR;
                this.allDepositAmountByStatus.SR = depositAmountByStatus.SR.toFixed(2);
                this.allDepositCountByStatus.DS = depositCountByStatus.DS;
                this.allDepositAmountByStatus.DS = depositAmountByStatus.DS.toFixed(2);
                this.allDepositCountByStatus.RP = depositCountByStatus.RP;
                this.allDepositAmountByStatus.RP = depositAmountByStatus.RP.toFixed(2);
                this.allDepositCountByStatus.DRLY = depositCountByStatus.DRLY;
                this.allDepositAmountByStatus.DRLY = depositAmountByStatus.DRLY.toFixed(2);
                this.allDepositCountByStatus.DPS = depositCountByStatus.DPS;
                this.allDepositAmountByStatus.DPS = depositAmountByStatus.DPS.toFixed(2);

                if (result.length > 0) {
                    for (var i = 0; i < result.length; i++) {
                        if (result[i].Status__c == 'Deposits protected by scheme') {
                            depositCountByStatus.DPBS = depositCountByStatus.DPBS + 1;
                            depositAmountByStatus.DPBS = depositAmountByStatus.DPBS + result[i].Deposit_Amount__c;
                            depositListByStatus.DPBS.push(result[i]);
                            this.searchList.DPBS.push(result[i]);
                        } else if (result[i].Status__c == 'Proposal submitted - tenant') {
                            depositCountByStatus.RRT = depositCountByStatus.RRT + 1;
                            depositAmountByStatus.RRT = depositAmountByStatus.RRT + result[i].Deposit_Amount__c;
                            depositListByStatus.RRT.push(result[i]);
                            this.searchList.RRT.push(result[i]);
                        } else if (result[i].Status__c == 'Proposal submitted – awaiting tenant response') {
                            depositCountByStatus.RRAL = depositCountByStatus.RRAL + 1;
                            depositAmountByStatus.RRAL = depositAmountByStatus.RRAL + result[i].Deposit_Amount__c;
                            depositListByStatus.RRAL.push(result[i]);
                            this.searchList.RRAL.push(result[i]);
                        } else if (result[i].Status__c == 'Repayment not agreed - In self-resolution') {
                            depositCountByStatus.SR = depositCountByStatus.SR + 1;
                            depositAmountByStatus.SR = depositAmountByStatus.SR + result[i].Deposit_Amount__c;
                            depositListByStatus.SR.push(result[i]);
                            this.searchList.SR.push(result[i]);
                        } else if (result[i].Status__c == 'Repayment not agreed - In dispute resolution') {
                            depositCountByStatus.DS = depositCountByStatus.DS + 1;
                            depositAmountByStatus.DS = depositAmountByStatus.DS + result[i].Deposit_Amount__c;
                            depositListByStatus.DS.push(result[i]);
                            this.searchList.DS.push(result[i]);
                        } else if (result[i].Status__c == 'Repayment process') {
                            depositCountByStatus.RP = depositCountByStatus.RP + 1;
                            depositAmountByStatus.RP = depositAmountByStatus.RP + result[i].Deposit_Amount__c;
                            depositListByStatus.RP.push(result[i]);
                            this.searchList.RP.push(result[i]);
                        } else if (result[i].Status__c == 'Deposit protections concluded in the last year') {
                            depositCountByStatus.DRLY = depositCountByStatus.DRLY + 1;
                            depositAmountByStatus.DRLY = depositAmountByStatus.DRLY + result[i].Deposit_Amount__c;
                            depositListByStatus.DRLY.push(result[i]);
                            this.searchList.DRLY.push(result[i]);
                        } else if (result[i].Status__c == 'Registered (not paid)') {
                            depositCountByStatus.RNP = depositCountByStatus.RNP + 1;
                            depositAmountByStatus.RNP = depositAmountByStatus.RNP + result[i].Deposit_Amount__c;
                            depositListByStatus.RNP.push(result[i]);
                            this.searchList.RNP.push(result[i]);
                        } else if (result[i].Status__c == 'Deposit protected by scheme (tenancy ended)') {
                            depositCountByStatus.DPS = depositCountByStatus.DPS + 1;
                            depositAmountByStatus.DPS = depositAmountByStatus.DPS + result[i].Deposit_Amount__c;
                            depositListByStatus.DPS.push(result[i]);
                            this.searchList.DPS.push(result[i]);
                        }
                    }

                    if (depositListByStatus.RNP.length > 0) {
                        this.allDepositCountByStatus.RNP = depositCountByStatus.RNP;
                        this.allDepositAmountByStatus.RNP = depositAmountByStatus.RNP.toFixed(2);
                        this.allDepositListByStatus.RNP = depositListByStatus.RNP;

                        this.template.querySelector('[data-id="confirmTenant"]').style.backgroundColor = "#13185C";
                        if (this.hideSectionOne) {
                            this.template.querySelector('[data-id="RNPDiv1"]').style.color = "#fff";
                            /* this.template.querySelector('[data-id="RNPDiv2"]').style.color = "#fff";
                            this.template.querySelector('[data-id="RNPDiv3"]').style.color = "#fff"; */
                        }
                    }
                    if (depositListByStatus.DPBS.length > 0) {
                        this.allDepositCountByStatus.DPBS = depositCountByStatus.DPBS;
                        this.allDepositAmountByStatus.DPBS = depositAmountByStatus.DPBS.toFixed(2);
                        this.allDepositListByStatus.DPBS = depositListByStatus.DPBS;

                        this.template.querySelector('[data-id="depositHeld"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="DHBSDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DHBSDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DHBSDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.RRT.length > 0) {
                        this.allDepositCountByStatus.RRT = depositCountByStatus.RRT;
                        this.allDepositAmountByStatus.RRT = depositAmountByStatus.RRT.toFixed(2);
                        this.allDepositListByStatus.RRT = depositListByStatus.RRT;

                        this.template.querySelector('[data-id="repaymentReqTenant"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="RRTDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RRTDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RRTDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.RRAL.length > 0) {
                        this.allDepositCountByStatus.RRAL = depositCountByStatus.RRAL;
                        this.allDepositAmountByStatus.RRAL = depositAmountByStatus.RRAL.toFixed(2);
                        this.allDepositListByStatus.RRAL = depositListByStatus.RRAL;

                        this.template.querySelector('[data-id="repaymentReqAgnt"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="RRALDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RRALDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RRALDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.SR.length > 0) {
                        this.allDepositCountByStatus.SR = depositCountByStatus.SR;
                        this.allDepositAmountByStatus.SR = depositAmountByStatus.SR.toFixed(2);
                        this.allDepositListByStatus.SR = depositListByStatus.SR;

                        this.template.querySelector('[data-id="repaymentNotAgrISR"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="SRDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="SRDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="SRDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.DS.length > 0) {
                        this.allDepositCountByStatus.DS = depositCountByStatus.DS;
                        this.allDepositAmountByStatus.DS = depositAmountByStatus.DS.toFixed(2);
                        this.allDepositListByStatus.DS = depositListByStatus.DS;

                        this.template.querySelector('[data-id="repaymentNotAgrIDR"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="DSDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DSDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DSDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.RP.length > 0) {
                        this.allDepositCountByStatus.RP = depositCountByStatus.RP;
                        this.allDepositAmountByStatus.RP = depositAmountByStatus.RP.toFixed(2);
                        this.allDepositListByStatus.RP = depositListByStatus.RP;

                        this.template.querySelector('[data-id="repayProcess"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="RPDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RPDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="RPDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.DRLY.length > 0) {
                        this.allDepositCountByStatus.DRLY = depositCountByStatus.DRLY;
                        this.allDepositAmountByStatus.DRLY = depositAmountByStatus.DRLY.toFixed(2);
                        this.allDepositListByStatus.DRLY = depositListByStatus.DRLY;

                        this.template.querySelector('[data-id="depositRepayments"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="DRLYDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DRLYDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DRLYDiv3"]').style.color = "#fff";
                    }
                    if (depositListByStatus.DPS.length > 0) {
                        this.allDepositCountByStatus.DPS = depositCountByStatus.DPS;
                        this.allDepositAmountByStatus.DPS = depositAmountByStatus.DPS.toFixed(2);
                        this.allDepositListByStatus.DPS = depositListByStatus.DPS;

                        this.template.querySelector('[data-id="depositProtected"]').style.backgroundColor = "#13185C";
                        this.template.querySelector('[data-id="DPSDiv1"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DPSDiv2"]').style.color = "#fff";
                        this.template.querySelector('[data-id="DPSDiv3"]').style.color = "#fff";
                    }
                }
            })
        } else {
            this.getDepositsByStatus(this.allDepositsByStatus, this.nonValidatedDeposits);
            this.isSearchResult=false;
        }
    }

    handleCustodialSection() {
        this.showCustodialDeposits = true;
        this.showInsuredDeposits = false;
        this.displayMessage = false;
        eval("$A.get('e.force:refreshView').fire();");
    }
    handleInsuredSection() {
        this.showCustodialDeposits = false;
        this.showInsuredDeposits = true;

        var custodialTab = this.template.querySelector("[name='custodial-deposits']");
        var insuredTab = this.template.querySelector("[name='insured-deposits']");

        custodialTab.classList.remove('active');
        insuredTab.classList.add('active');
    }

    confirmDeposit(event) {
        event.preventDefault();
        console.log('Deposit Id::', event.target.name);
        this.depositId = event.target.name;
        for (var i = 0; i < this.unvalidatedDeposits.length; i++) {
            if (this.unvalidatedDeposits[i].depositId == event.target.name) {
                this.unvalidatedDeposits[i].rowColor = 'background-color:#409ac9';
            } else {
                this.unvalidatedDeposits[i].rowColor = 'background-color:';
            }
        }

        // Generate Years
        let currentYear = new Date().getFullYear();
        let startYear = 1990;
        for (var i = currentYear + 3; i >= startYear; i--) {
            this.years.push(i);
        }
        this.validationError = false;
        this.showConfirmForm = true;
        if (this.showConfirmForm) {
            this.template.querySelector("[name='postCode']").value = '';
            this.template.querySelector('lightning-input[data-name="deposit-amount"]').value = '';
        }
    }

    submitDeposit(event) {
        var isValid = true;

        let postCode = this.template.querySelector("[name='postCode']").value;
        //let depositAmount = this.template.querySelector("[name='deposit-amount']").value;
        let depositAmount = this.template.querySelector('lightning-input[data-name="deposit-amount"]').value;
        // let monthSelected = this.template.querySelector("[name='start-month']").value;
        // let yearSelected = this.template.querySelector("[name='start-year']").value;

        if (postCode.trim() == "" || postCode.trim() == null || postCode == undefined) {
            this.postCodeError = true;
            isValid = false;
        }
        if (depositAmount == "" || depositAmount == null || depositAmount == undefined) {
            this.depositAmountError = true;
            isValid = false;
        }
        /* if (monthSelected == "" || monthSelected == null || monthSelected == undefined) {
            this.tenancyMonthError = true;
            isValid = false;
        }
        if (yearSelected == "" || yearSelected == null || yearSelected == undefined) {
            this.tenancyYearError = true;
            isValid = false;
        } */

        if (!isValid) {
            this.template.querySelector('.errorMessages').scrollIntoView();
        }
        if (isValid) {
            this.validationError = false;
            validateDeposit({
                "postCode": postCode,
                "amount": parseFloat(depositAmount),
                /* "month": parseInt(monthSelected),
                "year": parseInt(yearSelected), */
                "depositId": this.depositId
            }).then(result => {
                console.log('Deposit after validation:::' + JSON.stringify(result));
                if (result[0].Number_Of_Attempts__c == 3 && result[0].Answered_Correctly__c == 'No') {
                    console.log('Inside if');
                    window.location.reload();
                } else if (result[0].Answered_Correctly__c == 'No' && (result[0].Number_Of_Attempts__c == 1 || result[0].Number_Of_Attempts__c == 2)) {
                    console.log('Inside ielse if');
                    this.remainingAttempts = 3 - result[0].Number_Of_Attempts__c;
                    this.validationError = true;
                } else {
                    console.log('Inside else');
                    if (this.unvalidatedDeposits.length > 1) {
                        window.location.reload();
                    } else if (this.unvalidatedDeposits.length == 1) {
                        this[NavigationMixin.Navigate]({
                            type: 'comm__namedPage',
                            attributes: {
                                pageName: 'deposit-summary'
                            },
                            state: {
                                c__depositRecId: window.btoa(this.depositId)
                            }
                        });
                    }
                }
            }).catch(error => {
                console.log('Error at deposit validation::', JSON.stringify(error));
            })
        }
    }

    // navigateToSummary(event) {
    //     event.preventDefault();
    //     var depositId = window.btoa(event.currentTarget.name);
    //     // var depositId = event.currentTarget.name;
    //     if (depositId != null && depositId != "" && depositId != undefined) {
    //         this[NavigationMixin.Navigate]({
    //             type: 'comm__namedPage',
    //             attributes: {
    //                 pageName: 'deposit-summary'
    //             },
    //             state: {
    //                 c__depositRecId: depositId
    //             }
    //         });
    //     }
    // }

    handleCaptcha(event) {
        console.log('received message from child');
        console.log('childMessage', JSON.stringify(event.detail));
        if (!event.detail.value && (event.detail.response != null && event.detail.response != "" && event.detail.response != undefined)) {
            RecaptchaHandler({
                recaptchaResponse: event.detail.response
            }).then(result => {
                if (result.includes('Success')) {
                    this.showSubmit = true;
                } else {
                    this.showSubmit = false;
                }
                console.log('Result:::', result);
            }).catch(error => {
                this.showSubmit = false;
                console.log('Error while validating Captcha::', JSON.stringify(error));
            })
        } else if (event.detail.value) {
            this.showSubmit = false;
        }
    }

    hideBootstrapErrors(event) {
        var buttonName = event.target.name;
        switch (buttonName) {
            case "postCodeErrorMsg":
                this.postCodeError = false;
                break;
            case "depositAmountErrorMsg":
                this.depositAmountError = false;
                break;
            case "tenancyMonthErrorMsg":
                this.tenancyMonthError = false;
                break;
            case "tenancyYearErrorMsg":
                this.tenancyYearError = false;
                break;
        }
    }
}