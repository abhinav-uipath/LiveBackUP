import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import updateBankDetailsOfTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.updateBankDetailsOfTenant';
import updateIntBankDetailsOfTenant from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.updateIntBankDetailsOfTenant';
import fetchBankDetails from '@salesforce/apex/EI_NI_TenantRespondToRepaymentRequest.fetchBankDetails';


export default class EI_NI_TenantBankDetailEviGather extends LightningElement {

    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    featherImg = NI_Theme + '/assets/img/feather-edit_nhos.svg';
    //UK bank section
    isNoBankDetailsfound = false;
    isbankdetailsPresent = false;
    isShowbankdetailSection = false;
    isBankSuccessMessage = false;
    isBankErrorMessage = false;
    isBankNoChangeError = false;
    isBankNoChangeError1 = false;
    isNameOnAccountBlankError = false;
    isNameOnAccountSizeError = false;
    isNameOnAccountSpecialCharError = false;
    isAccountNumberLengthError = false;
    isAccountNumberBlankError = false;
    isInvalidAccountNumberError = false;
    isInvalidIBANError = false;
    isSortCodeBlankError = false;
    isSortcodelengtherror = false;
    isInvalidSortCodeError = false;

    // International bank error handler
    isIntBankSuccessMessage = false;

    isIntNameOnAccountBlankError = false;
    IntBankAccNamePatternError = false;
    IntAccNamelenError = false;
    isBankNameBlankError = false;
    IntBankNamePatternError = false;
    IntbankNamelenError = false;
    isIBANblankError = false;
    IntIbanSpecialError = false;
    IbanlenError = false;
    isSwiftCodeBlankError = false;
    IntBankSwiftPatternError = false;
    IntBankSwiftlenError = false;
    isBICCodeBlankError = false;
    IntBankIdentPatternError = false;
    IntBankIdentPatternlenError = false;
    isBenificiaryBlankError = false;

    //UK and INt.bank 
    wiredAccountData;
    @api bankAccountName = '';
    @api bankAccountNumber = '';
    @api sortCode = '';
    @api bankName = '';
    @api branchIds = null;
    @api IntbankAccountName = '';
    @api IntbankName = '';
    @api IntbankIdentCode = '';
    @api IntbankSwiftcode = '';
    @api IntbankIban = '';
    @api IntbankAccountBenfAdd = '';
    @api isBankDetails = false;

    @api isFuturePay = false;
    @api userName = '';
    @api calledFrom;

    @api yesBankParent = false;
    @api noBankParent = false;
    isNoBankParent = false;
    isYesBankParent = true;
    @api isEvidenceGatheringButtons;

    //showSpinner = false;

    connectedCallback() {
        Promise.all([
            loadStyle(this, `${NI_Theme}/assets/css/custom-ni.css`),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js')
        ]).then(() => {
            console.log('Files loaded.');
        })
            .catch(error => {
                console.log(error.body.message);
            });
        console.log('depid@@' + this.calledFrom);
        let accountId = this.calledFrom;

        fetchBankDetails({
            accId: accountId
        }).then(result => {
            console.log('child bank details-->', JSON.stringify(result));
            // console.log('bank ac name-->'+result[0].Bank_Account_Holder_Name__c);ValidInternationBankDetails__c

            this.bankDetails = result;
            console.log('Iban==>' + this.bankDetails[0].IBAN__c);
            if (this.bankDetails[0].ValidInternationBankDetails__c == false && this.bankDetails[0].IBAN__c == undefined) {
                console.log('bank details not fount-->');
                this.isNoBankDetailsfound = true;
                this.isBankDetails = false;
                this.isbankdetailsPresent = false;
                this.userName = this.bankDetails[0].Name;
            } else {
                this.isbankdetailsPresent = true;
                this.isBankDetails = true;
                this.userName = this.bankDetails[0].Name;

                console.log('userName==>' + this.userName);
                console.log('name on A/C-->' + this.bankDetails[0].Bank_Account_Holder_Name__c);
                console.log('bank a/c number-->' + this.bankDetails[0].Account_Number__c);
                console.log('bankSortcode-->' + this.bankDetails[0].Sort_Code__c);
                console.log('bank name-->' + this.bankDetails[0].Bank_Name__c);
                //  UK bank details
                if (this.bankDetails[0].Bank_Account_Holder_Name__c != undefined && this.bankDetails[0].Bank_Account_Holder_Name__c != "" && this.bankDetails[0].Bank_Account_Holder_Name__c != null) {
                    this.bankAccountName = this.bankDetails[0].Bank_Account_Holder_Name__c;
                } else {
                    this.bankAccountName = '';
                }
                if (this.bankDetails[0].Account_Number__c != undefined && this.bankDetails[0].Account_Number__c != "" && this.bankDetails[0].Account_Number__c != null) {
                    this.bankAccountNumber = this.bankDetails[0].Account_Number__c;
                } else {
                    this.bankAccountNumber = '';
                }
                if (this.bankDetails[0].Sort_Code__c != undefined && this.bankDetails[0].Sort_Code__c != "" && this.bankDetails[0].Sort_Code__c != null) {
                    this.sortCode = this.bankDetails[0].Sort_Code__c;
                } else {
                    this.sortCode = '';
                }
                if (this.bankDetails[0].Bank_Name__c != undefined && this.bankDetails[0].Bank_Name__c != "" && this.bankDetails[0].Bank_Name__c != null) {
                    this.bankName = this.bankDetails[0].Bank_Name__c;
                } else {
                    this.bankName = '';
                }
                //    intenational bank details
                if (this.bankDetails[0].International_Bank_Account_Holder_Name__c != undefined) {//|| this.bankDetails[0].International_Bank_Account_Holder_Name__c != "" || this.bankDetails[0].International_Bank_Account_Holder_Name__c != null){
                    this.IntbankAccountName = this.bankDetails[0].International_Bank_Account_Holder_Name__c;
                    console.log('int bank from IF');
                } else {
                    this.IntbankAccountName = '';
                    console.log('int bank from else');
                }
                if (this.bankDetails[0].BIC__c != undefined) {// || this.bankDetails[0].BIC__c != "" || this.bankDetails[0].BIC__c != null){
                    this.IntbankIdentCode = this.bankDetails[0].BIC__c;
                } else {
                    this.IntbankIdentCode = '';
                }
                if (this.bankDetails[0].Swift_Code__c != undefined) {//|| this.bankDetails[0].Swift_Code__c != "" || this.bankDetails[0].Swift_Code__c != null){
                    this.IntbankSwiftcode = this.bankDetails[0].Swift_Code__c;
                } else {
                    this.IntbankSwiftcode = '';
                }
                if (this.bankDetails[0].IBAN__c != undefined) {//|| this.bankDetails[0].IBAN__c != "" || this.bankDetails[0].IBAN__c != null){
                    this.IntbankIban = this.bankDetails[0].IBAN__c;
                } else {
                    this.IntbankIban = '';
                }
                if (this.bankDetails[0].International_Bank_Name__c != undefined) {// || this.bankDetails[0].International_Bank_Name__c != "" || this.bankDetails[0].International_Bank_Name__c != null){
                    this.IntbankName = this.bankDetails[0].International_Bank_Name__c;
                } else {
                    this.IntbankName = '';
                }
                if (this.bankDetails[0].Beneficiary_home_address__c != undefined) {
                    this.IntbankAccountBenfAdd = this.bankDetails[0].Beneficiary_home_address__c;
                } else {
                    this.IntbankAccountBenfAdd = '';
                }
            }

            // Firing event from Child component to Parent component START
            const eventData = { isBankDetails: this.isbankdetailsPresent };
            const event = new CustomEvent('getbankdetails', { detail: eventData });
            this.dispatchEvent(event);
            // Firing event from Child component to Parent component END

        }).catch(error => {
            console.log('bank details error-->', JSON.stringify(error));

        });

        console.log('no Bank Parent-->' + this.isNoBankParent);
        console.log('yes Bank Parent-->' + this.isYesBankParent);
        /* console.log('noBankParent-->'+this.noBankParent);
        if(!this.noBankParent){
            console.log('123');
            this.isNoBankParent=false;
            this.isYesBankParent=true;
        }
        else{
            console.log('1232345');
            this.isNoBankParent=true;
            this.isYesBankParent=false;
        } */

    }

    renderedCallback() {

        // Pass initial data to parent component
        // console.log('bank true'+this.isBankDetails);
        // const eventData = {isBankDetails: this.isBankDetails};
        // const event = new CustomEvent('getbankdetails', { detail: eventData });
        // this.dispatchEvent(event);
    }

    /* @api bankDetailsEditSection(event){
        event.preventDefault();
        this.isShowbankdetailSection = true;
    } */

    @api
    showWarning(isWarning) {
        this.noBankParent = isWarning;
        console.log('this.noBankParent ==>' + this.noBankParent);
        if (this.noBankParent) {
            this.isNoBankParent = true;
            this.isYesBankParent = false;
        }
    }

    @api
    bankDetailsEditSection(event) {
        event.preventDefault();
        this.isShowbankdetailSection = true;
        this.isbankdetailsNotAvl = false;
        this.isBankSuccessMessage = false;
        this.isBankErrorMessage = false;
        this.isBankNoChangeError = false;
        this.isBankNoChangeError1 = false;
        this.isNameOnAccountBlankError = false;
        this.isNameOnAccountSizeError = false;
        this.isNameOnAccountSpecialCharError = false;
        this.isAccountNumberLengthError = false;
        this.isAccountNumberBlankError = false;
        this.isInvalidAccountNumberError = false;
        this.isSortCodeBlankError = false;
        this.isSortcodelengtherror = false;
        this.isInvalidSortCodeError = false;


        // International bank error handler
        this.isIntNameOnAccountBlankError = false;
        this.IntBankAccNamePatternError = false;
        this.IntAccNamelenError = false;
        this.isBankNameBlankError = false;
        this.IntBankNamePatternError = false;
        this.IntbankNamelenError = false;
        this.isIBANblankError = false;
        this.IntIbanSpecialError = false;
        this.IbanlenError = false;
        this.isSwiftCodeBlankError = false;
        this.IntBankSwiftPatternError = false;
        this.IntBankSwiftlenError = false;
        this.isBICCodeBlankError = false;
        this.IntBankIdentPatternError = false;
        this.IntBankIdentPatternlenError = false;
        this.isBenificiaryBlankError = false;
        console.log('bank ac name from edit-->' + this.bankAccountName);
        console.log('add bank detail' + this.isNoBankDetailsfound);

    }

    get onKeyDownHandle() {
        return ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight'].includes(event.code) ? true : !isNaN(Number(event.key)) && event.code !== 'Space';
    }

    //Handle UK payment detail
    handlebankAccountNamechange(event) {
        this.bankAccountName = event.target.value;
    }

    handlebankAccountNumberChange(event) {
        var str = event.target.value;
        str = str.replace(/[^0-9]/g, '');
        event.target.value = str;
        this.bankAccountNumber = str;
        console.log('this.bankAccountNumber : @@@@@' + this.bankAccountNumber);
    }

    handlesortcodeChange(event) {
        var str = event.target.value;
        str = str.replace(/[^0-9]/g, '');
        event.target.value = str;
        this.sortCode = str;
        console.log('this.sortCode : @@@@@' + this.sortCode);
    }

    updateBankDetails(event) {
        this.isBankSuccessMessage = false;
        this.isBankErrorMessage = false;
        this.isBankNoChangeError = false;
        this.isNameOnAccountBlankError = false;
        this.isNameOnAccountSizeError = false;
        this.isNameOnAccountSpecialCharError = false;
        this.isAccountNumberLengthError = false;
        this.isAccountNumberBlankError = false;
        this.isInvalidAccountNumberError = false;
        this.isSortCodeBlankError = false;
        this.isSortcodelengtherror = false;
        this.isInvalidSortCodeError = false;

        let isValid = true;
        let accountNumber = this.bankAccountNumber;
        let sortCode = this.sortCode;
        let bankAccountNames = this.bankAccountName;

        const regEX = /^[a-zA-Z0-9\s]*$/;
        const nameNumRegEx = /^[a-zA-Z0-9\s]*$/;


        if (bankAccountNames == undefined || bankAccountNames == "" || bankAccountNames == null || bankAccountNames.trim() == "") {
            isValid = false;
            this.isNameOnAccountBlankError = true;
        } else if (!regEX.test(bankAccountNames)) {
            this.isNameOnAccountSpecialCharError = true;
            isValid = false;
        }

        if (bankAccountNames.length > 64) {
            this.isNameOnAccountSizeError = true;
            isValid = false;
        }

        if (sortCode == undefined || sortCode == '' || sortCode == null || sortCode.trim() == '') {
            isValid = false;
            this.isSortCodeBlankError = true;
        } else if (!nameNumRegEx.test(sortCode)) {
            this.isInvalidSortCodeError = true;
            isValid = false;
        } else if (sortCode.length < 6 || sortCode.length > 6) {
            this.isSortcodelengtherror = true;
            isValid = false;
        }


        if (accountNumber == undefined || accountNumber == "" || accountNumber == null || accountNumber.trim() == "") {
            isValid = false;
            this.isAccountNumberBlankError = true;
        } else if (!nameNumRegEx.test(this.accountNumber)) {
            isValid = false;
            this.isInvalidAccountNumberError = true;
        } else if (accountNumber.length < 8 || accountNumber.length > 8) {
            this.isAccountNumberLengthError = true;
            isValid = false;
        }

        if (isValid) {
            //this.showSpinner = true;
            this.isSortCodeBlankError = false;
            this.isAccountNumberBlankError = false;
            this.isNameOnAccountBlankError = false;
            if (this.isbankdetailsPresent &&
                (this.bankAccountName == this.bankDetails[0].Bank_Account_Holder_Name__c &&
                    this.bankAccountNumber == this.bankDetails[0].Account_Number__c && this.sortCode == this.bankDetails[0].Sort_Code__c)) {
                this.isBankSuccessMessage = true;
            } else {
                let bankInfoType = 'account';
                updateBankDetailsOfTenant({
                    accountNumber: accountNumber,
                    sortCode: sortCode,
                    bankAccountName: bankAccountNames,
                    bankName: this.bankName,
                    bankInfoType: bankInfoType
                }).then(result => {
                    var messageValue = result;
                    if (messageValue == 'UnknownSortCode') {
                        this.isInvalidSortCodeError = true;
                    }
                    if (messageValue == 'InvalidAccountNumber') {
                        this.isInvalidAccountNumberError = true;
                    } else if (messageValue != 'UnknownSortCode' && messageValue != 'InvalidAccountNumber') {
                        this.isBankSuccessMessage = true;
                        this.isNoBankDetailsfound = false;
                        this.isbankdetailsPresent = true;
                        this.isbankdetailsNotAvl = false;
                        this.isBankDetails = true;
                        this.bankName = messageValue;

                        // Firing event from Child component to Parent component START
                        const eventData = { isBankDetails: this.isBankDetails };
                        const event = new CustomEvent('getbankdetails', { detail: eventData });
                        this.dispatchEvent(event);
                        // Firing event from Child component to Parent component END
                    }
                    //this.showSpinner = false;
                }).catch(error => {
                    //this.showSpinner = false;
                    this.isBankSuccessMessage = false;
                    this.isBankErrorMessage = true;
                    console.log('Line 210 Error -> ', error);
                });
            }
        }
    }

    bankdetailcancelhandle(event) {
        this.isShowbankdetailSection = false;
    }

    // International Bank detils section
    handleIntbankAccountNamechange(event) {
        this.IntbankAccountName = event.target.value;
    }

    handleIntbankNamechange(event) {
        this.IntbankName = event.target.value;
    }

    handleIntBICchange(event) {
        this.IntbankIdentCode = event.target.value;
    }

    handleIntbankSWIFTchange(event) {
        this.IntbankSwiftcode = event.target.value;
    }

    handleIntbankIBANchange(event) {
        this.IntbankIban = event.target.value;
    }

    handleIntbankAccountBenfNamechange(event) {
        this.IntbankAccountBenfAdd = event.target.value;
        console.log('IntBenfAdd@@@' + this.IntbankAccountBenfAdd);
    }

    updateIntBankDetails(event) {
        // International bank error handler
        this.isIntBankSuccessMessage = false;
        this.isIntNameOnAccountBlankError = false;
        this.IntBankAccNamePatternError = false;
        this.IntAccNamelenError = false;
        this.isBankNameBlankError = false;
        this.IntBankNamePatternError = false;
        this.IntbankNamelenError = false;
        this.isBICCodeBlankError = false;
        this.IntBankIdentPatternError = false;
        this.IntBankIdentPatternlenError = false;
        this.isSwiftCodeBlankError = false;
        this.IntBankSwiftPatternError = false;
        this.IntBankSwiftlenError = false;
        this.isIBANblankError = false;
        this.IntIbanSpecialError = false;
        this.IbanlenError = false;
        this.isBenificiaryBlankError = false;
        this.isInvalidIBANError = false;

        let isValid = true;
        var bankIntName = this.IntbankName;
        var bankIdentificationCode = this.IntbankIdentCode;
        var bankSwiftCode = this.IntbankSwiftcode;
        var IBAN = this.IntbankIban;
        var bankIntAccountName = this.IntbankAccountName;
        var bankBenfiAdd = this.IntbankAccountBenfAdd;

        const nameRegEx = /^[a-zA-Z\s]*$/;
        const nameNumRegEx = /^[a-zA-Z0-9\s]*$/;
        var specials = /[-!$+%^&*@#()_|~=`{}\[\]:";\'<>?,.\/]/;

        if (bankIntAccountName == null || bankIntAccountName.trim() == "" || bankIntAccountName == undefined) {
            isValid = false;
            this.isIntNameOnAccountBlankError = true;
        } else if (!nameNumRegEx.test(bankIntAccountName)) {
            isValid = false;
            this.IntBankAccNamePatternError = true;
        } else if (bankIntAccountName.length > 64) {
            isValid = false;
            this.IntAccNamelenError = true;
        }

        if (bankIntName == undefined || bankIntName.trim() == "" || bankIntName == null) {
            isValid = false;
            this.isBankNameBlankError = true;
        } else if (!nameRegEx.test(bankIntName)) {
            isValid = false;
            this.IntBankNamePatternError = true;
        } else if (bankIntName.length > 64) {
            isValid = false;
            this.IntbankNamelenError = true;
        }

        if (bankIdentificationCode == null || bankIdentificationCode == undefined || bankIdentificationCode.trim() == "") {
            isValid = false;
            this.isBICCodeBlankError = true;
        } else if (!nameNumRegEx.test(bankIdentificationCode)) {
            isValid = false;
            this.IntBankIdentPatternError = true;
        } else if (bankIdentificationCode.length > 64) {
            isValid = false;
            this.IntBankIdentPatternlenError = true;
        }

        if (bankSwiftCode == null || bankSwiftCode == undefined || bankSwiftCode.trim() == "") {
            isValid = false;
            this.isSwiftCodeBlankError = true;
        } else if (!nameNumRegEx.test(bankSwiftCode)) {
            isValid = false;
            this.IntBankSwiftPatternError = true;
        } else if (bankSwiftCode.length > 64) {
            isValid = false;
            this.IntBankSwiftlenError = true;
        }

        if (IBAN == null || IBAN == undefined || IBAN.trim() == "") {
            isValid = false;
            this.isIBANblankError = true;
        } else if (!nameNumRegEx.test(IBAN)) {
            isValid = false;
            this.IntIbanSpecialError = true;
        } else if (IBAN.length < 15) {
            isValid = false;
            this.IbanlenError = true;
        }

        if (bankBenfiAdd == undefined || bankBenfiAdd == "" || bankBenfiAdd == null || bankBenfiAdd.trim() == "") {
            this.isBenificiaryBlankError = true;
            isValid = false;

        }

        if (!isValid) {
            this.template.querySelector(".bankErrors").scrollIntoView();
        }

        if (isValid) {
            //this.showSpinner = true;
            let bankInfoType = 'account';
            updateIntBankDetailsOfTenant({
                bankIntName: bankIntName, bankIntaddress: bankBenfiAdd,
                bankIntAccountName: bankIntAccountName, bankIdentificationCode: bankIdentificationCode,
                bankSwiftCode: bankSwiftCode, IBAN: IBAN, bankInfoType: bankInfoType, depositId: ''
            }).then(result => {
                console.log('UK Result>>>' + JSON.stringify(result));
                if (result == 'invalidIBAN') {
                    this.isInvalidIBANError = true;
                }
                if (result == 'successMessage') {
                    this.isIntBankSuccessMessage = true;
                    this.isInvalidIBANError = false;
                    this.isbankdetailsNotAvl = false;
                    this.isbankdetailsPresent = true;
                    this.isNoBankDetailsfound = false;
                    this.isBankDetails = true;
                    // eval("$A.get('e.force:refreshView').fire();");

                    // Firing event from Child component to Parent component START
                    const eventData = { isBankDetails: this.isBankDetails };
                    const event = new CustomEvent('getbankdetails', { detail: eventData });
                    this.dispatchEvent(event);
                    // Firing event from Child component to Parent component END
                }
                //this.showSpinner = false;
            }).catch(error => {
               // this.showSpinner = false;
                console.log('Error occured updating/inserting international bank details--->' + error);
            });
        }
    }

    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "bankSuccessMessage":
                this.isBankSuccessMessage = false;
                break;
            case "bankErrorMessage":
                this.isBankErrorMessage = false;
                break;
            case "bankNoChangeError":
                this.isBankNoChangeError = false;
                this.isBankNoChangeError1 = false;
                break;
            case "nameOnAccountBlankError":
                this.isNameOnAccountBlankError = false;
                break;
            case "nameOnAccountSizeError":
                this.isNameOnAccountSizeError = false;
                break;
            case "nameOnAccountSpecialCharError":
                this.isNameOnAccountSpecialCharError = false;
                break;
            case "accountNumberLengthError":
                this.isAccountNumberLengthError = false;
                break;
            case "accountNumberBlankError":
                this.isAccountNumberBlankError = false;
                break;
            case "invalidAccountNumberError":
                this.isInvalidAccountNumberError = false;
                break;
            case "sortCodeBlankError":
                this.isSortCodeBlankError = false;
                break;
            case "Sortcodelengtherror":
                this.isSortcodelengtherror = false;
                break;
            case "invalidSortCodeError":
                this.isInvalidSortCodeError = false;
                break;
            case "IntbankSuccessMessage":
                this.isIntBankSuccessMessage = false;
                break;
            case "IntnameOnAccountBlankError":
                this.isIntNameOnAccountBlankError = false;
                break;
            case "BankNameBlankError":
                this.isBankNameBlankError = false;
                break;
            case "IBANNumberBlankError":
                this.isIBANblankError = false;
                break;
            case "SwiftCodeBlankError":
                this.isSwiftCodeBlankError = false;
                break;
            case "BICCodeBlankError":
                this.isBICCodeBlankError = false;
                break;
            case "BenificiaryBlankError":
                this.isBenificiaryBlankError = false;
                break;
            case "invalidIBANError":
                this.isInvalidIBANError = false;
                break;
            case "IbanlenErrorMsg":
                this.IbanlenError = false;
                break;
            case "IntIbanSpecialErrorMsg":
                this.IntIbanSpecialError = false;
                break;
            case "IntBankSwiftErrorlenMsg":
                this.IntBankSwiftlenError = false;
                break;
            case "IntBankSwiftPatternErrorMsg":
                this.IntBankSwiftPatternError = false;
                break;
            case "IntBankIdentlenErrorMsg":
                this.IntBankIdentPatternlenError = false;
                break;
            case "IntBankIdentPatternErrorMsg":
                this.IntBankIdentPatternError = false;
                break;
            case "IntbankNamelenErrorMsg":
                this.IntbankNamelenError = false;
                break;
            case "IntBankNamePatternErrorMsg":
                this.IntBankNamePatternError = false;
                break;
            case "IntAccNamelenErrorMsg":
                this.IntAccNamelenError = false;
                break;
            case "IntBankAccNamePatternErrorMsg":
                this.IntBankAccNamePatternError = false;
                break;

        }
    }
}