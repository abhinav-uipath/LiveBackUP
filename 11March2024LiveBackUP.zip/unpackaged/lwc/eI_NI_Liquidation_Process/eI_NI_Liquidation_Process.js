import { LightningElement, track, wire, api } from 'lwc';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import jQuery from '@salesforce/resourceUrl/JQuery';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
import getAllDeposits from '@salesforce/apex/EI_NI_DepositManagement.getDepositDetails';
import updateMyTenancyHasntEnded from '@salesforce/apex/eI_NI_Liquidation_Process_Cls.updateMyTenancyHasntEnded';
import getEvidenceList from '@salesforce/apex/eI_NI_Liquidation_Process_Cls.getEvidenceList';

export default class EI_NI_Liquidation_Process extends NavigationMixin(LightningElement) {
   downloadBtnImg = NI_THEME + '/assets/img/ZD_download.png';
   editIcon = NI_THEME + '/assets/img/feather-edit_blue.png';
   back_icon = NI_THEME + '/assets/img/ew-arrow-dropleft.png';
   calendarwhite = NI_THEME + '/assets/img/calendar-white.svg';

   @track depositId;
   @track depositRec = {};
   @track usrData = {};
   @track tenantRecords;
   @track landlordRecords;
   @track caseRecord;
  
   @track fillRequiedFieldsError = false;
   @track isShowThankyouPage = false;
   @track isDisable = false;
   @track evidenceAttachments = [];

   @track startDay='';
   @track startMonth='';
   @track startYear='';
   @track startDateYMD='';
   @track startDateDMY='';
   @track TenancyStartDateVal = '';

   @track endDay='';
   @track endMonth='';
   @track endYear='';
   @track endDateYMD='';
   @track endDateDMY='';
   @track TenancyEndDateVal = '';
   
   @track tenancyStartDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
   { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
   { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
   { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
   { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
   { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
   { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
   { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];
   @track tenancyEndDateList = [{ name: '1', value: '01', isSelected: false }, { name: '2', value: '02', isSelected: false }, { name: '3', value: '03', isSelected: false }, { name: '4', value: '04', isSelected: false },
   { name: '5', value: '05', isSelected: false }, { name: '6', value: '06', isSelected: false }, { name: '7', value: '07', isSelected: false }, { name: '8', value: '08', isSelected: false }, { name: '9', value: '09', isSelected: false },
   { name: '10', value: '10', isSelected: false }, { name: '11', value: '11', isSelected: false }, { name: '12', value: '12', isSelected: false }, { name: '13', value: '13', isSelected: false },
   { name: '14', value: '14', isSelected: false }, { name: '15', value: '15', isSelected: false }, { name: '16', value: '16', isSelected: false }, { name: '17', value: '17', isSelected: false },
   { name: '18', value: '18', isSelected: false }, { name: '19', value: '19', isSelected: false }, { name: '20', value: '20', isSelected: false }, { name: '21', value: '21', isSelected: false },
   { name: '22', value: '22', isSelected: false }, { name: '23', value: '23', isSelected: false }, { name: '24', value: '24', isSelected: false }, { name: '25', value: '25', isSelected: false },
   { name: '26', value: '26', isSelected: false }, { name: '27', value: '27', isSelected: false }, { name: '28', value: '28', isSelected: false }, { name: '29', value: '29', isSelected: false },
   { name: '30', value: '30', isSelected: false }, { name: '31', value: '31', isSelected: false }];

   @track tenancyStartMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
   { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
   { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
   { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];
   @track tenancyEndMonthList = [{ name: 'January', value: '01', isSelected: false }, { name: 'February', value: '02', isSelected: false }, { name: 'March', value: '03', isSelected: false },
   { name: 'April', value: '04', isSelected: false }, { name: 'May', value: '05', isSelected: false }, { name: 'June', value: '06', isSelected: false }, { name: 'July', value: '07', isSelected: false },
   { name: 'August', value: '08', isSelected: false }, { name: 'September', value: '09', isSelected: false }, { name: 'October', value: '10', isSelected: false },
   { name: 'November', value: '11', isSelected: false }, { name: 'December', value: '12', isSelected: false }];

   @track tenancyStartYearList = [];
   @track tenancyEndYearList = [];
   @track TenancyStartDate ;
   @track TenancyEndDate ;

   @track todayDate = '';

   @wire(CurrentPageReference)
   currentPageReference;

   connectedCallback(){
      var depositRecId = `${this.currentPageReference.state.depositId}`;
      this.depositId = atob(depositRecId);

      loadScript(this, jQuery).then(() => {
         console.log('JQuery loaded.');
      }).catch(error => {
            console.log('Failed to load the JQuery : ' + error);
      });
      Promise.all([
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')
      ]).then(() => {
            console.log('Files loaded');

      }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
      });

      // set today date for max date as future dates should be grayed out
      var today = new Date();
      var todayDate = today.getDate();
      todayDate = todayDate > 9 ? todayDate : '0'+todayDate;
      var todayMonth = today.getMonth()+1;
      todayMonth = todayMonth > 9 ? todayMonth : '0'+todayMonth;
      var todayYear = today.getFullYear();
      this.todayDate = todayYear+'-'+todayMonth+'-'+todayDate;
      console.log(' MAx todayDate => ' + this.todayDate);

      //tenancyEndYear List//
      let tenancyStartYearList = [];
      let tenancyEndYearList = [];
      for (var i = 2012; i <= 2024; i++) {
         // console.log('Line 105 -> ',typeof i);
         // console.log('Line 105 -> ',typeof i.toString());
         tenancyStartYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
         tenancyEndYearList.push({ name: i.toString(), value: i.toString(), isSelected: false });
         //yearList.push({label:'selectYear'+i, key:i});
      }
      this.tenancyStartYearList = tenancyStartYearList;
      this.tenancyEndYearList = tenancyEndYearList;

      getAllDeposits({
         "recId": this.depositId
      }).then(result => {
         console.log('Deposits Data::', JSON.stringify(result));
         this.depositRec = result.depositData;
         // this.depositRecData['Landlord_name_Liquidation__c'] = result.depositData.Landlord_name_Liquidation__c!=undefined?result.depositData.Landlord_name_Liquidation__c : '';
         // this.depositRecData['Landlord_postal_address_Liquidation__c'] = result.depositData.Landlord_postal_address_Liquidation__c!=undefined?result.depositData.Landlord_postal_address_Liquidation__c : '';
         // this.depositRecData['Landlord_telephone_number_Liquidation__c'] = result.depositData.Landlord_telephone_number_Liquidation__c!=undefined?result.depositData.Landlord_telephone_number_Liquidation__c : '';
         // this.depositRecData['Landlord_email_Liquidation__c'] = result.depositData.Landlord_email_Liquidation__c!=undefined?result.depositData.Landlord_email_Liquidation__c : '';
         // this.depositRecData['Deposit_amount_Liquidation__c'] = result.depositData.Deposit_amount_Liquidation__c!=undefined?result.depositData.Deposit_amount_Liquidation__c : '';
         // this.depositRecData['Tenancy_start_date_Liquidation__c'] = result.depositData.Tenancy_start_date_Liquidation__c!=undefined?result.depositData.Tenancy_start_date_Liquidation__c : '';
         // this.depositRecData['Tenancy_expected_end_date_liquidation__c'] = result.depositData.Tenancy_expected_end_date_liquidation__c!=undefined?result.depositData.Tenancy_expected_end_date_liquidation__c : '';

         this.tenantRecords = result.tenantDeposits;
         this.landlordRecords = result.landlordDeposits;
         this.caseRecord = result.caseDetails;
         this.usrData = result.loggedInUserDetails;

         getEvidenceList({accountId : this.usrData.AccountId, depositId : this.depositRec.Id}).then(result =>{
            console.log('getEvidenceList => ' + result);
            this.evidenceAttachments = result;
         }).catch(error => {
         console.log('getEvidenceList Error 1 => ', JSON.stringify(error));
         console.log('getEvidenceList Error 2 => ', (error));
         });

      }).catch(error => {
         this.showSpinner = false;
         console.log('getAllDeposits Error 1 => ', JSON.stringify(error));
         console.log('getAllDeposits Error 2 => ', (error));
      });
   }

   renderedCallback(){
      // Start date set 
      console.log('this.tenancyStartDateList => ' + this.tenancyStartDateList);
      console.log('this.tenancyStartMonthList => ' + this.tenancyStartMonthList);
      console.log('this.tenancyStartYearList => ' + this.tenancyStartYearList);
      console.log('render callnack startdate => ' + this.depositRec.Tenancy_start_date_Liquidation__c);
      if(this.depositRec.Tenancy_start_date_Liquidation__c!=undefined
         && !this.depositRec.Tenancy_start_date_Liquidation__c.includes('Select day') 
         && !this.depositRec.Tenancy_start_date_Liquidation__c.includes('Select month') 
         && !this.depositRec.Tenancy_start_date_Liquidation__c.includes('Select year') ){    
         let dateVal = new Date(this.depositRec.Tenancy_start_date_Liquidation__c);
         var day = dateVal.getDate();
         var month = dateVal.getMonth() + 1;
         var year = dateVal.getFullYear();

            console.log('start day => ' + day);
            console.log('start month => ' + month);
            console.log('start year => ' + year);
   
         for(let i=0; i< this.tenancyStartDateList.length; i++){
            if(this.tenancyStartDateList[i].value == day){
               this.tenancyStartDateList[i].isSelected = true;
               console.log('debug 1');
               this.template.querySelector('[name="tenancyStartDate"]').value = this.tenancyStartDateList[i].value;
               console.log('debug 2');
            }else{
               this.tenancyStartDateList[i].isSelected = false;   
            }
         }

         for(let i=0; i< this.tenancyStartMonthList.length; i++){
            if(this.tenancyStartMonthList[i].value == month){
               this.tenancyStartMonthList[i].isSelected = true;
               console.log('debug 1');
               this.template.querySelector('[name="tenancyStartMonth"]').value = this.tenancyStartMonthList[i].value;
               console.log('debug 2');
            }else{
               this.tenancyStartMonthList[i].isSelected = false;   
            }
         }
         
         for(let i=0; i< this.tenancyStartYearList.length; i++){
            if(this.tenancyStartYearList[i].value == year){
               this.tenancyStartYearList[i].isSelected = true;
               console.log('debug 1');
               this.template.querySelector('[name="tenancyStartYear"]').value = this.tenancyStartYearList[i].value;
               console.log('debug 2');
            }else{
               this.tenancyStartYearList[i].isSelected = false;   
            }
         }
      }
      
      // End Date set
      console.log('this.tenancyEndDateList => ' + this.tenancyEndDateList);
      console.log('this.tenancyEndMonthList => ' + this.tenancyEndMonthList);
      console.log('this.tenancyEndYearList => ' + this.tenancyEndYearList);
      if(this.depositRec.Tenancy_expected_end_date_liquidation__c!=undefined
         && !this.depositRec.Tenancy_expected_end_date_liquidation__c.includes('Select day') 
         && !this.depositRec.Tenancy_expected_end_date_liquidation__c.includes('Select month') 
         && !this.depositRec.Tenancy_expected_end_date_liquidation__c.includes('Select year') ){
         let dateVal = new Date(this.depositRec.Tenancy_expected_end_date_liquidation__c);
         let day = dateVal.getDate();
         let month = dateVal.getMonth() + 1;
         let year = dateVal.getFullYear();
            console.log('day => ' + day);
            console.log('month => ' + month);
            console.log('year => ' + year);
   
         for(let i=0; i< this.tenancyEndDateList.length; i++){
            if(this.tenancyEndDateList[i].value == day){
               this.tenancyEndDateList[i].isSelected = true;
               this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyEndDateList[i].value;
            }else{
               this.tenancyEndDateList[i].isSelected = false;   
            }
         }
   
         for(let i=0; i< this.tenancyEndMonthList.length; i++){
            if(this.tenancyEndMonthList[i].value == month){
               this.tenancyEndMonthList[i].isSelected = true;
               this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyEndMonthList[i].value;
            }else{
               this.tenancyEndMonthList[i].isSelected = false;   
            }
         }
         
         for(let i=0; i< this.tenancyEndYearList.length; i++){
            if(this.tenancyEndYearList[i].value == year){
               this.tenancyEndYearList[i].isSelected = true;
               this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyEndYearList[i].value;
            }else{
               this.tenancyEndYearList[i].isSelected = false;   
            }
         }
      }
   }

   // Handle go back to the Deposit summary page
   goBackToDepositSummary() {
      var encodedDepositId = btoa(this.depositId);

      this[NavigationMixin.Navigate]({
          type: 'standard__namedPage',
          attributes: {
              pageName: 'deposit-summary',
          },
          state: {
            c__depositRecId: encodedDepositId
          },
      })
   }

   removeZero(event) {
      var edValue = event.target.value;
      function trimNumber(s) {
          while (s.substring(0,1) == '0' && s.length>=1 && !s.includes(".")) { 
              s = s.substring(1,9999); 
          }
          return s;
      }
      var trimeVal = trimNumber(edValue);
      event.target.value = trimeVal;
      
      if(trimeVal.includes('.')){
          var number = trimeVal.split('.');
          console.log('numbs '+number[1]);
          if(number[1].length>2)
          event.target.value = parseFloat(trimeVal).toFixed(2);
      }else{
          event.target.value = trimeVal;
      }
  }

   handleInputValuesChange(event){
      console.log(event.target.value);
      //this.ClaimsDetails[event.target.name] = event.target.value;
      var descText = event.target.value;
      this.depositRec[event.target.name] = descText;
   }

   handleDeleteEviAttachmentList(event){
      console.log( 'Value from Child LWC is ' + JSON.stringify(event.detail) );
      var attachmensts = [];
      console.log('event.detail => ' + event.detail);
      for(let index in this.evidenceAttachments){
         console.log('this.evidenceAttachments[index].Id => ' + this.evidenceAttachments[index].Id);
         
         if(this.evidenceAttachments[index].Id != event.detail){
            attachmensts.push(this.evidenceAttachments[index]);
         }
      }
      this.evidenceAttachments = attachmensts;
     
      console.log('this.evidenceAttachments after => '+ JSON.stringify(this.evidenceAttachments));
   }

   handleAddEviAttachmentList(event){
      console.log( 'Value from Child LWC is ' + JSON.stringify(event.detail) );
      var attachmensts = [];
      let aviAttachment = event.detail;
      attachmensts = [...this.evidenceAttachments, aviAttachment];
      this.evidenceAttachments = attachmensts;
      console.log('this.evidenceAttachments after => '+ JSON.stringify(this.evidenceAttachments));
   }

   checkStartDateChange(){
      // tenancy start date
      let tenancyStartDate = this.template.querySelector('[name="tenancyStartDate"]').value;
      if (tenancyStartDate != 'Select day') {
          this.startDay = tenancyStartDate;
      }
      let tenancyStartMonth = this.template.querySelector('[name="tenancyStartMonth"]').value;
      if (tenancyStartMonth != 'Select month') {
          this.startMonth = tenancyStartMonth;
      }
      let tenancyStartYear = this.template.querySelector('[name="tenancyStartYear"]').value;
      if (tenancyStartYear != 'Select year') {
          this.startYear = tenancyStartYear;
      }
      let tenancyDateYMD = tenancyStartYear + '-' + tenancyStartMonth + '-' + tenancyStartDate;
      let tenancyDateDMY = tenancyStartDate + '/' + tenancyStartMonth + '/' + tenancyStartYear;
      
      this.TenancyStartDateVal = tenancyDateYMD;
      this.depositRec['Tenancy_start_date_Liquidation__c'] = tenancyDateYMD;
      console.log('Line 518 Tenancy Start Date-->' + tenancyDateYMD);
   }

   checkEndDateChange(){
      // deposit End date
      let tenancyEndDate = this.template.querySelector('[name="tenancyEndDate"]').value;
      // console.log('line 601'+tenancyEndDate);
      if (tenancyEndDate != 'Select day') {
          this.tenancyDay = tenancyEndDate;
      }
      //  console.log('line 605'+this.tenancyDay);
      let tenancyEndMonth = this.template.querySelector('[name="tenancyEndMonth"]').value;
      if (tenancyEndMonth != 'Select month') {
          this.tenancyMonth = tenancyEndMonth;
      }
      let tenancyEndYear = this.template.querySelector('[name="tenancyEndYear"]').value;
      if (tenancyEndYear != 'Select year') {
          this.tenancyYear = tenancyEndYear;
      }
      let tenancyDateYMD = tenancyEndYear + '-' + tenancyEndMonth + '-' + tenancyEndDate;
      let tenancyDateDMY = tenancyEndDate + '/' + tenancyEndMonth + '/' + tenancyEndYear;
      
      this.TenancyEndDateVal = tenancyDateYMD;
      this.depositRec['Tenancy_expected_end_date_liquidation__c'] = tenancyDateYMD
      console.log('Line 511 Deposit Receive Date-->' + tenancyDateYMD);
   }

   onStartDatePickerChangeHandler(event){
      this.TenancyStartDateVal = event.target.value;
      console.log('onDatePickerChangeHandler date picker => '+ event.target.value);
      let dateVal = new Date(event.target.value);
      var day = dateVal.getUTCDate();
      var month = dateVal.getUTCMonth() + 1;
      var year = dateVal.getUTCFullYear();

      for(let i=0; i< this.tenancyStartDateList.length; i++){
          if(this.tenancyStartDateList[i].value == day){
              this.tenancyStartDateList[i].isSelected = true;
              this.template.querySelector('[name="tenancyStartDate"]').value = this.tenancyStartDateList[i].value;
          }else{
              this.tenancyStartDateList[i].isSelected = false;   
          }
      }

      for(let i=0; i< this.tenancyStartMonthList.length; i++){
          if(this.tenancyStartMonthList[i].value == month){
              this.tenancyStartMonthList[i].isSelected = true;
              this.template.querySelector('[name="tenancyStartMonth"]').value = this.tenancyStartMonthList[i].value;
          }else{
              this.tenancyStartMonthList[i].isSelected = false;   
          }
      }
        
      for(let i=0; i< this.tenancyStartYearList.length; i++){
          if(this.tenancyStartYearList[i].value == year){
              this.tenancyStartYearList[i].isSelected = true;
              this.template.querySelector('[name="tenancyStartYear"]').value = this.tenancyStartYearList[i].value;
          }else{
              this.tenancyStartYearList[i].isSelected = false;   
          }
      }

      this.checkStartDateChange(event);
   }

   onEndDatePickerChangeHandler(event){
      this.TenancyEndDateVal = event.target.value;
      console.log('onEndDatePickerChangeHandler date picker => '+ event.target.value);
      let dateVal = new Date(event.target.value);
      var day = dateVal.getUTCDate();
      var month = dateVal.getUTCMonth() + 1;
      var year = dateVal.getUTCFullYear();
         console.log('day => ' + day);
         console.log('month => ' + month);
         console.log('year => ' + year);

      for(let i=0; i< this.tenancyEndDateList.length; i++){
         if(this.tenancyEndDateList[i].value == day){
            this.tenancyEndDateList[i].isSelected = true;
            this.template.querySelector('[name="tenancyEndDate"]').value = this.tenancyEndDateList[i].value;
         }else{
            this.tenancyEndDateList[i].isSelected = false;   
         }
      }

      for(let i=0; i< this.tenancyEndMonthList.length; i++){
         if(this.tenancyEndMonthList[i].value == month){
            this.tenancyEndMonthList[i].isSelected = true;
            this.template.querySelector('[name="tenancyEndMonth"]').value = this.tenancyEndMonthList[i].value;
         }else{
            this.tenancyEndMonthList[i].isSelected = false;   
         }
      }
      
      for(let i=0; i< this.tenancyEndYearList.length; i++){
         if(this.tenancyEndYearList[i].value == year){
            this.tenancyEndYearList[i].isSelected = true;
            this.template.querySelector('[name="tenancyEndYear"]').value = this.tenancyEndYearList[i].value;
         }else{
            this.tenancyEndYearList[i].isSelected = false;   
         }
      }

      this.checkEndDateChange(event);
   }

   handleSubmitButton(){
      if(this.depositRec['Landlord_name_Liquidation__c'] == null || this.depositRec['Landlord_name_Liquidation__c'] == '' || this.depositRec['Landlord_name_Liquidation__c'] == undefined || 
      this.depositRec['Landlord_postal_address_Liquidation__c'] == null || this.depositRec['Landlord_postal_address_Liquidation__c'] == '' || this.depositRec['Landlord_postal_address_Liquidation__c'] == undefined || 
      this.depositRec['Landlord_telephone_number_Liquidation__c'] == null || this.depositRec['Landlord_telephone_number_Liquidation__c'] == '' || this.depositRec['Landlord_telephone_number_Liquidation__c'] == undefined || 
      this.depositRec['Landlord_email_Liquidation__c'] == null || this.depositRec['Landlord_email_Liquidation__c'] == '' || this.depositRec['Landlord_email_Liquidation__c'] == undefined || 
      this.depositRec['Deposit_amount_Liquidation__c'] == null || this.depositRec['Deposit_amount_Liquidation__c'] == '' || this.depositRec['Deposit_amount_Liquidation__c'] == undefined || 
      this.depositRec['Tenancy_start_date_Liquidation__c'] == null || this.depositRec['Tenancy_start_date_Liquidation__c'] == '' || this.depositRec['Tenancy_start_date_Liquidation__c'] == undefined) 
    //  || this.depositRec['Tenancy_expected_end_date_liquidation__c'] == null || this.depositRec['Tenancy_expected_end_date_liquidation__c'] == '' || this.depositRec['Tenancy_expected_end_date_liquidation__c'] == undefined)
      {
         this.fillRequiedFieldsError= true;
      }else{
         console.log("this.depositRec => " +this.depositRec);
         let depoStr = JSON.stringify(this.depositRec);
         console.log("this.depositRec => " + depoStr);
         let depoAllocListStr = JSON.stringify(this.tenantRecords);
         console.log("this.depositRec => " + depoAllocListStr);

         updateMyTenancyHasntEnded({caseId: this.caseRecord.Id, 
            depositStr: depoStr, 
            depositAllocListStr: depoAllocListStr,
            logginUserContactId: this.usrData.ContactId
         }).then(result => {
            this.isShowThankyouPage = true;
            console.log('updated => ' + result);
         }).catch(error => {
            this.showSpinner = false;
            console.log('handleSubmitButton Error', JSON.stringify(error));
         })
      }
   }

}