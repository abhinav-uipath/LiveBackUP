import { LightningElement, track, wire, api } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import NI_Theme from '@salesforce/resourceUrl/NI_Theme';
import getLandlordWrapper from '@salesforce/apex/EI_NI_createLandlord.createLandlordWrapper';
import checkEmailDuplicate from '@salesforce/apex/EI_NI_createLandlord.checkDuplicateEmail';
import saveLandlordData from '@salesforce/apex/EI_NI_createLandlord.savelandlord';
import savelandlordDepositSummaryData from '@salesforce/apex/EI_NI_createLandlord.savelandlordDepositSummary';


export default class EI_NI_addLandlord extends LightningElement {
    backBtnImg = NI_Theme + '/assets/img/ew-arrow-dropleft.png';
    backArrowImg = NI_Theme + '/assets/img/nhos-arrow-dropleft.svg`';
    warningImg = NI_Theme + '/assets/img/warning-icon.png';
    cancel_icon = NI_Theme + '/assets/img/Cancel-icon.png';
    property_blue_icon = NI_Theme + '/assets/img/add-new-property_blue.png';
    quesCircleImg = NI_Theme + '/assets/img/question-circle.png';
    featherImg = NI_Theme + '/assets/img/feather-edit.svg';
    viewIconImg = NI_Theme + '/assets/img/View_icon.svg';

    @api depositid;
    @api callingFromDepositSummary;
    @api fromProperty;
    @api middleText = 'a';
    removeRecId = '';
    // loaded data
    @track errorMetaDataRecords = [];
    @track niPostcodeMetaDataRecords = [];
    @track phoneCodeList = [];
    @track defaultPhoneCode = '+44';
    @track isLandlineNumOfUk = true;
    @track isMobileNumOfUk = true;
    @track salutation = [];

    // attributes to show error message
    isLandlordYesNo = false;
    isSucceessmessage = false;
    isErrorMsg = false;
    isCompanyNameError = false;
    isCompanyPhoneError = false;
    isCompanyPhonelengthError = false;
    isTitleError = false;
    isFirstNameError = false;
    isSurNameError = false;
    isEmailError = false;
    isEmailFormatError = false;
    isTelephoneNumError = false;
    isPhonelengthError = false;
    isMobileEmailError = false;
    // isAddressNotOfNiError = false;
    isAddressValidError = false;
    isDuplicateEmailError = false;
    isDuplicateNameError = false;

    // Landlord data
    isAddLandlordSection = false;
    @track isCompanySelect = false;
    @track isUserSelect = false;
    @track branchId = null;
    @track companyName = '';
    @track companyPhoneCode = '';
    @track companyPhone = '';
    @track title = '';
    @track firstName = '';
    @track lastName = '';
    @track email = '';
    @track phoneCode = '';
    @track phone = '';
    @track landlordAddress = '';
    @track landlordCorrosAddress = '';
    @track landlordRef = '';
    @track isLoading = false;

    // address 
    @track primaryAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
    @track corresAddress = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '', houseNo: '' };
    @track isPrimaryAddressOfNI = false;
    @track isCorresAddressOfNI = false;
    @track showCorresAddress = false;
    isAddressNotOfNiError = false;

    @api
    showModal(removePrimaryRecIdFromParent) {
        console.log('removePrimaryRecIdFromParent*********', removePrimaryRecIdFromParent);
        this.removeRecId = removePrimaryRecIdFromParent;
        this.isAddLandlordSection = true;
    }
    constructor() {
        super();
    }

    renderedCallback() {
    }

    connectedCallback() {
        Promise.all([
            loadStyle(this, NI_Theme + '/assets/css/custom-ni.css'),
            loadScript(this, NI_Theme + '/assets/js/plugin.min.js'),
            loadScript(this, NI_Theme + '/assets/js/custom.js'),
            loadScript(this, NI_Theme + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_Theme + '/assets/js/datepicker.js')

        ]).then(() => {
            console.log('Files loaded');
        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        });

        var urlString = window.location.search;
        var urlParams = new URLSearchParams(urlString);

        if (urlParams != undefined) {
            var branchRecId = urlParams.get('branchRecId');
            if (branchRecId != null && branchRecId != '' && branchRecId != undefined) {
                this.branchId = window.atob(branchRecId);
            }
        }

        getLandlordWrapper()
            .then(data => {
                if (data.length > 0) {
                    this.errorMetaDataRecords = data[0].errorMessageList;
                    this.niPostcodeMetaDataRecords = data[0].niPostcodeList;

                    // Salutation load
                    var conts = data[0].salutationMap;
                    for (var key in conts) {
                        this.salutation.push({ value: conts[key], key: key }); //Here we are creating the array to show on UI.
                    }

                    // Phonecode
                    for (var key in data[0].countryPhoneCodeList) {
                        if (data[0].countryPhoneCodeList[key] == '+44') {
                            this.phoneCodeList.push({ key: data[0].countryPhoneCodeList[key], value: true });
                        }
                        else {
                            this.phoneCodeList.push({ key: data[0].countryPhoneCodeList[key], value: false });
                        }
                    }
                }
            })
            .catch(error => {
                console.error('Error calling sign up wrapper ==> ' + JSON.stringify(error));
            })
    }


    @api resetstate(event) {
        event.preventDefault();
        this.isAddLandlordSection = true;
        this.isCompanySelect = false;
        this.isLandlordYesNo = false;
        this.isSucceessmessage = false;
        this.isErrorMsg = false;
        this.isCompanyNameError = false;
        this.isCompanyPhoneError = false;
        this.isCompanyPhonelengthError = false;
        this.isTitleError = false;
        this.isFirstNameError = false;
        this.isSurNameError = false;
        this.isMobileEmailError = false;
        this.isEmailError = false;
        this.isEmailFormatError = false;
        this.isTelephoneNumError = false;
        this.isPhonelengthError = false;
        this.isAddressNotOfNiError = false;
        this.isAddressValidError = false;
        this.isDuplicateEmailError = false;
        this.isDuplicateNameError = false;

        this.companyName = '';
        this.companyPhoneCode = '';
        this.companyPhone = '';
        this.title = '';
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.phoneCode = '';
        this.phone = '';
        this.primaryAddress = {};
        this.corresAddress = {};
        this.landlordAddress = '';
        this.landlordCorrosAddress = '';
        this.landlordRef = '';
        this.showCorresAddress = false;
    }

    popupCancelHandle() {
        this.isAddLandlordSection = false;
    }

    landlordYesSelect(event) {
        event.preventDefault();
        this.isLandlordYesNo = false;
        this.isSucceessmessage = false;
        this.isErrorMsg = false;
        this.isCompanyNameError = false;
        this.isCompanyPhoneError = false;
        this.isCompanyPhonelengthError = false;
        this.isTitleError = false;
        this.isFirstNameError = false;
        this.isSurNameError = false;
        this.isMobileEmailError = false;
        this.isEmailError = false;
        this.isEmailFormatError = false;
        this.isTelephoneNumError = false;
        this.isPhonelengthError = false;
        this.isAddressNotOfNiError = false;
        this.isAddressValidError = false;
        this.isDuplicateEmailError = false;
        this.isDuplicateNameError = false;


        this.isCompanySelect = true;
        this.isUserSelect = false;

        let selectBtn = this.template.querySelector('[name="landlordCompYes"]');
        selectBtn.style.backgroundColor = '#1DAE83';
        selectBtn.style.color = '#fff';

        this.template.querySelector('[name="landlordCompNo"]').style.color = '';
        this.template.querySelector('[name="landlordCompNo"]').style.backgroundColor = '';
    }

    landlordNoSelect(event) {
        event.preventDefault();
        this.isLandlordYesNo = false;
        this.isSucceessmessage = false;
        this.isErrorMsg = false;
        this.isCompanyNameError = false;
        this.isCompanyPhoneError = false;
        this.isCompanyPhonelengthError = false;
        this.isTitleError = false;
        this.isFirstNameError = false;
        this.isSurNameError = false;
        this.isMobileEmailError = false;
        this.isEmailError = false;
        this.isEmailFormatError = false;
        this.isTelephoneNumError = false;
        this.isPhonelengthError = false;
        this.isAddressNotOfNiError = false;
        this.isAddressValidError = false;
        this.isDuplicateEmailError = false;
        this.isDuplicateNameError = false;

        this.isCompanySelect = false;
        this.isUserSelect = true;

        let selectBtn = this.template.querySelector('[name="landlordCompNo"]');
        selectBtn.style.backgroundColor = '#1DAE83';
        selectBtn.style.color = '#fff';

        this.template.querySelector('[name="landlordCompYes"]').style.color = '';
        this.template.querySelector('[name="landlordCompYes"]').style.backgroundColor = '';

    }

    // For handling event from child component(address finder) for 'onfieldchange' event i.e. entering manually
    addressFieldChangeHandler(event) {
        let returnedData = event.detail;

        if (returnedData.addressType == 'Address') {
            if (returnedData.fieldName.includes("TownCity")) {
                this.primaryAddress = { ...this.primaryAddress, "Town": returnedData.value }

            } else if (returnedData.fieldName.includes("County")) {
                this.primaryAddress = { ...this.primaryAddress, "County": returnedData.value }

            } else if (returnedData.fieldName.includes("Postcode")) {
                this.primaryAddress = { ...this.primaryAddress, "Postcode": returnedData.value }
                var isPrimaryAddressOfNiPostcode = false;
                this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                    if (returnedData.value.includes(postCodeRecord.Label)) {
                        isPrimaryAddressOfNiPostcode = true;
                    }
                });
                this.showCorresAddress = !isPrimaryAddressOfNiPostcode;

                this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;
                if (this.isPrimaryAddressOfNI) {
                    this.isAddressNotOfNiError = false;
                }

            } else if (returnedData.fieldName.includes("Country")) {
                this.primaryAddress = { ...this.primaryAddress, "Country": returnedData.value }
            } else if (returnedData.fieldName.includes("Street")) {
                this.primaryAddress = { ...this.primaryAddress, "Street": returnedData.value }
            } else if (returnedData.fieldName.includes("House")) {
                console.log('In House--->' + returnedData.value);
                this.primaryAddress = { ...this.primaryAddress, "houseNo": returnedData.value }

            }
            this.landlordAddress = this.primaryAddress.houseNo + ' ' + this.primaryAddress.Street + ' ' + this.primaryAddress.Town + ' ' + this.primaryAddress.County + ' ' + this.primaryAddress.Postcode + ' ' + this.primaryAddress.Country;
        } else if (returnedData.addressType == 'Correspondence address') {
            if (returnedData.fieldName.includes("TownCity")) {
                this.corresAddress = { ...this.corresAddress, "Town": returnedData.value }
            } else if (returnedData.fieldName.includes("County")) {
                this.corresAddress = { ...this.corresAddress, "County": returnedData.value }
            } else if (returnedData.fieldName.includes("Postcode")) {
                this.corresAddress = { ...this.corresAddress, "Postcode": returnedData.value }
                var isCorresAddressOfNiPostcode = false;
                this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                    if (returnedData.value.includes(postCodeRecord.Label)) {
                        isCorresAddressOfNiPostcode = true;
                    }
                });
                this.isCorresAddressOfNI = isCorresAddressOfNiPostcode;
            } else if (returnedData.fieldName.includes("Country")) {
                this.corresAddress = { ...this.corresAddress, "Country": returnedData.value }
            } else if (returnedData.fieldName.includes("Street")) {
                this.corresAddress = { ...this.corresAddress, "Street": returnedData.value }
            } else if (returnedData.fieldName.includes("House")) {
                this.corresAddress = { ...this.primaryAddress, "houseNo": returnedData.value }
                
            }
            this.landlordCorrosAddress = this.corresAddress.houseNo + ' ' + this.corresAddress.Street + ' ' + this.corresAddress.Town + ' ' + this.corresAddress.County + ' ' + this.corresAddress.Postcode + ' ' + this.corresAddress.Country;
        }
    }

    // For handling event from child component(address finder) for 'onselectingaddress' event i.e. selecting automatically
    selectingAddressHandler(event) {
        let returnedData = event.detail;

        if (returnedData.addressType == 'Address') {
            this.primaryAddress = returnedData.addressObj;

            var isPrimaryAddressOfNiPostcode = false;
            this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                if (this.primaryAddress.Postcode.includes(postCodeRecord.Label)) {
                    isPrimaryAddressOfNiPostcode = true;
                }
            });
            this.showCorresAddress = !isPrimaryAddressOfNiPostcode;
            this.isPrimaryAddressOfNI = isPrimaryAddressOfNiPostcode;
            if (this.isPrimaryAddressOfNI) {
                this.isAddressNotOfNiError = false;
            }
            this.landlordAddress = this.landlordAddress.houseNo + ' ' + this.primaryAddress.Street + ' ' + this.primaryAddress.Town + ' ' + this.primaryAddress.County + ' ' + this.primaryAddress.Postcode + ' ' + this.primaryAddress.Country;
        } else if (returnedData.addressType == 'Correspondence address') {
            this.corresAddress = returnedData.addressObj;
            var isCorresAddressOfNiPostcode = false;
            this.niPostcodeMetaDataRecords.forEach(postCodeRecord => {
                if (this.corresAddress.Postcode.includes(postCodeRecord.Label)) {
                    isCorresAddressOfNiPostcode = true;
                }
            });
            this.isCorresAddressOfNI = isCorresAddressOfNiPostcode;
            this.landlordCorrosAddress = this.corresAddress.houseNo + ' ' + this.corresAddress.Street + ' ' + this.corresAddress.Town + ' ' + this.corresAddress.County + ' ' + this.corresAddress.Postcode + ' ' + this.corresAddress.Country;
        }
    }

    // Allow only numeric keys and certain control keys
    allowNumberKeyHandle(event) {
        if (!/^\d$/.test(event.key) && !['Backspace', 'ArrowLeft', 'ArrowRight', 'Delete','Tab'].includes(event.key)) {
            event.preventDefault();
        }
    }

    capitalize(s){
        return s.toLowerCase().replace( /\b./g, function(a){ return a.toUpperCase(); } );
    };

    // Handle landlord input
    addLandlordDataHandle() {
        if (this.isCompanySelect) {
            this.companyName = this.template.querySelector('[data-id="companyNameLL"]').value;
            this.companyPhoneCode = this.template.querySelector('[data-id="selectCompanyCodeLL"]').value;
            this.companyPhone= this.template.querySelector('[data-id="companyPhoneLL"]').value;
        }
        this.title = this.template.querySelector('[data-id="selectLandlordTitle"]').value;
        this.title=this.capitalize(this.title);
        this.firstName = this.template.querySelector('[data-id="firstNameLL"]').value;
        this.firstName=this.capitalize(this.firstName);
        this.lastName = this.template.querySelector('[data-id="surNameLL"]').value;
        this.lastName=this.capitalize(this.lastName);
        this.email = this.template.querySelector('[data-id="emailLL"]').value;
        this.phoneCode = this.template.querySelector("[name='selectPhoneCodeAddLL']").value;
        this.phone = this.template.querySelector('[data-id="telephoneNumberLL"]').value;
        this.landlordRef = this.template.querySelector("[name='Landlord_reference']").value;
    }

    /*  emailBlurHandle() {
          const topDiv = this.template.querySelector('[data-id="landlord_modal_view"]');
         
          this.isDuplicateEmailError = false;
          this.isEmailFormatError = false;
          var landlordEmail= this.template.querySelector('[data-id="emailLL"]').value;
          this.email = landlordEmail;
          console.log('line 202 Email: '+this.email);
          var isValid=true;
          const EMAIL_REGEX=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          console.log("line 204-->",+landlordEmail.length);
          if(landlordEmail.length>0) { 
            if(!landlordEmail.match(EMAIL_REGEX)) {
                this.isEmailFormatError = true;
                isValid = false; 
                topDiv.scrollIntoView();
              }           
          }
  
          if(isValid && landlordEmail.length>0) {
              checkEmailDuplicate({email: landlordEmail})
              .then(result => {
                  console.log('result-->'+result);
                  if(result=='Duplicate Email'){
                      console.log('Line 338 Duplicate Email');
                      this.isDuplicateEmailError = true;
                      topDiv.scrollIntoView();
                  }else{
                     // this.emailTnt = tenantEmail;
                      console.log('Success Email-->'+this.email);
                  }
  
              })
              .catch(error => {
                  console.log('Line 210 Error -> ',error);
              })
          } 
              
      }*/

    handleCancel() {
        this.isAddLandlordSection = false;
    }

    clickSaveHandle(event) {
        event.preventDefault();
        const topDiv = this.template.querySelector('[data-id="landlord_modal_view"]');
        // topDiv.scrollIntoView({block: "end", inline: "start"});
        topDiv.scrollIntoView();
        this.isLandlordYesNo = false;
        this.isSucceessmessage = false;
        this.isErrorMsg = false;
        this.isCompanyNameError = false;
        this.isCompanyPhoneError = false;
        this.isCompanyPhonelengthError = false;
        this.isTitleError = false;
        this.isFirstNameError = false;
        this.isSurNameError = false;
        this.isMobileEmailError = false;
        this.isEmailError = false;
        this.isEmailFormatError = false;
        this.isTelephoneNumError = false;
        this.isPhonelengthError = false;
        this.isAddressNotOfNiError = false;
        this.isAddressValidError = false;
        this.isDuplicateEmailError = false;
        this.isDuplicateNameError = false;

        var companyNamecheck = this.companyName;
        var companyPhoneCode = this.companyPhoneCode;
        var companyPhonecheck = this.companyPhone;
        var titleCheck = this.title;
        var firstNameCheck = this.firstName;
        var surnameCheck = this.lastName;
        var emailCheck = this.email;
        var phoneCodeCheck = this.phoneCode;
        var telephoneCheck = this.phone;
        var landlordRefCheck = this.landlordRef;
        var isValid = true;
        const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        // var isYesNoSelect = true;

        if (this.isCompanySelect === false && this.isUserSelect === false) {
            this.isLandlordYesNo = true;
            isValid = false;
        }
        if (isValid) {
            if (this.isCompanySelect) {
                if (companyNamecheck == undefined || companyNamecheck == "" || companyNamecheck == null) {
                    this.isCompanyNameError = true;
                    isValid = false;
                }
                if (companyPhonecheck == undefined || companyPhonecheck == "" || companyPhonecheck == null) {
                    this.isCompanyPhoneError = true;
                    isValid = false;
                }
                
                 if (!this.isCompanyPhoneError) {
                    if (companyPhoneCode == '+44' && companyPhonecheck.length > 0 && companyPhonecheck.length != 11) {
                        this.isCompanyPhonelengthError = true;
                        isValid = false;
                    }
                 }
            }

            if (this.isUserSelect /* || this.isCompanySelect */) {
                if (titleCheck == undefined || titleCheck == "" || titleCheck == null || titleCheck == "-- Select Title --") {
                    this.isTitleError = true;
                    isValid = false;
                }
                if (firstNameCheck == undefined || firstNameCheck == "" || firstNameCheck == null) {
                    this.isFirstNameError = true;
                    isValid = false;
                }
                if (surnameCheck == undefined || surnameCheck == "" || surnameCheck == null) {
                    this.isSurNameError = true;
                    isValid = false;
                }
            }
            if (this.isUserSelect || this.isCompanySelect) {
                if (emailCheck == undefined || emailCheck == "" || emailCheck == null) {
                    this.isEmailError = true;
                    isValid = false;
                } else if (!emailCheck.match(EMAIL_REGEX)) {
                    this.isEmailFormatError = true;
                    isValid = false;
                }
            }

            if (telephoneCheck == undefined || telephoneCheck == "" || telephoneCheck == null) {
                this.isTelephoneNumError = true;
                isValid = false;
            }

            if (!this.isTelephoneNumError) {
                if (phoneCodeCheck == '+44' && telephoneCheck.length > 0 && telephoneCheck.length != 11) {
                    this.isPhonelengthError = true;
                    isValid = false;
                }
            }

            if (this.landlordAddress == undefined || this.landlordAddress == "" || this.landlordAddress == null) {
                this.isAddressValidError = true;
                isValid = false;
            }
            if ((this.landlordCorrosAddress == undefined || this.landlordCorrosAddress == "" || this.landlordCorrosAddress == null) && !this.isPrimaryAddressOfNI) {
                this.isAddressValidError = true;
                isValid = false;
            }

            if (!this.isAddressValidError) {
                if (!this.isPrimaryAddressOfNI) {
                    if (!this.isCorresAddressOfNI) {
                        this.isAddressNotOfNiError = true;
                        isValid = false;
                    }
                }
            }
        }

        if (!isValid) {
            this.template.querySelector(".slds-p-top_none").scrollIntoView();
        }

        if (isValid) {
            this.isLoading = true;
            var returnLandlord = {};

            returnLandlord.branchId = this.branchId;
            returnLandlord.isCompanySelect = this.isCompanySelect;
            returnLandlord.companyName = this.companyName;
            returnLandlord.companyPhoneCode = this.companyPhoneCode;
            returnLandlord.companyPhone = this.companyPhone;
            if (this.title == '-- Select Title --' || this.title == null || this.title == '') {
                returnLandlord.title = '';
            } else {
                returnLandlord.title = this.title;
            }

            returnLandlord.firstName = this.firstName;
            returnLandlord.lastName = this.lastName;
            returnLandlord.email = this.email;
            returnLandlord.phoneCode = this.phoneCode;
            returnLandlord.phone = this.phone;
            returnLandlord.landlordAddressStreet = this.primaryAddress.Street;
            returnLandlord.landlordAddressCity = this.primaryAddress.Town;
            returnLandlord.landlordAddressCounty = this.primaryAddress.County;
            returnLandlord.landlordAddressPostcode = this.primaryAddress.Postcode;
            returnLandlord.landlordAddressCountry = this.primaryAddress.Country;
            returnLandlord.landlordAddressHouseNo = this.primaryAddress.houseNo;
            //console.log('line 555'+this.primaryAddress.Street);
            //console.log('line 556'+this.primaryAddress.houseNo);
            // returnLandlord.primaryAddressObj = this.primaryAddress;
            if(!this.isPrimaryAddressOfNI){
            console.log('corespodent Str'+this.corresAddress.Street);
            returnLandlord.landlordCorrStreet = this.corresAddress.Street != undefined ? this.corresAddress.Street : '';
            console.log('corespodent Str==>'+returnLandlord.landlordCorrStreet);
            returnLandlord.landlordCorrCity = this.corresAddress.Town;
            returnLandlord.landlordCorrCounty = this.corresAddress.County;
            returnLandlord.landlordCorrPostcode = this.corresAddress.Postcode;
            returnLandlord.landlordCorrCountry = this.corresAddress.Country;
            returnLandlord.landlordCorrHouseNo = this.corresAddress.houseNo != undefined ? this.corresAddress.houseNo : '';
        }else{
            returnLandlord.landlordCorrStreet='';
            returnLandlord.landlordCorrCity='';
            returnLandlord.landlordCorrCounty='';
            returnLandlord.landlordCorrPostcode='';
            returnLandlord.landlordCorrCountry='';
            returnLandlord.landlordCorrHouseNo='';
            }
            //  returnLandlord.corresAddressObj = this.corresAddress;
            returnLandlord.landlordRef = this.landlordRef;


            let paramStr = JSON.stringify(returnLandlord);
            console.log('ParamStr==>'+JSON.stringify(returnLandlord));
            /*   checkEmailDuplicate({email: emailCheck,firstname:firstNameCheck,surname: surnameCheck})
               .then(result => {
                   console.log('result-->'+result);
                   if(result=='Duplicate Email'){
                       console.log('Line 338 Duplicate Email-->'+emailCheck);
                       this.isDuplicateEmailError = true;
                       topDiv.scrollIntoView();
                       isValid=false;
                       
                   }else{
                      // this.emailTnt = tenantEmail;
                       console.log('Success Email-->'+this.email); */
            if (this.callingFromDepositSummary) {
                savelandlordDepositSummaryData({
                    receivedParams: paramStr,
                    depositId: this.depositid,
                    removeAllocationId: this.removeRecId
                }).then(result => {
                    if (result != null) {
                        if (result.duplicateLandlord) {
                            this.isAddLandlordSection = false;
                            this.isLoading = false;

                            // Calling parent using Event with data START
                            const myEvent = new CustomEvent('addlandlord', {
                                detail: result.duplicateLandlord
                            });

                            this.dispatchEvent(myEvent);
                            // Calling parent using Event with data END
                        } else if (result.landlordCreated) {
                            this.isSucceessmessage = true;
                            this.isLoading = false;
                            setTimeout(() => {
                                this.isAddLandlordSection = false;
                            }, 1000);

                            // Calling parent using Event with data START
                            const myEvent = new CustomEvent('addlandlord', {
                                detail: result.landlordCreated
                            });

                            this.dispatchEvent(myEvent);
                            // Calling parent using Event with data END

                        } else {
                            console.log('error occured--->' + result);
                            this.isErrorMsg = true;
                            this.isLoading = false;
                        }
                    } else {
                        console.log('Some error occured');
                        this.isErrorMsg = true;
                        this.isLoading = false;
                    }
                }).catch(error => {
                    console.log('Line 288 Error -> ', error);
                });
            } else {
                saveLandlordData({
                    receivedParams: paramStr
                }).then(result => {
                    if (result != null) {
                        if (result.duplicateLandlord) {
                            this.isAddLandlordSection = false;
                            this.isLoading = false;

                            // Calling parent using Event with data START
                            const myEvent = new CustomEvent('addlandlord', {
                                detail: result.duplicateLandlord
                            });

                            this.dispatchEvent(myEvent);
                            // Calling parent using Event with data END
                        } else if (result.landlordCreated) {
                            this.isSucceessmessage = true;
                            this.isLoading = false;
                            setTimeout(() => {
                                this.isAddLandlordSection = false;
                            }, 1000);

                            // Calling parent using Event with data START

                            const myEvent = new CustomEvent('addlandlord', {
                                detail: result.landlordCreated
                            });

                            this.dispatchEvent(myEvent);
                            // Calling parent using Event with data END
                        } else {
                            console.log('error occured--->' + result);
                            this.isErrorMsg = true;
                            this.isLoading = false;
                        }
                    } else {
                        console.log('Some error occured');
                        this.isErrorMsg = true;
                        this.isLoading = false;
                    }
                }).catch(error => {
                    console.log('Line 288 Error -> ', error);
                });
            }
        }
    }


    hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "landlordYesNoError":
                this.isLandlordYesNo = false;
                break;
            case "successmsg":
                this.isSucceessmessage = false;
                break;
            case "errorMsg":
                this.isErrorMsg = false;
                break;
            case "companyName":
                this.isCompanyNameError = false;
                break;
            case "companyPhone":
                this.isCompanyPhoneError = false;
                break;
            case "companyPhonelength":
                this.isCompanyPhonelengthError = false;
                break;
            case "title":
                this.isTitleError = false;
                break;
            case "firstName":
                this.isFirstNameError = false;
                break;
            case "surName":
                this.isSurNameError = false;
                break;
            case "emailOfUser":
                this.isEmailError = false;
                break;
            case "emailFormatErrorMsg":
                this.isEmailFormatError = false;
                break;
            case "mobileEmailError":
                this.isMobileEmailError = false;
                break;
            case "telephoneNumber":
                this.isTelephoneNumError = false;
                break;
            case "phonelength":
                this.isPhonelengthError = false;
                break;
            case "validAddress":
                this.isAddressValidError = false;
                break;
            case "addressNotOfNiErrorMsg":
                this.isAddressNotOfNiError = false;
                break;
            case "duplicateEmail":
                this.isDuplicateEmailError = false;
                break;

        }
    }
}